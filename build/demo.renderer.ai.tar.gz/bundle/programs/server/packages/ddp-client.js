Package["core-runtime"].queue("ddp-client",function () {/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var EmitterPromise = Package.meteor.EmitterPromise;
var check = Package.check.check;
var Match = Package.check.Match;
var Random = Package.random.Random;
var EJSON = Package.ejson.EJSON;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var Retry = Package.retry.Retry;
var IdMap = Package['id-map'].IdMap;
var ECMAScript = Package.ecmascript.ECMAScript;
var Hook = Package['callback-hook'].Hook;
var DDPCommon = Package['ddp-common'].DDPCommon;
var DiffSequence = Package['diff-sequence'].DiffSequence;
var MongoID = Package['mongo-id'].MongoID;
var meteorInstall = Package.modules.meteorInstall;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var options, callback, args, DDP;

var require = meteorInstall({"node_modules":{"meteor":{"ddp-client":{"server":{"server.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/ddp-client/server/server.js                                                                               //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
!module.wrapAsync(async function (module, __reifyWaitForDeps__, __reify_async_result__) {
  "use strict";
  try {
    module.link("../common/namespace.js", {
      DDP: "DDP"
    }, 0);
    if (__reifyWaitForDeps__()) (await __reifyWaitForDeps__())();
    __reify_async_result__();
  } catch (_reifyError) {
    return __reify_async_result__(_reifyError);
  }
  __reify_async_result__()
}, {
  self: this,
  async: false
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"common":{"MethodInvoker.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/ddp-client/common/MethodInvoker.js                                                                        //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({
  default: () => MethodInvoker
});
class MethodInvoker {
  constructor(options) {
    // Public (within this file) fields.
    this.methodId = options.methodId;
    this.sentMessage = false;
    this._callback = options.callback;
    this._connection = options.connection;
    this._message = options.message;
    this._onResultReceived = options.onResultReceived || (() => {});
    this._wait = options.wait;
    this.noRetry = options.noRetry;
    this._methodResult = null;
    this._dataVisible = false;

    // Register with the connection.
    this._connection._methodInvokers[this.methodId] = this;
  }
  // Sends the method message to the server. May be called additional times if
  // we lose the connection and reconnect before receiving a result.
  sendMessage() {
    // This function is called before sending a method (including resending on
    // reconnect). We should only (re)send methods where we don't already have a
    // result!
    if (this.gotResult()) throw new Error('sendingMethod is called on method with result');

    // If we're re-sending it, it doesn't matter if data was written the first
    // time.
    this._dataVisible = false;
    this.sentMessage = true;

    // If this is a wait method, make all data messages be buffered until it is
    // done.
    if (this._wait) this._connection._methodsBlockingQuiescence[this.methodId] = true;

    // Actually send the message.
    this._connection._send(this._message);
  }
  // Invoke the callback, if we have both a result and know that all data has
  // been written to the local cache.
  _maybeInvokeCallback() {
    if (this._methodResult && this._dataVisible) {
      // Call the callback. (This won't throw: the callback was wrapped with
      // bindEnvironment.)
      this._callback(this._methodResult[0], this._methodResult[1]);

      // Forget about this method.
      delete this._connection._methodInvokers[this.methodId];

      // Let the connection know that this method is finished, so it can try to
      // move on to the next block of methods.
      this._connection._outstandingMethodFinished();
    }
  }
  // Call with the result of the method from the server. Only may be called
  // once; once it is called, you should not call sendMessage again.
  // If the user provided an onResultReceived callback, call it immediately.
  // Then invoke the main callback if data is also visible.
  receiveResult(err, result) {
    if (this.gotResult()) throw new Error('Methods should only receive results once');
    this._methodResult = [err, result];
    this._onResultReceived(err, result);
    this._maybeInvokeCallback();
  }
  // Call this when all data written by the method is visible. This means that
  // the method has returns its "data is done" message *AND* all server
  // documents that are buffered at that time have been written to the local
  // cache. Invokes the main callback if the result has been received.
  dataVisible() {
    this._dataVisible = true;
    this._maybeInvokeCallback();
  }
  // True if receiveResult has been called.
  gotResult() {
    return !!this._methodResult;
  }
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"livedata_connection.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/ddp-client/common/livedata_connection.js                                                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
!module.wrapAsync(async function (module, __reifyWaitForDeps__, __reify_async_result__) {
  "use strict";
  try {
    let _objectWithoutProperties;
    module.link("@babel/runtime/helpers/objectWithoutProperties", {
      default(v) {
        _objectWithoutProperties = v;
      }
    }, 0);
    let _objectSpread;
    module.link("@babel/runtime/helpers/objectSpread2", {
      default(v) {
        _objectSpread = v;
      }
    }, 1);
    const _excluded = ["stubInvocation", "invocation"],
      _excluded2 = ["stubInvocation", "invocation"];
    module.export({
      Connection: () => Connection
    });
    let Meteor;
    module.link("meteor/meteor", {
      Meteor(v) {
        Meteor = v;
      }
    }, 0);
    let DDPCommon;
    module.link("meteor/ddp-common", {
      DDPCommon(v) {
        DDPCommon = v;
      }
    }, 1);
    let Tracker;
    module.link("meteor/tracker", {
      Tracker(v) {
        Tracker = v;
      }
    }, 2);
    let EJSON;
    module.link("meteor/ejson", {
      EJSON(v) {
        EJSON = v;
      }
    }, 3);
    let Random;
    module.link("meteor/random", {
      Random(v) {
        Random = v;
      }
    }, 4);
    let Hook;
    module.link("meteor/callback-hook", {
      Hook(v) {
        Hook = v;
      }
    }, 5);
    let MongoID;
    module.link("meteor/mongo-id", {
      MongoID(v) {
        MongoID = v;
      }
    }, 6);
    let DDP;
    module.link("./namespace.js", {
      DDP(v) {
        DDP = v;
      }
    }, 7);
    let MethodInvoker;
    module.link("./MethodInvoker.js", {
      default(v) {
        MethodInvoker = v;
      }
    }, 8);
    let hasOwn, slice, keys, isEmpty, last;
    module.link("meteor/ddp-common/utils.js", {
      hasOwn(v) {
        hasOwn = v;
      },
      slice(v) {
        slice = v;
      },
      keys(v) {
        keys = v;
      },
      isEmpty(v) {
        isEmpty = v;
      },
      last(v) {
        last = v;
      }
    }, 9);
    if (__reifyWaitForDeps__()) (await __reifyWaitForDeps__())();
    class MongoIDMap extends IdMap {
      constructor() {
        super(MongoID.idStringify, MongoID.idParse);
      }
    }

    // @param url {String|Object} URL to Meteor app,
    //   or an object as a test hook (see code)
    // Options:
    //   reloadWithOutstanding: is it OK to reload if there are outstanding methods?
    //   headers: extra headers to send on the websockets connection, for
    //     server-to-server DDP only
    //   _sockjsOptions: Specifies options to pass through to the sockjs client
    //   onDDPNegotiationVersionFailure: callback when version negotiation fails.
    //
    // XXX There should be a way to destroy a DDP connection, causing all
    // outstanding method calls to fail.
    //
    // XXX Our current way of handling failure and reconnection is great
    // for an app (where we want to tolerate being disconnected as an
    // expect state, and keep trying forever to reconnect) but cumbersome
    // for something like a command line tool that wants to make a
    // connection, call a method, and print an error if connection
    // fails. We should have better usability in the latter case (while
    // still transparently reconnecting if it's just a transient failure
    // or the server migrating us).
    class Connection {
      constructor(url, options) {
        const self = this;
        this.options = options = _objectSpread({
          onConnected() {},
          onDDPVersionNegotiationFailure(description) {
            Meteor._debug(description);
          },
          heartbeatInterval: 17500,
          heartbeatTimeout: 15000,
          npmFayeOptions: Object.create(null),
          // These options are only for testing.
          reloadWithOutstanding: false,
          supportedDDPVersions: DDPCommon.SUPPORTED_DDP_VERSIONS,
          retry: true,
          respondToPings: true,
          // When updates are coming within this ms interval, batch them together.
          bufferedWritesInterval: 5,
          // Flush buffers immediately if writes are happening continuously for more than this many ms.
          bufferedWritesMaxAge: 500
        }, options);

        // If set, called when we reconnect, queuing method calls _before_ the
        // existing outstanding ones.
        // NOTE: This feature has been preserved for backwards compatibility. The
        // preferred method of setting a callback on reconnect is to use
        // DDP.onReconnect.
        self.onReconnect = null;

        // as a test hook, allow passing a stream instead of a url.
        if (typeof url === 'object') {
          self._stream = url;
        } else {
          const {
            ClientStream
          } = require("meteor/socket-stream-client");
          self._stream = new ClientStream(url, {
            retry: options.retry,
            ConnectionError: DDP.ConnectionError,
            headers: options.headers,
            _sockjsOptions: options._sockjsOptions,
            // Used to keep some tests quiet, or for other cases in which
            // the right thing to do with connection errors is to silently
            // fail (e.g. sending package usage stats). At some point we
            // should have a real API for handling client-stream-level
            // errors.
            _dontPrintErrors: options._dontPrintErrors,
            connectTimeoutMs: options.connectTimeoutMs,
            npmFayeOptions: options.npmFayeOptions
          });
        }
        self._lastSessionId = null;
        self._versionSuggestion = null; // The last proposed DDP version.
        self._version = null; // The DDP version agreed on by client and server.
        self._stores = Object.create(null); // name -> object with methods
        self._methodHandlers = Object.create(null); // name -> func
        self._nextMethodId = 1;
        self._supportedDDPVersions = options.supportedDDPVersions;
        self._heartbeatInterval = options.heartbeatInterval;
        self._heartbeatTimeout = options.heartbeatTimeout;

        // Tracks methods which the user has tried to call but which have not yet
        // called their user callback (ie, they are waiting on their result or for all
        // of their writes to be written to the local cache). Map from method ID to
        // MethodInvoker object.
        self._methodInvokers = Object.create(null);

        // Tracks methods which the user has called but whose result messages have not
        // arrived yet.
        //
        // _outstandingMethodBlocks is an array of blocks of methods. Each block
        // represents a set of methods that can run at the same time. The first block
        // represents the methods which are currently in flight; subsequent blocks
        // must wait for previous blocks to be fully finished before they can be sent
        // to the server.
        //
        // Each block is an object with the following fields:
        // - methods: a list of MethodInvoker objects
        // - wait: a boolean; if true, this block had a single method invoked with
        //         the "wait" option
        //
        // There will never be adjacent blocks with wait=false, because the only thing
        // that makes methods need to be serialized is a wait method.
        //
        // Methods are removed from the first block when their "result" is
        // received. The entire first block is only removed when all of the in-flight
        // methods have received their results (so the "methods" list is empty) *AND*
        // all of the data written by those methods are visible in the local cache. So
        // it is possible for the first block's methods list to be empty, if we are
        // still waiting for some objects to quiesce.
        //
        // Example:
        //  _outstandingMethodBlocks = [
        //    {wait: false, methods: []},
        //    {wait: true, methods: [<MethodInvoker for 'login'>]},
        //    {wait: false, methods: [<MethodInvoker for 'foo'>,
        //                            <MethodInvoker for 'bar'>]}]
        // This means that there were some methods which were sent to the server and
        // which have returned their results, but some of the data written by
        // the methods may not be visible in the local cache. Once all that data is
        // visible, we will send a 'login' method. Once the login method has returned
        // and all the data is visible (including re-running subs if userId changes),
        // we will send the 'foo' and 'bar' methods in parallel.
        self._outstandingMethodBlocks = [];

        // method ID -> array of objects with keys 'collection' and 'id', listing
        // documents written by a given method's stub. keys are associated with
        // methods whose stub wrote at least one document, and whose data-done message
        // has not yet been received.
        self._documentsWrittenByStub = {};
        // collection -> IdMap of "server document" object. A "server document" has:
        // - "document": the version of the document according the
        //   server (ie, the snapshot before a stub wrote it, amended by any changes
        //   received from the server)
        //   It is undefined if we think the document does not exist
        // - "writtenByStubs": a set of method IDs whose stubs wrote to the document
        //   whose "data done" messages have not yet been processed
        self._serverDocuments = {};

        // Array of callbacks to be called after the next update of the local
        // cache. Used for:
        //  - Calling methodInvoker.dataVisible and sub ready callbacks after
        //    the relevant data is flushed.
        //  - Invoking the callbacks of "half-finished" methods after reconnect
        //    quiescence. Specifically, methods whose result was received over the old
        //    connection (so we don't re-send it) but whose data had not been made
        //    visible.
        self._afterUpdateCallbacks = [];

        // In two contexts, we buffer all incoming data messages and then process them
        // all at once in a single update:
        //   - During reconnect, we buffer all data messages until all subs that had
        //     been ready before reconnect are ready again, and all methods that are
        //     active have returned their "data done message"; then
        //   - During the execution of a "wait" method, we buffer all data messages
        //     until the wait method gets its "data done" message. (If the wait method
        //     occurs during reconnect, it doesn't get any special handling.)
        // all data messages are processed in one update.
        //
        // The following fields are used for this "quiescence" process.

        // This buffers the messages that aren't being processed yet.
        self._messagesBufferedUntilQuiescence = [];
        // Map from method ID -> true. Methods are removed from this when their
        // "data done" message is received, and we will not quiesce until it is
        // empty.
        self._methodsBlockingQuiescence = {};
        // map from sub ID -> true for subs that were ready (ie, called the sub
        // ready callback) before reconnect but haven't become ready again yet
        self._subsBeingRevived = {}; // map from sub._id -> true
        // if true, the next data update should reset all stores. (set during
        // reconnect.)
        self._resetStores = false;

        // name -> array of updates for (yet to be created) collections
        self._updatesForUnknownStores = {};
        // if we're blocking a migration, the retry func
        self._retryMigrate = null;
        self.__flushBufferedWrites = Meteor.bindEnvironment(self._flushBufferedWrites, 'flushing DDP buffered writes', self);
        // Collection name -> array of messages.
        self._bufferedWrites = {};
        // When current buffer of updates must be flushed at, in ms timestamp.
        self._bufferedWritesFlushAt = null;
        // Timeout handle for the next processing of all pending writes
        self._bufferedWritesFlushHandle = null;
        self._bufferedWritesInterval = options.bufferedWritesInterval;
        self._bufferedWritesMaxAge = options.bufferedWritesMaxAge;

        // metadata for subscriptions.  Map from sub ID to object with keys:
        //   - id
        //   - name
        //   - params
        //   - inactive (if true, will be cleaned up if not reused in re-run)
        //   - ready (has the 'ready' message been received?)
        //   - readyCallback (an optional callback to call when ready)
        //   - errorCallback (an optional callback to call if the sub terminates with
        //                    an error, XXX COMPAT WITH 1.0.3.1)
        //   - stopCallback (an optional callback to call when the sub terminates
        //     for any reason, with an error argument if an error triggered the stop)
        self._subscriptions = {};

        // Reactive userId.
        self._userId = null;
        self._userIdDeps = new Tracker.Dependency();

        // Block auto-reload while we're waiting for method responses.
        if (Meteor.isClient && Package.reload && !options.reloadWithOutstanding) {
          Package.reload.Reload._onMigrate(retry => {
            if (!self._readyToMigrate()) {
              self._retryMigrate = retry;
              return [false];
            } else {
              return [true];
            }
          });
        }
        const onDisconnect = () => {
          if (self._heartbeat) {
            self._heartbeat.stop();
            self._heartbeat = null;
          }
        };
        if (Meteor.isServer) {
          self._stream.on('message', Meteor.bindEnvironment(this.onMessage.bind(this), 'handling DDP message'));
          self._stream.on('reset', Meteor.bindEnvironment(this.onReset.bind(this), 'handling DDP reset'));
          self._stream.on('disconnect', Meteor.bindEnvironment(onDisconnect, 'handling DDP disconnect'));
        } else {
          self._stream.on('message', this.onMessage.bind(this));
          self._stream.on('reset', this.onReset.bind(this));
          self._stream.on('disconnect', onDisconnect);
        }
      }

      // 'name' is the name of the data on the wire that should go in the
      // store. 'wrappedStore' should be an object with methods beginUpdate, update,
      // endUpdate, saveOriginals, retrieveOriginals. see Collection for an example.
      createStoreMethods(name, wrappedStore) {
        const self = this;
        if (name in self._stores) return false;

        // Wrap the input object in an object which makes any store method not
        // implemented by 'store' into a no-op.
        const store = Object.create(null);
        const keysOfStore = ['update', 'beginUpdate', 'endUpdate', 'saveOriginals', 'retrieveOriginals', 'getDoc', '_getCollection'];
        keysOfStore.forEach(method => {
          store[method] = function () {
            if (wrappedStore[method]) {
              return wrappedStore[method](...arguments);
            }
          };
        });
        self._stores[name] = store;
        return store;
      }
      registerStoreClient(name, wrappedStore) {
        const self = this;
        const store = self.createStoreMethods(name, wrappedStore);
        const queued = self._updatesForUnknownStores[name];
        if (Array.isArray(queued)) {
          store.beginUpdate(queued.length, false);
          queued.forEach(msg => {
            store.update(msg);
          });
          store.endUpdate();
          delete self._updatesForUnknownStores[name];
        }
        return true;
      }
      async registerStoreServer(name, wrappedStore) {
        const self = this;
        const store = self.createStoreMethods(name, wrappedStore);
        const queued = self._updatesForUnknownStores[name];
        if (Array.isArray(queued)) {
          await store.beginUpdate(queued.length, false);
          for (const msg of queued) {
            await store.update(msg);
          }
          await store.endUpdate();
          delete self._updatesForUnknownStores[name];
        }
        return true;
      }

      /**
       * @memberOf Meteor
       * @importFromPackage meteor
       * @alias Meteor.subscribe
       * @summary Subscribe to a record set.  Returns a handle that provides
       * `stop()` and `ready()` methods.
       * @locus Client
       * @param {String} name Name of the subscription.  Matches the name of the
       * server's `publish()` call.
       * @param {EJSONable} [arg1,arg2...] Optional arguments passed to publisher
       * function on server.
       * @param {Function|Object} [callbacks] Optional. May include `onStop`
       * and `onReady` callbacks. If there is an error, it is passed as an
       * argument to `onStop`. If a function is passed instead of an object, it
       * is interpreted as an `onReady` callback.
       */
      subscribe(name /* .. [arguments] .. (callback|callbacks) */) {
        const self = this;
        const params = slice.call(arguments, 1);
        let callbacks = Object.create(null);
        if (params.length) {
          const lastParam = params[params.length - 1];
          if (typeof lastParam === 'function') {
            callbacks.onReady = params.pop();
          } else if (lastParam && [lastParam.onReady,
          // XXX COMPAT WITH 1.0.3.1 onError used to exist, but now we use
          // onStop with an error callback instead.
          lastParam.onError, lastParam.onStop].some(f => typeof f === "function")) {
            callbacks = params.pop();
          }
        }

        // Is there an existing sub with the same name and param, run in an
        // invalidated Computation? This will happen if we are rerunning an
        // existing computation.
        //
        // For example, consider a rerun of:
        //
        //     Tracker.autorun(function () {
        //       Meteor.subscribe("foo", Session.get("foo"));
        //       Meteor.subscribe("bar", Session.get("bar"));
        //     });
        //
        // If "foo" has changed but "bar" has not, we will match the "bar"
        // subcribe to an existing inactive subscription in order to not
        // unsub and resub the subscription unnecessarily.
        //
        // We only look for one such sub; if there are N apparently-identical subs
        // being invalidated, we will require N matching subscribe calls to keep
        // them all active.
        const existing = Object.values(self._subscriptions).find(sub => sub.inactive && sub.name === name && EJSON.equals(sub.params, params));
        let id;
        if (existing) {
          id = existing.id;
          existing.inactive = false; // reactivate

          if (callbacks.onReady) {
            // If the sub is not already ready, replace any ready callback with the
            // one provided now. (It's not really clear what users would expect for
            // an onReady callback inside an autorun; the semantics we provide is
            // that at the time the sub first becomes ready, we call the last
            // onReady callback provided, if any.)
            // If the sub is already ready, run the ready callback right away.
            // It seems that users would expect an onReady callback inside an
            // autorun to trigger once the sub first becomes ready and also
            // when re-subs happens.
            if (existing.ready) {
              callbacks.onReady();
            } else {
              existing.readyCallback = callbacks.onReady;
            }
          }

          // XXX COMPAT WITH 1.0.3.1 we used to have onError but now we call
          // onStop with an optional error argument
          if (callbacks.onError) {
            // Replace existing callback if any, so that errors aren't
            // double-reported.
            existing.errorCallback = callbacks.onError;
          }
          if (callbacks.onStop) {
            existing.stopCallback = callbacks.onStop;
          }
        } else {
          // New sub! Generate an id, save it locally, and send message.
          id = Random.id();
          self._subscriptions[id] = {
            id: id,
            name: name,
            params: EJSON.clone(params),
            inactive: false,
            ready: false,
            readyDeps: new Tracker.Dependency(),
            readyCallback: callbacks.onReady,
            // XXX COMPAT WITH 1.0.3.1 #errorCallback
            errorCallback: callbacks.onError,
            stopCallback: callbacks.onStop,
            connection: self,
            remove() {
              delete this.connection._subscriptions[this.id];
              this.ready && this.readyDeps.changed();
            },
            stop() {
              this.connection._sendQueued({
                msg: 'unsub',
                id: id
              });
              this.remove();
              if (callbacks.onStop) {
                callbacks.onStop();
              }
            }
          };
          self._send({
            msg: 'sub',
            id: id,
            name: name,
            params: params
          });
        }

        // return a handle to the application.
        const handle = {
          stop() {
            if (!hasOwn.call(self._subscriptions, id)) {
              return;
            }
            self._subscriptions[id].stop();
          },
          ready() {
            // return false if we've unsubscribed.
            if (!hasOwn.call(self._subscriptions, id)) {
              return false;
            }
            const record = self._subscriptions[id];
            record.readyDeps.depend();
            return record.ready;
          },
          subscriptionId: id
        };
        if (Tracker.active) {
          // We're in a reactive computation, so we'd like to unsubscribe when the
          // computation is invalidated... but not if the rerun just re-subscribes
          // to the same subscription!  When a rerun happens, we use onInvalidate
          // as a change to mark the subscription "inactive" so that it can
          // be reused from the rerun.  If it isn't reused, it's killed from
          // an afterFlush.
          Tracker.onInvalidate(c => {
            if (hasOwn.call(self._subscriptions, id)) {
              self._subscriptions[id].inactive = true;
            }
            Tracker.afterFlush(() => {
              if (hasOwn.call(self._subscriptions, id) && self._subscriptions[id].inactive) {
                handle.stop();
              }
            });
          });
        }
        return handle;
      }

      /**
       * @summary Tells if the method call came from a call or a callAsync.
       * @alias Meteor.isAsyncCall
       * @locus Anywhere
       * @memberOf Meteor
       * @importFromPackage meteor
       * @returns boolean
       */
      isAsyncCall() {
        return DDP._CurrentMethodInvocation._isCallAsyncMethodRunning();
      }
      methods(methods) {
        Object.entries(methods).forEach(_ref => {
          let [name, func] = _ref;
          if (typeof func !== 'function') {
            throw new Error("Method '" + name + "' must be a function");
          }
          if (this._methodHandlers[name]) {
            throw new Error("A method named '" + name + "' is already defined");
          }
          this._methodHandlers[name] = func;
        });
      }
      _getIsSimulation(_ref2) {
        let {
          isFromCallAsync,
          alreadyInSimulation
        } = _ref2;
        if (!isFromCallAsync) {
          return alreadyInSimulation;
        }
        return alreadyInSimulation && DDP._CurrentMethodInvocation._isCallAsyncMethodRunning();
      }

      /**
       * @memberOf Meteor
       * @importFromPackage meteor
       * @alias Meteor.call
       * @summary Invokes a method with a sync stub, passing any number of arguments.
       * @locus Anywhere
       * @param {String} name Name of method to invoke
       * @param {EJSONable} [arg1,arg2...] Optional method arguments
       * @param {Function} [asyncCallback] Optional callback, which is called asynchronously with the error or result after the method is complete. If not provided, the method runs synchronously if possible (see below).
       */
      call(name /* .. [arguments] .. callback */) {
        // if it's a function, the last argument is the result callback,
        // not a parameter to the remote method.
        const args = slice.call(arguments, 1);
        let callback;
        if (args.length && typeof args[args.length - 1] === 'function') {
          callback = args.pop();
        }
        return this.apply(name, args, callback);
      }
      /**
       * @memberOf Meteor
       * @importFromPackage meteor
       * @alias Meteor.callAsync
       * @summary Invokes a method with an async stub, passing any number of arguments.
       * @locus Anywhere
       * @param {String} name Name of method to invoke
       * @param {EJSONable} [arg1,arg2...] Optional method arguments
       * @returns {Promise}
       */
      callAsync(name /* .. [arguments] .. */) {
        const args = slice.call(arguments, 1);
        if (args.length && typeof args[args.length - 1] === 'function') {
          throw new Error("Meteor.callAsync() does not accept a callback. You should 'await' the result, or use .then().");
        }
        return this.applyAsync(name, args, {
          returnServerResultPromise: true
        });
      }

      /**
       * @memberOf Meteor
       * @importFromPackage meteor
       * @alias Meteor.apply
       * @summary Invoke a method passing an array of arguments.
       * @locus Anywhere
       * @param {String} name Name of method to invoke
       * @param {EJSONable[]} args Method arguments
       * @param {Object} [options]
       * @param {Boolean} options.wait (Client only) If true, don't send this method until all previous method calls have completed, and don't send any subsequent method calls until this one is completed.
       * @param {Function} options.onResultReceived (Client only) This callback is invoked with the error or result of the method (just like `asyncCallback`) as soon as the error or result is available. The local cache may not yet reflect the writes performed by the method.
       * @param {Boolean} options.noRetry (Client only) if true, don't send this method again on reload, simply call the callback an error with the error code 'invocation-failed'.
       * @param {Boolean} options.throwStubExceptions (Client only) If true, exceptions thrown by method stubs will be thrown instead of logged, and the method will not be invoked on the server.
       * @param {Boolean} options.returnStubValue (Client only) If true then in cases where we would have otherwise discarded the stub's return value and returned undefined, instead we go ahead and return it. Specifically, this is any time other than when (a) we are already inside a stub or (b) we are in Node and no callback was provided. Currently we require this flag to be explicitly passed to reduce the likelihood that stub return values will be confused with server return values; we may improve this in future.
       * @param {Function} [asyncCallback] Optional callback; same semantics as in [`Meteor.call`](#meteor_call).
       */
      apply(name, args, options, callback) {
        const _this$_stubCall = this._stubCall(name, EJSON.clone(args)),
          {
            stubInvocation,
            invocation
          } = _this$_stubCall,
          stubOptions = _objectWithoutProperties(_this$_stubCall, _excluded);
        if (stubOptions.hasStub) {
          if (!this._getIsSimulation({
            alreadyInSimulation: stubOptions.alreadyInSimulation,
            isFromCallAsync: stubOptions.isFromCallAsync
          })) {
            this._saveOriginals();
          }
          try {
            stubOptions.stubReturnValue = DDP._CurrentMethodInvocation.withValue(invocation, stubInvocation);
            if (Meteor._isPromise(stubOptions.stubReturnValue)) {
              Meteor._debug("Method ".concat(name, ": Calling a method that has an async method stub with call/apply can lead to unexpected behaviors. Use callAsync/applyAsync instead."));
            }
          } catch (e) {
            stubOptions.exception = e;
          }
        }
        return this._apply(name, stubOptions, args, options, callback);
      }

      /**
       * @memberOf Meteor
       * @importFromPackage meteor
       * @alias Meteor.applyAsync
       * @summary Invoke a method passing an array of arguments.
       * @locus Anywhere
       * @param {String} name Name of method to invoke
       * @param {EJSONable[]} args Method arguments
       * @param {Object} [options]
       * @param {Boolean} options.wait (Client only) If true, don't send this method until all previous method calls have completed, and don't send any subsequent method calls until this one is completed.
       * @param {Function} options.onResultReceived (Client only) This callback is invoked with the error or result of the method (just like `asyncCallback`) as soon as the error or result is available. The local cache may not yet reflect the writes performed by the method.
       * @param {Boolean} options.noRetry (Client only) if true, don't send this method again on reload, simply call the callback an error with the error code 'invocation-failed'.
       * @param {Boolean} options.throwStubExceptions (Client only) If true, exceptions thrown by method stubs will be thrown instead of logged, and the method will not be invoked on the server.
       * @param {Boolean} options.returnStubValue (Client only) If true then in cases where we would have otherwise discarded the stub's return value and returned undefined, instead we go ahead and return it. Specifically, this is any time other than when (a) we are already inside a stub or (b) we are in Node and no callback was provided. Currently we require this flag to be explicitly passed to reduce the likelihood that stub return values will be confused with server return values; we may improve this in future.
       */
      applyAsync(name, args, options) {
        let callback = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : null;
        const stubPromise = this._applyAsyncStubInvocation(name, args, options);
        const promise = this._applyAsync({
          name,
          args,
          options,
          callback,
          stubPromise
        });
        if (Meteor.isClient) {
          // only return the stubReturnValue
          promise.stubPromise = stubPromise.then(o => {
            if (o.exception) {
              throw o.exception;
            }
            return o.stubReturnValue;
          });
          // this avoids attribute recursion
          promise.serverPromise = new Promise((resolve, reject) => promise.then(resolve).catch(reject));
        }
        return promise;
      }
      async _applyAsyncStubInvocation(name, args, options) {
        const _this$_stubCall2 = this._stubCall(name, EJSON.clone(args), options),
          {
            stubInvocation,
            invocation
          } = _this$_stubCall2,
          stubOptions = _objectWithoutProperties(_this$_stubCall2, _excluded2);
        if (stubOptions.hasStub) {
          if (!this._getIsSimulation({
            alreadyInSimulation: stubOptions.alreadyInSimulation,
            isFromCallAsync: stubOptions.isFromCallAsync
          })) {
            this._saveOriginals();
          }
          try {
            /*
             * The code below follows the same logic as the function withValues().
             *
             * But as the Meteor package is not compiled by ecmascript, it is unable to use newer syntax in the browser,
             * such as, the async/await.
             *
             * So, to keep supporting old browsers, like IE 11, we're creating the logic one level above.
             */
            const currentContext = DDP._CurrentMethodInvocation._setNewContextAndGetCurrent(invocation);
            try {
              stubOptions.stubReturnValue = await stubInvocation();
            } catch (e) {
              stubOptions.exception = e;
            } finally {
              DDP._CurrentMethodInvocation._set(currentContext);
            }
          } catch (e) {
            stubOptions.exception = e;
          }
        }
        return stubOptions;
      }
      async _applyAsync(_ref3) {
        let {
          name,
          args,
          options,
          callback,
          stubPromise
        } = _ref3;
        const stubOptions = await stubPromise;
        return this._apply(name, stubOptions, args, options, callback);
      }
      _apply(name, stubCallValue, args, options, callback) {
        const self = this;
        // We were passed 3 arguments. They may be either (name, args, options)
        // or (name, args, callback)
        if (!callback && typeof options === 'function') {
          callback = options;
          options = Object.create(null);
        }
        options = options || Object.create(null);
        if (callback) {
          // XXX would it be better form to do the binding in stream.on,
          // or caller, instead of here?
          // XXX improve error message (and how we report it)
          callback = Meteor.bindEnvironment(callback, "delivering result of invoking '" + name + "'");
        }
        const {
          hasStub,
          exception,
          stubReturnValue,
          alreadyInSimulation,
          randomSeed
        } = stubCallValue;

        // Keep our args safe from mutation (eg if we don't send the message for a
        // while because of a wait method).
        args = EJSON.clone(args);
        // If we're in a simulation, stop and return the result we have,
        // rather than going on to do an RPC. If there was no stub,
        // we'll end up returning undefined.
        if (this._getIsSimulation({
          alreadyInSimulation,
          isFromCallAsync: stubCallValue.isFromCallAsync
        })) {
          if (callback) {
            callback(exception, stubReturnValue);
            return undefined;
          }
          if (exception) throw exception;
          return stubReturnValue;
        }

        // We only create the methodId here because we don't actually need one if
        // we're already in a simulation
        const methodId = '' + self._nextMethodId++;
        if (hasStub) {
          self._retrieveAndStoreOriginals(methodId);
        }

        // Generate the DDP message for the method call. Note that on the client,
        // it is important that the stub have finished before we send the RPC, so
        // that we know we have a complete list of which local documents the stub
        // wrote.
        const message = {
          msg: 'method',
          id: methodId,
          method: name,
          params: args
        };

        // If an exception occurred in a stub, and we're ignoring it
        // because we're doing an RPC and want to use what the server
        // returns instead, log it so the developer knows
        // (unless they explicitly ask to see the error).
        //
        // Tests can set the '_expectedByTest' flag on an exception so it won't
        // go to log.
        if (exception) {
          if (options.throwStubExceptions) {
            throw exception;
          } else if (!exception._expectedByTest) {
            Meteor._debug("Exception while simulating the effect of invoking '" + name + "'", exception);
          }
        }

        // At this point we're definitely doing an RPC, and we're going to
        // return the value of the RPC to the caller.

        // If the caller didn't give a callback, decide what to do.
        let future;
        if (!callback) {
          if (Meteor.isClient && !options.returnServerResultPromise && (!options.isFromCallAsync || options.returnStubValue)) {
            // On the client, we don't have fibers, so we can't block. The
            // only thing we can do is to return undefined and discard the
            // result of the RPC. If an error occurred then print the error
            // to the console.
            callback = err => {
              err && Meteor._debug("Error invoking Method '" + name + "'", err);
            };
          } else {
            // On the server, make the function synchronous. Throw on
            // errors, return on success.
            future = new Promise((resolve, reject) => {
              callback = function () {
                for (var _len = arguments.length, allArgs = new Array(_len), _key = 0; _key < _len; _key++) {
                  allArgs[_key] = arguments[_key];
                }
                let args = Array.from(allArgs);
                let err = args.shift();
                if (err) {
                  reject(err);
                  return;
                }
                resolve(...args);
              };
            });
          }
        }

        // Send the randomSeed only if we used it
        if (randomSeed.value !== null) {
          message.randomSeed = randomSeed.value;
        }
        const methodInvoker = new MethodInvoker({
          methodId,
          callback: callback,
          connection: self,
          onResultReceived: options.onResultReceived,
          wait: !!options.wait,
          message: message,
          noRetry: !!options.noRetry
        });
        if (options.wait) {
          // It's a wait method! Wait methods go in their own block.
          self._outstandingMethodBlocks.push({
            wait: true,
            methods: [methodInvoker]
          });
        } else {
          // Not a wait method. Start a new block if the previous block was a wait
          // block, and add it to the last block of methods.
          if (isEmpty(self._outstandingMethodBlocks) || last(self._outstandingMethodBlocks).wait) {
            self._outstandingMethodBlocks.push({
              wait: false,
              methods: []
            });
          }
          last(self._outstandingMethodBlocks).methods.push(methodInvoker);
        }

        // If we added it to the first block, send it out now.
        if (self._outstandingMethodBlocks.length === 1) methodInvoker.sendMessage();

        // If we're using the default callback on the server,
        // block waiting for the result.
        if (future) {
          // This is the result of the method ran in the client.
          // You can opt-in in getting the local result by running:
          // const { stubPromise, serverPromise } = Meteor.callAsync(...);
          // const whatServerDid = await serverPromise;
          if (options.returnStubValue) {
            return future.then(() => stubReturnValue);
          }
          return future;
        }
        return options.returnStubValue ? stubReturnValue : undefined;
      }
      _stubCall(name, args, options) {
        // Run the stub, if we have one. The stub is supposed to make some
        // temporary writes to the database to give the user a smooth experience
        // until the actual result of executing the method comes back from the
        // server (whereupon the temporary writes to the database will be reversed
        // during the beginUpdate/endUpdate process.)
        //
        // Normally, we ignore the return value of the stub (even if it is an
        // exception), in favor of the real return value from the server. The
        // exception is if the *caller* is a stub. In that case, we're not going
        // to do a RPC, so we use the return value of the stub as our return
        // value.
        const self = this;
        const enclosing = DDP._CurrentMethodInvocation.get();
        const stub = self._methodHandlers[name];
        const alreadyInSimulation = enclosing === null || enclosing === void 0 ? void 0 : enclosing.isSimulation;
        const isFromCallAsync = enclosing === null || enclosing === void 0 ? void 0 : enclosing._isFromCallAsync;
        const randomSeed = {
          value: null
        };
        const defaultReturn = {
          alreadyInSimulation,
          randomSeed,
          isFromCallAsync
        };
        if (!stub) {
          return _objectSpread(_objectSpread({}, defaultReturn), {}, {
            hasStub: false
          });
        }

        // Lazily generate a randomSeed, only if it is requested by the stub.
        // The random streams only have utility if they're used on both the client
        // and the server; if the client doesn't generate any 'random' values
        // then we don't expect the server to generate any either.
        // Less commonly, the server may perform different actions from the client,
        // and may in fact generate values where the client did not, but we don't
        // have any client-side values to match, so even here we may as well just
        // use a random seed on the server.  In that case, we don't pass the
        // randomSeed to save bandwidth, and we don't even generate it to save a
        // bit of CPU and to avoid consuming entropy.

        const randomSeedGenerator = () => {
          if (randomSeed.value === null) {
            randomSeed.value = DDPCommon.makeRpcSeed(enclosing, name);
          }
          return randomSeed.value;
        };
        const setUserId = userId => {
          self.setUserId(userId);
        };
        const invocation = new DDPCommon.MethodInvocation({
          name,
          isSimulation: true,
          userId: self.userId(),
          isFromCallAsync: options === null || options === void 0 ? void 0 : options.isFromCallAsync,
          setUserId: setUserId,
          randomSeed() {
            return randomSeedGenerator();
          }
        });

        // Note that unlike in the corresponding server code, we never audit
        // that stubs check() their arguments.
        const stubInvocation = () => {
          if (Meteor.isServer) {
            // Because saveOriginals and retrieveOriginals aren't reentrant,
            // don't allow stubs to yield.
            return Meteor._noYieldsAllowed(() => {
              // re-clone, so that the stub can't affect our caller's values
              return stub.apply(invocation, EJSON.clone(args));
            });
          } else {
            return stub.apply(invocation, EJSON.clone(args));
          }
        };
        return _objectSpread(_objectSpread({}, defaultReturn), {}, {
          hasStub: true,
          stubInvocation,
          invocation
        });
      }

      // Before calling a method stub, prepare all stores to track changes and allow
      // _retrieveAndStoreOriginals to get the original versions of changed
      // documents.
      _saveOriginals() {
        if (!this._waitingForQuiescence()) {
          this._flushBufferedWritesClient();
        }
        Object.values(this._stores).forEach(store => {
          store.saveOriginals();
        });
      }

      // Retrieves the original versions of all documents modified by the stub for
      // method 'methodId' from all stores and saves them to _serverDocuments (keyed
      // by document) and _documentsWrittenByStub (keyed by method ID).
      _retrieveAndStoreOriginals(methodId) {
        const self = this;
        if (self._documentsWrittenByStub[methodId]) throw new Error('Duplicate methodId in _retrieveAndStoreOriginals');
        const docsWritten = [];
        Object.entries(self._stores).forEach(_ref4 => {
          let [collection, store] = _ref4;
          const originals = store.retrieveOriginals();
          // not all stores define retrieveOriginals
          if (!originals) return;
          originals.forEach((doc, id) => {
            docsWritten.push({
              collection,
              id
            });
            if (!hasOwn.call(self._serverDocuments, collection)) {
              self._serverDocuments[collection] = new MongoIDMap();
            }
            const serverDoc = self._serverDocuments[collection].setDefault(id, Object.create(null));
            if (serverDoc.writtenByStubs) {
              // We're not the first stub to write this doc. Just add our method ID
              // to the record.
              serverDoc.writtenByStubs[methodId] = true;
            } else {
              // First stub! Save the original value and our method ID.
              serverDoc.document = doc;
              serverDoc.flushCallbacks = [];
              serverDoc.writtenByStubs = Object.create(null);
              serverDoc.writtenByStubs[methodId] = true;
            }
          });
        });
        if (!isEmpty(docsWritten)) {
          self._documentsWrittenByStub[methodId] = docsWritten;
        }
      }

      // This is very much a private function we use to make the tests
      // take up fewer server resources after they complete.
      _unsubscribeAll() {
        Object.values(this._subscriptions).forEach(sub => {
          // Avoid killing the autoupdate subscription so that developers
          // still get hot code pushes when writing tests.
          //
          // XXX it's a hack to encode knowledge about autoupdate here,
          // but it doesn't seem worth it yet to have a special API for
          // subscriptions to preserve after unit tests.
          if (sub.name !== 'meteor_autoupdate_clientVersions') {
            sub.stop();
          }
        });
      }

      // Sends the DDP stringification of the given message object
      _send(obj) {
        this._stream.send(DDPCommon.stringifyDDP(obj));
      }

      // Always queues the call before sending the message
      // Used, for example, on subscription.[id].stop() to make sure a "sub" message is always called before an "unsub" message
      // https://github.com/meteor/meteor/issues/13212
      //
      // This is part of the actual fix for the rest check:
      // https://github.com/meteor/meteor/pull/13236
      _sendQueued(obj) {
        this._send(obj, true);
      }

      // We detected via DDP-level heartbeats that we've lost the
      // connection.  Unlike `disconnect` or `close`, a lost connection
      // will be automatically retried.
      _lostConnection(error) {
        this._stream._lostConnection(error);
      }

      /**
       * @memberOf Meteor
       * @importFromPackage meteor
       * @alias Meteor.status
       * @summary Get the current connection status. A reactive data source.
       * @locus Client
       */
      status() {
        return this._stream.status(...arguments);
      }

      /**
       * @summary Force an immediate reconnection attempt if the client is not connected to the server.
       This method does nothing if the client is already connected.
       * @memberOf Meteor
       * @importFromPackage meteor
       * @alias Meteor.reconnect
       * @locus Client
       */
      reconnect() {
        return this._stream.reconnect(...arguments);
      }

      /**
       * @memberOf Meteor
       * @importFromPackage meteor
       * @alias Meteor.disconnect
       * @summary Disconnect the client from the server.
       * @locus Client
       */
      disconnect() {
        return this._stream.disconnect(...arguments);
      }
      close() {
        return this._stream.disconnect({
          _permanent: true
        });
      }

      ///
      /// Reactive user system
      ///
      userId() {
        if (this._userIdDeps) this._userIdDeps.depend();
        return this._userId;
      }
      setUserId(userId) {
        // Avoid invalidating dependents if setUserId is called with current value.
        if (this._userId === userId) return;
        this._userId = userId;
        if (this._userIdDeps) this._userIdDeps.changed();
      }

      // Returns true if we are in a state after reconnect of waiting for subs to be
      // revived or early methods to finish their data, or we are waiting for a
      // "wait" method to finish.
      _waitingForQuiescence() {
        return !isEmpty(this._subsBeingRevived) || !isEmpty(this._methodsBlockingQuiescence);
      }

      // Returns true if any method whose message has been sent to the server has
      // not yet invoked its user callback.
      _anyMethodsAreOutstanding() {
        const invokers = this._methodInvokers;
        return Object.values(invokers).some(invoker => !!invoker.sentMessage);
      }
      async _livedata_connected(msg) {
        const self = this;
        if (self._version !== 'pre1' && self._heartbeatInterval !== 0) {
          self._heartbeat = new DDPCommon.Heartbeat({
            heartbeatInterval: self._heartbeatInterval,
            heartbeatTimeout: self._heartbeatTimeout,
            onTimeout() {
              self._lostConnection(new DDP.ConnectionError('DDP heartbeat timed out'));
            },
            sendPing() {
              self._send({
                msg: 'ping'
              });
            }
          });
          self._heartbeat.start();
        }

        // If this is a reconnect, we'll have to reset all stores.
        if (self._lastSessionId) self._resetStores = true;
        let reconnectedToPreviousSession;
        if (typeof msg.session === 'string') {
          reconnectedToPreviousSession = self._lastSessionId === msg.session;
          self._lastSessionId = msg.session;
        }
        if (reconnectedToPreviousSession) {
          // Successful reconnection -- pick up where we left off.  Note that right
          // now, this never happens: the server never connects us to a previous
          // session, because DDP doesn't provide enough data for the server to know
          // what messages the client has processed. We need to improve DDP to make
          // this possible, at which point we'll probably need more code here.
          return;
        }

        // Server doesn't have our data any more. Re-sync a new session.

        // Forget about messages we were buffering for unknown collections. They'll
        // be resent if still relevant.
        self._updatesForUnknownStores = Object.create(null);
        if (self._resetStores) {
          // Forget about the effects of stubs. We'll be resetting all collections
          // anyway.
          self._documentsWrittenByStub = Object.create(null);
          self._serverDocuments = Object.create(null);
        }

        // Clear _afterUpdateCallbacks.
        self._afterUpdateCallbacks = [];

        // Mark all named subscriptions which are ready (ie, we already called the
        // ready callback) as needing to be revived.
        // XXX We should also block reconnect quiescence until unnamed subscriptions
        //     (eg, autopublish) are done re-publishing to avoid flicker!
        self._subsBeingRevived = Object.create(null);
        Object.entries(self._subscriptions).forEach(_ref5 => {
          let [id, sub] = _ref5;
          if (sub.ready) {
            self._subsBeingRevived[id] = true;
          }
        });

        // Arrange for "half-finished" methods to have their callbacks run, and
        // track methods that were sent on this connection so that we don't
        // quiesce until they are all done.
        //
        // Start by clearing _methodsBlockingQuiescence: methods sent before
        // reconnect don't matter, and any "wait" methods sent on the new connection
        // that we drop here will be restored by the loop below.
        self._methodsBlockingQuiescence = Object.create(null);
        if (self._resetStores) {
          const invokers = self._methodInvokers;
          keys(invokers).forEach(id => {
            const invoker = invokers[id];
            if (invoker.gotResult()) {
              // This method already got its result, but it didn't call its callback
              // because its data didn't become visible. We did not resend the
              // method RPC. We'll call its callback when we get a full quiesce,
              // since that's as close as we'll get to "data must be visible".
              self._afterUpdateCallbacks.push(function () {
                return invoker.dataVisible(...arguments);
              });
            } else if (invoker.sentMessage) {
              // This method has been sent on this connection (maybe as a resend
              // from the last connection, maybe from onReconnect, maybe just very
              // quickly before processing the connected message).
              //
              // We don't need to do anything special to ensure its callbacks get
              // called, but we'll count it as a method which is preventing
              // reconnect quiescence. (eg, it might be a login method that was run
              // from onReconnect, and we don't want to see flicker by seeing a
              // logged-out state.)
              self._methodsBlockingQuiescence[invoker.methodId] = true;
            }
          });
        }
        self._messagesBufferedUntilQuiescence = [];

        // If we're not waiting on any methods or subs, we can reset the stores and
        // call the callbacks immediately.
        if (!self._waitingForQuiescence()) {
          if (self._resetStores) {
            for (const store of Object.values(self._stores)) {
              await store.beginUpdate(0, true);
              await store.endUpdate();
            }
            self._resetStores = false;
          }
          self._runAfterUpdateCallbacks();
        }
      }
      async _processOneDataMessage(msg, updates) {
        const messageType = msg.msg;

        // msg is one of ['added', 'changed', 'removed', 'ready', 'updated']
        if (messageType === 'added') {
          await this._process_added(msg, updates);
        } else if (messageType === 'changed') {
          this._process_changed(msg, updates);
        } else if (messageType === 'removed') {
          this._process_removed(msg, updates);
        } else if (messageType === 'ready') {
          this._process_ready(msg, updates);
        } else if (messageType === 'updated') {
          this._process_updated(msg, updates);
        } else if (messageType === 'nosub') {
          // ignore this
        } else {
          Meteor._debug('discarding unknown livedata data message type', msg);
        }
      }
      async _livedata_data(msg) {
        const self = this;
        if (self._waitingForQuiescence()) {
          self._messagesBufferedUntilQuiescence.push(msg);
          if (msg.msg === 'nosub') {
            delete self._subsBeingRevived[msg.id];
          }
          if (msg.subs) {
            msg.subs.forEach(subId => {
              delete self._subsBeingRevived[subId];
            });
          }
          if (msg.methods) {
            msg.methods.forEach(methodId => {
              delete self._methodsBlockingQuiescence[methodId];
            });
          }
          if (self._waitingForQuiescence()) {
            return;
          }

          // No methods or subs are blocking quiescence!
          // We'll now process and all of our buffered messages, reset all stores,
          // and apply them all at once.

          const bufferedMessages = self._messagesBufferedUntilQuiescence;
          for (const bufferedMessage of Object.values(bufferedMessages)) {
            await self._processOneDataMessage(bufferedMessage, self._bufferedWrites);
          }
          self._messagesBufferedUntilQuiescence = [];
        } else {
          await self._processOneDataMessage(msg, self._bufferedWrites);
        }

        // Immediately flush writes when:
        //  1. Buffering is disabled. Or;
        //  2. any non-(added/changed/removed) message arrives.
        const standardWrite = msg.msg === "added" || msg.msg === "changed" || msg.msg === "removed";
        if (self._bufferedWritesInterval === 0 || !standardWrite) {
          await self._flushBufferedWrites();
          return;
        }
        if (self._bufferedWritesFlushAt === null) {
          self._bufferedWritesFlushAt = new Date().valueOf() + self._bufferedWritesMaxAge;
        } else if (self._bufferedWritesFlushAt < new Date().valueOf()) {
          await self._flushBufferedWrites();
          return;
        }
        if (self._bufferedWritesFlushHandle) {
          clearTimeout(self._bufferedWritesFlushHandle);
        }
        self._bufferedWritesFlushHandle = setTimeout(() => {
          // __flushBufferedWrites is a promise, so with this we can wait the promise to finish
          // before doing something
          self._liveDataWritesPromise = self.__flushBufferedWrites();
          if (Meteor._isPromise(self._liveDataWritesPromise)) {
            self._liveDataWritesPromise.finally(() => self._liveDataWritesPromise = undefined);
          }
        }, self._bufferedWritesInterval);
      }
      _prepareBuffersToFlush() {
        const self = this;
        if (self._bufferedWritesFlushHandle) {
          clearTimeout(self._bufferedWritesFlushHandle);
          self._bufferedWritesFlushHandle = null;
        }
        self._bufferedWritesFlushAt = null;
        // We need to clear the buffer before passing it to
        //  performWrites. As there's no guarantee that it
        //  will exit cleanly.
        const writes = self._bufferedWrites;
        self._bufferedWrites = Object.create(null);
        return writes;
      }
      async _flushBufferedWritesServer() {
        const self = this;
        const writes = self._prepareBuffersToFlush();
        await self._performWritesServer(writes);
      }
      _flushBufferedWritesClient() {
        const self = this;
        const writes = self._prepareBuffersToFlush();
        self._performWritesClient(writes);
      }
      _flushBufferedWrites() {
        const self = this;
        return Meteor.isClient ? self._flushBufferedWritesClient() : self._flushBufferedWritesServer();
      }
      async _performWritesServer(updates) {
        const self = this;
        if (self._resetStores || !isEmpty(updates)) {
          // Begin a transactional update of each store.

          for (const [storeName, store] of Object.entries(self._stores)) {
            await store.beginUpdate(hasOwn.call(updates, storeName) ? updates[storeName].length : 0, self._resetStores);
          }
          self._resetStores = false;
          for (const [storeName, updateMessages] of Object.entries(updates)) {
            const store = self._stores[storeName];
            if (store) {
              for (const updateMessage of updateMessages) {
                await store.update(updateMessage);
              }
            } else {
              // Nobody's listening for this data. Queue it up until
              // someone wants it.
              // XXX memory use will grow without bound if you forget to
              // create a collection or just don't care about it... going
              // to have to do something about that.
              const updates = self._updatesForUnknownStores;
              if (!hasOwn.call(updates, storeName)) {
                updates[storeName] = [];
              }
              updates[storeName].push(...updateMessages);
            }
          }
          // End update transaction.
          for (const store of Object.values(self._stores)) {
            await store.endUpdate();
          }
        }
        self._runAfterUpdateCallbacks();
      }
      _performWritesClient(updates) {
        const self = this;
        if (self._resetStores || !isEmpty(updates)) {
          // Begin a transactional update of each store.

          for (const [storeName, store] of Object.entries(self._stores)) {
            store.beginUpdate(hasOwn.call(updates, storeName) ? updates[storeName].length : 0, self._resetStores);
          }
          self._resetStores = false;
          for (const [storeName, updateMessages] of Object.entries(updates)) {
            const store = self._stores[storeName];
            if (store) {
              for (const updateMessage of updateMessages) {
                store.update(updateMessage);
              }
            } else {
              // Nobody's listening for this data. Queue it up until
              // someone wants it.
              // XXX memory use will grow without bound if you forget to
              // create a collection or just don't care about it... going
              // to have to do something about that.
              const updates = self._updatesForUnknownStores;
              if (!hasOwn.call(updates, storeName)) {
                updates[storeName] = [];
              }
              updates[storeName].push(...updateMessages);
            }
          }
          // End update transaction.
          for (const store of Object.values(self._stores)) {
            store.endUpdate();
          }
        }
        self._runAfterUpdateCallbacks();
      }

      // Call any callbacks deferred with _runWhenAllServerDocsAreFlushed whose
      // relevant docs have been flushed, as well as dataVisible callbacks at
      // reconnect-quiescence time.
      _runAfterUpdateCallbacks() {
        const self = this;
        const callbacks = self._afterUpdateCallbacks;
        self._afterUpdateCallbacks = [];
        callbacks.forEach(c => {
          c();
        });
      }
      _pushUpdate(updates, collection, msg) {
        if (!hasOwn.call(updates, collection)) {
          updates[collection] = [];
        }
        updates[collection].push(msg);
      }
      _getServerDoc(collection, id) {
        const self = this;
        if (!hasOwn.call(self._serverDocuments, collection)) {
          return null;
        }
        const serverDocsForCollection = self._serverDocuments[collection];
        return serverDocsForCollection.get(id) || null;
      }
      async _process_added(msg, updates) {
        const self = this;
        const id = MongoID.idParse(msg.id);
        const serverDoc = self._getServerDoc(msg.collection, id);
        if (serverDoc) {
          // Some outstanding stub wrote here.
          const isExisting = serverDoc.document !== undefined;
          serverDoc.document = msg.fields || Object.create(null);
          serverDoc.document._id = id;
          if (self._resetStores) {
            // During reconnect the server is sending adds for existing ids.
            // Always push an update so that document stays in the store after
            // reset. Use current version of the document for this update, so
            // that stub-written values are preserved.
            const currentDoc = await self._stores[msg.collection].getDoc(msg.id);
            if (currentDoc !== undefined) msg.fields = currentDoc;
            self._pushUpdate(updates, msg.collection, msg);
          } else if (isExisting) {
            throw new Error('Server sent add for existing id: ' + msg.id);
          }
        } else {
          self._pushUpdate(updates, msg.collection, msg);
        }
      }
      _process_changed(msg, updates) {
        const self = this;
        const serverDoc = self._getServerDoc(msg.collection, MongoID.idParse(msg.id));
        if (serverDoc) {
          if (serverDoc.document === undefined) throw new Error('Server sent changed for nonexisting id: ' + msg.id);
          DiffSequence.applyChanges(serverDoc.document, msg.fields);
        } else {
          self._pushUpdate(updates, msg.collection, msg);
        }
      }
      _process_removed(msg, updates) {
        const self = this;
        const serverDoc = self._getServerDoc(msg.collection, MongoID.idParse(msg.id));
        if (serverDoc) {
          // Some outstanding stub wrote here.
          if (serverDoc.document === undefined) throw new Error('Server sent removed for nonexisting id:' + msg.id);
          serverDoc.document = undefined;
        } else {
          self._pushUpdate(updates, msg.collection, {
            msg: 'removed',
            collection: msg.collection,
            id: msg.id
          });
        }
      }
      _process_updated(msg, updates) {
        const self = this;
        // Process "method done" messages.

        msg.methods.forEach(methodId => {
          const docs = self._documentsWrittenByStub[methodId] || {};
          Object.values(docs).forEach(written => {
            const serverDoc = self._getServerDoc(written.collection, written.id);
            if (!serverDoc) {
              throw new Error('Lost serverDoc for ' + JSON.stringify(written));
            }
            if (!serverDoc.writtenByStubs[methodId]) {
              throw new Error('Doc ' + JSON.stringify(written) + ' not written by  method ' + methodId);
            }
            delete serverDoc.writtenByStubs[methodId];
            if (isEmpty(serverDoc.writtenByStubs)) {
              // All methods whose stubs wrote this method have completed! We can
              // now copy the saved document to the database (reverting the stub's
              // change if the server did not write to this object, or applying the
              // server's writes if it did).

              // This is a fake ddp 'replace' message.  It's just for talking
              // between livedata connections and minimongo.  (We have to stringify
              // the ID because it's supposed to look like a wire message.)
              self._pushUpdate(updates, written.collection, {
                msg: 'replace',
                id: MongoID.idStringify(written.id),
                replace: serverDoc.document
              });
              // Call all flush callbacks.

              serverDoc.flushCallbacks.forEach(c => {
                c();
              });

              // Delete this completed serverDocument. Don't bother to GC empty
              // IdMaps inside self._serverDocuments, since there probably aren't
              // many collections and they'll be written repeatedly.
              self._serverDocuments[written.collection].remove(written.id);
            }
          });
          delete self._documentsWrittenByStub[methodId];

          // We want to call the data-written callback, but we can't do so until all
          // currently buffered messages are flushed.
          const callbackInvoker = self._methodInvokers[methodId];
          if (!callbackInvoker) {
            throw new Error('No callback invoker for method ' + methodId);
          }
          self._runWhenAllServerDocsAreFlushed(function () {
            return callbackInvoker.dataVisible(...arguments);
          });
        });
      }
      _process_ready(msg, updates) {
        const self = this;
        // Process "sub ready" messages. "sub ready" messages don't take effect
        // until all current server documents have been flushed to the local
        // database. We can use a write fence to implement this.

        msg.subs.forEach(subId => {
          self._runWhenAllServerDocsAreFlushed(() => {
            const subRecord = self._subscriptions[subId];
            // Did we already unsubscribe?
            if (!subRecord) return;
            // Did we already receive a ready message? (Oops!)
            if (subRecord.ready) return;
            subRecord.ready = true;
            subRecord.readyCallback && subRecord.readyCallback();
            subRecord.readyDeps.changed();
          });
        });
      }

      // Ensures that "f" will be called after all documents currently in
      // _serverDocuments have been written to the local cache. f will not be called
      // if the connection is lost before then!
      _runWhenAllServerDocsAreFlushed(f) {
        const self = this;
        const runFAfterUpdates = () => {
          self._afterUpdateCallbacks.push(f);
        };
        let unflushedServerDocCount = 0;
        const onServerDocFlush = () => {
          --unflushedServerDocCount;
          if (unflushedServerDocCount === 0) {
            // This was the last doc to flush! Arrange to run f after the updates
            // have been applied.
            runFAfterUpdates();
          }
        };
        Object.values(self._serverDocuments).forEach(serverDocuments => {
          serverDocuments.forEach(serverDoc => {
            const writtenByStubForAMethodWithSentMessage = keys(serverDoc.writtenByStubs).some(methodId => {
              const invoker = self._methodInvokers[methodId];
              return invoker && invoker.sentMessage;
            });
            if (writtenByStubForAMethodWithSentMessage) {
              ++unflushedServerDocCount;
              serverDoc.flushCallbacks.push(onServerDocFlush);
            }
          });
        });
        if (unflushedServerDocCount === 0) {
          // There aren't any buffered docs --- we can call f as soon as the current
          // round of updates is applied!
          runFAfterUpdates();
        }
      }
      async _livedata_nosub(msg) {
        const self = this;

        // First pass it through _livedata_data, which only uses it to help get
        // towards quiescence.
        await self._livedata_data(msg);

        // Do the rest of our processing immediately, with no
        // buffering-until-quiescence.

        // we weren't subbed anyway, or we initiated the unsub.
        if (!hasOwn.call(self._subscriptions, msg.id)) {
          return;
        }

        // XXX COMPAT WITH 1.0.3.1 #errorCallback
        const errorCallback = self._subscriptions[msg.id].errorCallback;
        const stopCallback = self._subscriptions[msg.id].stopCallback;
        self._subscriptions[msg.id].remove();
        const meteorErrorFromMsg = msgArg => {
          return msgArg && msgArg.error && new Meteor.Error(msgArg.error.error, msgArg.error.reason, msgArg.error.details);
        };

        // XXX COMPAT WITH 1.0.3.1 #errorCallback
        if (errorCallback && msg.error) {
          errorCallback(meteorErrorFromMsg(msg));
        }
        if (stopCallback) {
          stopCallback(meteorErrorFromMsg(msg));
        }
      }
      async _livedata_result(msg) {
        // id, result or error. error has error (code), reason, details

        const self = this;

        // Lets make sure there are no buffered writes before returning result.
        if (!isEmpty(self._bufferedWrites)) {
          await self._flushBufferedWrites();
        }

        // find the outstanding request
        // should be O(1) in nearly all realistic use cases
        if (isEmpty(self._outstandingMethodBlocks)) {
          Meteor._debug('Received method result but no methods outstanding');
          return;
        }
        const currentMethodBlock = self._outstandingMethodBlocks[0].methods;
        let i;
        const m = currentMethodBlock.find((method, idx) => {
          const found = method.methodId === msg.id;
          if (found) i = idx;
          return found;
        });
        if (!m) {
          Meteor._debug("Can't match method response to original method call", msg);
          return;
        }

        // Remove from current method block. This may leave the block empty, but we
        // don't move on to the next block until the callback has been delivered, in
        // _outstandingMethodFinished.
        currentMethodBlock.splice(i, 1);
        if (hasOwn.call(msg, 'error')) {
          m.receiveResult(new Meteor.Error(msg.error.error, msg.error.reason, msg.error.details));
        } else {
          // msg.result may be undefined if the method didn't return a
          // value
          m.receiveResult(undefined, msg.result);
        }
      }

      // Called by MethodInvoker after a method's callback is invoked.  If this was
      // the last outstanding method in the current block, runs the next block. If
      // there are no more methods, consider accepting a hot code push.
      _outstandingMethodFinished() {
        const self = this;
        if (self._anyMethodsAreOutstanding()) return;

        // No methods are outstanding. This should mean that the first block of
        // methods is empty. (Or it might not exist, if this was a method that
        // half-finished before disconnect/reconnect.)
        if (!isEmpty(self._outstandingMethodBlocks)) {
          const firstBlock = self._outstandingMethodBlocks.shift();
          if (!isEmpty(firstBlock.methods)) throw new Error('No methods outstanding but nonempty block: ' + JSON.stringify(firstBlock));

          // Send the outstanding methods now in the first block.
          if (!isEmpty(self._outstandingMethodBlocks)) self._sendOutstandingMethods();
        }

        // Maybe accept a hot code push.
        self._maybeMigrate();
      }

      // Sends messages for all the methods in the first block in
      // _outstandingMethodBlocks.
      _sendOutstandingMethods() {
        const self = this;
        if (isEmpty(self._outstandingMethodBlocks)) {
          return;
        }
        self._outstandingMethodBlocks[0].methods.forEach(m => {
          m.sendMessage();
        });
      }
      _livedata_error(msg) {
        Meteor._debug('Received error from server: ', msg.reason);
        if (msg.offendingMessage) Meteor._debug('For: ', msg.offendingMessage);
      }
      _sendOutstandingMethodBlocksMessages(oldOutstandingMethodBlocks) {
        const self = this;
        if (isEmpty(oldOutstandingMethodBlocks)) return;

        // We have at least one block worth of old outstanding methods to try
        // again. First: did onReconnect actually send anything? If not, we just
        // restore all outstanding methods and run the first block.
        if (isEmpty(self._outstandingMethodBlocks)) {
          self._outstandingMethodBlocks = oldOutstandingMethodBlocks;
          self._sendOutstandingMethods();
          return;
        }

        // OK, there are blocks on both sides. Special case: merge the last block of
        // the reconnect methods with the first block of the original methods, if
        // neither of them are "wait" blocks.
        if (!last(self._outstandingMethodBlocks).wait && !oldOutstandingMethodBlocks[0].wait) {
          oldOutstandingMethodBlocks[0].methods.forEach(m => {
            last(self._outstandingMethodBlocks).methods.push(m);

            // If this "last block" is also the first block, send the message.
            if (self._outstandingMethodBlocks.length === 1) {
              m.sendMessage();
            }
          });
          oldOutstandingMethodBlocks.shift();
        }

        // Now add the rest of the original blocks on.
        self._outstandingMethodBlocks.push(...oldOutstandingMethodBlocks);
      }
      _callOnReconnectAndSendAppropriateOutstandingMethods() {
        const self = this;
        const oldOutstandingMethodBlocks = self._outstandingMethodBlocks;
        self._outstandingMethodBlocks = [];
        self.onReconnect && self.onReconnect();
        DDP._reconnectHook.each(callback => {
          callback(self);
          return true;
        });
        self._sendOutstandingMethodBlocksMessages(oldOutstandingMethodBlocks);
      }

      // We can accept a hot code push if there are no methods in flight.
      _readyToMigrate() {
        return isEmpty(this._methodInvokers);
      }

      // If we were blocking a migration, see if it's now possible to continue.
      // Call whenever the set of outstanding/blocked methods shrinks.
      _maybeMigrate() {
        const self = this;
        if (self._retryMigrate && self._readyToMigrate()) {
          self._retryMigrate();
          self._retryMigrate = null;
        }
      }
      async onMessage(raw_msg) {
        let msg;
        try {
          msg = DDPCommon.parseDDP(raw_msg);
        } catch (e) {
          Meteor._debug('Exception while parsing DDP', e);
          return;
        }

        // Any message counts as receiving a pong, as it demonstrates that
        // the server is still alive.
        if (this._heartbeat) {
          this._heartbeat.messageReceived();
        }
        if (msg === null || !msg.msg) {
          if (!msg || !msg.testMessageOnConnect) {
            if (Object.keys(msg).length === 1 && msg.server_id) return;
            Meteor._debug('discarding invalid livedata message', msg);
          }
          return;
        }
        if (msg.msg === 'connected') {
          this._version = this._versionSuggestion;
          await this._livedata_connected(msg);
          this.options.onConnected();
        } else if (msg.msg === 'failed') {
          if (this._supportedDDPVersions.indexOf(msg.version) >= 0) {
            this._versionSuggestion = msg.version;
            this._stream.reconnect({
              _force: true
            });
          } else {
            const description = 'DDP version negotiation failed; server requested version ' + msg.version;
            this._stream.disconnect({
              _permanent: true,
              _error: description
            });
            this.options.onDDPVersionNegotiationFailure(description);
          }
        } else if (msg.msg === 'ping' && this.options.respondToPings) {
          this._send({
            msg: 'pong',
            id: msg.id
          });
        } else if (msg.msg === 'pong') {
          // noop, as we assume everything's a pong
        } else if (['added', 'changed', 'removed', 'ready', 'updated'].includes(msg.msg)) {
          await this._livedata_data(msg);
        } else if (msg.msg === 'nosub') {
          await this._livedata_nosub(msg);
        } else if (msg.msg === 'result') {
          await this._livedata_result(msg);
        } else if (msg.msg === 'error') {
          this._livedata_error(msg);
        } else {
          Meteor._debug('discarding unknown livedata message type', msg);
        }
      }
      onReset() {
        // Send a connect message at the beginning of the stream.
        // NOTE: reset is called even on the first connection, so this is
        // the only place we send this message.
        const msg = {
          msg: 'connect'
        };
        if (this._lastSessionId) msg.session = this._lastSessionId;
        msg.version = this._versionSuggestion || this._supportedDDPVersions[0];
        this._versionSuggestion = msg.version;
        msg.support = this._supportedDDPVersions;
        this._send(msg);

        // Mark non-retry calls as failed. This has to be done early as getting these methods out of the
        // current block is pretty important to making sure that quiescence is properly calculated, as
        // well as possibly moving on to another useful block.

        // Only bother testing if there is an outstandingMethodBlock (there might not be, especially if
        // we are connecting for the first time.
        if (this._outstandingMethodBlocks.length > 0) {
          // If there is an outstanding method block, we only care about the first one as that is the
          // one that could have already sent messages with no response, that are not allowed to retry.
          const currentMethodBlock = this._outstandingMethodBlocks[0].methods;
          this._outstandingMethodBlocks[0].methods = currentMethodBlock.filter(methodInvoker => {
            // Methods with 'noRetry' option set are not allowed to re-send after
            // recovering dropped connection.
            if (methodInvoker.sentMessage && methodInvoker.noRetry) {
              // Make sure that the method is told that it failed.
              methodInvoker.receiveResult(new Meteor.Error('invocation-failed', 'Method invocation might have failed due to dropped connection. ' + 'Failing because `noRetry` option was passed to Meteor.apply.'));
            }

            // Only keep a method if it wasn't sent or it's allowed to retry.
            // This may leave the block empty, but we don't move on to the next
            // block until the callback has been delivered, in _outstandingMethodFinished.
            return !(methodInvoker.sentMessage && methodInvoker.noRetry);
          });
        }

        // Now, to minimize setup latency, go ahead and blast out all of
        // our pending methods ands subscriptions before we've even taken
        // the necessary RTT to know if we successfully reconnected. (1)
        // They're supposed to be idempotent, and where they are not,
        // they can block retry in apply; (2) even if we did reconnect,
        // we're not sure what messages might have gotten lost
        // (in either direction) since we were disconnected (TCP being
        // sloppy about that.)

        // If the current block of methods all got their results (but didn't all get
        // their data visible), discard the empty block now.
        if (this._outstandingMethodBlocks.length > 0 && this._outstandingMethodBlocks[0].methods.length === 0) {
          this._outstandingMethodBlocks.shift();
        }

        // Mark all messages as unsent, they have not yet been sent on this
        // connection.
        keys(this._methodInvokers).forEach(id => {
          this._methodInvokers[id].sentMessage = false;
        });

        // If an `onReconnect` handler is set, call it first. Go through
        // some hoops to ensure that methods that are called from within
        // `onReconnect` get executed _before_ ones that were originally
        // outstanding (since `onReconnect` is used to re-establish auth
        // certificates)
        this._callOnReconnectAndSendAppropriateOutstandingMethods();

        // add new subscriptions at the end. this way they take effect after
        // the handlers and we don't see flicker.
        Object.entries(this._subscriptions).forEach(_ref6 => {
          let [id, sub] = _ref6;
          this._send({
            msg: 'sub',
            id: id,
            name: sub.name,
            params: sub.params
          });
        });
      }
    }
    __reify_async_result__();
  } catch (_reifyError) {
    return __reify_async_result__(_reifyError);
  }
  __reify_async_result__()
}, {
  self: this,
  async: false
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"namespace.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/ddp-client/common/namespace.js                                                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
!module.wrapAsync(async function (module, __reifyWaitForDeps__, __reify_async_result__) {
  "use strict";
  try {
    module.export({
      DDP: () => DDP
    });
    let DDPCommon;
    module.link("meteor/ddp-common", {
      DDPCommon(v) {
        DDPCommon = v;
      }
    }, 0);
    let Meteor;
    module.link("meteor/meteor", {
      Meteor(v) {
        Meteor = v;
      }
    }, 1);
    let Connection;
    module.link("./livedata_connection.js", {
      Connection(v) {
        Connection = v;
      }
    }, 2);
    if (__reifyWaitForDeps__()) (await __reifyWaitForDeps__())();
    // This array allows the `_allSubscriptionsReady` method below, which
    // is used by the `spiderable` package, to keep track of whether all
    // data is ready.
    const allConnections = [];

    /**
     * @namespace DDP
     * @summary Namespace for DDP-related methods/classes.
     */
    const DDP = {};
    // This is private but it's used in a few places. accounts-base uses
    // it to get the current user. Meteor.setTimeout and friends clear
    // it. We can probably find a better way to factor this.
    DDP._CurrentMethodInvocation = new Meteor.EnvironmentVariable();
    DDP._CurrentPublicationInvocation = new Meteor.EnvironmentVariable();

    // XXX: Keep DDP._CurrentInvocation for backwards-compatibility.
    DDP._CurrentInvocation = DDP._CurrentMethodInvocation;
    DDP._CurrentCallAsyncInvocation = new Meteor.EnvironmentVariable();

    // This is passed into a weird `makeErrorType` function that expects its thing
    // to be a constructor
    function connectionErrorConstructor(message) {
      this.message = message;
    }
    DDP.ConnectionError = Meteor.makeErrorType('DDP.ConnectionError', connectionErrorConstructor);
    DDP.ForcedReconnectError = Meteor.makeErrorType('DDP.ForcedReconnectError', () => {});

    // Returns the named sequence of pseudo-random values.
    // The scope will be DDP._CurrentMethodInvocation.get(), so the stream will produce
    // consistent values for method calls on the client and server.
    DDP.randomStream = name => {
      const scope = DDP._CurrentMethodInvocation.get();
      return DDPCommon.RandomStream.get(scope, name);
    };

    // @param url {String} URL to Meteor app,
    //     e.g.:
    //     "subdomain.meteor.com",
    //     "http://subdomain.meteor.com",
    //     "/",
    //     "ddp+sockjs://ddp--****-foo.meteor.com/sockjs"

    /**
     * @summary Connect to the server of a different Meteor application to subscribe to its document sets and invoke its remote methods.
     * @locus Anywhere
     * @param {String} url The URL of another Meteor application.
     * @param {Object} [options]
     * @param {Boolean} options.reloadWithOutstanding is it OK to reload if there are outstanding methods?
     * @param {Object} options.headers extra headers to send on the websockets connection, for server-to-server DDP only
     * @param {Object} options._sockjsOptions Specifies options to pass through to the sockjs client
     * @param {Function} options.onDDPNegotiationVersionFailure callback when version negotiation fails.
     */
    DDP.connect = (url, options) => {
      const ret = new Connection(url, options);
      allConnections.push(ret); // hack. see below.
      return ret;
    };
    DDP._reconnectHook = new Hook({
      bindEnvironment: false
    });

    /**
     * @summary Register a function to call as the first step of
     * reconnecting. This function can call methods which will be executed before
     * any other outstanding methods. For example, this can be used to re-establish
     * the appropriate authentication context on the connection.
     * @locus Anywhere
     * @param {Function} callback The function to call. It will be called with a
     * single argument, the [connection object](#ddp_connect) that is reconnecting.
     */
    DDP.onReconnect = callback => DDP._reconnectHook.register(callback);

    // Hack for `spiderable` package: a way to see if the page is done
    // loading all the data it needs.
    //
    DDP._allSubscriptionsReady = () => allConnections.every(conn => Object.values(conn._subscriptions).every(sub => sub.ready));
    __reify_async_result__();
  } catch (_reifyError) {
    return __reify_async_result__(_reifyError);
  }
  __reify_async_result__()
}, {
  self: this,
  async: false
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});


/* Exports */
return {
  export: function () { return {
      DDP: DDP
    };},
  require: require,
  eagerModulePaths: [
    "/node_modules/meteor/ddp-client/server/server.js"
  ],
  mainModulePath: "/node_modules/meteor/ddp-client/server/server.js"
}});

//# sourceURL=meteor://💻app/packages/ddp-client.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvZGRwLWNsaWVudC9zZXJ2ZXIvc2VydmVyLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9kZHAtY2xpZW50L2NvbW1vbi9NZXRob2RJbnZva2VyLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9kZHAtY2xpZW50L2NvbW1vbi9saXZlZGF0YV9jb25uZWN0aW9uLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9kZHAtY2xpZW50L2NvbW1vbi9uYW1lc3BhY2UuanMiXSwibmFtZXMiOlsibW9kdWxlIiwibGluayIsIkREUCIsIl9fcmVpZnlXYWl0Rm9yRGVwc19fIiwiX19yZWlmeV9hc3luY19yZXN1bHRfXyIsIl9yZWlmeUVycm9yIiwic2VsZiIsImFzeW5jIiwiZXhwb3J0IiwiZGVmYXVsdCIsIk1ldGhvZEludm9rZXIiLCJjb25zdHJ1Y3RvciIsIm9wdGlvbnMiLCJtZXRob2RJZCIsInNlbnRNZXNzYWdlIiwiX2NhbGxiYWNrIiwiY2FsbGJhY2siLCJfY29ubmVjdGlvbiIsImNvbm5lY3Rpb24iLCJfbWVzc2FnZSIsIm1lc3NhZ2UiLCJfb25SZXN1bHRSZWNlaXZlZCIsIm9uUmVzdWx0UmVjZWl2ZWQiLCJfd2FpdCIsIndhaXQiLCJub1JldHJ5IiwiX21ldGhvZFJlc3VsdCIsIl9kYXRhVmlzaWJsZSIsIl9tZXRob2RJbnZva2VycyIsInNlbmRNZXNzYWdlIiwiZ290UmVzdWx0IiwiRXJyb3IiLCJfbWV0aG9kc0Jsb2NraW5nUXVpZXNjZW5jZSIsIl9zZW5kIiwiX21heWJlSW52b2tlQ2FsbGJhY2siLCJfb3V0c3RhbmRpbmdNZXRob2RGaW5pc2hlZCIsInJlY2VpdmVSZXN1bHQiLCJlcnIiLCJyZXN1bHQiLCJkYXRhVmlzaWJsZSIsIl9vYmplY3RXaXRob3V0UHJvcGVydGllcyIsInYiLCJfb2JqZWN0U3ByZWFkIiwiX2V4Y2x1ZGVkIiwiX2V4Y2x1ZGVkMiIsIkNvbm5lY3Rpb24iLCJNZXRlb3IiLCJERFBDb21tb24iLCJUcmFja2VyIiwiRUpTT04iLCJSYW5kb20iLCJIb29rIiwiTW9uZ29JRCIsImhhc093biIsInNsaWNlIiwia2V5cyIsImlzRW1wdHkiLCJsYXN0IiwiTW9uZ29JRE1hcCIsIklkTWFwIiwiaWRTdHJpbmdpZnkiLCJpZFBhcnNlIiwidXJsIiwib25Db25uZWN0ZWQiLCJvbkREUFZlcnNpb25OZWdvdGlhdGlvbkZhaWx1cmUiLCJkZXNjcmlwdGlvbiIsIl9kZWJ1ZyIsImhlYXJ0YmVhdEludGVydmFsIiwiaGVhcnRiZWF0VGltZW91dCIsIm5wbUZheWVPcHRpb25zIiwiT2JqZWN0IiwiY3JlYXRlIiwicmVsb2FkV2l0aE91dHN0YW5kaW5nIiwic3VwcG9ydGVkRERQVmVyc2lvbnMiLCJTVVBQT1JURURfRERQX1ZFUlNJT05TIiwicmV0cnkiLCJyZXNwb25kVG9QaW5ncyIsImJ1ZmZlcmVkV3JpdGVzSW50ZXJ2YWwiLCJidWZmZXJlZFdyaXRlc01heEFnZSIsIm9uUmVjb25uZWN0IiwiX3N0cmVhbSIsIkNsaWVudFN0cmVhbSIsInJlcXVpcmUiLCJDb25uZWN0aW9uRXJyb3IiLCJoZWFkZXJzIiwiX3NvY2tqc09wdGlvbnMiLCJfZG9udFByaW50RXJyb3JzIiwiY29ubmVjdFRpbWVvdXRNcyIsIl9sYXN0U2Vzc2lvbklkIiwiX3ZlcnNpb25TdWdnZXN0aW9uIiwiX3ZlcnNpb24iLCJfc3RvcmVzIiwiX21ldGhvZEhhbmRsZXJzIiwiX25leHRNZXRob2RJZCIsIl9zdXBwb3J0ZWRERFBWZXJzaW9ucyIsIl9oZWFydGJlYXRJbnRlcnZhbCIsIl9oZWFydGJlYXRUaW1lb3V0IiwiX291dHN0YW5kaW5nTWV0aG9kQmxvY2tzIiwiX2RvY3VtZW50c1dyaXR0ZW5CeVN0dWIiLCJfc2VydmVyRG9jdW1lbnRzIiwiX2FmdGVyVXBkYXRlQ2FsbGJhY2tzIiwiX21lc3NhZ2VzQnVmZmVyZWRVbnRpbFF1aWVzY2VuY2UiLCJfc3Vic0JlaW5nUmV2aXZlZCIsIl9yZXNldFN0b3JlcyIsIl91cGRhdGVzRm9yVW5rbm93blN0b3JlcyIsIl9yZXRyeU1pZ3JhdGUiLCJfX2ZsdXNoQnVmZmVyZWRXcml0ZXMiLCJiaW5kRW52aXJvbm1lbnQiLCJfZmx1c2hCdWZmZXJlZFdyaXRlcyIsIl9idWZmZXJlZFdyaXRlcyIsIl9idWZmZXJlZFdyaXRlc0ZsdXNoQXQiLCJfYnVmZmVyZWRXcml0ZXNGbHVzaEhhbmRsZSIsIl9idWZmZXJlZFdyaXRlc0ludGVydmFsIiwiX2J1ZmZlcmVkV3JpdGVzTWF4QWdlIiwiX3N1YnNjcmlwdGlvbnMiLCJfdXNlcklkIiwiX3VzZXJJZERlcHMiLCJEZXBlbmRlbmN5IiwiaXNDbGllbnQiLCJQYWNrYWdlIiwicmVsb2FkIiwiUmVsb2FkIiwiX29uTWlncmF0ZSIsIl9yZWFkeVRvTWlncmF0ZSIsIm9uRGlzY29ubmVjdCIsIl9oZWFydGJlYXQiLCJzdG9wIiwiaXNTZXJ2ZXIiLCJvbiIsIm9uTWVzc2FnZSIsImJpbmQiLCJvblJlc2V0IiwiY3JlYXRlU3RvcmVNZXRob2RzIiwibmFtZSIsIndyYXBwZWRTdG9yZSIsInN0b3JlIiwia2V5c09mU3RvcmUiLCJmb3JFYWNoIiwibWV0aG9kIiwiYXJndW1lbnRzIiwicmVnaXN0ZXJTdG9yZUNsaWVudCIsInF1ZXVlZCIsIkFycmF5IiwiaXNBcnJheSIsImJlZ2luVXBkYXRlIiwibGVuZ3RoIiwibXNnIiwidXBkYXRlIiwiZW5kVXBkYXRlIiwicmVnaXN0ZXJTdG9yZVNlcnZlciIsInN1YnNjcmliZSIsInBhcmFtcyIsImNhbGwiLCJjYWxsYmFja3MiLCJsYXN0UGFyYW0iLCJvblJlYWR5IiwicG9wIiwib25FcnJvciIsIm9uU3RvcCIsInNvbWUiLCJmIiwiZXhpc3RpbmciLCJ2YWx1ZXMiLCJmaW5kIiwic3ViIiwiaW5hY3RpdmUiLCJlcXVhbHMiLCJpZCIsInJlYWR5IiwicmVhZHlDYWxsYmFjayIsImVycm9yQ2FsbGJhY2siLCJzdG9wQ2FsbGJhY2siLCJjbG9uZSIsInJlYWR5RGVwcyIsInJlbW92ZSIsImNoYW5nZWQiLCJfc2VuZFF1ZXVlZCIsImhhbmRsZSIsInJlY29yZCIsImRlcGVuZCIsInN1YnNjcmlwdGlvbklkIiwiYWN0aXZlIiwib25JbnZhbGlkYXRlIiwiYyIsImFmdGVyRmx1c2giLCJpc0FzeW5jQ2FsbCIsIl9DdXJyZW50TWV0aG9kSW52b2NhdGlvbiIsIl9pc0NhbGxBc3luY01ldGhvZFJ1bm5pbmciLCJtZXRob2RzIiwiZW50cmllcyIsIl9yZWYiLCJmdW5jIiwiX2dldElzU2ltdWxhdGlvbiIsIl9yZWYyIiwiaXNGcm9tQ2FsbEFzeW5jIiwiYWxyZWFkeUluU2ltdWxhdGlvbiIsImFyZ3MiLCJhcHBseSIsImNhbGxBc3luYyIsImFwcGx5QXN5bmMiLCJyZXR1cm5TZXJ2ZXJSZXN1bHRQcm9taXNlIiwiX3RoaXMkX3N0dWJDYWxsIiwiX3N0dWJDYWxsIiwic3R1Ykludm9jYXRpb24iLCJpbnZvY2F0aW9uIiwic3R1Yk9wdGlvbnMiLCJoYXNTdHViIiwiX3NhdmVPcmlnaW5hbHMiLCJzdHViUmV0dXJuVmFsdWUiLCJ3aXRoVmFsdWUiLCJfaXNQcm9taXNlIiwiY29uY2F0IiwiZSIsImV4Y2VwdGlvbiIsIl9hcHBseSIsInVuZGVmaW5lZCIsInN0dWJQcm9taXNlIiwiX2FwcGx5QXN5bmNTdHViSW52b2NhdGlvbiIsInByb21pc2UiLCJfYXBwbHlBc3luYyIsInRoZW4iLCJvIiwic2VydmVyUHJvbWlzZSIsIlByb21pc2UiLCJyZXNvbHZlIiwicmVqZWN0IiwiY2F0Y2giLCJfdGhpcyRfc3R1YkNhbGwyIiwiY3VycmVudENvbnRleHQiLCJfc2V0TmV3Q29udGV4dEFuZEdldEN1cnJlbnQiLCJfc2V0IiwiX3JlZjMiLCJzdHViQ2FsbFZhbHVlIiwicmFuZG9tU2VlZCIsIl9yZXRyaWV2ZUFuZFN0b3JlT3JpZ2luYWxzIiwidGhyb3dTdHViRXhjZXB0aW9ucyIsIl9leHBlY3RlZEJ5VGVzdCIsImZ1dHVyZSIsInJldHVyblN0dWJWYWx1ZSIsIl9sZW4iLCJhbGxBcmdzIiwiX2tleSIsImZyb20iLCJzaGlmdCIsInZhbHVlIiwibWV0aG9kSW52b2tlciIsInB1c2giLCJlbmNsb3NpbmciLCJnZXQiLCJzdHViIiwiaXNTaW11bGF0aW9uIiwiX2lzRnJvbUNhbGxBc3luYyIsImRlZmF1bHRSZXR1cm4iLCJyYW5kb21TZWVkR2VuZXJhdG9yIiwibWFrZVJwY1NlZWQiLCJzZXRVc2VySWQiLCJ1c2VySWQiLCJNZXRob2RJbnZvY2F0aW9uIiwiX25vWWllbGRzQWxsb3dlZCIsIl93YWl0aW5nRm9yUXVpZXNjZW5jZSIsIl9mbHVzaEJ1ZmZlcmVkV3JpdGVzQ2xpZW50Iiwic2F2ZU9yaWdpbmFscyIsImRvY3NXcml0dGVuIiwiX3JlZjQiLCJjb2xsZWN0aW9uIiwib3JpZ2luYWxzIiwicmV0cmlldmVPcmlnaW5hbHMiLCJkb2MiLCJzZXJ2ZXJEb2MiLCJzZXREZWZhdWx0Iiwid3JpdHRlbkJ5U3R1YnMiLCJkb2N1bWVudCIsImZsdXNoQ2FsbGJhY2tzIiwiX3Vuc3Vic2NyaWJlQWxsIiwib2JqIiwic2VuZCIsInN0cmluZ2lmeUREUCIsIl9sb3N0Q29ubmVjdGlvbiIsImVycm9yIiwic3RhdHVzIiwicmVjb25uZWN0IiwiZGlzY29ubmVjdCIsImNsb3NlIiwiX3Blcm1hbmVudCIsIl9hbnlNZXRob2RzQXJlT3V0c3RhbmRpbmciLCJpbnZva2VycyIsImludm9rZXIiLCJfbGl2ZWRhdGFfY29ubmVjdGVkIiwiSGVhcnRiZWF0Iiwib25UaW1lb3V0Iiwic2VuZFBpbmciLCJzdGFydCIsInJlY29ubmVjdGVkVG9QcmV2aW91c1Nlc3Npb24iLCJzZXNzaW9uIiwiX3JlZjUiLCJfcnVuQWZ0ZXJVcGRhdGVDYWxsYmFja3MiLCJfcHJvY2Vzc09uZURhdGFNZXNzYWdlIiwidXBkYXRlcyIsIm1lc3NhZ2VUeXBlIiwiX3Byb2Nlc3NfYWRkZWQiLCJfcHJvY2Vzc19jaGFuZ2VkIiwiX3Byb2Nlc3NfcmVtb3ZlZCIsIl9wcm9jZXNzX3JlYWR5IiwiX3Byb2Nlc3NfdXBkYXRlZCIsIl9saXZlZGF0YV9kYXRhIiwic3VicyIsInN1YklkIiwiYnVmZmVyZWRNZXNzYWdlcyIsImJ1ZmZlcmVkTWVzc2FnZSIsInN0YW5kYXJkV3JpdGUiLCJEYXRlIiwidmFsdWVPZiIsImNsZWFyVGltZW91dCIsInNldFRpbWVvdXQiLCJfbGl2ZURhdGFXcml0ZXNQcm9taXNlIiwiZmluYWxseSIsIl9wcmVwYXJlQnVmZmVyc1RvRmx1c2giLCJ3cml0ZXMiLCJfZmx1c2hCdWZmZXJlZFdyaXRlc1NlcnZlciIsIl9wZXJmb3JtV3JpdGVzU2VydmVyIiwiX3BlcmZvcm1Xcml0ZXNDbGllbnQiLCJzdG9yZU5hbWUiLCJ1cGRhdGVNZXNzYWdlcyIsInVwZGF0ZU1lc3NhZ2UiLCJfcHVzaFVwZGF0ZSIsIl9nZXRTZXJ2ZXJEb2MiLCJzZXJ2ZXJEb2NzRm9yQ29sbGVjdGlvbiIsImlzRXhpc3RpbmciLCJmaWVsZHMiLCJfaWQiLCJjdXJyZW50RG9jIiwiZ2V0RG9jIiwiRGlmZlNlcXVlbmNlIiwiYXBwbHlDaGFuZ2VzIiwiZG9jcyIsIndyaXR0ZW4iLCJKU09OIiwic3RyaW5naWZ5IiwicmVwbGFjZSIsImNhbGxiYWNrSW52b2tlciIsIl9ydW5XaGVuQWxsU2VydmVyRG9jc0FyZUZsdXNoZWQiLCJzdWJSZWNvcmQiLCJydW5GQWZ0ZXJVcGRhdGVzIiwidW5mbHVzaGVkU2VydmVyRG9jQ291bnQiLCJvblNlcnZlckRvY0ZsdXNoIiwic2VydmVyRG9jdW1lbnRzIiwid3JpdHRlbkJ5U3R1YkZvckFNZXRob2RXaXRoU2VudE1lc3NhZ2UiLCJfbGl2ZWRhdGFfbm9zdWIiLCJtZXRlb3JFcnJvckZyb21Nc2ciLCJtc2dBcmciLCJyZWFzb24iLCJkZXRhaWxzIiwiX2xpdmVkYXRhX3Jlc3VsdCIsImN1cnJlbnRNZXRob2RCbG9jayIsImkiLCJtIiwiaWR4IiwiZm91bmQiLCJzcGxpY2UiLCJmaXJzdEJsb2NrIiwiX3NlbmRPdXRzdGFuZGluZ01ldGhvZHMiLCJfbWF5YmVNaWdyYXRlIiwiX2xpdmVkYXRhX2Vycm9yIiwib2ZmZW5kaW5nTWVzc2FnZSIsIl9zZW5kT3V0c3RhbmRpbmdNZXRob2RCbG9ja3NNZXNzYWdlcyIsIm9sZE91dHN0YW5kaW5nTWV0aG9kQmxvY2tzIiwiX2NhbGxPblJlY29ubmVjdEFuZFNlbmRBcHByb3ByaWF0ZU91dHN0YW5kaW5nTWV0aG9kcyIsIl9yZWNvbm5lY3RIb29rIiwiZWFjaCIsInJhd19tc2ciLCJwYXJzZUREUCIsIm1lc3NhZ2VSZWNlaXZlZCIsInRlc3RNZXNzYWdlT25Db25uZWN0Iiwic2VydmVyX2lkIiwiaW5kZXhPZiIsInZlcnNpb24iLCJfZm9yY2UiLCJfZXJyb3IiLCJpbmNsdWRlcyIsInN1cHBvcnQiLCJmaWx0ZXIiLCJfcmVmNiIsImFsbENvbm5lY3Rpb25zIiwiRW52aXJvbm1lbnRWYXJpYWJsZSIsIl9DdXJyZW50UHVibGljYXRpb25JbnZvY2F0aW9uIiwiX0N1cnJlbnRJbnZvY2F0aW9uIiwiX0N1cnJlbnRDYWxsQXN5bmNJbnZvY2F0aW9uIiwiY29ubmVjdGlvbkVycm9yQ29uc3RydWN0b3IiLCJtYWtlRXJyb3JUeXBlIiwiRm9yY2VkUmVjb25uZWN0RXJyb3IiLCJyYW5kb21TdHJlYW0iLCJzY29wZSIsIlJhbmRvbVN0cmVhbSIsImNvbm5lY3QiLCJyZXQiLCJyZWdpc3RlciIsIl9hbGxTdWJzY3JpcHRpb25zUmVhZHkiLCJldmVyeSIsImNvbm4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0lBQUFBLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLHdCQUF3QixFQUFDO01BQUNDLEdBQUcsRUFBQztJQUFLLENBQUMsRUFBQyxDQUFDLENBQUM7SUFBQyxJQUFJQyxvQkFBb0IsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxNQUFNQSxvQkFBb0IsQ0FBQyxDQUFDLEVBQUUsQ0FBQztJQUFDQyxzQkFBQTtFQUFBLFNBQUFDLFdBQUE7SUFBQSxPQUFBRCxzQkFBQSxDQUFBQyxXQUFBO0VBQUE7RUFBQUQsc0JBQUE7QUFBQTtFQUFBRSxJQUFBO0VBQUFDLEtBQUE7QUFBQSxHOzs7Ozs7Ozs7OztBQ0FqSFAsTUFBTSxDQUFDUSxNQUFNLENBQUM7RUFBQ0MsT0FBTyxFQUFDQSxDQUFBLEtBQUlDO0FBQWEsQ0FBQyxDQUFDO0FBSzNCLE1BQU1BLGFBQWEsQ0FBQztFQUNqQ0MsV0FBV0EsQ0FBQ0MsT0FBTyxFQUFFO0lBQ25CO0lBQ0EsSUFBSSxDQUFDQyxRQUFRLEdBQUdELE9BQU8sQ0FBQ0MsUUFBUTtJQUNoQyxJQUFJLENBQUNDLFdBQVcsR0FBRyxLQUFLO0lBRXhCLElBQUksQ0FBQ0MsU0FBUyxHQUFHSCxPQUFPLENBQUNJLFFBQVE7SUFDakMsSUFBSSxDQUFDQyxXQUFXLEdBQUdMLE9BQU8sQ0FBQ00sVUFBVTtJQUNyQyxJQUFJLENBQUNDLFFBQVEsR0FBR1AsT0FBTyxDQUFDUSxPQUFPO0lBQy9CLElBQUksQ0FBQ0MsaUJBQWlCLEdBQUdULE9BQU8sQ0FBQ1UsZ0JBQWdCLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQztJQUMvRCxJQUFJLENBQUNDLEtBQUssR0FBR1gsT0FBTyxDQUFDWSxJQUFJO0lBQ3pCLElBQUksQ0FBQ0MsT0FBTyxHQUFHYixPQUFPLENBQUNhLE9BQU87SUFDOUIsSUFBSSxDQUFDQyxhQUFhLEdBQUcsSUFBSTtJQUN6QixJQUFJLENBQUNDLFlBQVksR0FBRyxLQUFLOztJQUV6QjtJQUNBLElBQUksQ0FBQ1YsV0FBVyxDQUFDVyxlQUFlLENBQUMsSUFBSSxDQUFDZixRQUFRLENBQUMsR0FBRyxJQUFJO0VBQ3hEO0VBQ0E7RUFDQTtFQUNBZ0IsV0FBV0EsQ0FBQSxFQUFHO0lBQ1o7SUFDQTtJQUNBO0lBQ0EsSUFBSSxJQUFJLENBQUNDLFNBQVMsQ0FBQyxDQUFDLEVBQ2xCLE1BQU0sSUFBSUMsS0FBSyxDQUFDLCtDQUErQyxDQUFDOztJQUVsRTtJQUNBO0lBQ0EsSUFBSSxDQUFDSixZQUFZLEdBQUcsS0FBSztJQUN6QixJQUFJLENBQUNiLFdBQVcsR0FBRyxJQUFJOztJQUV2QjtJQUNBO0lBQ0EsSUFBSSxJQUFJLENBQUNTLEtBQUssRUFDWixJQUFJLENBQUNOLFdBQVcsQ0FBQ2UsMEJBQTBCLENBQUMsSUFBSSxDQUFDbkIsUUFBUSxDQUFDLEdBQUcsSUFBSTs7SUFFbkU7SUFDQSxJQUFJLENBQUNJLFdBQVcsQ0FBQ2dCLEtBQUssQ0FBQyxJQUFJLENBQUNkLFFBQVEsQ0FBQztFQUN2QztFQUNBO0VBQ0E7RUFDQWUsb0JBQW9CQSxDQUFBLEVBQUc7SUFDckIsSUFBSSxJQUFJLENBQUNSLGFBQWEsSUFBSSxJQUFJLENBQUNDLFlBQVksRUFBRTtNQUMzQztNQUNBO01BQ0EsSUFBSSxDQUFDWixTQUFTLENBQUMsSUFBSSxDQUFDVyxhQUFhLENBQUMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDQSxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUM7O01BRTVEO01BQ0EsT0FBTyxJQUFJLENBQUNULFdBQVcsQ0FBQ1csZUFBZSxDQUFDLElBQUksQ0FBQ2YsUUFBUSxDQUFDOztNQUV0RDtNQUNBO01BQ0EsSUFBSSxDQUFDSSxXQUFXLENBQUNrQiwwQkFBMEIsQ0FBQyxDQUFDO0lBQy9DO0VBQ0Y7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBQyxhQUFhQSxDQUFDQyxHQUFHLEVBQUVDLE1BQU0sRUFBRTtJQUN6QixJQUFJLElBQUksQ0FBQ1IsU0FBUyxDQUFDLENBQUMsRUFDbEIsTUFBTSxJQUFJQyxLQUFLLENBQUMsMENBQTBDLENBQUM7SUFDN0QsSUFBSSxDQUFDTCxhQUFhLEdBQUcsQ0FBQ1csR0FBRyxFQUFFQyxNQUFNLENBQUM7SUFDbEMsSUFBSSxDQUFDakIsaUJBQWlCLENBQUNnQixHQUFHLEVBQUVDLE1BQU0sQ0FBQztJQUNuQyxJQUFJLENBQUNKLG9CQUFvQixDQUFDLENBQUM7RUFDN0I7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBSyxXQUFXQSxDQUFBLEVBQUc7SUFDWixJQUFJLENBQUNaLFlBQVksR0FBRyxJQUFJO0lBQ3hCLElBQUksQ0FBQ08sb0JBQW9CLENBQUMsQ0FBQztFQUM3QjtFQUNBO0VBQ0FKLFNBQVNBLENBQUEsRUFBRztJQUNWLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQ0osYUFBYTtFQUM3QjtBQUNGLEM7Ozs7Ozs7Ozs7Ozs7O0lDcEZBLElBQUljLHdCQUF3QjtJQUFDeEMsTUFBTSxDQUFDQyxJQUFJLENBQUMsZ0RBQWdELEVBQUM7TUFBQ1EsT0FBT0EsQ0FBQ2dDLENBQUMsRUFBQztRQUFDRCx3QkFBd0IsR0FBQ0MsQ0FBQztNQUFBO0lBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztJQUFDLElBQUlDLGFBQWE7SUFBQzFDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLHNDQUFzQyxFQUFDO01BQUNRLE9BQU9BLENBQUNnQyxDQUFDLEVBQUM7UUFBQ0MsYUFBYSxHQUFDRCxDQUFDO01BQUE7SUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0lBQUMsTUFBQUUsU0FBQTtNQUFBQyxVQUFBO0lBQTVPNUMsTUFBTSxDQUFDUSxNQUFNLENBQUM7TUFBQ3FDLFVBQVUsRUFBQ0EsQ0FBQSxLQUFJQTtJQUFVLENBQUMsQ0FBQztJQUFDLElBQUlDLE1BQU07SUFBQzlDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLGVBQWUsRUFBQztNQUFDNkMsTUFBTUEsQ0FBQ0wsQ0FBQyxFQUFDO1FBQUNLLE1BQU0sR0FBQ0wsQ0FBQztNQUFBO0lBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztJQUFDLElBQUlNLFNBQVM7SUFBQy9DLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLG1CQUFtQixFQUFDO01BQUM4QyxTQUFTQSxDQUFDTixDQUFDLEVBQUM7UUFBQ00sU0FBUyxHQUFDTixDQUFDO01BQUE7SUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0lBQUMsSUFBSU8sT0FBTztJQUFDaEQsTUFBTSxDQUFDQyxJQUFJLENBQUMsZ0JBQWdCLEVBQUM7TUFBQytDLE9BQU9BLENBQUNQLENBQUMsRUFBQztRQUFDTyxPQUFPLEdBQUNQLENBQUM7TUFBQTtJQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7SUFBQyxJQUFJUSxLQUFLO0lBQUNqRCxNQUFNLENBQUNDLElBQUksQ0FBQyxjQUFjLEVBQUM7TUFBQ2dELEtBQUtBLENBQUNSLENBQUMsRUFBQztRQUFDUSxLQUFLLEdBQUNSLENBQUM7TUFBQTtJQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7SUFBQyxJQUFJUyxNQUFNO0lBQUNsRCxNQUFNLENBQUNDLElBQUksQ0FBQyxlQUFlLEVBQUM7TUFBQ2lELE1BQU1BLENBQUNULENBQUMsRUFBQztRQUFDUyxNQUFNLEdBQUNULENBQUM7TUFBQTtJQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7SUFBQyxJQUFJVSxJQUFJO0lBQUNuRCxNQUFNLENBQUNDLElBQUksQ0FBQyxzQkFBc0IsRUFBQztNQUFDa0QsSUFBSUEsQ0FBQ1YsQ0FBQyxFQUFDO1FBQUNVLElBQUksR0FBQ1YsQ0FBQztNQUFBO0lBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztJQUFDLElBQUlXLE9BQU87SUFBQ3BELE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLGlCQUFpQixFQUFDO01BQUNtRCxPQUFPQSxDQUFDWCxDQUFDLEVBQUM7UUFBQ1csT0FBTyxHQUFDWCxDQUFDO01BQUE7SUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0lBQUMsSUFBSXZDLEdBQUc7SUFBQ0YsTUFBTSxDQUFDQyxJQUFJLENBQUMsZ0JBQWdCLEVBQUM7TUFBQ0MsR0FBR0EsQ0FBQ3VDLENBQUMsRUFBQztRQUFDdkMsR0FBRyxHQUFDdUMsQ0FBQztNQUFBO0lBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztJQUFDLElBQUkvQixhQUFhO0lBQUNWLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLG9CQUFvQixFQUFDO01BQUNRLE9BQU9BLENBQUNnQyxDQUFDLEVBQUM7UUFBQy9CLGFBQWEsR0FBQytCLENBQUM7TUFBQTtJQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7SUFBQyxJQUFJWSxNQUFNLEVBQUNDLEtBQUssRUFBQ0MsSUFBSSxFQUFDQyxPQUFPLEVBQUNDLElBQUk7SUFBQ3pELE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLDRCQUE0QixFQUFDO01BQUNvRCxNQUFNQSxDQUFDWixDQUFDLEVBQUM7UUFBQ1ksTUFBTSxHQUFDWixDQUFDO01BQUEsQ0FBQztNQUFDYSxLQUFLQSxDQUFDYixDQUFDLEVBQUM7UUFBQ2EsS0FBSyxHQUFDYixDQUFDO01BQUEsQ0FBQztNQUFDYyxJQUFJQSxDQUFDZCxDQUFDLEVBQUM7UUFBQ2MsSUFBSSxHQUFDZCxDQUFDO01BQUEsQ0FBQztNQUFDZSxPQUFPQSxDQUFDZixDQUFDLEVBQUM7UUFBQ2UsT0FBTyxHQUFDZixDQUFDO01BQUEsQ0FBQztNQUFDZ0IsSUFBSUEsQ0FBQ2hCLENBQUMsRUFBQztRQUFDZ0IsSUFBSSxHQUFDaEIsQ0FBQztNQUFBO0lBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztJQUFDLElBQUl0QyxvQkFBb0IsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxNQUFNQSxvQkFBb0IsQ0FBQyxDQUFDLEVBQUUsQ0FBQztJQWlCbjNCLE1BQU11RCxVQUFVLFNBQVNDLEtBQUssQ0FBQztNQUM3QmhELFdBQVdBLENBQUEsRUFBRztRQUNaLEtBQUssQ0FBQ3lDLE9BQU8sQ0FBQ1EsV0FBVyxFQUFFUixPQUFPLENBQUNTLE9BQU8sQ0FBQztNQUM3QztJQUNGOztJQUVBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDTyxNQUFNaEIsVUFBVSxDQUFDO01BQ3RCbEMsV0FBV0EsQ0FBQ21ELEdBQUcsRUFBRWxELE9BQU8sRUFBRTtRQUN4QixNQUFNTixJQUFJLEdBQUcsSUFBSTtRQUVqQixJQUFJLENBQUNNLE9BQU8sR0FBR0EsT0FBTyxHQUFBOEIsYUFBQTtVQUNwQnFCLFdBQVdBLENBQUEsRUFBRyxDQUFDLENBQUM7VUFDaEJDLDhCQUE4QkEsQ0FBQ0MsV0FBVyxFQUFFO1lBQzFDbkIsTUFBTSxDQUFDb0IsTUFBTSxDQUFDRCxXQUFXLENBQUM7VUFDNUIsQ0FBQztVQUNERSxpQkFBaUIsRUFBRSxLQUFLO1VBQ3hCQyxnQkFBZ0IsRUFBRSxLQUFLO1VBQ3ZCQyxjQUFjLEVBQUVDLE1BQU0sQ0FBQ0MsTUFBTSxDQUFDLElBQUksQ0FBQztVQUNuQztVQUNBQyxxQkFBcUIsRUFBRSxLQUFLO1VBQzVCQyxvQkFBb0IsRUFBRTFCLFNBQVMsQ0FBQzJCLHNCQUFzQjtVQUN0REMsS0FBSyxFQUFFLElBQUk7VUFDWEMsY0FBYyxFQUFFLElBQUk7VUFDcEI7VUFDQUMsc0JBQXNCLEVBQUUsQ0FBQztVQUN6QjtVQUNBQyxvQkFBb0IsRUFBRTtRQUFHLEdBRXRCbEUsT0FBTyxDQUNYOztRQUVEO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQU4sSUFBSSxDQUFDeUUsV0FBVyxHQUFHLElBQUk7O1FBRXZCO1FBQ0EsSUFBSSxPQUFPakIsR0FBRyxLQUFLLFFBQVEsRUFBRTtVQUMzQnhELElBQUksQ0FBQzBFLE9BQU8sR0FBR2xCLEdBQUc7UUFDcEIsQ0FBQyxNQUFNO1VBQ0wsTUFBTTtZQUFFbUI7VUFBYSxDQUFDLEdBQUdDLE9BQU8sQ0FBQyw2QkFBNkIsQ0FBQztVQUMvRDVFLElBQUksQ0FBQzBFLE9BQU8sR0FBRyxJQUFJQyxZQUFZLENBQUNuQixHQUFHLEVBQUU7WUFDbkNhLEtBQUssRUFBRS9ELE9BQU8sQ0FBQytELEtBQUs7WUFDcEJRLGVBQWUsRUFBRWpGLEdBQUcsQ0FBQ2lGLGVBQWU7WUFDcENDLE9BQU8sRUFBRXhFLE9BQU8sQ0FBQ3dFLE9BQU87WUFDeEJDLGNBQWMsRUFBRXpFLE9BQU8sQ0FBQ3lFLGNBQWM7WUFDdEM7WUFDQTtZQUNBO1lBQ0E7WUFDQTtZQUNBQyxnQkFBZ0IsRUFBRTFFLE9BQU8sQ0FBQzBFLGdCQUFnQjtZQUMxQ0MsZ0JBQWdCLEVBQUUzRSxPQUFPLENBQUMyRSxnQkFBZ0I7WUFDMUNsQixjQUFjLEVBQUV6RCxPQUFPLENBQUN5RDtVQUMxQixDQUFDLENBQUM7UUFDSjtRQUVBL0QsSUFBSSxDQUFDa0YsY0FBYyxHQUFHLElBQUk7UUFDMUJsRixJQUFJLENBQUNtRixrQkFBa0IsR0FBRyxJQUFJLENBQUMsQ0FBQztRQUNoQ25GLElBQUksQ0FBQ29GLFFBQVEsR0FBRyxJQUFJLENBQUMsQ0FBQztRQUN0QnBGLElBQUksQ0FBQ3FGLE9BQU8sR0FBR3JCLE1BQU0sQ0FBQ0MsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7UUFDcENqRSxJQUFJLENBQUNzRixlQUFlLEdBQUd0QixNQUFNLENBQUNDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBQzVDakUsSUFBSSxDQUFDdUYsYUFBYSxHQUFHLENBQUM7UUFDdEJ2RixJQUFJLENBQUN3RixxQkFBcUIsR0FBR2xGLE9BQU8sQ0FBQzZELG9CQUFvQjtRQUV6RG5FLElBQUksQ0FBQ3lGLGtCQUFrQixHQUFHbkYsT0FBTyxDQUFDdUQsaUJBQWlCO1FBQ25EN0QsSUFBSSxDQUFDMEYsaUJBQWlCLEdBQUdwRixPQUFPLENBQUN3RCxnQkFBZ0I7O1FBRWpEO1FBQ0E7UUFDQTtRQUNBO1FBQ0E5RCxJQUFJLENBQUNzQixlQUFlLEdBQUcwQyxNQUFNLENBQUNDLE1BQU0sQ0FBQyxJQUFJLENBQUM7O1FBRTFDO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBakUsSUFBSSxDQUFDMkYsd0JBQXdCLEdBQUcsRUFBRTs7UUFFbEM7UUFDQTtRQUNBO1FBQ0E7UUFDQTNGLElBQUksQ0FBQzRGLHVCQUF1QixHQUFHLENBQUMsQ0FBQztRQUNqQztRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBNUYsSUFBSSxDQUFDNkYsZ0JBQWdCLEdBQUcsQ0FBQyxDQUFDOztRQUUxQjtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E3RixJQUFJLENBQUM4RixxQkFBcUIsR0FBRyxFQUFFOztRQUUvQjtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBOztRQUVBO1FBQ0E5RixJQUFJLENBQUMrRixnQ0FBZ0MsR0FBRyxFQUFFO1FBQzFDO1FBQ0E7UUFDQTtRQUNBL0YsSUFBSSxDQUFDMEIsMEJBQTBCLEdBQUcsQ0FBQyxDQUFDO1FBQ3BDO1FBQ0E7UUFDQTFCLElBQUksQ0FBQ2dHLGlCQUFpQixHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDN0I7UUFDQTtRQUNBaEcsSUFBSSxDQUFDaUcsWUFBWSxHQUFHLEtBQUs7O1FBRXpCO1FBQ0FqRyxJQUFJLENBQUNrRyx3QkFBd0IsR0FBRyxDQUFDLENBQUM7UUFDbEM7UUFDQWxHLElBQUksQ0FBQ21HLGFBQWEsR0FBRyxJQUFJO1FBRXpCbkcsSUFBSSxDQUFDb0cscUJBQXFCLEdBQUc1RCxNQUFNLENBQUM2RCxlQUFlLENBQ2pEckcsSUFBSSxDQUFDc0csb0JBQW9CLEVBQ3pCLDhCQUE4QixFQUM5QnRHLElBQ0YsQ0FBQztRQUNEO1FBQ0FBLElBQUksQ0FBQ3VHLGVBQWUsR0FBRyxDQUFDLENBQUM7UUFDekI7UUFDQXZHLElBQUksQ0FBQ3dHLHNCQUFzQixHQUFHLElBQUk7UUFDbEM7UUFDQXhHLElBQUksQ0FBQ3lHLDBCQUEwQixHQUFHLElBQUk7UUFFdEN6RyxJQUFJLENBQUMwRyx1QkFBdUIsR0FBR3BHLE9BQU8sQ0FBQ2lFLHNCQUFzQjtRQUM3RHZFLElBQUksQ0FBQzJHLHFCQUFxQixHQUFHckcsT0FBTyxDQUFDa0Usb0JBQW9COztRQUV6RDtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0F4RSxJQUFJLENBQUM0RyxjQUFjLEdBQUcsQ0FBQyxDQUFDOztRQUV4QjtRQUNBNUcsSUFBSSxDQUFDNkcsT0FBTyxHQUFHLElBQUk7UUFDbkI3RyxJQUFJLENBQUM4RyxXQUFXLEdBQUcsSUFBSXBFLE9BQU8sQ0FBQ3FFLFVBQVUsQ0FBQyxDQUFDOztRQUUzQztRQUNBLElBQUl2RSxNQUFNLENBQUN3RSxRQUFRLElBQ2pCQyxPQUFPLENBQUNDLE1BQU0sSUFDZCxDQUFFNUcsT0FBTyxDQUFDNEQscUJBQXFCLEVBQUU7VUFDakMrQyxPQUFPLENBQUNDLE1BQU0sQ0FBQ0MsTUFBTSxDQUFDQyxVQUFVLENBQUMvQyxLQUFLLElBQUk7WUFDeEMsSUFBSSxDQUFFckUsSUFBSSxDQUFDcUgsZUFBZSxDQUFDLENBQUMsRUFBRTtjQUM1QnJILElBQUksQ0FBQ21HLGFBQWEsR0FBRzlCLEtBQUs7Y0FDMUIsT0FBTyxDQUFDLEtBQUssQ0FBQztZQUNoQixDQUFDLE1BQU07Y0FDTCxPQUFPLENBQUMsSUFBSSxDQUFDO1lBQ2Y7VUFDRixDQUFDLENBQUM7UUFDSjtRQUVBLE1BQU1pRCxZQUFZLEdBQUdBLENBQUEsS0FBTTtVQUN6QixJQUFJdEgsSUFBSSxDQUFDdUgsVUFBVSxFQUFFO1lBQ25CdkgsSUFBSSxDQUFDdUgsVUFBVSxDQUFDQyxJQUFJLENBQUMsQ0FBQztZQUN0QnhILElBQUksQ0FBQ3VILFVBQVUsR0FBRyxJQUFJO1VBQ3hCO1FBQ0YsQ0FBQztRQUVELElBQUkvRSxNQUFNLENBQUNpRixRQUFRLEVBQUU7VUFDbkJ6SCxJQUFJLENBQUMwRSxPQUFPLENBQUNnRCxFQUFFLENBQ2IsU0FBUyxFQUNUbEYsTUFBTSxDQUFDNkQsZUFBZSxDQUNwQixJQUFJLENBQUNzQixTQUFTLENBQUNDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFDekIsc0JBQ0YsQ0FDRixDQUFDO1VBQ0Q1SCxJQUFJLENBQUMwRSxPQUFPLENBQUNnRCxFQUFFLENBQ2IsT0FBTyxFQUNQbEYsTUFBTSxDQUFDNkQsZUFBZSxDQUFDLElBQUksQ0FBQ3dCLE9BQU8sQ0FBQ0QsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLG9CQUFvQixDQUN0RSxDQUFDO1VBQ0Q1SCxJQUFJLENBQUMwRSxPQUFPLENBQUNnRCxFQUFFLENBQ2IsWUFBWSxFQUNabEYsTUFBTSxDQUFDNkQsZUFBZSxDQUFDaUIsWUFBWSxFQUFFLHlCQUF5QixDQUNoRSxDQUFDO1FBQ0gsQ0FBQyxNQUFNO1VBQ0x0SCxJQUFJLENBQUMwRSxPQUFPLENBQUNnRCxFQUFFLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQ0MsU0FBUyxDQUFDQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7VUFDckQ1SCxJQUFJLENBQUMwRSxPQUFPLENBQUNnRCxFQUFFLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQ0csT0FBTyxDQUFDRCxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7VUFDakQ1SCxJQUFJLENBQUMwRSxPQUFPLENBQUNnRCxFQUFFLENBQUMsWUFBWSxFQUFFSixZQUFZLENBQUM7UUFDN0M7TUFDRjs7TUFFQTtNQUNBO01BQ0E7TUFDQVEsa0JBQWtCQSxDQUFDQyxJQUFJLEVBQUVDLFlBQVksRUFBRTtRQUNyQyxNQUFNaEksSUFBSSxHQUFHLElBQUk7UUFFakIsSUFBSStILElBQUksSUFBSS9ILElBQUksQ0FBQ3FGLE9BQU8sRUFBRSxPQUFPLEtBQUs7O1FBRXRDO1FBQ0E7UUFDQSxNQUFNNEMsS0FBSyxHQUFHakUsTUFBTSxDQUFDQyxNQUFNLENBQUMsSUFBSSxDQUFDO1FBQ2pDLE1BQU1pRSxXQUFXLEdBQUcsQ0FDbEIsUUFBUSxFQUNSLGFBQWEsRUFDYixXQUFXLEVBQ1gsZUFBZSxFQUNmLG1CQUFtQixFQUNuQixRQUFRLEVBQ1IsZ0JBQWdCLENBQ2pCO1FBQ0RBLFdBQVcsQ0FBQ0MsT0FBTyxDQUFFQyxNQUFNLElBQUs7VUFDOUJILEtBQUssQ0FBQ0csTUFBTSxDQUFDLEdBQUcsWUFBYTtZQUMzQixJQUFJSixZQUFZLENBQUNJLE1BQU0sQ0FBQyxFQUFFO2NBQ3hCLE9BQU9KLFlBQVksQ0FBQ0ksTUFBTSxDQUFDLENBQUMsR0FBQUMsU0FBTyxDQUFDO1lBQ3RDO1VBQ0YsQ0FBQztRQUNILENBQUMsQ0FBQztRQUNGckksSUFBSSxDQUFDcUYsT0FBTyxDQUFDMEMsSUFBSSxDQUFDLEdBQUdFLEtBQUs7UUFDMUIsT0FBT0EsS0FBSztNQUNkO01BRUFLLG1CQUFtQkEsQ0FBQ1AsSUFBSSxFQUFFQyxZQUFZLEVBQUU7UUFDdEMsTUFBTWhJLElBQUksR0FBRyxJQUFJO1FBRWpCLE1BQU1pSSxLQUFLLEdBQUdqSSxJQUFJLENBQUM4SCxrQkFBa0IsQ0FBQ0MsSUFBSSxFQUFFQyxZQUFZLENBQUM7UUFFekQsTUFBTU8sTUFBTSxHQUFHdkksSUFBSSxDQUFDa0csd0JBQXdCLENBQUM2QixJQUFJLENBQUM7UUFDbEQsSUFBSVMsS0FBSyxDQUFDQyxPQUFPLENBQUNGLE1BQU0sQ0FBQyxFQUFFO1VBQ3pCTixLQUFLLENBQUNTLFdBQVcsQ0FBQ0gsTUFBTSxDQUFDSSxNQUFNLEVBQUUsS0FBSyxDQUFDO1VBQ3ZDSixNQUFNLENBQUNKLE9BQU8sQ0FBQ1MsR0FBRyxJQUFJO1lBQ3BCWCxLQUFLLENBQUNZLE1BQU0sQ0FBQ0QsR0FBRyxDQUFDO1VBQ25CLENBQUMsQ0FBQztVQUNGWCxLQUFLLENBQUNhLFNBQVMsQ0FBQyxDQUFDO1VBQ2pCLE9BQU85SSxJQUFJLENBQUNrRyx3QkFBd0IsQ0FBQzZCLElBQUksQ0FBQztRQUM1QztRQUVBLE9BQU8sSUFBSTtNQUNiO01BQ0EsTUFBTWdCLG1CQUFtQkEsQ0FBQ2hCLElBQUksRUFBRUMsWUFBWSxFQUFFO1FBQzVDLE1BQU1oSSxJQUFJLEdBQUcsSUFBSTtRQUVqQixNQUFNaUksS0FBSyxHQUFHakksSUFBSSxDQUFDOEgsa0JBQWtCLENBQUNDLElBQUksRUFBRUMsWUFBWSxDQUFDO1FBRXpELE1BQU1PLE1BQU0sR0FBR3ZJLElBQUksQ0FBQ2tHLHdCQUF3QixDQUFDNkIsSUFBSSxDQUFDO1FBQ2xELElBQUlTLEtBQUssQ0FBQ0MsT0FBTyxDQUFDRixNQUFNLENBQUMsRUFBRTtVQUN6QixNQUFNTixLQUFLLENBQUNTLFdBQVcsQ0FBQ0gsTUFBTSxDQUFDSSxNQUFNLEVBQUUsS0FBSyxDQUFDO1VBQzdDLEtBQUssTUFBTUMsR0FBRyxJQUFJTCxNQUFNLEVBQUU7WUFDeEIsTUFBTU4sS0FBSyxDQUFDWSxNQUFNLENBQUNELEdBQUcsQ0FBQztVQUN6QjtVQUNBLE1BQU1YLEtBQUssQ0FBQ2EsU0FBUyxDQUFDLENBQUM7VUFDdkIsT0FBTzlJLElBQUksQ0FBQ2tHLHdCQUF3QixDQUFDNkIsSUFBSSxDQUFDO1FBQzVDO1FBRUEsT0FBTyxJQUFJO01BQ2I7O01BRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7TUFDRWlCLFNBQVNBLENBQUNqQixJQUFJLENBQUMsOENBQThDO1FBQzNELE1BQU0vSCxJQUFJLEdBQUcsSUFBSTtRQUVqQixNQUFNaUosTUFBTSxHQUFHakcsS0FBSyxDQUFDa0csSUFBSSxDQUFDYixTQUFTLEVBQUUsQ0FBQyxDQUFDO1FBQ3ZDLElBQUljLFNBQVMsR0FBR25GLE1BQU0sQ0FBQ0MsTUFBTSxDQUFDLElBQUksQ0FBQztRQUNuQyxJQUFJZ0YsTUFBTSxDQUFDTixNQUFNLEVBQUU7VUFDakIsTUFBTVMsU0FBUyxHQUFHSCxNQUFNLENBQUNBLE1BQU0sQ0FBQ04sTUFBTSxHQUFHLENBQUMsQ0FBQztVQUMzQyxJQUFJLE9BQU9TLFNBQVMsS0FBSyxVQUFVLEVBQUU7WUFDbkNELFNBQVMsQ0FBQ0UsT0FBTyxHQUFHSixNQUFNLENBQUNLLEdBQUcsQ0FBQyxDQUFDO1VBQ2xDLENBQUMsTUFBTSxJQUFJRixTQUFTLElBQUksQ0FDdEJBLFNBQVMsQ0FBQ0MsT0FBTztVQUNqQjtVQUNBO1VBQ0FELFNBQVMsQ0FBQ0csT0FBTyxFQUNqQkgsU0FBUyxDQUFDSSxNQUFNLENBQ2pCLENBQUNDLElBQUksQ0FBQ0MsQ0FBQyxJQUFJLE9BQU9BLENBQUMsS0FBSyxVQUFVLENBQUMsRUFBRTtZQUNwQ1AsU0FBUyxHQUFHRixNQUFNLENBQUNLLEdBQUcsQ0FBQyxDQUFDO1VBQzFCO1FBQ0Y7O1FBRUE7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0EsTUFBTUssUUFBUSxHQUFHM0YsTUFBTSxDQUFDNEYsTUFBTSxDQUFDNUosSUFBSSxDQUFDNEcsY0FBYyxDQUFDLENBQUNpRCxJQUFJLENBQ3REQyxHQUFHLElBQUtBLEdBQUcsQ0FBQ0MsUUFBUSxJQUFJRCxHQUFHLENBQUMvQixJQUFJLEtBQUtBLElBQUksSUFBSXBGLEtBQUssQ0FBQ3FILE1BQU0sQ0FBQ0YsR0FBRyxDQUFDYixNQUFNLEVBQUVBLE1BQU0sQ0FDOUUsQ0FBQztRQUVELElBQUlnQixFQUFFO1FBQ04sSUFBSU4sUUFBUSxFQUFFO1VBQ1pNLEVBQUUsR0FBR04sUUFBUSxDQUFDTSxFQUFFO1VBQ2hCTixRQUFRLENBQUNJLFFBQVEsR0FBRyxLQUFLLENBQUMsQ0FBQzs7VUFFM0IsSUFBSVosU0FBUyxDQUFDRSxPQUFPLEVBQUU7WUFDckI7WUFDQTtZQUNBO1lBQ0E7WUFDQTtZQUNBO1lBQ0E7WUFDQTtZQUNBO1lBQ0EsSUFBSU0sUUFBUSxDQUFDTyxLQUFLLEVBQUU7Y0FDbEJmLFNBQVMsQ0FBQ0UsT0FBTyxDQUFDLENBQUM7WUFDckIsQ0FBQyxNQUFNO2NBQ0xNLFFBQVEsQ0FBQ1EsYUFBYSxHQUFHaEIsU0FBUyxDQUFDRSxPQUFPO1lBQzVDO1VBQ0Y7O1VBRUE7VUFDQTtVQUNBLElBQUlGLFNBQVMsQ0FBQ0ksT0FBTyxFQUFFO1lBQ3JCO1lBQ0E7WUFDQUksUUFBUSxDQUFDUyxhQUFhLEdBQUdqQixTQUFTLENBQUNJLE9BQU87VUFDNUM7VUFFQSxJQUFJSixTQUFTLENBQUNLLE1BQU0sRUFBRTtZQUNwQkcsUUFBUSxDQUFDVSxZQUFZLEdBQUdsQixTQUFTLENBQUNLLE1BQU07VUFDMUM7UUFDRixDQUFDLE1BQU07VUFDTDtVQUNBUyxFQUFFLEdBQUdySCxNQUFNLENBQUNxSCxFQUFFLENBQUMsQ0FBQztVQUNoQmpLLElBQUksQ0FBQzRHLGNBQWMsQ0FBQ3FELEVBQUUsQ0FBQyxHQUFHO1lBQ3hCQSxFQUFFLEVBQUVBLEVBQUU7WUFDTmxDLElBQUksRUFBRUEsSUFBSTtZQUNWa0IsTUFBTSxFQUFFdEcsS0FBSyxDQUFDMkgsS0FBSyxDQUFDckIsTUFBTSxDQUFDO1lBQzNCYyxRQUFRLEVBQUUsS0FBSztZQUNmRyxLQUFLLEVBQUUsS0FBSztZQUNaSyxTQUFTLEVBQUUsSUFBSTdILE9BQU8sQ0FBQ3FFLFVBQVUsQ0FBQyxDQUFDO1lBQ25Db0QsYUFBYSxFQUFFaEIsU0FBUyxDQUFDRSxPQUFPO1lBQ2hDO1lBQ0FlLGFBQWEsRUFBRWpCLFNBQVMsQ0FBQ0ksT0FBTztZQUNoQ2MsWUFBWSxFQUFFbEIsU0FBUyxDQUFDSyxNQUFNO1lBQzlCNUksVUFBVSxFQUFFWixJQUFJO1lBQ2hCd0ssTUFBTUEsQ0FBQSxFQUFHO2NBQ1AsT0FBTyxJQUFJLENBQUM1SixVQUFVLENBQUNnRyxjQUFjLENBQUMsSUFBSSxDQUFDcUQsRUFBRSxDQUFDO2NBQzlDLElBQUksQ0FBQ0MsS0FBSyxJQUFJLElBQUksQ0FBQ0ssU0FBUyxDQUFDRSxPQUFPLENBQUMsQ0FBQztZQUN4QyxDQUFDO1lBQ0RqRCxJQUFJQSxDQUFBLEVBQUc7Y0FDTCxJQUFJLENBQUM1RyxVQUFVLENBQUM4SixXQUFXLENBQUM7Z0JBQUU5QixHQUFHLEVBQUUsT0FBTztnQkFBRXFCLEVBQUUsRUFBRUE7Y0FBRyxDQUFDLENBQUM7Y0FDckQsSUFBSSxDQUFDTyxNQUFNLENBQUMsQ0FBQztjQUViLElBQUlyQixTQUFTLENBQUNLLE1BQU0sRUFBRTtnQkFDcEJMLFNBQVMsQ0FBQ0ssTUFBTSxDQUFDLENBQUM7Y0FDcEI7WUFDRjtVQUNGLENBQUM7VUFDRHhKLElBQUksQ0FBQzJCLEtBQUssQ0FBQztZQUFFaUgsR0FBRyxFQUFFLEtBQUs7WUFBRXFCLEVBQUUsRUFBRUEsRUFBRTtZQUFFbEMsSUFBSSxFQUFFQSxJQUFJO1lBQUVrQixNQUFNLEVBQUVBO1VBQU8sQ0FBQyxDQUFDO1FBQ2hFOztRQUVBO1FBQ0EsTUFBTTBCLE1BQU0sR0FBRztVQUNibkQsSUFBSUEsQ0FBQSxFQUFHO1lBQ0wsSUFBSSxDQUFFekUsTUFBTSxDQUFDbUcsSUFBSSxDQUFDbEosSUFBSSxDQUFDNEcsY0FBYyxFQUFFcUQsRUFBRSxDQUFDLEVBQUU7Y0FDMUM7WUFDRjtZQUNBakssSUFBSSxDQUFDNEcsY0FBYyxDQUFDcUQsRUFBRSxDQUFDLENBQUN6QyxJQUFJLENBQUMsQ0FBQztVQUNoQyxDQUFDO1VBQ0QwQyxLQUFLQSxDQUFBLEVBQUc7WUFDTjtZQUNBLElBQUksQ0FBQ25ILE1BQU0sQ0FBQ21HLElBQUksQ0FBQ2xKLElBQUksQ0FBQzRHLGNBQWMsRUFBRXFELEVBQUUsQ0FBQyxFQUFFO2NBQ3pDLE9BQU8sS0FBSztZQUNkO1lBQ0EsTUFBTVcsTUFBTSxHQUFHNUssSUFBSSxDQUFDNEcsY0FBYyxDQUFDcUQsRUFBRSxDQUFDO1lBQ3RDVyxNQUFNLENBQUNMLFNBQVMsQ0FBQ00sTUFBTSxDQUFDLENBQUM7WUFDekIsT0FBT0QsTUFBTSxDQUFDVixLQUFLO1VBQ3JCLENBQUM7VUFDRFksY0FBYyxFQUFFYjtRQUNsQixDQUFDO1FBRUQsSUFBSXZILE9BQU8sQ0FBQ3FJLE1BQU0sRUFBRTtVQUNsQjtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQXJJLE9BQU8sQ0FBQ3NJLFlBQVksQ0FBRUMsQ0FBQyxJQUFLO1lBQzFCLElBQUlsSSxNQUFNLENBQUNtRyxJQUFJLENBQUNsSixJQUFJLENBQUM0RyxjQUFjLEVBQUVxRCxFQUFFLENBQUMsRUFBRTtjQUN4Q2pLLElBQUksQ0FBQzRHLGNBQWMsQ0FBQ3FELEVBQUUsQ0FBQyxDQUFDRixRQUFRLEdBQUcsSUFBSTtZQUN6QztZQUVBckgsT0FBTyxDQUFDd0ksVUFBVSxDQUFDLE1BQU07Y0FDdkIsSUFBSW5JLE1BQU0sQ0FBQ21HLElBQUksQ0FBQ2xKLElBQUksQ0FBQzRHLGNBQWMsRUFBRXFELEVBQUUsQ0FBQyxJQUNwQ2pLLElBQUksQ0FBQzRHLGNBQWMsQ0FBQ3FELEVBQUUsQ0FBQyxDQUFDRixRQUFRLEVBQUU7Z0JBQ3BDWSxNQUFNLENBQUNuRCxJQUFJLENBQUMsQ0FBQztjQUNmO1lBQ0YsQ0FBQyxDQUFDO1VBQ0osQ0FBQyxDQUFDO1FBQ0o7UUFFQSxPQUFPbUQsTUFBTTtNQUNmOztNQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7TUFDRVEsV0FBV0EsQ0FBQSxFQUFFO1FBQ1gsT0FBT3ZMLEdBQUcsQ0FBQ3dMLHdCQUF3QixDQUFDQyx5QkFBeUIsQ0FBQyxDQUFDO01BQ2pFO01BQ0FDLE9BQU9BLENBQUNBLE9BQU8sRUFBRTtRQUNmdEgsTUFBTSxDQUFDdUgsT0FBTyxDQUFDRCxPQUFPLENBQUMsQ0FBQ25ELE9BQU8sQ0FBQ3FELElBQUEsSUFBa0I7VUFBQSxJQUFqQixDQUFDekQsSUFBSSxFQUFFMEQsSUFBSSxDQUFDLEdBQUFELElBQUE7VUFDM0MsSUFBSSxPQUFPQyxJQUFJLEtBQUssVUFBVSxFQUFFO1lBQzlCLE1BQU0sSUFBSWhLLEtBQUssQ0FBQyxVQUFVLEdBQUdzRyxJQUFJLEdBQUcsc0JBQXNCLENBQUM7VUFDN0Q7VUFDQSxJQUFJLElBQUksQ0FBQ3pDLGVBQWUsQ0FBQ3lDLElBQUksQ0FBQyxFQUFFO1lBQzlCLE1BQU0sSUFBSXRHLEtBQUssQ0FBQyxrQkFBa0IsR0FBR3NHLElBQUksR0FBRyxzQkFBc0IsQ0FBQztVQUNyRTtVQUNBLElBQUksQ0FBQ3pDLGVBQWUsQ0FBQ3lDLElBQUksQ0FBQyxHQUFHMEQsSUFBSTtRQUNuQyxDQUFDLENBQUM7TUFDSjtNQUVBQyxnQkFBZ0JBLENBQUFDLEtBQUEsRUFBeUM7UUFBQSxJQUF4QztVQUFDQyxlQUFlO1VBQUVDO1FBQW1CLENBQUMsR0FBQUYsS0FBQTtRQUNyRCxJQUFJLENBQUNDLGVBQWUsRUFBRTtVQUNwQixPQUFPQyxtQkFBbUI7UUFDNUI7UUFDQSxPQUFPQSxtQkFBbUIsSUFBSWpNLEdBQUcsQ0FBQ3dMLHdCQUF3QixDQUFDQyx5QkFBeUIsQ0FBQyxDQUFDO01BQ3hGOztNQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO01BQ0VuQyxJQUFJQSxDQUFDbkIsSUFBSSxDQUFDLGtDQUFrQztRQUMxQztRQUNBO1FBQ0EsTUFBTStELElBQUksR0FBRzlJLEtBQUssQ0FBQ2tHLElBQUksQ0FBQ2IsU0FBUyxFQUFFLENBQUMsQ0FBQztRQUNyQyxJQUFJM0gsUUFBUTtRQUNaLElBQUlvTCxJQUFJLENBQUNuRCxNQUFNLElBQUksT0FBT21ELElBQUksQ0FBQ0EsSUFBSSxDQUFDbkQsTUFBTSxHQUFHLENBQUMsQ0FBQyxLQUFLLFVBQVUsRUFBRTtVQUM5RGpJLFFBQVEsR0FBR29MLElBQUksQ0FBQ3hDLEdBQUcsQ0FBQyxDQUFDO1FBQ3ZCO1FBQ0EsT0FBTyxJQUFJLENBQUN5QyxLQUFLLENBQUNoRSxJQUFJLEVBQUUrRCxJQUFJLEVBQUVwTCxRQUFRLENBQUM7TUFDekM7TUFDQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtNQUNFc0wsU0FBU0EsQ0FBQ2pFLElBQUksQ0FBQyx5QkFBeUI7UUFDdEMsTUFBTStELElBQUksR0FBRzlJLEtBQUssQ0FBQ2tHLElBQUksQ0FBQ2IsU0FBUyxFQUFFLENBQUMsQ0FBQztRQUNyQyxJQUFJeUQsSUFBSSxDQUFDbkQsTUFBTSxJQUFJLE9BQU9tRCxJQUFJLENBQUNBLElBQUksQ0FBQ25ELE1BQU0sR0FBRyxDQUFDLENBQUMsS0FBSyxVQUFVLEVBQUU7VUFDOUQsTUFBTSxJQUFJbEgsS0FBSyxDQUNiLCtGQUNGLENBQUM7UUFDSDtRQUVBLE9BQU8sSUFBSSxDQUFDd0ssVUFBVSxDQUFDbEUsSUFBSSxFQUFFK0QsSUFBSSxFQUFFO1VBQUVJLHlCQUF5QixFQUFFO1FBQUssQ0FBQyxDQUFDO01BQ3pFOztNQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO01BQ0VILEtBQUtBLENBQUNoRSxJQUFJLEVBQUUrRCxJQUFJLEVBQUV4TCxPQUFPLEVBQUVJLFFBQVEsRUFBRTtRQUNuQyxNQUFBeUwsZUFBQSxHQUF1RCxJQUFJLENBQUNDLFNBQVMsQ0FBQ3JFLElBQUksRUFBRXBGLEtBQUssQ0FBQzJILEtBQUssQ0FBQ3dCLElBQUksQ0FBQyxDQUFDO1VBQXhGO1lBQUVPLGNBQWM7WUFBRUM7VUFBMkIsQ0FBQyxHQUFBSCxlQUFBO1VBQWJJLFdBQVcsR0FBQXJLLHdCQUFBLENBQUFpSyxlQUFBLEVBQUE5SixTQUFBO1FBRWxELElBQUlrSyxXQUFXLENBQUNDLE9BQU8sRUFBRTtVQUN2QixJQUNFLENBQUMsSUFBSSxDQUFDZCxnQkFBZ0IsQ0FBQztZQUNyQkcsbUJBQW1CLEVBQUVVLFdBQVcsQ0FBQ1YsbUJBQW1CO1lBQ3BERCxlQUFlLEVBQUVXLFdBQVcsQ0FBQ1g7VUFDL0IsQ0FBQyxDQUFDLEVBQ0Y7WUFDQSxJQUFJLENBQUNhLGNBQWMsQ0FBQyxDQUFDO1VBQ3ZCO1VBQ0EsSUFBSTtZQUNGRixXQUFXLENBQUNHLGVBQWUsR0FBRzlNLEdBQUcsQ0FBQ3dMLHdCQUF3QixDQUN2RHVCLFNBQVMsQ0FBQ0wsVUFBVSxFQUFFRCxjQUFjLENBQUM7WUFDeEMsSUFBSTdKLE1BQU0sQ0FBQ29LLFVBQVUsQ0FBQ0wsV0FBVyxDQUFDRyxlQUFlLENBQUMsRUFBRTtjQUNsRGxLLE1BQU0sQ0FBQ29CLE1BQU0sV0FBQWlKLE1BQUEsQ0FDRDlFLElBQUkseUlBQ2hCLENBQUM7WUFDSDtVQUNGLENBQUMsQ0FBQyxPQUFPK0UsQ0FBQyxFQUFFO1lBQ1ZQLFdBQVcsQ0FBQ1EsU0FBUyxHQUFHRCxDQUFDO1VBQzNCO1FBQ0Y7UUFDQSxPQUFPLElBQUksQ0FBQ0UsTUFBTSxDQUFDakYsSUFBSSxFQUFFd0UsV0FBVyxFQUFFVCxJQUFJLEVBQUV4TCxPQUFPLEVBQUVJLFFBQVEsQ0FBQztNQUNoRTs7TUFFQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7TUFDRXVMLFVBQVVBLENBQUNsRSxJQUFJLEVBQUUrRCxJQUFJLEVBQUV4TCxPQUFPLEVBQW1CO1FBQUEsSUFBakJJLFFBQVEsR0FBQTJILFNBQUEsQ0FBQU0sTUFBQSxRQUFBTixTQUFBLFFBQUE0RSxTQUFBLEdBQUE1RSxTQUFBLE1BQUcsSUFBSTtRQUM3QyxNQUFNNkUsV0FBVyxHQUFHLElBQUksQ0FBQ0MseUJBQXlCLENBQUNwRixJQUFJLEVBQUUrRCxJQUFJLEVBQUV4TCxPQUFPLENBQUM7UUFFdkUsTUFBTThNLE9BQU8sR0FBRyxJQUFJLENBQUNDLFdBQVcsQ0FBQztVQUMvQnRGLElBQUk7VUFDSitELElBQUk7VUFDSnhMLE9BQU87VUFDUEksUUFBUTtVQUNSd007UUFDRixDQUFDLENBQUM7UUFDRixJQUFJMUssTUFBTSxDQUFDd0UsUUFBUSxFQUFFO1VBQ25CO1VBQ0FvRyxPQUFPLENBQUNGLFdBQVcsR0FBR0EsV0FBVyxDQUFDSSxJQUFJLENBQUNDLENBQUMsSUFBSTtZQUMxQyxJQUFJQSxDQUFDLENBQUNSLFNBQVMsRUFBRTtjQUNmLE1BQU1RLENBQUMsQ0FBQ1IsU0FBUztZQUNuQjtZQUNBLE9BQU9RLENBQUMsQ0FBQ2IsZUFBZTtVQUMxQixDQUFDLENBQUM7VUFDRjtVQUNBVSxPQUFPLENBQUNJLGFBQWEsR0FBRyxJQUFJQyxPQUFPLENBQUMsQ0FBQ0MsT0FBTyxFQUFFQyxNQUFNLEtBQ2xEUCxPQUFPLENBQUNFLElBQUksQ0FBQ0ksT0FBTyxDQUFDLENBQUNFLEtBQUssQ0FBQ0QsTUFBTSxDQUNwQyxDQUFDO1FBQ0g7UUFDQSxPQUFPUCxPQUFPO01BQ2hCO01BQ0EsTUFBTUQseUJBQXlCQSxDQUFDcEYsSUFBSSxFQUFFK0QsSUFBSSxFQUFFeEwsT0FBTyxFQUFFO1FBQ25ELE1BQUF1TixnQkFBQSxHQUF1RCxJQUFJLENBQUN6QixTQUFTLENBQUNyRSxJQUFJLEVBQUVwRixLQUFLLENBQUMySCxLQUFLLENBQUN3QixJQUFJLENBQUMsRUFBRXhMLE9BQU8sQ0FBQztVQUFqRztZQUFFK0wsY0FBYztZQUFFQztVQUEyQixDQUFDLEdBQUF1QixnQkFBQTtVQUFidEIsV0FBVyxHQUFBckssd0JBQUEsQ0FBQTJMLGdCQUFBLEVBQUF2TCxVQUFBO1FBQ2xELElBQUlpSyxXQUFXLENBQUNDLE9BQU8sRUFBRTtVQUN2QixJQUNFLENBQUMsSUFBSSxDQUFDZCxnQkFBZ0IsQ0FBQztZQUNyQkcsbUJBQW1CLEVBQUVVLFdBQVcsQ0FBQ1YsbUJBQW1CO1lBQ3BERCxlQUFlLEVBQUVXLFdBQVcsQ0FBQ1g7VUFDL0IsQ0FBQyxDQUFDLEVBQ0Y7WUFDQSxJQUFJLENBQUNhLGNBQWMsQ0FBQyxDQUFDO1VBQ3ZCO1VBQ0EsSUFBSTtZQUNGO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7WUFDUSxNQUFNcUIsY0FBYyxHQUFHbE8sR0FBRyxDQUFDd0wsd0JBQXdCLENBQUMyQywyQkFBMkIsQ0FDN0V6QixVQUNGLENBQUM7WUFDRCxJQUFJO2NBQ0ZDLFdBQVcsQ0FBQ0csZUFBZSxHQUFHLE1BQU1MLGNBQWMsQ0FBQyxDQUFDO1lBQ3RELENBQUMsQ0FBQyxPQUFPUyxDQUFDLEVBQUU7Y0FDVlAsV0FBVyxDQUFDUSxTQUFTLEdBQUdELENBQUM7WUFDM0IsQ0FBQyxTQUFTO2NBQ1JsTixHQUFHLENBQUN3TCx3QkFBd0IsQ0FBQzRDLElBQUksQ0FBQ0YsY0FBYyxDQUFDO1lBQ25EO1VBQ0YsQ0FBQyxDQUFDLE9BQU9oQixDQUFDLEVBQUU7WUFDVlAsV0FBVyxDQUFDUSxTQUFTLEdBQUdELENBQUM7VUFDM0I7UUFDRjtRQUNBLE9BQU9QLFdBQVc7TUFDcEI7TUFDQSxNQUFNYyxXQUFXQSxDQUFBWSxLQUFBLEVBQWlEO1FBQUEsSUFBaEQ7VUFBRWxHLElBQUk7VUFBRStELElBQUk7VUFBRXhMLE9BQU87VUFBRUksUUFBUTtVQUFFd007UUFBWSxDQUFDLEdBQUFlLEtBQUE7UUFDOUQsTUFBTTFCLFdBQVcsR0FBRyxNQUFNVyxXQUFXO1FBQ3JDLE9BQU8sSUFBSSxDQUFDRixNQUFNLENBQUNqRixJQUFJLEVBQUV3RSxXQUFXLEVBQUVULElBQUksRUFBRXhMLE9BQU8sRUFBRUksUUFBUSxDQUFDO01BQ2hFO01BRUFzTSxNQUFNQSxDQUFDakYsSUFBSSxFQUFFbUcsYUFBYSxFQUFFcEMsSUFBSSxFQUFFeEwsT0FBTyxFQUFFSSxRQUFRLEVBQUU7UUFDbkQsTUFBTVYsSUFBSSxHQUFHLElBQUk7UUFDakI7UUFDQTtRQUNBLElBQUksQ0FBQ1UsUUFBUSxJQUFJLE9BQU9KLE9BQU8sS0FBSyxVQUFVLEVBQUU7VUFDOUNJLFFBQVEsR0FBR0osT0FBTztVQUNsQkEsT0FBTyxHQUFHMEQsTUFBTSxDQUFDQyxNQUFNLENBQUMsSUFBSSxDQUFDO1FBQy9CO1FBQ0EzRCxPQUFPLEdBQUdBLE9BQU8sSUFBSTBELE1BQU0sQ0FBQ0MsTUFBTSxDQUFDLElBQUksQ0FBQztRQUV4QyxJQUFJdkQsUUFBUSxFQUFFO1VBQ1o7VUFDQTtVQUNBO1VBQ0FBLFFBQVEsR0FBRzhCLE1BQU0sQ0FBQzZELGVBQWUsQ0FDL0IzRixRQUFRLEVBQ1IsaUNBQWlDLEdBQUdxSCxJQUFJLEdBQUcsR0FDN0MsQ0FBQztRQUNIO1FBQ0EsTUFBTTtVQUNKeUUsT0FBTztVQUNQTyxTQUFTO1VBQ1RMLGVBQWU7VUFDZmIsbUJBQW1CO1VBQ25Cc0M7UUFDRixDQUFDLEdBQUdELGFBQWE7O1FBRWpCO1FBQ0E7UUFDQXBDLElBQUksR0FBR25KLEtBQUssQ0FBQzJILEtBQUssQ0FBQ3dCLElBQUksQ0FBQztRQUN4QjtRQUNBO1FBQ0E7UUFDQSxJQUNFLElBQUksQ0FBQ0osZ0JBQWdCLENBQUM7VUFDcEJHLG1CQUFtQjtVQUNuQkQsZUFBZSxFQUFFc0MsYUFBYSxDQUFDdEM7UUFDakMsQ0FBQyxDQUFDLEVBQ0Y7VUFDQSxJQUFJbEwsUUFBUSxFQUFFO1lBQ1pBLFFBQVEsQ0FBQ3FNLFNBQVMsRUFBRUwsZUFBZSxDQUFDO1lBQ3BDLE9BQU9PLFNBQVM7VUFDbEI7VUFDQSxJQUFJRixTQUFTLEVBQUUsTUFBTUEsU0FBUztVQUM5QixPQUFPTCxlQUFlO1FBQ3hCOztRQUVBO1FBQ0E7UUFDQSxNQUFNbk0sUUFBUSxHQUFHLEVBQUUsR0FBR1AsSUFBSSxDQUFDdUYsYUFBYSxFQUFFO1FBQzFDLElBQUlpSCxPQUFPLEVBQUU7VUFDWHhNLElBQUksQ0FBQ29PLDBCQUEwQixDQUFDN04sUUFBUSxDQUFDO1FBQzNDOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0EsTUFBTU8sT0FBTyxHQUFHO1VBQ2Q4SCxHQUFHLEVBQUUsUUFBUTtVQUNicUIsRUFBRSxFQUFFMUosUUFBUTtVQUNaNkgsTUFBTSxFQUFFTCxJQUFJO1VBQ1prQixNQUFNLEVBQUU2QztRQUNWLENBQUM7O1FBRUQ7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQSxJQUFJaUIsU0FBUyxFQUFFO1VBQ2IsSUFBSXpNLE9BQU8sQ0FBQytOLG1CQUFtQixFQUFFO1lBQy9CLE1BQU10QixTQUFTO1VBQ2pCLENBQUMsTUFBTSxJQUFJLENBQUNBLFNBQVMsQ0FBQ3VCLGVBQWUsRUFBRTtZQUNyQzlMLE1BQU0sQ0FBQ29CLE1BQU0sQ0FDWCxxREFBcUQsR0FBR21FLElBQUksR0FBRyxHQUFHLEVBQ2xFZ0YsU0FDRixDQUFDO1VBQ0g7UUFDRjs7UUFFQTtRQUNBOztRQUVBO1FBQ0EsSUFBSXdCLE1BQU07UUFDVixJQUFJLENBQUM3TixRQUFRLEVBQUU7VUFDYixJQUNFOEIsTUFBTSxDQUFDd0UsUUFBUSxJQUNmLENBQUMxRyxPQUFPLENBQUM0TCx5QkFBeUIsS0FDakMsQ0FBQzVMLE9BQU8sQ0FBQ3NMLGVBQWUsSUFBSXRMLE9BQU8sQ0FBQ2tPLGVBQWUsQ0FBQyxFQUNyRDtZQUNBO1lBQ0E7WUFDQTtZQUNBO1lBQ0E5TixRQUFRLEdBQUlxQixHQUFHLElBQUs7Y0FDbEJBLEdBQUcsSUFBSVMsTUFBTSxDQUFDb0IsTUFBTSxDQUFDLHlCQUF5QixHQUFHbUUsSUFBSSxHQUFHLEdBQUcsRUFBRWhHLEdBQUcsQ0FBQztZQUNuRSxDQUFDO1VBQ0gsQ0FBQyxNQUFNO1lBQ0w7WUFDQTtZQUNBd00sTUFBTSxHQUFHLElBQUlkLE9BQU8sQ0FBQyxDQUFDQyxPQUFPLEVBQUVDLE1BQU0sS0FBSztjQUN4Q2pOLFFBQVEsR0FBRyxTQUFBQSxDQUFBLEVBQWdCO2dCQUFBLFNBQUErTixJQUFBLEdBQUFwRyxTQUFBLENBQUFNLE1BQUEsRUFBWitGLE9BQU8sT0FBQWxHLEtBQUEsQ0FBQWlHLElBQUEsR0FBQUUsSUFBQSxNQUFBQSxJQUFBLEdBQUFGLElBQUEsRUFBQUUsSUFBQTtrQkFBUEQsT0FBTyxDQUFBQyxJQUFBLElBQUF0RyxTQUFBLENBQUFzRyxJQUFBO2dCQUFBO2dCQUNwQixJQUFJN0MsSUFBSSxHQUFHdEQsS0FBSyxDQUFDb0csSUFBSSxDQUFDRixPQUFPLENBQUM7Z0JBQzlCLElBQUkzTSxHQUFHLEdBQUcrSixJQUFJLENBQUMrQyxLQUFLLENBQUMsQ0FBQztnQkFDdEIsSUFBSTlNLEdBQUcsRUFBRTtrQkFDUDRMLE1BQU0sQ0FBQzVMLEdBQUcsQ0FBQztrQkFDWDtnQkFDRjtnQkFDQTJMLE9BQU8sQ0FBQyxHQUFHNUIsSUFBSSxDQUFDO2NBQ2xCLENBQUM7WUFDSCxDQUFDLENBQUM7VUFDSjtRQUNGOztRQUVBO1FBQ0EsSUFBSXFDLFVBQVUsQ0FBQ1csS0FBSyxLQUFLLElBQUksRUFBRTtVQUM3QmhPLE9BQU8sQ0FBQ3FOLFVBQVUsR0FBR0EsVUFBVSxDQUFDVyxLQUFLO1FBQ3ZDO1FBRUEsTUFBTUMsYUFBYSxHQUFHLElBQUkzTyxhQUFhLENBQUM7VUFDdENHLFFBQVE7VUFDUkcsUUFBUSxFQUFFQSxRQUFRO1VBQ2xCRSxVQUFVLEVBQUVaLElBQUk7VUFDaEJnQixnQkFBZ0IsRUFBRVYsT0FBTyxDQUFDVSxnQkFBZ0I7VUFDMUNFLElBQUksRUFBRSxDQUFDLENBQUNaLE9BQU8sQ0FBQ1ksSUFBSTtVQUNwQkosT0FBTyxFQUFFQSxPQUFPO1VBQ2hCSyxPQUFPLEVBQUUsQ0FBQyxDQUFDYixPQUFPLENBQUNhO1FBQ3JCLENBQUMsQ0FBQztRQUVGLElBQUliLE9BQU8sQ0FBQ1ksSUFBSSxFQUFFO1VBQ2hCO1VBQ0FsQixJQUFJLENBQUMyRix3QkFBd0IsQ0FBQ3FKLElBQUksQ0FBQztZQUNqQzlOLElBQUksRUFBRSxJQUFJO1lBQ1ZvSyxPQUFPLEVBQUUsQ0FBQ3lELGFBQWE7VUFDekIsQ0FBQyxDQUFDO1FBQ0osQ0FBQyxNQUFNO1VBQ0w7VUFDQTtVQUNBLElBQUk3TCxPQUFPLENBQUNsRCxJQUFJLENBQUMyRix3QkFBd0IsQ0FBQyxJQUN0Q3hDLElBQUksQ0FBQ25ELElBQUksQ0FBQzJGLHdCQUF3QixDQUFDLENBQUN6RSxJQUFJLEVBQUU7WUFDNUNsQixJQUFJLENBQUMyRix3QkFBd0IsQ0FBQ3FKLElBQUksQ0FBQztjQUNqQzlOLElBQUksRUFBRSxLQUFLO2NBQ1hvSyxPQUFPLEVBQUU7WUFDWCxDQUFDLENBQUM7VUFDSjtVQUVBbkksSUFBSSxDQUFDbkQsSUFBSSxDQUFDMkYsd0JBQXdCLENBQUMsQ0FBQzJGLE9BQU8sQ0FBQzBELElBQUksQ0FBQ0QsYUFBYSxDQUFDO1FBQ2pFOztRQUVBO1FBQ0EsSUFBSS9PLElBQUksQ0FBQzJGLHdCQUF3QixDQUFDZ0QsTUFBTSxLQUFLLENBQUMsRUFBRW9HLGFBQWEsQ0FBQ3hOLFdBQVcsQ0FBQyxDQUFDOztRQUUzRTtRQUNBO1FBQ0EsSUFBSWdOLE1BQU0sRUFBRTtVQUNWO1VBQ0E7VUFDQTtVQUNBO1VBQ0EsSUFBSWpPLE9BQU8sQ0FBQ2tPLGVBQWUsRUFBRTtZQUMzQixPQUFPRCxNQUFNLENBQUNqQixJQUFJLENBQUMsTUFBTVosZUFBZSxDQUFDO1VBQzNDO1VBQ0EsT0FBTzZCLE1BQU07UUFDZjtRQUNBLE9BQU9qTyxPQUFPLENBQUNrTyxlQUFlLEdBQUc5QixlQUFlLEdBQUdPLFNBQVM7TUFDOUQ7TUFHQWIsU0FBU0EsQ0FBQ3JFLElBQUksRUFBRStELElBQUksRUFBRXhMLE9BQU8sRUFBRTtRQUM3QjtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0EsTUFBTU4sSUFBSSxHQUFHLElBQUk7UUFDakIsTUFBTWlQLFNBQVMsR0FBR3JQLEdBQUcsQ0FBQ3dMLHdCQUF3QixDQUFDOEQsR0FBRyxDQUFDLENBQUM7UUFDcEQsTUFBTUMsSUFBSSxHQUFHblAsSUFBSSxDQUFDc0YsZUFBZSxDQUFDeUMsSUFBSSxDQUFDO1FBQ3ZDLE1BQU04RCxtQkFBbUIsR0FBR29ELFNBQVMsYUFBVEEsU0FBUyx1QkFBVEEsU0FBUyxDQUFFRyxZQUFZO1FBQ25ELE1BQU14RCxlQUFlLEdBQUdxRCxTQUFTLGFBQVRBLFNBQVMsdUJBQVRBLFNBQVMsQ0FBRUksZ0JBQWdCO1FBQ25ELE1BQU1sQixVQUFVLEdBQUc7VUFBRVcsS0FBSyxFQUFFO1FBQUksQ0FBQztRQUVqQyxNQUFNUSxhQUFhLEdBQUc7VUFDcEJ6RCxtQkFBbUI7VUFDbkJzQyxVQUFVO1VBQ1Z2QztRQUNGLENBQUM7UUFDRCxJQUFJLENBQUN1RCxJQUFJLEVBQUU7VUFDVCxPQUFBL00sYUFBQSxDQUFBQSxhQUFBLEtBQVlrTixhQUFhO1lBQUU5QyxPQUFPLEVBQUU7VUFBSztRQUMzQzs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTs7UUFFQSxNQUFNK0MsbUJBQW1CLEdBQUdBLENBQUEsS0FBTTtVQUNoQyxJQUFJcEIsVUFBVSxDQUFDVyxLQUFLLEtBQUssSUFBSSxFQUFFO1lBQzdCWCxVQUFVLENBQUNXLEtBQUssR0FBR3JNLFNBQVMsQ0FBQytNLFdBQVcsQ0FBQ1AsU0FBUyxFQUFFbEgsSUFBSSxDQUFDO1VBQzNEO1VBQ0EsT0FBT29HLFVBQVUsQ0FBQ1csS0FBSztRQUN6QixDQUFDO1FBRUQsTUFBTVcsU0FBUyxHQUFHQyxNQUFNLElBQUk7VUFDMUIxUCxJQUFJLENBQUN5UCxTQUFTLENBQUNDLE1BQU0sQ0FBQztRQUN4QixDQUFDO1FBRUQsTUFBTXBELFVBQVUsR0FBRyxJQUFJN0osU0FBUyxDQUFDa04sZ0JBQWdCLENBQUM7VUFDaEQ1SCxJQUFJO1VBQ0pxSCxZQUFZLEVBQUUsSUFBSTtVQUNsQk0sTUFBTSxFQUFFMVAsSUFBSSxDQUFDMFAsTUFBTSxDQUFDLENBQUM7VUFDckI5RCxlQUFlLEVBQUV0TCxPQUFPLGFBQVBBLE9BQU8sdUJBQVBBLE9BQU8sQ0FBRXNMLGVBQWU7VUFDekM2RCxTQUFTLEVBQUVBLFNBQVM7VUFDcEJ0QixVQUFVQSxDQUFBLEVBQUc7WUFDWCxPQUFPb0IsbUJBQW1CLENBQUMsQ0FBQztVQUM5QjtRQUNGLENBQUMsQ0FBQzs7UUFFRjtRQUNBO1FBQ0EsTUFBTWxELGNBQWMsR0FBR0EsQ0FBQSxLQUFNO1VBQ3pCLElBQUk3SixNQUFNLENBQUNpRixRQUFRLEVBQUU7WUFDbkI7WUFDQTtZQUNBLE9BQU9qRixNQUFNLENBQUNvTixnQkFBZ0IsQ0FBQyxNQUFNO2NBQ25DO2NBQ0EsT0FBT1QsSUFBSSxDQUFDcEQsS0FBSyxDQUFDTyxVQUFVLEVBQUUzSixLQUFLLENBQUMySCxLQUFLLENBQUN3QixJQUFJLENBQUMsQ0FBQztZQUNsRCxDQUFDLENBQUM7VUFDSixDQUFDLE1BQU07WUFDTCxPQUFPcUQsSUFBSSxDQUFDcEQsS0FBSyxDQUFDTyxVQUFVLEVBQUUzSixLQUFLLENBQUMySCxLQUFLLENBQUN3QixJQUFJLENBQUMsQ0FBQztVQUNsRDtRQUNKLENBQUM7UUFDRCxPQUFBMUosYUFBQSxDQUFBQSxhQUFBLEtBQVlrTixhQUFhO1VBQUU5QyxPQUFPLEVBQUUsSUFBSTtVQUFFSCxjQUFjO1VBQUVDO1FBQVU7TUFDdEU7O01BRUE7TUFDQTtNQUNBO01BQ0FHLGNBQWNBLENBQUEsRUFBRztRQUNmLElBQUksQ0FBRSxJQUFJLENBQUNvRCxxQkFBcUIsQ0FBQyxDQUFDLEVBQUU7VUFDbEMsSUFBSSxDQUFDQywwQkFBMEIsQ0FBQyxDQUFDO1FBQ25DO1FBRUE5TCxNQUFNLENBQUM0RixNQUFNLENBQUMsSUFBSSxDQUFDdkUsT0FBTyxDQUFDLENBQUM4QyxPQUFPLENBQUVGLEtBQUssSUFBSztVQUM3Q0EsS0FBSyxDQUFDOEgsYUFBYSxDQUFDLENBQUM7UUFDdkIsQ0FBQyxDQUFDO01BQ0o7O01BRUE7TUFDQTtNQUNBO01BQ0EzQiwwQkFBMEJBLENBQUM3TixRQUFRLEVBQUU7UUFDbkMsTUFBTVAsSUFBSSxHQUFHLElBQUk7UUFDakIsSUFBSUEsSUFBSSxDQUFDNEYsdUJBQXVCLENBQUNyRixRQUFRLENBQUMsRUFDeEMsTUFBTSxJQUFJa0IsS0FBSyxDQUFDLGtEQUFrRCxDQUFDO1FBRXJFLE1BQU11TyxXQUFXLEdBQUcsRUFBRTtRQUV0QmhNLE1BQU0sQ0FBQ3VILE9BQU8sQ0FBQ3ZMLElBQUksQ0FBQ3FGLE9BQU8sQ0FBQyxDQUFDOEMsT0FBTyxDQUFDOEgsS0FBQSxJQUF5QjtVQUFBLElBQXhCLENBQUNDLFVBQVUsRUFBRWpJLEtBQUssQ0FBQyxHQUFBZ0ksS0FBQTtVQUN2RCxNQUFNRSxTQUFTLEdBQUdsSSxLQUFLLENBQUNtSSxpQkFBaUIsQ0FBQyxDQUFDO1VBQzNDO1VBQ0EsSUFBSSxDQUFFRCxTQUFTLEVBQUU7VUFDakJBLFNBQVMsQ0FBQ2hJLE9BQU8sQ0FBQyxDQUFDa0ksR0FBRyxFQUFFcEcsRUFBRSxLQUFLO1lBQzdCK0YsV0FBVyxDQUFDaEIsSUFBSSxDQUFDO2NBQUVrQixVQUFVO2NBQUVqRztZQUFHLENBQUMsQ0FBQztZQUNwQyxJQUFJLENBQUVsSCxNQUFNLENBQUNtRyxJQUFJLENBQUNsSixJQUFJLENBQUM2RixnQkFBZ0IsRUFBRXFLLFVBQVUsQ0FBQyxFQUFFO2NBQ3BEbFEsSUFBSSxDQUFDNkYsZ0JBQWdCLENBQUNxSyxVQUFVLENBQUMsR0FBRyxJQUFJOU0sVUFBVSxDQUFDLENBQUM7WUFDdEQ7WUFDQSxNQUFNa04sU0FBUyxHQUFHdFEsSUFBSSxDQUFDNkYsZ0JBQWdCLENBQUNxSyxVQUFVLENBQUMsQ0FBQ0ssVUFBVSxDQUM1RHRHLEVBQUUsRUFDRmpHLE1BQU0sQ0FBQ0MsTUFBTSxDQUFDLElBQUksQ0FDcEIsQ0FBQztZQUNELElBQUlxTSxTQUFTLENBQUNFLGNBQWMsRUFBRTtjQUM1QjtjQUNBO2NBQ0FGLFNBQVMsQ0FBQ0UsY0FBYyxDQUFDalEsUUFBUSxDQUFDLEdBQUcsSUFBSTtZQUMzQyxDQUFDLE1BQU07Y0FDTDtjQUNBK1AsU0FBUyxDQUFDRyxRQUFRLEdBQUdKLEdBQUc7Y0FDeEJDLFNBQVMsQ0FBQ0ksY0FBYyxHQUFHLEVBQUU7Y0FDN0JKLFNBQVMsQ0FBQ0UsY0FBYyxHQUFHeE0sTUFBTSxDQUFDQyxNQUFNLENBQUMsSUFBSSxDQUFDO2NBQzlDcU0sU0FBUyxDQUFDRSxjQUFjLENBQUNqUSxRQUFRLENBQUMsR0FBRyxJQUFJO1lBQzNDO1VBQ0YsQ0FBQyxDQUFDO1FBQ0osQ0FBQyxDQUFDO1FBQ0YsSUFBSSxDQUFFMkMsT0FBTyxDQUFDOE0sV0FBVyxDQUFDLEVBQUU7VUFDMUJoUSxJQUFJLENBQUM0Rix1QkFBdUIsQ0FBQ3JGLFFBQVEsQ0FBQyxHQUFHeVAsV0FBVztRQUN0RDtNQUNGOztNQUVBO01BQ0E7TUFDQVcsZUFBZUEsQ0FBQSxFQUFHO1FBQ2hCM00sTUFBTSxDQUFDNEYsTUFBTSxDQUFDLElBQUksQ0FBQ2hELGNBQWMsQ0FBQyxDQUFDdUIsT0FBTyxDQUFFMkIsR0FBRyxJQUFLO1VBQ2xEO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBLElBQUlBLEdBQUcsQ0FBQy9CLElBQUksS0FBSyxrQ0FBa0MsRUFBRTtZQUNuRCtCLEdBQUcsQ0FBQ3RDLElBQUksQ0FBQyxDQUFDO1VBQ1o7UUFDRixDQUFDLENBQUM7TUFDSjs7TUFFQTtNQUNBN0YsS0FBS0EsQ0FBQ2lQLEdBQUcsRUFBRTtRQUNULElBQUksQ0FBQ2xNLE9BQU8sQ0FBQ21NLElBQUksQ0FBQ3BPLFNBQVMsQ0FBQ3FPLFlBQVksQ0FBQ0YsR0FBRyxDQUFDLENBQUM7TUFDaEQ7O01BRUE7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0FsRyxXQUFXQSxDQUFDa0csR0FBRyxFQUFFO1FBQ2YsSUFBSSxDQUFDalAsS0FBSyxDQUFDaVAsR0FBRyxFQUFFLElBQUksQ0FBQztNQUN2Qjs7TUFFQTtNQUNBO01BQ0E7TUFDQUcsZUFBZUEsQ0FBQ0MsS0FBSyxFQUFFO1FBQ3JCLElBQUksQ0FBQ3RNLE9BQU8sQ0FBQ3FNLGVBQWUsQ0FBQ0MsS0FBSyxDQUFDO01BQ3JDOztNQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO01BQ0VDLE1BQU1BLENBQUEsRUFBVTtRQUNkLE9BQU8sSUFBSSxDQUFDdk0sT0FBTyxDQUFDdU0sTUFBTSxDQUFDLEdBQUE1SSxTQUFPLENBQUM7TUFDckM7O01BRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtNQUVFNkksU0FBU0EsQ0FBQSxFQUFVO1FBQ2pCLE9BQU8sSUFBSSxDQUFDeE0sT0FBTyxDQUFDd00sU0FBUyxDQUFDLEdBQUE3SSxTQUFPLENBQUM7TUFDeEM7O01BRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7TUFDRThJLFVBQVVBLENBQUEsRUFBVTtRQUNsQixPQUFPLElBQUksQ0FBQ3pNLE9BQU8sQ0FBQ3lNLFVBQVUsQ0FBQyxHQUFBOUksU0FBTyxDQUFDO01BQ3pDO01BRUErSSxLQUFLQSxDQUFBLEVBQUc7UUFDTixPQUFPLElBQUksQ0FBQzFNLE9BQU8sQ0FBQ3lNLFVBQVUsQ0FBQztVQUFFRSxVQUFVLEVBQUU7UUFBSyxDQUFDLENBQUM7TUFDdEQ7O01BRUE7TUFDQTtNQUNBO01BQ0EzQixNQUFNQSxDQUFBLEVBQUc7UUFDUCxJQUFJLElBQUksQ0FBQzVJLFdBQVcsRUFBRSxJQUFJLENBQUNBLFdBQVcsQ0FBQytELE1BQU0sQ0FBQyxDQUFDO1FBQy9DLE9BQU8sSUFBSSxDQUFDaEUsT0FBTztNQUNyQjtNQUVBNEksU0FBU0EsQ0FBQ0MsTUFBTSxFQUFFO1FBQ2hCO1FBQ0EsSUFBSSxJQUFJLENBQUM3SSxPQUFPLEtBQUs2SSxNQUFNLEVBQUU7UUFDN0IsSUFBSSxDQUFDN0ksT0FBTyxHQUFHNkksTUFBTTtRQUNyQixJQUFJLElBQUksQ0FBQzVJLFdBQVcsRUFBRSxJQUFJLENBQUNBLFdBQVcsQ0FBQzJELE9BQU8sQ0FBQyxDQUFDO01BQ2xEOztNQUVBO01BQ0E7TUFDQTtNQUNBb0YscUJBQXFCQSxDQUFBLEVBQUc7UUFDdEIsT0FDRSxDQUFFM00sT0FBTyxDQUFDLElBQUksQ0FBQzhDLGlCQUFpQixDQUFDLElBQ2pDLENBQUU5QyxPQUFPLENBQUMsSUFBSSxDQUFDeEIsMEJBQTBCLENBQUM7TUFFOUM7O01BRUE7TUFDQTtNQUNBNFAseUJBQXlCQSxDQUFBLEVBQUc7UUFDMUIsTUFBTUMsUUFBUSxHQUFHLElBQUksQ0FBQ2pRLGVBQWU7UUFDckMsT0FBTzBDLE1BQU0sQ0FBQzRGLE1BQU0sQ0FBQzJILFFBQVEsQ0FBQyxDQUFDOUgsSUFBSSxDQUFFK0gsT0FBTyxJQUFLLENBQUMsQ0FBQ0EsT0FBTyxDQUFDaFIsV0FBVyxDQUFDO01BQ3pFO01BRUEsTUFBTWlSLG1CQUFtQkEsQ0FBQzdJLEdBQUcsRUFBRTtRQUM3QixNQUFNNUksSUFBSSxHQUFHLElBQUk7UUFFakIsSUFBSUEsSUFBSSxDQUFDb0YsUUFBUSxLQUFLLE1BQU0sSUFBSXBGLElBQUksQ0FBQ3lGLGtCQUFrQixLQUFLLENBQUMsRUFBRTtVQUM3RHpGLElBQUksQ0FBQ3VILFVBQVUsR0FBRyxJQUFJOUUsU0FBUyxDQUFDaVAsU0FBUyxDQUFDO1lBQ3hDN04saUJBQWlCLEVBQUU3RCxJQUFJLENBQUN5RixrQkFBa0I7WUFDMUMzQixnQkFBZ0IsRUFBRTlELElBQUksQ0FBQzBGLGlCQUFpQjtZQUN4Q2lNLFNBQVNBLENBQUEsRUFBRztjQUNWM1IsSUFBSSxDQUFDK1EsZUFBZSxDQUNsQixJQUFJblIsR0FBRyxDQUFDaUYsZUFBZSxDQUFDLHlCQUF5QixDQUNuRCxDQUFDO1lBQ0gsQ0FBQztZQUNEK00sUUFBUUEsQ0FBQSxFQUFHO2NBQ1Q1UixJQUFJLENBQUMyQixLQUFLLENBQUM7Z0JBQUVpSCxHQUFHLEVBQUU7Y0FBTyxDQUFDLENBQUM7WUFDN0I7VUFDRixDQUFDLENBQUM7VUFDRjVJLElBQUksQ0FBQ3VILFVBQVUsQ0FBQ3NLLEtBQUssQ0FBQyxDQUFDO1FBQ3pCOztRQUVBO1FBQ0EsSUFBSTdSLElBQUksQ0FBQ2tGLGNBQWMsRUFBRWxGLElBQUksQ0FBQ2lHLFlBQVksR0FBRyxJQUFJO1FBRWpELElBQUk2TCw0QkFBNEI7UUFDaEMsSUFBSSxPQUFPbEosR0FBRyxDQUFDbUosT0FBTyxLQUFLLFFBQVEsRUFBRTtVQUNuQ0QsNEJBQTRCLEdBQUc5UixJQUFJLENBQUNrRixjQUFjLEtBQUswRCxHQUFHLENBQUNtSixPQUFPO1VBQ2xFL1IsSUFBSSxDQUFDa0YsY0FBYyxHQUFHMEQsR0FBRyxDQUFDbUosT0FBTztRQUNuQztRQUVBLElBQUlELDRCQUE0QixFQUFFO1VBQ2hDO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtRQUNGOztRQUVBOztRQUVBO1FBQ0E7UUFDQTlSLElBQUksQ0FBQ2tHLHdCQUF3QixHQUFHbEMsTUFBTSxDQUFDQyxNQUFNLENBQUMsSUFBSSxDQUFDO1FBRW5ELElBQUlqRSxJQUFJLENBQUNpRyxZQUFZLEVBQUU7VUFDckI7VUFDQTtVQUNBakcsSUFBSSxDQUFDNEYsdUJBQXVCLEdBQUc1QixNQUFNLENBQUNDLE1BQU0sQ0FBQyxJQUFJLENBQUM7VUFDbERqRSxJQUFJLENBQUM2RixnQkFBZ0IsR0FBRzdCLE1BQU0sQ0FBQ0MsTUFBTSxDQUFDLElBQUksQ0FBQztRQUM3Qzs7UUFFQTtRQUNBakUsSUFBSSxDQUFDOEYscUJBQXFCLEdBQUcsRUFBRTs7UUFFL0I7UUFDQTtRQUNBO1FBQ0E7UUFDQTlGLElBQUksQ0FBQ2dHLGlCQUFpQixHQUFHaEMsTUFBTSxDQUFDQyxNQUFNLENBQUMsSUFBSSxDQUFDO1FBQzVDRCxNQUFNLENBQUN1SCxPQUFPLENBQUN2TCxJQUFJLENBQUM0RyxjQUFjLENBQUMsQ0FBQ3VCLE9BQU8sQ0FBQzZKLEtBQUEsSUFBZTtVQUFBLElBQWQsQ0FBQy9ILEVBQUUsRUFBRUgsR0FBRyxDQUFDLEdBQUFrSSxLQUFBO1VBQ3BELElBQUlsSSxHQUFHLENBQUNJLEtBQUssRUFBRTtZQUNibEssSUFBSSxDQUFDZ0csaUJBQWlCLENBQUNpRSxFQUFFLENBQUMsR0FBRyxJQUFJO1VBQ25DO1FBQ0YsQ0FBQyxDQUFDOztRQUVGO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0FqSyxJQUFJLENBQUMwQiwwQkFBMEIsR0FBR3NDLE1BQU0sQ0FBQ0MsTUFBTSxDQUFDLElBQUksQ0FBQztRQUNyRCxJQUFJakUsSUFBSSxDQUFDaUcsWUFBWSxFQUFFO1VBQ3JCLE1BQU1zTCxRQUFRLEdBQUd2UixJQUFJLENBQUNzQixlQUFlO1VBQ3JDMkIsSUFBSSxDQUFDc08sUUFBUSxDQUFDLENBQUNwSixPQUFPLENBQUM4QixFQUFFLElBQUk7WUFDM0IsTUFBTXVILE9BQU8sR0FBR0QsUUFBUSxDQUFDdEgsRUFBRSxDQUFDO1lBQzVCLElBQUl1SCxPQUFPLENBQUNoUSxTQUFTLENBQUMsQ0FBQyxFQUFFO2NBQ3ZCO2NBQ0E7Y0FDQTtjQUNBO2NBQ0F4QixJQUFJLENBQUM4RixxQkFBcUIsQ0FBQ2tKLElBQUksQ0FDN0I7Z0JBQUEsT0FBYXdDLE9BQU8sQ0FBQ3ZQLFdBQVcsQ0FBQyxHQUFBb0csU0FBTyxDQUFDO2NBQUEsQ0FDM0MsQ0FBQztZQUNILENBQUMsTUFBTSxJQUFJbUosT0FBTyxDQUFDaFIsV0FBVyxFQUFFO2NBQzlCO2NBQ0E7Y0FDQTtjQUNBO2NBQ0E7Y0FDQTtjQUNBO2NBQ0E7Y0FDQTtjQUNBUixJQUFJLENBQUMwQiwwQkFBMEIsQ0FBQzhQLE9BQU8sQ0FBQ2pSLFFBQVEsQ0FBQyxHQUFHLElBQUk7WUFDMUQ7VUFDRixDQUFDLENBQUM7UUFDSjtRQUVBUCxJQUFJLENBQUMrRixnQ0FBZ0MsR0FBRyxFQUFFOztRQUUxQztRQUNBO1FBQ0EsSUFBSSxDQUFFL0YsSUFBSSxDQUFDNlAscUJBQXFCLENBQUMsQ0FBQyxFQUFFO1VBQ2xDLElBQUk3UCxJQUFJLENBQUNpRyxZQUFZLEVBQUU7WUFDckIsS0FBSyxNQUFNZ0MsS0FBSyxJQUFJakUsTUFBTSxDQUFDNEYsTUFBTSxDQUFDNUosSUFBSSxDQUFDcUYsT0FBTyxDQUFDLEVBQUU7Y0FDL0MsTUFBTTRDLEtBQUssQ0FBQ1MsV0FBVyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUM7Y0FDaEMsTUFBTVQsS0FBSyxDQUFDYSxTQUFTLENBQUMsQ0FBQztZQUN6QjtZQUNBOUksSUFBSSxDQUFDaUcsWUFBWSxHQUFHLEtBQUs7VUFDM0I7VUFDQWpHLElBQUksQ0FBQ2lTLHdCQUF3QixDQUFDLENBQUM7UUFDakM7TUFDRjtNQUVBLE1BQU1DLHNCQUFzQkEsQ0FBQ3RKLEdBQUcsRUFBRXVKLE9BQU8sRUFBRTtRQUN6QyxNQUFNQyxXQUFXLEdBQUd4SixHQUFHLENBQUNBLEdBQUc7O1FBRTNCO1FBQ0EsSUFBSXdKLFdBQVcsS0FBSyxPQUFPLEVBQUU7VUFDM0IsTUFBTSxJQUFJLENBQUNDLGNBQWMsQ0FBQ3pKLEdBQUcsRUFBRXVKLE9BQU8sQ0FBQztRQUN6QyxDQUFDLE1BQU0sSUFBSUMsV0FBVyxLQUFLLFNBQVMsRUFBRTtVQUNwQyxJQUFJLENBQUNFLGdCQUFnQixDQUFDMUosR0FBRyxFQUFFdUosT0FBTyxDQUFDO1FBQ3JDLENBQUMsTUFBTSxJQUFJQyxXQUFXLEtBQUssU0FBUyxFQUFFO1VBQ3BDLElBQUksQ0FBQ0csZ0JBQWdCLENBQUMzSixHQUFHLEVBQUV1SixPQUFPLENBQUM7UUFDckMsQ0FBQyxNQUFNLElBQUlDLFdBQVcsS0FBSyxPQUFPLEVBQUU7VUFDbEMsSUFBSSxDQUFDSSxjQUFjLENBQUM1SixHQUFHLEVBQUV1SixPQUFPLENBQUM7UUFDbkMsQ0FBQyxNQUFNLElBQUlDLFdBQVcsS0FBSyxTQUFTLEVBQUU7VUFDcEMsSUFBSSxDQUFDSyxnQkFBZ0IsQ0FBQzdKLEdBQUcsRUFBRXVKLE9BQU8sQ0FBQztRQUNyQyxDQUFDLE1BQU0sSUFBSUMsV0FBVyxLQUFLLE9BQU8sRUFBRTtVQUNsQztRQUFBLENBQ0QsTUFBTTtVQUNMNVAsTUFBTSxDQUFDb0IsTUFBTSxDQUFDLCtDQUErQyxFQUFFZ0YsR0FBRyxDQUFDO1FBQ3JFO01BQ0Y7TUFFQSxNQUFNOEosY0FBY0EsQ0FBQzlKLEdBQUcsRUFBRTtRQUN4QixNQUFNNUksSUFBSSxHQUFHLElBQUk7UUFFakIsSUFBSUEsSUFBSSxDQUFDNlAscUJBQXFCLENBQUMsQ0FBQyxFQUFFO1VBQ2hDN1AsSUFBSSxDQUFDK0YsZ0NBQWdDLENBQUNpSixJQUFJLENBQUNwRyxHQUFHLENBQUM7VUFFL0MsSUFBSUEsR0FBRyxDQUFDQSxHQUFHLEtBQUssT0FBTyxFQUFFO1lBQ3ZCLE9BQU81SSxJQUFJLENBQUNnRyxpQkFBaUIsQ0FBQzRDLEdBQUcsQ0FBQ3FCLEVBQUUsQ0FBQztVQUN2QztVQUVBLElBQUlyQixHQUFHLENBQUMrSixJQUFJLEVBQUU7WUFDWi9KLEdBQUcsQ0FBQytKLElBQUksQ0FBQ3hLLE9BQU8sQ0FBQ3lLLEtBQUssSUFBSTtjQUN4QixPQUFPNVMsSUFBSSxDQUFDZ0csaUJBQWlCLENBQUM0TSxLQUFLLENBQUM7WUFDdEMsQ0FBQyxDQUFDO1VBQ0o7VUFFQSxJQUFJaEssR0FBRyxDQUFDMEMsT0FBTyxFQUFFO1lBQ2YxQyxHQUFHLENBQUMwQyxPQUFPLENBQUNuRCxPQUFPLENBQUM1SCxRQUFRLElBQUk7Y0FDOUIsT0FBT1AsSUFBSSxDQUFDMEIsMEJBQTBCLENBQUNuQixRQUFRLENBQUM7WUFDbEQsQ0FBQyxDQUFDO1VBQ0o7VUFFQSxJQUFJUCxJQUFJLENBQUM2UCxxQkFBcUIsQ0FBQyxDQUFDLEVBQUU7WUFDaEM7VUFDRjs7VUFFQTtVQUNBO1VBQ0E7O1VBRUEsTUFBTWdELGdCQUFnQixHQUFHN1MsSUFBSSxDQUFDK0YsZ0NBQWdDO1VBQzlELEtBQUssTUFBTStNLGVBQWUsSUFBSTlPLE1BQU0sQ0FBQzRGLE1BQU0sQ0FBQ2lKLGdCQUFnQixDQUFDLEVBQUU7WUFDN0QsTUFBTTdTLElBQUksQ0FBQ2tTLHNCQUFzQixDQUMvQlksZUFBZSxFQUNmOVMsSUFBSSxDQUFDdUcsZUFDUCxDQUFDO1VBQ0g7VUFFQXZHLElBQUksQ0FBQytGLGdDQUFnQyxHQUFHLEVBQUU7UUFFNUMsQ0FBQyxNQUFNO1VBQ0wsTUFBTS9GLElBQUksQ0FBQ2tTLHNCQUFzQixDQUFDdEosR0FBRyxFQUFFNUksSUFBSSxDQUFDdUcsZUFBZSxDQUFDO1FBQzlEOztRQUVBO1FBQ0E7UUFDQTtRQUNBLE1BQU13TSxhQUFhLEdBQ2pCbkssR0FBRyxDQUFDQSxHQUFHLEtBQUssT0FBTyxJQUNuQkEsR0FBRyxDQUFDQSxHQUFHLEtBQUssU0FBUyxJQUNyQkEsR0FBRyxDQUFDQSxHQUFHLEtBQUssU0FBUztRQUV2QixJQUFJNUksSUFBSSxDQUFDMEcsdUJBQXVCLEtBQUssQ0FBQyxJQUFJLENBQUVxTSxhQUFhLEVBQUU7VUFDekQsTUFBTS9TLElBQUksQ0FBQ3NHLG9CQUFvQixDQUFDLENBQUM7VUFDakM7UUFDRjtRQUVBLElBQUl0RyxJQUFJLENBQUN3RyxzQkFBc0IsS0FBSyxJQUFJLEVBQUU7VUFDeEN4RyxJQUFJLENBQUN3RyxzQkFBc0IsR0FDekIsSUFBSXdNLElBQUksQ0FBQyxDQUFDLENBQUNDLE9BQU8sQ0FBQyxDQUFDLEdBQUdqVCxJQUFJLENBQUMyRyxxQkFBcUI7UUFDckQsQ0FBQyxNQUFNLElBQUkzRyxJQUFJLENBQUN3RyxzQkFBc0IsR0FBRyxJQUFJd00sSUFBSSxDQUFDLENBQUMsQ0FBQ0MsT0FBTyxDQUFDLENBQUMsRUFBRTtVQUM3RCxNQUFNalQsSUFBSSxDQUFDc0csb0JBQW9CLENBQUMsQ0FBQztVQUNqQztRQUNGO1FBRUEsSUFBSXRHLElBQUksQ0FBQ3lHLDBCQUEwQixFQUFFO1VBQ25DeU0sWUFBWSxDQUFDbFQsSUFBSSxDQUFDeUcsMEJBQTBCLENBQUM7UUFDL0M7UUFDQXpHLElBQUksQ0FBQ3lHLDBCQUEwQixHQUFHME0sVUFBVSxDQUFDLE1BQU07VUFDakQ7VUFDQTtVQUNBblQsSUFBSSxDQUFDb1Qsc0JBQXNCLEdBQUdwVCxJQUFJLENBQUNvRyxxQkFBcUIsQ0FBQyxDQUFDO1VBRTFELElBQUk1RCxNQUFNLENBQUNvSyxVQUFVLENBQUM1TSxJQUFJLENBQUNvVCxzQkFBc0IsQ0FBQyxFQUFFO1lBQ2xEcFQsSUFBSSxDQUFDb1Qsc0JBQXNCLENBQUNDLE9BQU8sQ0FDakMsTUFBT3JULElBQUksQ0FBQ29ULHNCQUFzQixHQUFHbkcsU0FDdkMsQ0FBQztVQUNIO1FBQ0YsQ0FBQyxFQUFFak4sSUFBSSxDQUFDMEcsdUJBQXVCLENBQUM7TUFDbEM7TUFFQTRNLHNCQUFzQkEsQ0FBQSxFQUFHO1FBQ3ZCLE1BQU10VCxJQUFJLEdBQUcsSUFBSTtRQUNqQixJQUFJQSxJQUFJLENBQUN5RywwQkFBMEIsRUFBRTtVQUNuQ3lNLFlBQVksQ0FBQ2xULElBQUksQ0FBQ3lHLDBCQUEwQixDQUFDO1VBQzdDekcsSUFBSSxDQUFDeUcsMEJBQTBCLEdBQUcsSUFBSTtRQUN4QztRQUVBekcsSUFBSSxDQUFDd0csc0JBQXNCLEdBQUcsSUFBSTtRQUNsQztRQUNBO1FBQ0E7UUFDQSxNQUFNK00sTUFBTSxHQUFHdlQsSUFBSSxDQUFDdUcsZUFBZTtRQUNuQ3ZHLElBQUksQ0FBQ3VHLGVBQWUsR0FBR3ZDLE1BQU0sQ0FBQ0MsTUFBTSxDQUFDLElBQUksQ0FBQztRQUMxQyxPQUFPc1AsTUFBTTtNQUNmO01BRUEsTUFBTUMsMEJBQTBCQSxDQUFBLEVBQUc7UUFDakMsTUFBTXhULElBQUksR0FBRyxJQUFJO1FBQ2pCLE1BQU11VCxNQUFNLEdBQUd2VCxJQUFJLENBQUNzVCxzQkFBc0IsQ0FBQyxDQUFDO1FBQzVDLE1BQU10VCxJQUFJLENBQUN5VCxvQkFBb0IsQ0FBQ0YsTUFBTSxDQUFDO01BQ3pDO01BQ0F6RCwwQkFBMEJBLENBQUEsRUFBRztRQUMzQixNQUFNOVAsSUFBSSxHQUFHLElBQUk7UUFDakIsTUFBTXVULE1BQU0sR0FBR3ZULElBQUksQ0FBQ3NULHNCQUFzQixDQUFDLENBQUM7UUFDNUN0VCxJQUFJLENBQUMwVCxvQkFBb0IsQ0FBQ0gsTUFBTSxDQUFDO01BQ25DO01BQ0FqTixvQkFBb0JBLENBQUEsRUFBRztRQUNyQixNQUFNdEcsSUFBSSxHQUFHLElBQUk7UUFDakIsT0FBT3dDLE1BQU0sQ0FBQ3dFLFFBQVEsR0FDbEJoSCxJQUFJLENBQUM4UCwwQkFBMEIsQ0FBQyxDQUFDLEdBQ2pDOVAsSUFBSSxDQUFDd1QsMEJBQTBCLENBQUMsQ0FBQztNQUN2QztNQUNBLE1BQU1DLG9CQUFvQkEsQ0FBQ3RCLE9BQU8sRUFBRTtRQUNsQyxNQUFNblMsSUFBSSxHQUFHLElBQUk7UUFFakIsSUFBSUEsSUFBSSxDQUFDaUcsWUFBWSxJQUFJLENBQUUvQyxPQUFPLENBQUNpUCxPQUFPLENBQUMsRUFBRTtVQUMzQzs7VUFFQSxLQUFLLE1BQU0sQ0FBQ3dCLFNBQVMsRUFBRTFMLEtBQUssQ0FBQyxJQUFJakUsTUFBTSxDQUFDdUgsT0FBTyxDQUFDdkwsSUFBSSxDQUFDcUYsT0FBTyxDQUFDLEVBQUU7WUFDN0QsTUFBTTRDLEtBQUssQ0FBQ1MsV0FBVyxDQUNyQjNGLE1BQU0sQ0FBQ21HLElBQUksQ0FBQ2lKLE9BQU8sRUFBRXdCLFNBQVMsQ0FBQyxHQUMzQnhCLE9BQU8sQ0FBQ3dCLFNBQVMsQ0FBQyxDQUFDaEwsTUFBTSxHQUN6QixDQUFDLEVBQ0wzSSxJQUFJLENBQUNpRyxZQUNQLENBQUM7VUFDSDtVQUVBakcsSUFBSSxDQUFDaUcsWUFBWSxHQUFHLEtBQUs7VUFFekIsS0FBSyxNQUFNLENBQUMwTixTQUFTLEVBQUVDLGNBQWMsQ0FBQyxJQUFJNVAsTUFBTSxDQUFDdUgsT0FBTyxDQUFDNEcsT0FBTyxDQUFDLEVBQUU7WUFDakUsTUFBTWxLLEtBQUssR0FBR2pJLElBQUksQ0FBQ3FGLE9BQU8sQ0FBQ3NPLFNBQVMsQ0FBQztZQUNyQyxJQUFJMUwsS0FBSyxFQUFFO2NBQ1QsS0FBSyxNQUFNNEwsYUFBYSxJQUFJRCxjQUFjLEVBQUU7Z0JBQzFDLE1BQU0zTCxLQUFLLENBQUNZLE1BQU0sQ0FBQ2dMLGFBQWEsQ0FBQztjQUNuQztZQUNGLENBQUMsTUFBTTtjQUNMO2NBQ0E7Y0FDQTtjQUNBO2NBQ0E7Y0FDQSxNQUFNMUIsT0FBTyxHQUFHblMsSUFBSSxDQUFDa0csd0JBQXdCO2NBRTdDLElBQUksQ0FBRW5ELE1BQU0sQ0FBQ21HLElBQUksQ0FBQ2lKLE9BQU8sRUFBRXdCLFNBQVMsQ0FBQyxFQUFFO2dCQUNyQ3hCLE9BQU8sQ0FBQ3dCLFNBQVMsQ0FBQyxHQUFHLEVBQUU7Y0FDekI7Y0FFQXhCLE9BQU8sQ0FBQ3dCLFNBQVMsQ0FBQyxDQUFDM0UsSUFBSSxDQUFDLEdBQUc0RSxjQUFjLENBQUM7WUFDNUM7VUFDRjtVQUNBO1VBQ0EsS0FBSyxNQUFNM0wsS0FBSyxJQUFJakUsTUFBTSxDQUFDNEYsTUFBTSxDQUFDNUosSUFBSSxDQUFDcUYsT0FBTyxDQUFDLEVBQUU7WUFDL0MsTUFBTTRDLEtBQUssQ0FBQ2EsU0FBUyxDQUFDLENBQUM7VUFDekI7UUFDRjtRQUVBOUksSUFBSSxDQUFDaVMsd0JBQXdCLENBQUMsQ0FBQztNQUNqQztNQUNBeUIsb0JBQW9CQSxDQUFDdkIsT0FBTyxFQUFFO1FBQzVCLE1BQU1uUyxJQUFJLEdBQUcsSUFBSTtRQUVqQixJQUFJQSxJQUFJLENBQUNpRyxZQUFZLElBQUksQ0FBRS9DLE9BQU8sQ0FBQ2lQLE9BQU8sQ0FBQyxFQUFFO1VBQzNDOztVQUVBLEtBQUssTUFBTSxDQUFDd0IsU0FBUyxFQUFFMUwsS0FBSyxDQUFDLElBQUlqRSxNQUFNLENBQUN1SCxPQUFPLENBQUN2TCxJQUFJLENBQUNxRixPQUFPLENBQUMsRUFBRTtZQUM3RDRDLEtBQUssQ0FBQ1MsV0FBVyxDQUNmM0YsTUFBTSxDQUFDbUcsSUFBSSxDQUFDaUosT0FBTyxFQUFFd0IsU0FBUyxDQUFDLEdBQzNCeEIsT0FBTyxDQUFDd0IsU0FBUyxDQUFDLENBQUNoTCxNQUFNLEdBQ3pCLENBQUMsRUFDTDNJLElBQUksQ0FBQ2lHLFlBQ1AsQ0FBQztVQUNIO1VBRUFqRyxJQUFJLENBQUNpRyxZQUFZLEdBQUcsS0FBSztVQUV6QixLQUFLLE1BQU0sQ0FBQzBOLFNBQVMsRUFBRUMsY0FBYyxDQUFDLElBQUk1UCxNQUFNLENBQUN1SCxPQUFPLENBQUM0RyxPQUFPLENBQUMsRUFBRTtZQUNqRSxNQUFNbEssS0FBSyxHQUFHakksSUFBSSxDQUFDcUYsT0FBTyxDQUFDc08sU0FBUyxDQUFDO1lBQ3JDLElBQUkxTCxLQUFLLEVBQUU7Y0FDVCxLQUFLLE1BQU00TCxhQUFhLElBQUlELGNBQWMsRUFBRTtnQkFDMUMzTCxLQUFLLENBQUNZLE1BQU0sQ0FBQ2dMLGFBQWEsQ0FBQztjQUM3QjtZQUNGLENBQUMsTUFBTTtjQUNMO2NBQ0E7Y0FDQTtjQUNBO2NBQ0E7Y0FDQSxNQUFNMUIsT0FBTyxHQUFHblMsSUFBSSxDQUFDa0csd0JBQXdCO2NBRTdDLElBQUksQ0FBRW5ELE1BQU0sQ0FBQ21HLElBQUksQ0FBQ2lKLE9BQU8sRUFBRXdCLFNBQVMsQ0FBQyxFQUFFO2dCQUNyQ3hCLE9BQU8sQ0FBQ3dCLFNBQVMsQ0FBQyxHQUFHLEVBQUU7Y0FDekI7Y0FFQXhCLE9BQU8sQ0FBQ3dCLFNBQVMsQ0FBQyxDQUFDM0UsSUFBSSxDQUFDLEdBQUc0RSxjQUFjLENBQUM7WUFDNUM7VUFDRjtVQUNBO1VBQ0EsS0FBSyxNQUFNM0wsS0FBSyxJQUFJakUsTUFBTSxDQUFDNEYsTUFBTSxDQUFDNUosSUFBSSxDQUFDcUYsT0FBTyxDQUFDLEVBQUU7WUFDL0M0QyxLQUFLLENBQUNhLFNBQVMsQ0FBQyxDQUFDO1VBQ25CO1FBQ0Y7UUFFQTlJLElBQUksQ0FBQ2lTLHdCQUF3QixDQUFDLENBQUM7TUFDakM7O01BRUE7TUFDQTtNQUNBO01BQ0FBLHdCQUF3QkEsQ0FBQSxFQUFHO1FBQ3pCLE1BQU1qUyxJQUFJLEdBQUcsSUFBSTtRQUNqQixNQUFNbUosU0FBUyxHQUFHbkosSUFBSSxDQUFDOEYscUJBQXFCO1FBQzVDOUYsSUFBSSxDQUFDOEYscUJBQXFCLEdBQUcsRUFBRTtRQUMvQnFELFNBQVMsQ0FBQ2hCLE9BQU8sQ0FBRThDLENBQUMsSUFBSztVQUN2QkEsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUM7TUFDSjtNQUVBNkksV0FBV0EsQ0FBQzNCLE9BQU8sRUFBRWpDLFVBQVUsRUFBRXRILEdBQUcsRUFBRTtRQUNwQyxJQUFJLENBQUU3RixNQUFNLENBQUNtRyxJQUFJLENBQUNpSixPQUFPLEVBQUVqQyxVQUFVLENBQUMsRUFBRTtVQUN0Q2lDLE9BQU8sQ0FBQ2pDLFVBQVUsQ0FBQyxHQUFHLEVBQUU7UUFDMUI7UUFDQWlDLE9BQU8sQ0FBQ2pDLFVBQVUsQ0FBQyxDQUFDbEIsSUFBSSxDQUFDcEcsR0FBRyxDQUFDO01BQy9CO01BRUFtTCxhQUFhQSxDQUFDN0QsVUFBVSxFQUFFakcsRUFBRSxFQUFFO1FBQzVCLE1BQU1qSyxJQUFJLEdBQUcsSUFBSTtRQUNqQixJQUFJLENBQUUrQyxNQUFNLENBQUNtRyxJQUFJLENBQUNsSixJQUFJLENBQUM2RixnQkFBZ0IsRUFBRXFLLFVBQVUsQ0FBQyxFQUFFO1VBQ3BELE9BQU8sSUFBSTtRQUNiO1FBQ0EsTUFBTThELHVCQUF1QixHQUFHaFUsSUFBSSxDQUFDNkYsZ0JBQWdCLENBQUNxSyxVQUFVLENBQUM7UUFDakUsT0FBTzhELHVCQUF1QixDQUFDOUUsR0FBRyxDQUFDakYsRUFBRSxDQUFDLElBQUksSUFBSTtNQUNoRDtNQUVBLE1BQU1vSSxjQUFjQSxDQUFDekosR0FBRyxFQUFFdUosT0FBTyxFQUFFO1FBQ2pDLE1BQU1uUyxJQUFJLEdBQUcsSUFBSTtRQUNqQixNQUFNaUssRUFBRSxHQUFHbkgsT0FBTyxDQUFDUyxPQUFPLENBQUNxRixHQUFHLENBQUNxQixFQUFFLENBQUM7UUFDbEMsTUFBTXFHLFNBQVMsR0FBR3RRLElBQUksQ0FBQytULGFBQWEsQ0FBQ25MLEdBQUcsQ0FBQ3NILFVBQVUsRUFBRWpHLEVBQUUsQ0FBQztRQUN4RCxJQUFJcUcsU0FBUyxFQUFFO1VBQ2I7VUFDQSxNQUFNMkQsVUFBVSxHQUFHM0QsU0FBUyxDQUFDRyxRQUFRLEtBQUt4RCxTQUFTO1VBRW5EcUQsU0FBUyxDQUFDRyxRQUFRLEdBQUc3SCxHQUFHLENBQUNzTCxNQUFNLElBQUlsUSxNQUFNLENBQUNDLE1BQU0sQ0FBQyxJQUFJLENBQUM7VUFDdERxTSxTQUFTLENBQUNHLFFBQVEsQ0FBQzBELEdBQUcsR0FBR2xLLEVBQUU7VUFFM0IsSUFBSWpLLElBQUksQ0FBQ2lHLFlBQVksRUFBRTtZQUNyQjtZQUNBO1lBQ0E7WUFDQTtZQUNBLE1BQU1tTyxVQUFVLEdBQUcsTUFBTXBVLElBQUksQ0FBQ3FGLE9BQU8sQ0FBQ3VELEdBQUcsQ0FBQ3NILFVBQVUsQ0FBQyxDQUFDbUUsTUFBTSxDQUFDekwsR0FBRyxDQUFDcUIsRUFBRSxDQUFDO1lBQ3BFLElBQUltSyxVQUFVLEtBQUtuSCxTQUFTLEVBQUVyRSxHQUFHLENBQUNzTCxNQUFNLEdBQUdFLFVBQVU7WUFFckRwVSxJQUFJLENBQUM4VCxXQUFXLENBQUMzQixPQUFPLEVBQUV2SixHQUFHLENBQUNzSCxVQUFVLEVBQUV0SCxHQUFHLENBQUM7VUFDaEQsQ0FBQyxNQUFNLElBQUlxTCxVQUFVLEVBQUU7WUFDckIsTUFBTSxJQUFJeFMsS0FBSyxDQUFDLG1DQUFtQyxHQUFHbUgsR0FBRyxDQUFDcUIsRUFBRSxDQUFDO1VBQy9EO1FBQ0YsQ0FBQyxNQUFNO1VBQ0xqSyxJQUFJLENBQUM4VCxXQUFXLENBQUMzQixPQUFPLEVBQUV2SixHQUFHLENBQUNzSCxVQUFVLEVBQUV0SCxHQUFHLENBQUM7UUFDaEQ7TUFDRjtNQUVBMEosZ0JBQWdCQSxDQUFDMUosR0FBRyxFQUFFdUosT0FBTyxFQUFFO1FBQzdCLE1BQU1uUyxJQUFJLEdBQUcsSUFBSTtRQUNqQixNQUFNc1EsU0FBUyxHQUFHdFEsSUFBSSxDQUFDK1QsYUFBYSxDQUFDbkwsR0FBRyxDQUFDc0gsVUFBVSxFQUFFcE4sT0FBTyxDQUFDUyxPQUFPLENBQUNxRixHQUFHLENBQUNxQixFQUFFLENBQUMsQ0FBQztRQUM3RSxJQUFJcUcsU0FBUyxFQUFFO1VBQ2IsSUFBSUEsU0FBUyxDQUFDRyxRQUFRLEtBQUt4RCxTQUFTLEVBQ2xDLE1BQU0sSUFBSXhMLEtBQUssQ0FBQywwQ0FBMEMsR0FBR21ILEdBQUcsQ0FBQ3FCLEVBQUUsQ0FBQztVQUN0RXFLLFlBQVksQ0FBQ0MsWUFBWSxDQUFDakUsU0FBUyxDQUFDRyxRQUFRLEVBQUU3SCxHQUFHLENBQUNzTCxNQUFNLENBQUM7UUFDM0QsQ0FBQyxNQUFNO1VBQ0xsVSxJQUFJLENBQUM4VCxXQUFXLENBQUMzQixPQUFPLEVBQUV2SixHQUFHLENBQUNzSCxVQUFVLEVBQUV0SCxHQUFHLENBQUM7UUFDaEQ7TUFDRjtNQUVBMkosZ0JBQWdCQSxDQUFDM0osR0FBRyxFQUFFdUosT0FBTyxFQUFFO1FBQzdCLE1BQU1uUyxJQUFJLEdBQUcsSUFBSTtRQUNqQixNQUFNc1EsU0FBUyxHQUFHdFEsSUFBSSxDQUFDK1QsYUFBYSxDQUFDbkwsR0FBRyxDQUFDc0gsVUFBVSxFQUFFcE4sT0FBTyxDQUFDUyxPQUFPLENBQUNxRixHQUFHLENBQUNxQixFQUFFLENBQUMsQ0FBQztRQUM3RSxJQUFJcUcsU0FBUyxFQUFFO1VBQ2I7VUFDQSxJQUFJQSxTQUFTLENBQUNHLFFBQVEsS0FBS3hELFNBQVMsRUFDbEMsTUFBTSxJQUFJeEwsS0FBSyxDQUFDLHlDQUF5QyxHQUFHbUgsR0FBRyxDQUFDcUIsRUFBRSxDQUFDO1VBQ3JFcUcsU0FBUyxDQUFDRyxRQUFRLEdBQUd4RCxTQUFTO1FBQ2hDLENBQUMsTUFBTTtVQUNMak4sSUFBSSxDQUFDOFQsV0FBVyxDQUFDM0IsT0FBTyxFQUFFdkosR0FBRyxDQUFDc0gsVUFBVSxFQUFFO1lBQ3hDdEgsR0FBRyxFQUFFLFNBQVM7WUFDZHNILFVBQVUsRUFBRXRILEdBQUcsQ0FBQ3NILFVBQVU7WUFDMUJqRyxFQUFFLEVBQUVyQixHQUFHLENBQUNxQjtVQUNWLENBQUMsQ0FBQztRQUNKO01BQ0Y7TUFFQXdJLGdCQUFnQkEsQ0FBQzdKLEdBQUcsRUFBRXVKLE9BQU8sRUFBRTtRQUM3QixNQUFNblMsSUFBSSxHQUFHLElBQUk7UUFDakI7O1FBRUE0SSxHQUFHLENBQUMwQyxPQUFPLENBQUNuRCxPQUFPLENBQUU1SCxRQUFRLElBQUs7VUFDaEMsTUFBTWlVLElBQUksR0FBR3hVLElBQUksQ0FBQzRGLHVCQUF1QixDQUFDckYsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDO1VBQ3pEeUQsTUFBTSxDQUFDNEYsTUFBTSxDQUFDNEssSUFBSSxDQUFDLENBQUNyTSxPQUFPLENBQUVzTSxPQUFPLElBQUs7WUFDdkMsTUFBTW5FLFNBQVMsR0FBR3RRLElBQUksQ0FBQytULGFBQWEsQ0FBQ1UsT0FBTyxDQUFDdkUsVUFBVSxFQUFFdUUsT0FBTyxDQUFDeEssRUFBRSxDQUFDO1lBQ3BFLElBQUksQ0FBRXFHLFNBQVMsRUFBRTtjQUNmLE1BQU0sSUFBSTdPLEtBQUssQ0FBQyxxQkFBcUIsR0FBR2lULElBQUksQ0FBQ0MsU0FBUyxDQUFDRixPQUFPLENBQUMsQ0FBQztZQUNsRTtZQUNBLElBQUksQ0FBRW5FLFNBQVMsQ0FBQ0UsY0FBYyxDQUFDalEsUUFBUSxDQUFDLEVBQUU7Y0FDeEMsTUFBTSxJQUFJa0IsS0FBSyxDQUNiLE1BQU0sR0FDSmlULElBQUksQ0FBQ0MsU0FBUyxDQUFDRixPQUFPLENBQUMsR0FDdkIsMEJBQTBCLEdBQzFCbFUsUUFDSixDQUFDO1lBQ0g7WUFDQSxPQUFPK1AsU0FBUyxDQUFDRSxjQUFjLENBQUNqUSxRQUFRLENBQUM7WUFDekMsSUFBSTJDLE9BQU8sQ0FBQ29OLFNBQVMsQ0FBQ0UsY0FBYyxDQUFDLEVBQUU7Y0FDckM7Y0FDQTtjQUNBO2NBQ0E7O2NBRUE7Y0FDQTtjQUNBO2NBQ0F4USxJQUFJLENBQUM4VCxXQUFXLENBQUMzQixPQUFPLEVBQUVzQyxPQUFPLENBQUN2RSxVQUFVLEVBQUU7Z0JBQzVDdEgsR0FBRyxFQUFFLFNBQVM7Z0JBQ2RxQixFQUFFLEVBQUVuSCxPQUFPLENBQUNRLFdBQVcsQ0FBQ21SLE9BQU8sQ0FBQ3hLLEVBQUUsQ0FBQztnQkFDbkMySyxPQUFPLEVBQUV0RSxTQUFTLENBQUNHO2NBQ3JCLENBQUMsQ0FBQztjQUNGOztjQUVBSCxTQUFTLENBQUNJLGNBQWMsQ0FBQ3ZJLE9BQU8sQ0FBRThDLENBQUMsSUFBSztnQkFDdENBLENBQUMsQ0FBQyxDQUFDO2NBQ0wsQ0FBQyxDQUFDOztjQUVGO2NBQ0E7Y0FDQTtjQUNBakwsSUFBSSxDQUFDNkYsZ0JBQWdCLENBQUM0TyxPQUFPLENBQUN2RSxVQUFVLENBQUMsQ0FBQzFGLE1BQU0sQ0FBQ2lLLE9BQU8sQ0FBQ3hLLEVBQUUsQ0FBQztZQUM5RDtVQUNGLENBQUMsQ0FBQztVQUNGLE9BQU9qSyxJQUFJLENBQUM0Rix1QkFBdUIsQ0FBQ3JGLFFBQVEsQ0FBQzs7VUFFN0M7VUFDQTtVQUNBLE1BQU1zVSxlQUFlLEdBQUc3VSxJQUFJLENBQUNzQixlQUFlLENBQUNmLFFBQVEsQ0FBQztVQUN0RCxJQUFJLENBQUVzVSxlQUFlLEVBQUU7WUFDckIsTUFBTSxJQUFJcFQsS0FBSyxDQUFDLGlDQUFpQyxHQUFHbEIsUUFBUSxDQUFDO1VBQy9EO1VBRUFQLElBQUksQ0FBQzhVLCtCQUErQixDQUNsQztZQUFBLE9BQWFELGVBQWUsQ0FBQzVTLFdBQVcsQ0FBQyxHQUFBb0csU0FBTyxDQUFDO1VBQUEsQ0FDbkQsQ0FBQztRQUNILENBQUMsQ0FBQztNQUNKO01BRUFtSyxjQUFjQSxDQUFDNUosR0FBRyxFQUFFdUosT0FBTyxFQUFFO1FBQzNCLE1BQU1uUyxJQUFJLEdBQUcsSUFBSTtRQUNqQjtRQUNBO1FBQ0E7O1FBRUE0SSxHQUFHLENBQUMrSixJQUFJLENBQUN4SyxPQUFPLENBQUV5SyxLQUFLLElBQUs7VUFDMUI1UyxJQUFJLENBQUM4VSwrQkFBK0IsQ0FBQyxNQUFNO1lBQ3pDLE1BQU1DLFNBQVMsR0FBRy9VLElBQUksQ0FBQzRHLGNBQWMsQ0FBQ2dNLEtBQUssQ0FBQztZQUM1QztZQUNBLElBQUksQ0FBQ21DLFNBQVMsRUFBRTtZQUNoQjtZQUNBLElBQUlBLFNBQVMsQ0FBQzdLLEtBQUssRUFBRTtZQUNyQjZLLFNBQVMsQ0FBQzdLLEtBQUssR0FBRyxJQUFJO1lBQ3RCNkssU0FBUyxDQUFDNUssYUFBYSxJQUFJNEssU0FBUyxDQUFDNUssYUFBYSxDQUFDLENBQUM7WUFDcEQ0SyxTQUFTLENBQUN4SyxTQUFTLENBQUNFLE9BQU8sQ0FBQyxDQUFDO1VBQy9CLENBQUMsQ0FBQztRQUNKLENBQUMsQ0FBQztNQUNKOztNQUVBO01BQ0E7TUFDQTtNQUNBcUssK0JBQStCQSxDQUFDcEwsQ0FBQyxFQUFFO1FBQ2pDLE1BQU0xSixJQUFJLEdBQUcsSUFBSTtRQUNqQixNQUFNZ1YsZ0JBQWdCLEdBQUdBLENBQUEsS0FBTTtVQUM3QmhWLElBQUksQ0FBQzhGLHFCQUFxQixDQUFDa0osSUFBSSxDQUFDdEYsQ0FBQyxDQUFDO1FBQ3BDLENBQUM7UUFDRCxJQUFJdUwsdUJBQXVCLEdBQUcsQ0FBQztRQUMvQixNQUFNQyxnQkFBZ0IsR0FBR0EsQ0FBQSxLQUFNO1VBQzdCLEVBQUVELHVCQUF1QjtVQUN6QixJQUFJQSx1QkFBdUIsS0FBSyxDQUFDLEVBQUU7WUFDakM7WUFDQTtZQUNBRCxnQkFBZ0IsQ0FBQyxDQUFDO1VBQ3BCO1FBQ0YsQ0FBQztRQUVEaFIsTUFBTSxDQUFDNEYsTUFBTSxDQUFDNUosSUFBSSxDQUFDNkYsZ0JBQWdCLENBQUMsQ0FBQ3NDLE9BQU8sQ0FBRWdOLGVBQWUsSUFBSztVQUNoRUEsZUFBZSxDQUFDaE4sT0FBTyxDQUFFbUksU0FBUyxJQUFLO1lBQ3JDLE1BQU04RSxzQ0FBc0MsR0FDMUNuUyxJQUFJLENBQUNxTixTQUFTLENBQUNFLGNBQWMsQ0FBQyxDQUFDL0csSUFBSSxDQUFDbEosUUFBUSxJQUFJO2NBQzlDLE1BQU1pUixPQUFPLEdBQUd4UixJQUFJLENBQUNzQixlQUFlLENBQUNmLFFBQVEsQ0FBQztjQUM5QyxPQUFPaVIsT0FBTyxJQUFJQSxPQUFPLENBQUNoUixXQUFXO1lBQ3ZDLENBQUMsQ0FBQztZQUVKLElBQUk0VSxzQ0FBc0MsRUFBRTtjQUMxQyxFQUFFSCx1QkFBdUI7Y0FDekIzRSxTQUFTLENBQUNJLGNBQWMsQ0FBQzFCLElBQUksQ0FBQ2tHLGdCQUFnQixDQUFDO1lBQ2pEO1VBQ0YsQ0FBQyxDQUFDO1FBQ0osQ0FBQyxDQUFDO1FBQ0YsSUFBSUQsdUJBQXVCLEtBQUssQ0FBQyxFQUFFO1VBQ2pDO1VBQ0E7VUFDQUQsZ0JBQWdCLENBQUMsQ0FBQztRQUNwQjtNQUNGO01BRUEsTUFBTUssZUFBZUEsQ0FBQ3pNLEdBQUcsRUFBRTtRQUN6QixNQUFNNUksSUFBSSxHQUFHLElBQUk7O1FBRWpCO1FBQ0E7UUFDQSxNQUFNQSxJQUFJLENBQUMwUyxjQUFjLENBQUM5SixHQUFHLENBQUM7O1FBRTlCO1FBQ0E7O1FBRUE7UUFDQSxJQUFJLENBQUU3RixNQUFNLENBQUNtRyxJQUFJLENBQUNsSixJQUFJLENBQUM0RyxjQUFjLEVBQUVnQyxHQUFHLENBQUNxQixFQUFFLENBQUMsRUFBRTtVQUM5QztRQUNGOztRQUVBO1FBQ0EsTUFBTUcsYUFBYSxHQUFHcEssSUFBSSxDQUFDNEcsY0FBYyxDQUFDZ0MsR0FBRyxDQUFDcUIsRUFBRSxDQUFDLENBQUNHLGFBQWE7UUFDL0QsTUFBTUMsWUFBWSxHQUFHckssSUFBSSxDQUFDNEcsY0FBYyxDQUFDZ0MsR0FBRyxDQUFDcUIsRUFBRSxDQUFDLENBQUNJLFlBQVk7UUFFN0RySyxJQUFJLENBQUM0RyxjQUFjLENBQUNnQyxHQUFHLENBQUNxQixFQUFFLENBQUMsQ0FBQ08sTUFBTSxDQUFDLENBQUM7UUFFcEMsTUFBTThLLGtCQUFrQixHQUFHQyxNQUFNLElBQUk7VUFDbkMsT0FDRUEsTUFBTSxJQUNOQSxNQUFNLENBQUN2RSxLQUFLLElBQ1osSUFBSXhPLE1BQU0sQ0FBQ2YsS0FBSyxDQUNkOFQsTUFBTSxDQUFDdkUsS0FBSyxDQUFDQSxLQUFLLEVBQ2xCdUUsTUFBTSxDQUFDdkUsS0FBSyxDQUFDd0UsTUFBTSxFQUNuQkQsTUFBTSxDQUFDdkUsS0FBSyxDQUFDeUUsT0FDZixDQUFDO1FBRUwsQ0FBQzs7UUFFRDtRQUNBLElBQUlyTCxhQUFhLElBQUl4QixHQUFHLENBQUNvSSxLQUFLLEVBQUU7VUFDOUI1RyxhQUFhLENBQUNrTCxrQkFBa0IsQ0FBQzFNLEdBQUcsQ0FBQyxDQUFDO1FBQ3hDO1FBRUEsSUFBSXlCLFlBQVksRUFBRTtVQUNoQkEsWUFBWSxDQUFDaUwsa0JBQWtCLENBQUMxTSxHQUFHLENBQUMsQ0FBQztRQUN2QztNQUNGO01BRUEsTUFBTThNLGdCQUFnQkEsQ0FBQzlNLEdBQUcsRUFBRTtRQUMxQjs7UUFFQSxNQUFNNUksSUFBSSxHQUFHLElBQUk7O1FBRWpCO1FBQ0EsSUFBSSxDQUFFa0QsT0FBTyxDQUFDbEQsSUFBSSxDQUFDdUcsZUFBZSxDQUFDLEVBQUU7VUFDbkMsTUFBTXZHLElBQUksQ0FBQ3NHLG9CQUFvQixDQUFDLENBQUM7UUFDbkM7O1FBRUE7UUFDQTtRQUNBLElBQUlwRCxPQUFPLENBQUNsRCxJQUFJLENBQUMyRix3QkFBd0IsQ0FBQyxFQUFFO1VBQzFDbkQsTUFBTSxDQUFDb0IsTUFBTSxDQUFDLG1EQUFtRCxDQUFDO1VBQ2xFO1FBQ0Y7UUFDQSxNQUFNK1Isa0JBQWtCLEdBQUczVixJQUFJLENBQUMyRix3QkFBd0IsQ0FBQyxDQUFDLENBQUMsQ0FBQzJGLE9BQU87UUFDbkUsSUFBSXNLLENBQUM7UUFDTCxNQUFNQyxDQUFDLEdBQUdGLGtCQUFrQixDQUFDOUwsSUFBSSxDQUFDLENBQUN6QixNQUFNLEVBQUUwTixHQUFHLEtBQUs7VUFDakQsTUFBTUMsS0FBSyxHQUFHM04sTUFBTSxDQUFDN0gsUUFBUSxLQUFLcUksR0FBRyxDQUFDcUIsRUFBRTtVQUN4QyxJQUFJOEwsS0FBSyxFQUFFSCxDQUFDLEdBQUdFLEdBQUc7VUFDbEIsT0FBT0MsS0FBSztRQUNkLENBQUMsQ0FBQztRQUNGLElBQUksQ0FBQ0YsQ0FBQyxFQUFFO1VBQ05yVCxNQUFNLENBQUNvQixNQUFNLENBQUMscURBQXFELEVBQUVnRixHQUFHLENBQUM7VUFDekU7UUFDRjs7UUFFQTtRQUNBO1FBQ0E7UUFDQStNLGtCQUFrQixDQUFDSyxNQUFNLENBQUNKLENBQUMsRUFBRSxDQUFDLENBQUM7UUFFL0IsSUFBSTdTLE1BQU0sQ0FBQ21HLElBQUksQ0FBQ04sR0FBRyxFQUFFLE9BQU8sQ0FBQyxFQUFFO1VBQzdCaU4sQ0FBQyxDQUFDL1QsYUFBYSxDQUNiLElBQUlVLE1BQU0sQ0FBQ2YsS0FBSyxDQUFDbUgsR0FBRyxDQUFDb0ksS0FBSyxDQUFDQSxLQUFLLEVBQUVwSSxHQUFHLENBQUNvSSxLQUFLLENBQUN3RSxNQUFNLEVBQUU1TSxHQUFHLENBQUNvSSxLQUFLLENBQUN5RSxPQUFPLENBQ3ZFLENBQUM7UUFDSCxDQUFDLE1BQU07VUFDTDtVQUNBO1VBQ0FJLENBQUMsQ0FBQy9ULGFBQWEsQ0FBQ21MLFNBQVMsRUFBRXJFLEdBQUcsQ0FBQzVHLE1BQU0sQ0FBQztRQUN4QztNQUNGOztNQUVBO01BQ0E7TUFDQTtNQUNBSCwwQkFBMEJBLENBQUEsRUFBRztRQUMzQixNQUFNN0IsSUFBSSxHQUFHLElBQUk7UUFDakIsSUFBSUEsSUFBSSxDQUFDc1IseUJBQXlCLENBQUMsQ0FBQyxFQUFFOztRQUV0QztRQUNBO1FBQ0E7UUFDQSxJQUFJLENBQUVwTyxPQUFPLENBQUNsRCxJQUFJLENBQUMyRix3QkFBd0IsQ0FBQyxFQUFFO1VBQzVDLE1BQU1zUSxVQUFVLEdBQUdqVyxJQUFJLENBQUMyRix3QkFBd0IsQ0FBQ2tKLEtBQUssQ0FBQyxDQUFDO1VBQ3hELElBQUksQ0FBRTNMLE9BQU8sQ0FBQytTLFVBQVUsQ0FBQzNLLE9BQU8sQ0FBQyxFQUMvQixNQUFNLElBQUk3SixLQUFLLENBQ2IsNkNBQTZDLEdBQzNDaVQsSUFBSSxDQUFDQyxTQUFTLENBQUNzQixVQUFVLENBQzdCLENBQUM7O1VBRUg7VUFDQSxJQUFJLENBQUUvUyxPQUFPLENBQUNsRCxJQUFJLENBQUMyRix3QkFBd0IsQ0FBQyxFQUMxQzNGLElBQUksQ0FBQ2tXLHVCQUF1QixDQUFDLENBQUM7UUFDbEM7O1FBRUE7UUFDQWxXLElBQUksQ0FBQ21XLGFBQWEsQ0FBQyxDQUFDO01BQ3RCOztNQUVBO01BQ0E7TUFDQUQsdUJBQXVCQSxDQUFBLEVBQUc7UUFDeEIsTUFBTWxXLElBQUksR0FBRyxJQUFJO1FBRWpCLElBQUlrRCxPQUFPLENBQUNsRCxJQUFJLENBQUMyRix3QkFBd0IsQ0FBQyxFQUFFO1VBQzFDO1FBQ0Y7UUFFQTNGLElBQUksQ0FBQzJGLHdCQUF3QixDQUFDLENBQUMsQ0FBQyxDQUFDMkYsT0FBTyxDQUFDbkQsT0FBTyxDQUFDME4sQ0FBQyxJQUFJO1VBQ3BEQSxDQUFDLENBQUN0VSxXQUFXLENBQUMsQ0FBQztRQUNqQixDQUFDLENBQUM7TUFDSjtNQUVBNlUsZUFBZUEsQ0FBQ3hOLEdBQUcsRUFBRTtRQUNuQnBHLE1BQU0sQ0FBQ29CLE1BQU0sQ0FBQyw4QkFBOEIsRUFBRWdGLEdBQUcsQ0FBQzRNLE1BQU0sQ0FBQztRQUN6RCxJQUFJNU0sR0FBRyxDQUFDeU4sZ0JBQWdCLEVBQUU3VCxNQUFNLENBQUNvQixNQUFNLENBQUMsT0FBTyxFQUFFZ0YsR0FBRyxDQUFDeU4sZ0JBQWdCLENBQUM7TUFDeEU7TUFFQUMsb0NBQW9DQSxDQUFDQywwQkFBMEIsRUFBRTtRQUMvRCxNQUFNdlcsSUFBSSxHQUFHLElBQUk7UUFDakIsSUFBSWtELE9BQU8sQ0FBQ3FULDBCQUEwQixDQUFDLEVBQUU7O1FBRXpDO1FBQ0E7UUFDQTtRQUNBLElBQUlyVCxPQUFPLENBQUNsRCxJQUFJLENBQUMyRix3QkFBd0IsQ0FBQyxFQUFFO1VBQzFDM0YsSUFBSSxDQUFDMkYsd0JBQXdCLEdBQUc0USwwQkFBMEI7VUFDMUR2VyxJQUFJLENBQUNrVyx1QkFBdUIsQ0FBQyxDQUFDO1VBQzlCO1FBQ0Y7O1FBRUE7UUFDQTtRQUNBO1FBQ0EsSUFDRSxDQUFDL1MsSUFBSSxDQUFDbkQsSUFBSSxDQUFDMkYsd0JBQXdCLENBQUMsQ0FBQ3pFLElBQUksSUFDekMsQ0FBQ3FWLDBCQUEwQixDQUFDLENBQUMsQ0FBQyxDQUFDclYsSUFBSSxFQUNuQztVQUNBcVYsMEJBQTBCLENBQUMsQ0FBQyxDQUFDLENBQUNqTCxPQUFPLENBQUNuRCxPQUFPLENBQUUwTixDQUFDLElBQUs7WUFDbkQxUyxJQUFJLENBQUNuRCxJQUFJLENBQUMyRix3QkFBd0IsQ0FBQyxDQUFDMkYsT0FBTyxDQUFDMEQsSUFBSSxDQUFDNkcsQ0FBQyxDQUFDOztZQUVuRDtZQUNBLElBQUk3VixJQUFJLENBQUMyRix3QkFBd0IsQ0FBQ2dELE1BQU0sS0FBSyxDQUFDLEVBQUU7Y0FDOUNrTixDQUFDLENBQUN0VSxXQUFXLENBQUMsQ0FBQztZQUNqQjtVQUNGLENBQUMsQ0FBQztVQUVGZ1YsMEJBQTBCLENBQUMxSCxLQUFLLENBQUMsQ0FBQztRQUNwQzs7UUFFQTtRQUNBN08sSUFBSSxDQUFDMkYsd0JBQXdCLENBQUNxSixJQUFJLENBQUMsR0FBR3VILDBCQUEwQixDQUFDO01BQ25FO01BQ0FDLG9EQUFvREEsQ0FBQSxFQUFHO1FBQ3JELE1BQU14VyxJQUFJLEdBQUcsSUFBSTtRQUNqQixNQUFNdVcsMEJBQTBCLEdBQUd2VyxJQUFJLENBQUMyRix3QkFBd0I7UUFDaEUzRixJQUFJLENBQUMyRix3QkFBd0IsR0FBRyxFQUFFO1FBRWxDM0YsSUFBSSxDQUFDeUUsV0FBVyxJQUFJekUsSUFBSSxDQUFDeUUsV0FBVyxDQUFDLENBQUM7UUFDdEM3RSxHQUFHLENBQUM2VyxjQUFjLENBQUNDLElBQUksQ0FBRWhXLFFBQVEsSUFBSztVQUNwQ0EsUUFBUSxDQUFDVixJQUFJLENBQUM7VUFDZCxPQUFPLElBQUk7UUFDYixDQUFDLENBQUM7UUFFRkEsSUFBSSxDQUFDc1csb0NBQW9DLENBQUNDLDBCQUEwQixDQUFDO01BQ3ZFOztNQUVBO01BQ0FsUCxlQUFlQSxDQUFBLEVBQUc7UUFDaEIsT0FBT25FLE9BQU8sQ0FBQyxJQUFJLENBQUM1QixlQUFlLENBQUM7TUFDdEM7O01BRUE7TUFDQTtNQUNBNlUsYUFBYUEsQ0FBQSxFQUFHO1FBQ2QsTUFBTW5XLElBQUksR0FBRyxJQUFJO1FBQ2pCLElBQUlBLElBQUksQ0FBQ21HLGFBQWEsSUFBSW5HLElBQUksQ0FBQ3FILGVBQWUsQ0FBQyxDQUFDLEVBQUU7VUFDaERySCxJQUFJLENBQUNtRyxhQUFhLENBQUMsQ0FBQztVQUNwQm5HLElBQUksQ0FBQ21HLGFBQWEsR0FBRyxJQUFJO1FBQzNCO01BQ0Y7TUFFQSxNQUFNd0IsU0FBU0EsQ0FBQ2dQLE9BQU8sRUFBRTtRQUN2QixJQUFJL04sR0FBRztRQUNQLElBQUk7VUFDRkEsR0FBRyxHQUFHbkcsU0FBUyxDQUFDbVUsUUFBUSxDQUFDRCxPQUFPLENBQUM7UUFDbkMsQ0FBQyxDQUFDLE9BQU83SixDQUFDLEVBQUU7VUFDVnRLLE1BQU0sQ0FBQ29CLE1BQU0sQ0FBQyw2QkFBNkIsRUFBRWtKLENBQUMsQ0FBQztVQUMvQztRQUNGOztRQUVBO1FBQ0E7UUFDQSxJQUFJLElBQUksQ0FBQ3ZGLFVBQVUsRUFBRTtVQUNuQixJQUFJLENBQUNBLFVBQVUsQ0FBQ3NQLGVBQWUsQ0FBQyxDQUFDO1FBQ25DO1FBRUEsSUFBSWpPLEdBQUcsS0FBSyxJQUFJLElBQUksQ0FBQ0EsR0FBRyxDQUFDQSxHQUFHLEVBQUU7VUFDNUIsSUFBRyxDQUFDQSxHQUFHLElBQUksQ0FBQ0EsR0FBRyxDQUFDa08sb0JBQW9CLEVBQUU7WUFDcEMsSUFBSTlTLE1BQU0sQ0FBQ2YsSUFBSSxDQUFDMkYsR0FBRyxDQUFDLENBQUNELE1BQU0sS0FBSyxDQUFDLElBQUlDLEdBQUcsQ0FBQ21PLFNBQVMsRUFBRTtZQUNwRHZVLE1BQU0sQ0FBQ29CLE1BQU0sQ0FBQyxxQ0FBcUMsRUFBRWdGLEdBQUcsQ0FBQztVQUMzRDtVQUNBO1FBQ0Y7UUFFQSxJQUFJQSxHQUFHLENBQUNBLEdBQUcsS0FBSyxXQUFXLEVBQUU7VUFDM0IsSUFBSSxDQUFDeEQsUUFBUSxHQUFHLElBQUksQ0FBQ0Qsa0JBQWtCO1VBQ3ZDLE1BQU0sSUFBSSxDQUFDc00sbUJBQW1CLENBQUM3SSxHQUFHLENBQUM7VUFDbkMsSUFBSSxDQUFDdEksT0FBTyxDQUFDbUQsV0FBVyxDQUFDLENBQUM7UUFDNUIsQ0FBQyxNQUFNLElBQUltRixHQUFHLENBQUNBLEdBQUcsS0FBSyxRQUFRLEVBQUU7VUFDL0IsSUFBSSxJQUFJLENBQUNwRCxxQkFBcUIsQ0FBQ3dSLE9BQU8sQ0FBQ3BPLEdBQUcsQ0FBQ3FPLE9BQU8sQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUN4RCxJQUFJLENBQUM5UixrQkFBa0IsR0FBR3lELEdBQUcsQ0FBQ3FPLE9BQU87WUFDckMsSUFBSSxDQUFDdlMsT0FBTyxDQUFDd00sU0FBUyxDQUFDO2NBQUVnRyxNQUFNLEVBQUU7WUFBSyxDQUFDLENBQUM7VUFDMUMsQ0FBQyxNQUFNO1lBQ0wsTUFBTXZULFdBQVcsR0FDZiwyREFBMkQsR0FDM0RpRixHQUFHLENBQUNxTyxPQUFPO1lBQ2IsSUFBSSxDQUFDdlMsT0FBTyxDQUFDeU0sVUFBVSxDQUFDO2NBQUVFLFVBQVUsRUFBRSxJQUFJO2NBQUU4RixNQUFNLEVBQUV4VDtZQUFZLENBQUMsQ0FBQztZQUNsRSxJQUFJLENBQUNyRCxPQUFPLENBQUNvRCw4QkFBOEIsQ0FBQ0MsV0FBVyxDQUFDO1VBQzFEO1FBQ0YsQ0FBQyxNQUFNLElBQUlpRixHQUFHLENBQUNBLEdBQUcsS0FBSyxNQUFNLElBQUksSUFBSSxDQUFDdEksT0FBTyxDQUFDZ0UsY0FBYyxFQUFFO1VBQzVELElBQUksQ0FBQzNDLEtBQUssQ0FBQztZQUFFaUgsR0FBRyxFQUFFLE1BQU07WUFBRXFCLEVBQUUsRUFBRXJCLEdBQUcsQ0FBQ3FCO1VBQUcsQ0FBQyxDQUFDO1FBQ3pDLENBQUMsTUFBTSxJQUFJckIsR0FBRyxDQUFDQSxHQUFHLEtBQUssTUFBTSxFQUFFO1VBQzdCO1FBQUEsQ0FDRCxNQUFNLElBQ0wsQ0FBQyxPQUFPLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxPQUFPLEVBQUUsU0FBUyxDQUFDLENBQUN3TyxRQUFRLENBQUN4TyxHQUFHLENBQUNBLEdBQUcsQ0FBQyxFQUNyRTtVQUNBLE1BQU0sSUFBSSxDQUFDOEosY0FBYyxDQUFDOUosR0FBRyxDQUFDO1FBQ2hDLENBQUMsTUFBTSxJQUFJQSxHQUFHLENBQUNBLEdBQUcsS0FBSyxPQUFPLEVBQUU7VUFDOUIsTUFBTSxJQUFJLENBQUN5TSxlQUFlLENBQUN6TSxHQUFHLENBQUM7UUFDakMsQ0FBQyxNQUFNLElBQUlBLEdBQUcsQ0FBQ0EsR0FBRyxLQUFLLFFBQVEsRUFBRTtVQUMvQixNQUFNLElBQUksQ0FBQzhNLGdCQUFnQixDQUFDOU0sR0FBRyxDQUFDO1FBQ2xDLENBQUMsTUFBTSxJQUFJQSxHQUFHLENBQUNBLEdBQUcsS0FBSyxPQUFPLEVBQUU7VUFDOUIsSUFBSSxDQUFDd04sZUFBZSxDQUFDeE4sR0FBRyxDQUFDO1FBQzNCLENBQUMsTUFBTTtVQUNMcEcsTUFBTSxDQUFDb0IsTUFBTSxDQUFDLDBDQUEwQyxFQUFFZ0YsR0FBRyxDQUFDO1FBQ2hFO01BQ0Y7TUFFQWYsT0FBT0EsQ0FBQSxFQUFHO1FBQ1I7UUFDQTtRQUNBO1FBQ0EsTUFBTWUsR0FBRyxHQUFHO1VBQUVBLEdBQUcsRUFBRTtRQUFVLENBQUM7UUFDOUIsSUFBSSxJQUFJLENBQUMxRCxjQUFjLEVBQUUwRCxHQUFHLENBQUNtSixPQUFPLEdBQUcsSUFBSSxDQUFDN00sY0FBYztRQUMxRDBELEdBQUcsQ0FBQ3FPLE9BQU8sR0FBRyxJQUFJLENBQUM5UixrQkFBa0IsSUFBSSxJQUFJLENBQUNLLHFCQUFxQixDQUFDLENBQUMsQ0FBQztRQUN0RSxJQUFJLENBQUNMLGtCQUFrQixHQUFHeUQsR0FBRyxDQUFDcU8sT0FBTztRQUNyQ3JPLEdBQUcsQ0FBQ3lPLE9BQU8sR0FBRyxJQUFJLENBQUM3UixxQkFBcUI7UUFDeEMsSUFBSSxDQUFDN0QsS0FBSyxDQUFDaUgsR0FBRyxDQUFDOztRQUVmO1FBQ0E7UUFDQTs7UUFFQTtRQUNBO1FBQ0EsSUFBSSxJQUFJLENBQUNqRCx3QkFBd0IsQ0FBQ2dELE1BQU0sR0FBRyxDQUFDLEVBQUU7VUFDNUM7VUFDQTtVQUNBLE1BQU1nTixrQkFBa0IsR0FBRyxJQUFJLENBQUNoUSx3QkFBd0IsQ0FBQyxDQUFDLENBQUMsQ0FBQzJGLE9BQU87VUFDbkUsSUFBSSxDQUFDM0Ysd0JBQXdCLENBQUMsQ0FBQyxDQUFDLENBQUMyRixPQUFPLEdBQUdxSyxrQkFBa0IsQ0FBQzJCLE1BQU0sQ0FDbEV2SSxhQUFhLElBQUk7WUFDZjtZQUNBO1lBQ0EsSUFBSUEsYUFBYSxDQUFDdk8sV0FBVyxJQUFJdU8sYUFBYSxDQUFDNU4sT0FBTyxFQUFFO2NBQ3REO2NBQ0E0TixhQUFhLENBQUNqTixhQUFhLENBQ3pCLElBQUlVLE1BQU0sQ0FBQ2YsS0FBSyxDQUNkLG1CQUFtQixFQUNuQixpRUFBaUUsR0FDL0QsOERBQ0osQ0FDRixDQUFDO1lBQ0g7O1lBRUE7WUFDQTtZQUNBO1lBQ0EsT0FBTyxFQUFFc04sYUFBYSxDQUFDdk8sV0FBVyxJQUFJdU8sYUFBYSxDQUFDNU4sT0FBTyxDQUFDO1VBQzlELENBQ0YsQ0FBQztRQUNIOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBLElBQ0UsSUFBSSxDQUFDd0Usd0JBQXdCLENBQUNnRCxNQUFNLEdBQUcsQ0FBQyxJQUN4QyxJQUFJLENBQUNoRCx3QkFBd0IsQ0FBQyxDQUFDLENBQUMsQ0FBQzJGLE9BQU8sQ0FBQzNDLE1BQU0sS0FBSyxDQUFDLEVBQ3JEO1VBQ0EsSUFBSSxDQUFDaEQsd0JBQXdCLENBQUNrSixLQUFLLENBQUMsQ0FBQztRQUN2Qzs7UUFFQTtRQUNBO1FBQ0E1TCxJQUFJLENBQUMsSUFBSSxDQUFDM0IsZUFBZSxDQUFDLENBQUM2RyxPQUFPLENBQUM4QixFQUFFLElBQUk7VUFDdkMsSUFBSSxDQUFDM0ksZUFBZSxDQUFDMkksRUFBRSxDQUFDLENBQUN6SixXQUFXLEdBQUcsS0FBSztRQUM5QyxDQUFDLENBQUM7O1FBRUY7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBLElBQUksQ0FBQ2dXLG9EQUFvRCxDQUFDLENBQUM7O1FBRTNEO1FBQ0E7UUFDQXhTLE1BQU0sQ0FBQ3VILE9BQU8sQ0FBQyxJQUFJLENBQUMzRSxjQUFjLENBQUMsQ0FBQ3VCLE9BQU8sQ0FBQ29QLEtBQUEsSUFBZTtVQUFBLElBQWQsQ0FBQ3ROLEVBQUUsRUFBRUgsR0FBRyxDQUFDLEdBQUF5TixLQUFBO1VBQ3BELElBQUksQ0FBQzVWLEtBQUssQ0FBQztZQUNUaUgsR0FBRyxFQUFFLEtBQUs7WUFDVnFCLEVBQUUsRUFBRUEsRUFBRTtZQUNObEMsSUFBSSxFQUFFK0IsR0FBRyxDQUFDL0IsSUFBSTtZQUNka0IsTUFBTSxFQUFFYSxHQUFHLENBQUNiO1VBQ2QsQ0FBQyxDQUFDO1FBQ0osQ0FBQyxDQUFDO01BQ0o7SUFDRjtJQUFDbkosc0JBQUE7RUFBQSxTQUFBQyxXQUFBO0lBQUEsT0FBQUQsc0JBQUEsQ0FBQUMsV0FBQTtFQUFBO0VBQUFELHNCQUFBO0FBQUE7RUFBQUUsSUFBQTtFQUFBQyxLQUFBO0FBQUEsRzs7Ozs7Ozs7Ozs7Ozs7SUN4OUREUCxNQUFNLENBQUNRLE1BQU0sQ0FBQztNQUFDTixHQUFHLEVBQUNBLENBQUEsS0FBSUE7SUFBRyxDQUFDLENBQUM7SUFBQyxJQUFJNkMsU0FBUztJQUFDL0MsTUFBTSxDQUFDQyxJQUFJLENBQUMsbUJBQW1CLEVBQUM7TUFBQzhDLFNBQVNBLENBQUNOLENBQUMsRUFBQztRQUFDTSxTQUFTLEdBQUNOLENBQUM7TUFBQTtJQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7SUFBQyxJQUFJSyxNQUFNO0lBQUM5QyxNQUFNLENBQUNDLElBQUksQ0FBQyxlQUFlLEVBQUM7TUFBQzZDLE1BQU1BLENBQUNMLENBQUMsRUFBQztRQUFDSyxNQUFNLEdBQUNMLENBQUM7TUFBQTtJQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7SUFBQyxJQUFJSSxVQUFVO0lBQUM3QyxNQUFNLENBQUNDLElBQUksQ0FBQywwQkFBMEIsRUFBQztNQUFDNEMsVUFBVUEsQ0FBQ0osQ0FBQyxFQUFDO1FBQUNJLFVBQVUsR0FBQ0osQ0FBQztNQUFBO0lBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztJQUFDLElBQUl0QyxvQkFBb0IsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxNQUFNQSxvQkFBb0IsQ0FBQyxDQUFDLEVBQUUsQ0FBQztJQUs3VDtJQUNBO0lBQ0E7SUFDQSxNQUFNMlgsY0FBYyxHQUFHLEVBQUU7O0lBRXpCO0FBQ0E7QUFDQTtBQUNBO0lBQ08sTUFBTTVYLEdBQUcsR0FBRyxDQUFDLENBQUM7SUFFckI7SUFDQTtJQUNBO0lBQ0FBLEdBQUcsQ0FBQ3dMLHdCQUF3QixHQUFHLElBQUk1SSxNQUFNLENBQUNpVixtQkFBbUIsQ0FBQyxDQUFDO0lBQy9EN1gsR0FBRyxDQUFDOFgsNkJBQTZCLEdBQUcsSUFBSWxWLE1BQU0sQ0FBQ2lWLG1CQUFtQixDQUFDLENBQUM7O0lBRXBFO0lBQ0E3WCxHQUFHLENBQUMrWCxrQkFBa0IsR0FBRy9YLEdBQUcsQ0FBQ3dMLHdCQUF3QjtJQUVyRHhMLEdBQUcsQ0FBQ2dZLDJCQUEyQixHQUFHLElBQUlwVixNQUFNLENBQUNpVixtQkFBbUIsQ0FBQyxDQUFDOztJQUVsRTtJQUNBO0lBQ0EsU0FBU0ksMEJBQTBCQSxDQUFDL1csT0FBTyxFQUFFO01BQzNDLElBQUksQ0FBQ0EsT0FBTyxHQUFHQSxPQUFPO0lBQ3hCO0lBRUFsQixHQUFHLENBQUNpRixlQUFlLEdBQUdyQyxNQUFNLENBQUNzVixhQUFhLENBQ3hDLHFCQUFxQixFQUNyQkQsMEJBQ0YsQ0FBQztJQUVEalksR0FBRyxDQUFDbVksb0JBQW9CLEdBQUd2VixNQUFNLENBQUNzVixhQUFhLENBQzdDLDBCQUEwQixFQUMxQixNQUFNLENBQUMsQ0FDVCxDQUFDOztJQUVEO0lBQ0E7SUFDQTtJQUNBbFksR0FBRyxDQUFDb1ksWUFBWSxHQUFHalEsSUFBSSxJQUFJO01BQ3pCLE1BQU1rUSxLQUFLLEdBQUdyWSxHQUFHLENBQUN3TCx3QkFBd0IsQ0FBQzhELEdBQUcsQ0FBQyxDQUFDO01BQ2hELE9BQU96TSxTQUFTLENBQUN5VixZQUFZLENBQUNoSixHQUFHLENBQUMrSSxLQUFLLEVBQUVsUSxJQUFJLENBQUM7SUFDaEQsQ0FBQzs7SUFFRDtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7O0lBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7SUFDQW5JLEdBQUcsQ0FBQ3VZLE9BQU8sR0FBRyxDQUFDM1UsR0FBRyxFQUFFbEQsT0FBTyxLQUFLO01BQzlCLE1BQU04WCxHQUFHLEdBQUcsSUFBSTdWLFVBQVUsQ0FBQ2lCLEdBQUcsRUFBRWxELE9BQU8sQ0FBQztNQUN4Q2tYLGNBQWMsQ0FBQ3hJLElBQUksQ0FBQ29KLEdBQUcsQ0FBQyxDQUFDLENBQUM7TUFDMUIsT0FBT0EsR0FBRztJQUNaLENBQUM7SUFFRHhZLEdBQUcsQ0FBQzZXLGNBQWMsR0FBRyxJQUFJNVQsSUFBSSxDQUFDO01BQUV3RCxlQUFlLEVBQUU7SUFBTSxDQUFDLENBQUM7O0lBRXpEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtJQUNBekcsR0FBRyxDQUFDNkUsV0FBVyxHQUFHL0QsUUFBUSxJQUFJZCxHQUFHLENBQUM2VyxjQUFjLENBQUM0QixRQUFRLENBQUMzWCxRQUFRLENBQUM7O0lBRW5FO0lBQ0E7SUFDQTtJQUNBZCxHQUFHLENBQUMwWSxzQkFBc0IsR0FBRyxNQUFNZCxjQUFjLENBQUNlLEtBQUssQ0FDckRDLElBQUksSUFBSXhVLE1BQU0sQ0FBQzRGLE1BQU0sQ0FBQzRPLElBQUksQ0FBQzVSLGNBQWMsQ0FBQyxDQUFDMlIsS0FBSyxDQUFDek8sR0FBRyxJQUFJQSxHQUFHLENBQUNJLEtBQUssQ0FDbkUsQ0FBQztJQUFDcEssc0JBQUE7RUFBQSxTQUFBQyxXQUFBO0lBQUEsT0FBQUQsc0JBQUEsQ0FBQUMsV0FBQTtFQUFBO0VBQUFELHNCQUFBO0FBQUE7RUFBQUUsSUFBQTtFQUFBQyxLQUFBO0FBQUEsRyIsImZpbGUiOiIvcGFja2FnZXMvZGRwLWNsaWVudC5qcyIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCB7IEREUCB9IGZyb20gJy4uL2NvbW1vbi9uYW1lc3BhY2UuanMnO1xuIiwiLy8gQSBNZXRob2RJbnZva2VyIG1hbmFnZXMgc2VuZGluZyBhIG1ldGhvZCB0byB0aGUgc2VydmVyIGFuZCBjYWxsaW5nIHRoZSB1c2VyJ3Ncbi8vIGNhbGxiYWNrcy4gT24gY29uc3RydWN0aW9uLCBpdCByZWdpc3RlcnMgaXRzZWxmIGluIHRoZSBjb25uZWN0aW9uJ3Ncbi8vIF9tZXRob2RJbnZva2VycyBtYXA7IGl0IHJlbW92ZXMgaXRzZWxmIG9uY2UgdGhlIG1ldGhvZCBpcyBmdWxseSBmaW5pc2hlZCBhbmRcbi8vIHRoZSBjYWxsYmFjayBpcyBpbnZva2VkLiBUaGlzIG9jY3VycyB3aGVuIGl0IGhhcyBib3RoIHJlY2VpdmVkIGEgcmVzdWx0LFxuLy8gYW5kIHRoZSBkYXRhIHdyaXR0ZW4gYnkgaXQgaXMgZnVsbHkgdmlzaWJsZS5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE1ldGhvZEludm9rZXIge1xuICBjb25zdHJ1Y3RvcihvcHRpb25zKSB7XG4gICAgLy8gUHVibGljICh3aXRoaW4gdGhpcyBmaWxlKSBmaWVsZHMuXG4gICAgdGhpcy5tZXRob2RJZCA9IG9wdGlvbnMubWV0aG9kSWQ7XG4gICAgdGhpcy5zZW50TWVzc2FnZSA9IGZhbHNlO1xuXG4gICAgdGhpcy5fY2FsbGJhY2sgPSBvcHRpb25zLmNhbGxiYWNrO1xuICAgIHRoaXMuX2Nvbm5lY3Rpb24gPSBvcHRpb25zLmNvbm5lY3Rpb247XG4gICAgdGhpcy5fbWVzc2FnZSA9IG9wdGlvbnMubWVzc2FnZTtcbiAgICB0aGlzLl9vblJlc3VsdFJlY2VpdmVkID0gb3B0aW9ucy5vblJlc3VsdFJlY2VpdmVkIHx8ICgoKSA9PiB7fSk7XG4gICAgdGhpcy5fd2FpdCA9IG9wdGlvbnMud2FpdDtcbiAgICB0aGlzLm5vUmV0cnkgPSBvcHRpb25zLm5vUmV0cnk7XG4gICAgdGhpcy5fbWV0aG9kUmVzdWx0ID0gbnVsbDtcbiAgICB0aGlzLl9kYXRhVmlzaWJsZSA9IGZhbHNlO1xuXG4gICAgLy8gUmVnaXN0ZXIgd2l0aCB0aGUgY29ubmVjdGlvbi5cbiAgICB0aGlzLl9jb25uZWN0aW9uLl9tZXRob2RJbnZva2Vyc1t0aGlzLm1ldGhvZElkXSA9IHRoaXM7XG4gIH1cbiAgLy8gU2VuZHMgdGhlIG1ldGhvZCBtZXNzYWdlIHRvIHRoZSBzZXJ2ZXIuIE1heSBiZSBjYWxsZWQgYWRkaXRpb25hbCB0aW1lcyBpZlxuICAvLyB3ZSBsb3NlIHRoZSBjb25uZWN0aW9uIGFuZCByZWNvbm5lY3QgYmVmb3JlIHJlY2VpdmluZyBhIHJlc3VsdC5cbiAgc2VuZE1lc3NhZ2UoKSB7XG4gICAgLy8gVGhpcyBmdW5jdGlvbiBpcyBjYWxsZWQgYmVmb3JlIHNlbmRpbmcgYSBtZXRob2QgKGluY2x1ZGluZyByZXNlbmRpbmcgb25cbiAgICAvLyByZWNvbm5lY3QpLiBXZSBzaG91bGQgb25seSAocmUpc2VuZCBtZXRob2RzIHdoZXJlIHdlIGRvbid0IGFscmVhZHkgaGF2ZSBhXG4gICAgLy8gcmVzdWx0IVxuICAgIGlmICh0aGlzLmdvdFJlc3VsdCgpKVxuICAgICAgdGhyb3cgbmV3IEVycm9yKCdzZW5kaW5nTWV0aG9kIGlzIGNhbGxlZCBvbiBtZXRob2Qgd2l0aCByZXN1bHQnKTtcblxuICAgIC8vIElmIHdlJ3JlIHJlLXNlbmRpbmcgaXQsIGl0IGRvZXNuJ3QgbWF0dGVyIGlmIGRhdGEgd2FzIHdyaXR0ZW4gdGhlIGZpcnN0XG4gICAgLy8gdGltZS5cbiAgICB0aGlzLl9kYXRhVmlzaWJsZSA9IGZhbHNlO1xuICAgIHRoaXMuc2VudE1lc3NhZ2UgPSB0cnVlO1xuXG4gICAgLy8gSWYgdGhpcyBpcyBhIHdhaXQgbWV0aG9kLCBtYWtlIGFsbCBkYXRhIG1lc3NhZ2VzIGJlIGJ1ZmZlcmVkIHVudGlsIGl0IGlzXG4gICAgLy8gZG9uZS5cbiAgICBpZiAodGhpcy5fd2FpdClcbiAgICAgIHRoaXMuX2Nvbm5lY3Rpb24uX21ldGhvZHNCbG9ja2luZ1F1aWVzY2VuY2VbdGhpcy5tZXRob2RJZF0gPSB0cnVlO1xuXG4gICAgLy8gQWN0dWFsbHkgc2VuZCB0aGUgbWVzc2FnZS5cbiAgICB0aGlzLl9jb25uZWN0aW9uLl9zZW5kKHRoaXMuX21lc3NhZ2UpO1xuICB9XG4gIC8vIEludm9rZSB0aGUgY2FsbGJhY2ssIGlmIHdlIGhhdmUgYm90aCBhIHJlc3VsdCBhbmQga25vdyB0aGF0IGFsbCBkYXRhIGhhc1xuICAvLyBiZWVuIHdyaXR0ZW4gdG8gdGhlIGxvY2FsIGNhY2hlLlxuICBfbWF5YmVJbnZva2VDYWxsYmFjaygpIHtcbiAgICBpZiAodGhpcy5fbWV0aG9kUmVzdWx0ICYmIHRoaXMuX2RhdGFWaXNpYmxlKSB7XG4gICAgICAvLyBDYWxsIHRoZSBjYWxsYmFjay4gKFRoaXMgd29uJ3QgdGhyb3c6IHRoZSBjYWxsYmFjayB3YXMgd3JhcHBlZCB3aXRoXG4gICAgICAvLyBiaW5kRW52aXJvbm1lbnQuKVxuICAgICAgdGhpcy5fY2FsbGJhY2sodGhpcy5fbWV0aG9kUmVzdWx0WzBdLCB0aGlzLl9tZXRob2RSZXN1bHRbMV0pO1xuXG4gICAgICAvLyBGb3JnZXQgYWJvdXQgdGhpcyBtZXRob2QuXG4gICAgICBkZWxldGUgdGhpcy5fY29ubmVjdGlvbi5fbWV0aG9kSW52b2tlcnNbdGhpcy5tZXRob2RJZF07XG5cbiAgICAgIC8vIExldCB0aGUgY29ubmVjdGlvbiBrbm93IHRoYXQgdGhpcyBtZXRob2QgaXMgZmluaXNoZWQsIHNvIGl0IGNhbiB0cnkgdG9cbiAgICAgIC8vIG1vdmUgb24gdG8gdGhlIG5leHQgYmxvY2sgb2YgbWV0aG9kcy5cbiAgICAgIHRoaXMuX2Nvbm5lY3Rpb24uX291dHN0YW5kaW5nTWV0aG9kRmluaXNoZWQoKTtcbiAgICB9XG4gIH1cbiAgLy8gQ2FsbCB3aXRoIHRoZSByZXN1bHQgb2YgdGhlIG1ldGhvZCBmcm9tIHRoZSBzZXJ2ZXIuIE9ubHkgbWF5IGJlIGNhbGxlZFxuICAvLyBvbmNlOyBvbmNlIGl0IGlzIGNhbGxlZCwgeW91IHNob3VsZCBub3QgY2FsbCBzZW5kTWVzc2FnZSBhZ2Fpbi5cbiAgLy8gSWYgdGhlIHVzZXIgcHJvdmlkZWQgYW4gb25SZXN1bHRSZWNlaXZlZCBjYWxsYmFjaywgY2FsbCBpdCBpbW1lZGlhdGVseS5cbiAgLy8gVGhlbiBpbnZva2UgdGhlIG1haW4gY2FsbGJhY2sgaWYgZGF0YSBpcyBhbHNvIHZpc2libGUuXG4gIHJlY2VpdmVSZXN1bHQoZXJyLCByZXN1bHQpIHtcbiAgICBpZiAodGhpcy5nb3RSZXN1bHQoKSlcbiAgICAgIHRocm93IG5ldyBFcnJvcignTWV0aG9kcyBzaG91bGQgb25seSByZWNlaXZlIHJlc3VsdHMgb25jZScpO1xuICAgIHRoaXMuX21ldGhvZFJlc3VsdCA9IFtlcnIsIHJlc3VsdF07XG4gICAgdGhpcy5fb25SZXN1bHRSZWNlaXZlZChlcnIsIHJlc3VsdCk7XG4gICAgdGhpcy5fbWF5YmVJbnZva2VDYWxsYmFjaygpO1xuICB9XG4gIC8vIENhbGwgdGhpcyB3aGVuIGFsbCBkYXRhIHdyaXR0ZW4gYnkgdGhlIG1ldGhvZCBpcyB2aXNpYmxlLiBUaGlzIG1lYW5zIHRoYXRcbiAgLy8gdGhlIG1ldGhvZCBoYXMgcmV0dXJucyBpdHMgXCJkYXRhIGlzIGRvbmVcIiBtZXNzYWdlICpBTkQqIGFsbCBzZXJ2ZXJcbiAgLy8gZG9jdW1lbnRzIHRoYXQgYXJlIGJ1ZmZlcmVkIGF0IHRoYXQgdGltZSBoYXZlIGJlZW4gd3JpdHRlbiB0byB0aGUgbG9jYWxcbiAgLy8gY2FjaGUuIEludm9rZXMgdGhlIG1haW4gY2FsbGJhY2sgaWYgdGhlIHJlc3VsdCBoYXMgYmVlbiByZWNlaXZlZC5cbiAgZGF0YVZpc2libGUoKSB7XG4gICAgdGhpcy5fZGF0YVZpc2libGUgPSB0cnVlO1xuICAgIHRoaXMuX21heWJlSW52b2tlQ2FsbGJhY2soKTtcbiAgfVxuICAvLyBUcnVlIGlmIHJlY2VpdmVSZXN1bHQgaGFzIGJlZW4gY2FsbGVkLlxuICBnb3RSZXN1bHQoKSB7XG4gICAgcmV0dXJuICEhdGhpcy5fbWV0aG9kUmVzdWx0O1xuICB9XG59XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7IEREUENvbW1vbiB9IGZyb20gJ21ldGVvci9kZHAtY29tbW9uJztcbmltcG9ydCB7IFRyYWNrZXIgfSBmcm9tICdtZXRlb3IvdHJhY2tlcic7XG5pbXBvcnQgeyBFSlNPTiB9IGZyb20gJ21ldGVvci9lanNvbic7XG5pbXBvcnQgeyBSYW5kb20gfSBmcm9tICdtZXRlb3IvcmFuZG9tJztcbmltcG9ydCB7IEhvb2sgfSBmcm9tICdtZXRlb3IvY2FsbGJhY2staG9vayc7XG5pbXBvcnQgeyBNb25nb0lEIH0gZnJvbSAnbWV0ZW9yL21vbmdvLWlkJztcbmltcG9ydCB7IEREUCB9IGZyb20gJy4vbmFtZXNwYWNlLmpzJztcbmltcG9ydCBNZXRob2RJbnZva2VyIGZyb20gJy4vTWV0aG9kSW52b2tlci5qcyc7XG5pbXBvcnQge1xuICBoYXNPd24sXG4gIHNsaWNlLFxuICBrZXlzLFxuICBpc0VtcHR5LFxuICBsYXN0LFxufSBmcm9tIFwibWV0ZW9yL2RkcC1jb21tb24vdXRpbHMuanNcIjtcblxuY2xhc3MgTW9uZ29JRE1hcCBleHRlbmRzIElkTWFwIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoTW9uZ29JRC5pZFN0cmluZ2lmeSwgTW9uZ29JRC5pZFBhcnNlKTtcbiAgfVxufVxuXG4vLyBAcGFyYW0gdXJsIHtTdHJpbmd8T2JqZWN0fSBVUkwgdG8gTWV0ZW9yIGFwcCxcbi8vICAgb3IgYW4gb2JqZWN0IGFzIGEgdGVzdCBob29rIChzZWUgY29kZSlcbi8vIE9wdGlvbnM6XG4vLyAgIHJlbG9hZFdpdGhPdXRzdGFuZGluZzogaXMgaXQgT0sgdG8gcmVsb2FkIGlmIHRoZXJlIGFyZSBvdXRzdGFuZGluZyBtZXRob2RzP1xuLy8gICBoZWFkZXJzOiBleHRyYSBoZWFkZXJzIHRvIHNlbmQgb24gdGhlIHdlYnNvY2tldHMgY29ubmVjdGlvbiwgZm9yXG4vLyAgICAgc2VydmVyLXRvLXNlcnZlciBERFAgb25seVxuLy8gICBfc29ja2pzT3B0aW9uczogU3BlY2lmaWVzIG9wdGlvbnMgdG8gcGFzcyB0aHJvdWdoIHRvIHRoZSBzb2NranMgY2xpZW50XG4vLyAgIG9uRERQTmVnb3RpYXRpb25WZXJzaW9uRmFpbHVyZTogY2FsbGJhY2sgd2hlbiB2ZXJzaW9uIG5lZ290aWF0aW9uIGZhaWxzLlxuLy9cbi8vIFhYWCBUaGVyZSBzaG91bGQgYmUgYSB3YXkgdG8gZGVzdHJveSBhIEREUCBjb25uZWN0aW9uLCBjYXVzaW5nIGFsbFxuLy8gb3V0c3RhbmRpbmcgbWV0aG9kIGNhbGxzIHRvIGZhaWwuXG4vL1xuLy8gWFhYIE91ciBjdXJyZW50IHdheSBvZiBoYW5kbGluZyBmYWlsdXJlIGFuZCByZWNvbm5lY3Rpb24gaXMgZ3JlYXRcbi8vIGZvciBhbiBhcHAgKHdoZXJlIHdlIHdhbnQgdG8gdG9sZXJhdGUgYmVpbmcgZGlzY29ubmVjdGVkIGFzIGFuXG4vLyBleHBlY3Qgc3RhdGUsIGFuZCBrZWVwIHRyeWluZyBmb3JldmVyIHRvIHJlY29ubmVjdCkgYnV0IGN1bWJlcnNvbWVcbi8vIGZvciBzb21ldGhpbmcgbGlrZSBhIGNvbW1hbmQgbGluZSB0b29sIHRoYXQgd2FudHMgdG8gbWFrZSBhXG4vLyBjb25uZWN0aW9uLCBjYWxsIGEgbWV0aG9kLCBhbmQgcHJpbnQgYW4gZXJyb3IgaWYgY29ubmVjdGlvblxuLy8gZmFpbHMuIFdlIHNob3VsZCBoYXZlIGJldHRlciB1c2FiaWxpdHkgaW4gdGhlIGxhdHRlciBjYXNlICh3aGlsZVxuLy8gc3RpbGwgdHJhbnNwYXJlbnRseSByZWNvbm5lY3RpbmcgaWYgaXQncyBqdXN0IGEgdHJhbnNpZW50IGZhaWx1cmVcbi8vIG9yIHRoZSBzZXJ2ZXIgbWlncmF0aW5nIHVzKS5cbmV4cG9ydCBjbGFzcyBDb25uZWN0aW9uIHtcbiAgY29uc3RydWN0b3IodXJsLCBvcHRpb25zKSB7XG4gICAgY29uc3Qgc2VsZiA9IHRoaXM7XG5cbiAgICB0aGlzLm9wdGlvbnMgPSBvcHRpb25zID0ge1xuICAgICAgb25Db25uZWN0ZWQoKSB7fSxcbiAgICAgIG9uRERQVmVyc2lvbk5lZ290aWF0aW9uRmFpbHVyZShkZXNjcmlwdGlvbikge1xuICAgICAgICBNZXRlb3IuX2RlYnVnKGRlc2NyaXB0aW9uKTtcbiAgICAgIH0sXG4gICAgICBoZWFydGJlYXRJbnRlcnZhbDogMTc1MDAsXG4gICAgICBoZWFydGJlYXRUaW1lb3V0OiAxNTAwMCxcbiAgICAgIG5wbUZheWVPcHRpb25zOiBPYmplY3QuY3JlYXRlKG51bGwpLFxuICAgICAgLy8gVGhlc2Ugb3B0aW9ucyBhcmUgb25seSBmb3IgdGVzdGluZy5cbiAgICAgIHJlbG9hZFdpdGhPdXRzdGFuZGluZzogZmFsc2UsXG4gICAgICBzdXBwb3J0ZWRERFBWZXJzaW9uczogRERQQ29tbW9uLlNVUFBPUlRFRF9ERFBfVkVSU0lPTlMsXG4gICAgICByZXRyeTogdHJ1ZSxcbiAgICAgIHJlc3BvbmRUb1BpbmdzOiB0cnVlLFxuICAgICAgLy8gV2hlbiB1cGRhdGVzIGFyZSBjb21pbmcgd2l0aGluIHRoaXMgbXMgaW50ZXJ2YWwsIGJhdGNoIHRoZW0gdG9nZXRoZXIuXG4gICAgICBidWZmZXJlZFdyaXRlc0ludGVydmFsOiA1LFxuICAgICAgLy8gRmx1c2ggYnVmZmVycyBpbW1lZGlhdGVseSBpZiB3cml0ZXMgYXJlIGhhcHBlbmluZyBjb250aW51b3VzbHkgZm9yIG1vcmUgdGhhbiB0aGlzIG1hbnkgbXMuXG4gICAgICBidWZmZXJlZFdyaXRlc01heEFnZTogNTAwLFxuXG4gICAgICAuLi5vcHRpb25zXG4gICAgfTtcblxuICAgIC8vIElmIHNldCwgY2FsbGVkIHdoZW4gd2UgcmVjb25uZWN0LCBxdWV1aW5nIG1ldGhvZCBjYWxscyBfYmVmb3JlXyB0aGVcbiAgICAvLyBleGlzdGluZyBvdXRzdGFuZGluZyBvbmVzLlxuICAgIC8vIE5PVEU6IFRoaXMgZmVhdHVyZSBoYXMgYmVlbiBwcmVzZXJ2ZWQgZm9yIGJhY2t3YXJkcyBjb21wYXRpYmlsaXR5LiBUaGVcbiAgICAvLyBwcmVmZXJyZWQgbWV0aG9kIG9mIHNldHRpbmcgYSBjYWxsYmFjayBvbiByZWNvbm5lY3QgaXMgdG8gdXNlXG4gICAgLy8gRERQLm9uUmVjb25uZWN0LlxuICAgIHNlbGYub25SZWNvbm5lY3QgPSBudWxsO1xuXG4gICAgLy8gYXMgYSB0ZXN0IGhvb2ssIGFsbG93IHBhc3NpbmcgYSBzdHJlYW0gaW5zdGVhZCBvZiBhIHVybC5cbiAgICBpZiAodHlwZW9mIHVybCA9PT0gJ29iamVjdCcpIHtcbiAgICAgIHNlbGYuX3N0cmVhbSA9IHVybDtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3QgeyBDbGllbnRTdHJlYW0gfSA9IHJlcXVpcmUoXCJtZXRlb3Ivc29ja2V0LXN0cmVhbS1jbGllbnRcIik7XG4gICAgICBzZWxmLl9zdHJlYW0gPSBuZXcgQ2xpZW50U3RyZWFtKHVybCwge1xuICAgICAgICByZXRyeTogb3B0aW9ucy5yZXRyeSxcbiAgICAgICAgQ29ubmVjdGlvbkVycm9yOiBERFAuQ29ubmVjdGlvbkVycm9yLFxuICAgICAgICBoZWFkZXJzOiBvcHRpb25zLmhlYWRlcnMsXG4gICAgICAgIF9zb2NranNPcHRpb25zOiBvcHRpb25zLl9zb2NranNPcHRpb25zLFxuICAgICAgICAvLyBVc2VkIHRvIGtlZXAgc29tZSB0ZXN0cyBxdWlldCwgb3IgZm9yIG90aGVyIGNhc2VzIGluIHdoaWNoXG4gICAgICAgIC8vIHRoZSByaWdodCB0aGluZyB0byBkbyB3aXRoIGNvbm5lY3Rpb24gZXJyb3JzIGlzIHRvIHNpbGVudGx5XG4gICAgICAgIC8vIGZhaWwgKGUuZy4gc2VuZGluZyBwYWNrYWdlIHVzYWdlIHN0YXRzKS4gQXQgc29tZSBwb2ludCB3ZVxuICAgICAgICAvLyBzaG91bGQgaGF2ZSBhIHJlYWwgQVBJIGZvciBoYW5kbGluZyBjbGllbnQtc3RyZWFtLWxldmVsXG4gICAgICAgIC8vIGVycm9ycy5cbiAgICAgICAgX2RvbnRQcmludEVycm9yczogb3B0aW9ucy5fZG9udFByaW50RXJyb3JzLFxuICAgICAgICBjb25uZWN0VGltZW91dE1zOiBvcHRpb25zLmNvbm5lY3RUaW1lb3V0TXMsXG4gICAgICAgIG5wbUZheWVPcHRpb25zOiBvcHRpb25zLm5wbUZheWVPcHRpb25zXG4gICAgICB9KTtcbiAgICB9XG5cbiAgICBzZWxmLl9sYXN0U2Vzc2lvbklkID0gbnVsbDtcbiAgICBzZWxmLl92ZXJzaW9uU3VnZ2VzdGlvbiA9IG51bGw7IC8vIFRoZSBsYXN0IHByb3Bvc2VkIEREUCB2ZXJzaW9uLlxuICAgIHNlbGYuX3ZlcnNpb24gPSBudWxsOyAvLyBUaGUgRERQIHZlcnNpb24gYWdyZWVkIG9uIGJ5IGNsaWVudCBhbmQgc2VydmVyLlxuICAgIHNlbGYuX3N0b3JlcyA9IE9iamVjdC5jcmVhdGUobnVsbCk7IC8vIG5hbWUgLT4gb2JqZWN0IHdpdGggbWV0aG9kc1xuICAgIHNlbGYuX21ldGhvZEhhbmRsZXJzID0gT2JqZWN0LmNyZWF0ZShudWxsKTsgLy8gbmFtZSAtPiBmdW5jXG4gICAgc2VsZi5fbmV4dE1ldGhvZElkID0gMTtcbiAgICBzZWxmLl9zdXBwb3J0ZWRERFBWZXJzaW9ucyA9IG9wdGlvbnMuc3VwcG9ydGVkRERQVmVyc2lvbnM7XG5cbiAgICBzZWxmLl9oZWFydGJlYXRJbnRlcnZhbCA9IG9wdGlvbnMuaGVhcnRiZWF0SW50ZXJ2YWw7XG4gICAgc2VsZi5faGVhcnRiZWF0VGltZW91dCA9IG9wdGlvbnMuaGVhcnRiZWF0VGltZW91dDtcblxuICAgIC8vIFRyYWNrcyBtZXRob2RzIHdoaWNoIHRoZSB1c2VyIGhhcyB0cmllZCB0byBjYWxsIGJ1dCB3aGljaCBoYXZlIG5vdCB5ZXRcbiAgICAvLyBjYWxsZWQgdGhlaXIgdXNlciBjYWxsYmFjayAoaWUsIHRoZXkgYXJlIHdhaXRpbmcgb24gdGhlaXIgcmVzdWx0IG9yIGZvciBhbGxcbiAgICAvLyBvZiB0aGVpciB3cml0ZXMgdG8gYmUgd3JpdHRlbiB0byB0aGUgbG9jYWwgY2FjaGUpLiBNYXAgZnJvbSBtZXRob2QgSUQgdG9cbiAgICAvLyBNZXRob2RJbnZva2VyIG9iamVjdC5cbiAgICBzZWxmLl9tZXRob2RJbnZva2VycyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG5cbiAgICAvLyBUcmFja3MgbWV0aG9kcyB3aGljaCB0aGUgdXNlciBoYXMgY2FsbGVkIGJ1dCB3aG9zZSByZXN1bHQgbWVzc2FnZXMgaGF2ZSBub3RcbiAgICAvLyBhcnJpdmVkIHlldC5cbiAgICAvL1xuICAgIC8vIF9vdXRzdGFuZGluZ01ldGhvZEJsb2NrcyBpcyBhbiBhcnJheSBvZiBibG9ja3Mgb2YgbWV0aG9kcy4gRWFjaCBibG9ja1xuICAgIC8vIHJlcHJlc2VudHMgYSBzZXQgb2YgbWV0aG9kcyB0aGF0IGNhbiBydW4gYXQgdGhlIHNhbWUgdGltZS4gVGhlIGZpcnN0IGJsb2NrXG4gICAgLy8gcmVwcmVzZW50cyB0aGUgbWV0aG9kcyB3aGljaCBhcmUgY3VycmVudGx5IGluIGZsaWdodDsgc3Vic2VxdWVudCBibG9ja3NcbiAgICAvLyBtdXN0IHdhaXQgZm9yIHByZXZpb3VzIGJsb2NrcyB0byBiZSBmdWxseSBmaW5pc2hlZCBiZWZvcmUgdGhleSBjYW4gYmUgc2VudFxuICAgIC8vIHRvIHRoZSBzZXJ2ZXIuXG4gICAgLy9cbiAgICAvLyBFYWNoIGJsb2NrIGlzIGFuIG9iamVjdCB3aXRoIHRoZSBmb2xsb3dpbmcgZmllbGRzOlxuICAgIC8vIC0gbWV0aG9kczogYSBsaXN0IG9mIE1ldGhvZEludm9rZXIgb2JqZWN0c1xuICAgIC8vIC0gd2FpdDogYSBib29sZWFuOyBpZiB0cnVlLCB0aGlzIGJsb2NrIGhhZCBhIHNpbmdsZSBtZXRob2QgaW52b2tlZCB3aXRoXG4gICAgLy8gICAgICAgICB0aGUgXCJ3YWl0XCIgb3B0aW9uXG4gICAgLy9cbiAgICAvLyBUaGVyZSB3aWxsIG5ldmVyIGJlIGFkamFjZW50IGJsb2NrcyB3aXRoIHdhaXQ9ZmFsc2UsIGJlY2F1c2UgdGhlIG9ubHkgdGhpbmdcbiAgICAvLyB0aGF0IG1ha2VzIG1ldGhvZHMgbmVlZCB0byBiZSBzZXJpYWxpemVkIGlzIGEgd2FpdCBtZXRob2QuXG4gICAgLy9cbiAgICAvLyBNZXRob2RzIGFyZSByZW1vdmVkIGZyb20gdGhlIGZpcnN0IGJsb2NrIHdoZW4gdGhlaXIgXCJyZXN1bHRcIiBpc1xuICAgIC8vIHJlY2VpdmVkLiBUaGUgZW50aXJlIGZpcnN0IGJsb2NrIGlzIG9ubHkgcmVtb3ZlZCB3aGVuIGFsbCBvZiB0aGUgaW4tZmxpZ2h0XG4gICAgLy8gbWV0aG9kcyBoYXZlIHJlY2VpdmVkIHRoZWlyIHJlc3VsdHMgKHNvIHRoZSBcIm1ldGhvZHNcIiBsaXN0IGlzIGVtcHR5KSAqQU5EKlxuICAgIC8vIGFsbCBvZiB0aGUgZGF0YSB3cml0dGVuIGJ5IHRob3NlIG1ldGhvZHMgYXJlIHZpc2libGUgaW4gdGhlIGxvY2FsIGNhY2hlLiBTb1xuICAgIC8vIGl0IGlzIHBvc3NpYmxlIGZvciB0aGUgZmlyc3QgYmxvY2sncyBtZXRob2RzIGxpc3QgdG8gYmUgZW1wdHksIGlmIHdlIGFyZVxuICAgIC8vIHN0aWxsIHdhaXRpbmcgZm9yIHNvbWUgb2JqZWN0cyB0byBxdWllc2NlLlxuICAgIC8vXG4gICAgLy8gRXhhbXBsZTpcbiAgICAvLyAgX291dHN0YW5kaW5nTWV0aG9kQmxvY2tzID0gW1xuICAgIC8vICAgIHt3YWl0OiBmYWxzZSwgbWV0aG9kczogW119LFxuICAgIC8vICAgIHt3YWl0OiB0cnVlLCBtZXRob2RzOiBbPE1ldGhvZEludm9rZXIgZm9yICdsb2dpbic+XX0sXG4gICAgLy8gICAge3dhaXQ6IGZhbHNlLCBtZXRob2RzOiBbPE1ldGhvZEludm9rZXIgZm9yICdmb28nPixcbiAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TWV0aG9kSW52b2tlciBmb3IgJ2Jhcic+XX1dXG4gICAgLy8gVGhpcyBtZWFucyB0aGF0IHRoZXJlIHdlcmUgc29tZSBtZXRob2RzIHdoaWNoIHdlcmUgc2VudCB0byB0aGUgc2VydmVyIGFuZFxuICAgIC8vIHdoaWNoIGhhdmUgcmV0dXJuZWQgdGhlaXIgcmVzdWx0cywgYnV0IHNvbWUgb2YgdGhlIGRhdGEgd3JpdHRlbiBieVxuICAgIC8vIHRoZSBtZXRob2RzIG1heSBub3QgYmUgdmlzaWJsZSBpbiB0aGUgbG9jYWwgY2FjaGUuIE9uY2UgYWxsIHRoYXQgZGF0YSBpc1xuICAgIC8vIHZpc2libGUsIHdlIHdpbGwgc2VuZCBhICdsb2dpbicgbWV0aG9kLiBPbmNlIHRoZSBsb2dpbiBtZXRob2QgaGFzIHJldHVybmVkXG4gICAgLy8gYW5kIGFsbCB0aGUgZGF0YSBpcyB2aXNpYmxlIChpbmNsdWRpbmcgcmUtcnVubmluZyBzdWJzIGlmIHVzZXJJZCBjaGFuZ2VzKSxcbiAgICAvLyB3ZSB3aWxsIHNlbmQgdGhlICdmb28nIGFuZCAnYmFyJyBtZXRob2RzIGluIHBhcmFsbGVsLlxuICAgIHNlbGYuX291dHN0YW5kaW5nTWV0aG9kQmxvY2tzID0gW107XG5cbiAgICAvLyBtZXRob2QgSUQgLT4gYXJyYXkgb2Ygb2JqZWN0cyB3aXRoIGtleXMgJ2NvbGxlY3Rpb24nIGFuZCAnaWQnLCBsaXN0aW5nXG4gICAgLy8gZG9jdW1lbnRzIHdyaXR0ZW4gYnkgYSBnaXZlbiBtZXRob2QncyBzdHViLiBrZXlzIGFyZSBhc3NvY2lhdGVkIHdpdGhcbiAgICAvLyBtZXRob2RzIHdob3NlIHN0dWIgd3JvdGUgYXQgbGVhc3Qgb25lIGRvY3VtZW50LCBhbmQgd2hvc2UgZGF0YS1kb25lIG1lc3NhZ2VcbiAgICAvLyBoYXMgbm90IHlldCBiZWVuIHJlY2VpdmVkLlxuICAgIHNlbGYuX2RvY3VtZW50c1dyaXR0ZW5CeVN0dWIgPSB7fTtcbiAgICAvLyBjb2xsZWN0aW9uIC0+IElkTWFwIG9mIFwic2VydmVyIGRvY3VtZW50XCIgb2JqZWN0LiBBIFwic2VydmVyIGRvY3VtZW50XCIgaGFzOlxuICAgIC8vIC0gXCJkb2N1bWVudFwiOiB0aGUgdmVyc2lvbiBvZiB0aGUgZG9jdW1lbnQgYWNjb3JkaW5nIHRoZVxuICAgIC8vICAgc2VydmVyIChpZSwgdGhlIHNuYXBzaG90IGJlZm9yZSBhIHN0dWIgd3JvdGUgaXQsIGFtZW5kZWQgYnkgYW55IGNoYW5nZXNcbiAgICAvLyAgIHJlY2VpdmVkIGZyb20gdGhlIHNlcnZlcilcbiAgICAvLyAgIEl0IGlzIHVuZGVmaW5lZCBpZiB3ZSB0aGluayB0aGUgZG9jdW1lbnQgZG9lcyBub3QgZXhpc3RcbiAgICAvLyAtIFwid3JpdHRlbkJ5U3R1YnNcIjogYSBzZXQgb2YgbWV0aG9kIElEcyB3aG9zZSBzdHVicyB3cm90ZSB0byB0aGUgZG9jdW1lbnRcbiAgICAvLyAgIHdob3NlIFwiZGF0YSBkb25lXCIgbWVzc2FnZXMgaGF2ZSBub3QgeWV0IGJlZW4gcHJvY2Vzc2VkXG4gICAgc2VsZi5fc2VydmVyRG9jdW1lbnRzID0ge307XG5cbiAgICAvLyBBcnJheSBvZiBjYWxsYmFja3MgdG8gYmUgY2FsbGVkIGFmdGVyIHRoZSBuZXh0IHVwZGF0ZSBvZiB0aGUgbG9jYWxcbiAgICAvLyBjYWNoZS4gVXNlZCBmb3I6XG4gICAgLy8gIC0gQ2FsbGluZyBtZXRob2RJbnZva2VyLmRhdGFWaXNpYmxlIGFuZCBzdWIgcmVhZHkgY2FsbGJhY2tzIGFmdGVyXG4gICAgLy8gICAgdGhlIHJlbGV2YW50IGRhdGEgaXMgZmx1c2hlZC5cbiAgICAvLyAgLSBJbnZva2luZyB0aGUgY2FsbGJhY2tzIG9mIFwiaGFsZi1maW5pc2hlZFwiIG1ldGhvZHMgYWZ0ZXIgcmVjb25uZWN0XG4gICAgLy8gICAgcXVpZXNjZW5jZS4gU3BlY2lmaWNhbGx5LCBtZXRob2RzIHdob3NlIHJlc3VsdCB3YXMgcmVjZWl2ZWQgb3ZlciB0aGUgb2xkXG4gICAgLy8gICAgY29ubmVjdGlvbiAoc28gd2UgZG9uJ3QgcmUtc2VuZCBpdCkgYnV0IHdob3NlIGRhdGEgaGFkIG5vdCBiZWVuIG1hZGVcbiAgICAvLyAgICB2aXNpYmxlLlxuICAgIHNlbGYuX2FmdGVyVXBkYXRlQ2FsbGJhY2tzID0gW107XG5cbiAgICAvLyBJbiB0d28gY29udGV4dHMsIHdlIGJ1ZmZlciBhbGwgaW5jb21pbmcgZGF0YSBtZXNzYWdlcyBhbmQgdGhlbiBwcm9jZXNzIHRoZW1cbiAgICAvLyBhbGwgYXQgb25jZSBpbiBhIHNpbmdsZSB1cGRhdGU6XG4gICAgLy8gICAtIER1cmluZyByZWNvbm5lY3QsIHdlIGJ1ZmZlciBhbGwgZGF0YSBtZXNzYWdlcyB1bnRpbCBhbGwgc3VicyB0aGF0IGhhZFxuICAgIC8vICAgICBiZWVuIHJlYWR5IGJlZm9yZSByZWNvbm5lY3QgYXJlIHJlYWR5IGFnYWluLCBhbmQgYWxsIG1ldGhvZHMgdGhhdCBhcmVcbiAgICAvLyAgICAgYWN0aXZlIGhhdmUgcmV0dXJuZWQgdGhlaXIgXCJkYXRhIGRvbmUgbWVzc2FnZVwiOyB0aGVuXG4gICAgLy8gICAtIER1cmluZyB0aGUgZXhlY3V0aW9uIG9mIGEgXCJ3YWl0XCIgbWV0aG9kLCB3ZSBidWZmZXIgYWxsIGRhdGEgbWVzc2FnZXNcbiAgICAvLyAgICAgdW50aWwgdGhlIHdhaXQgbWV0aG9kIGdldHMgaXRzIFwiZGF0YSBkb25lXCIgbWVzc2FnZS4gKElmIHRoZSB3YWl0IG1ldGhvZFxuICAgIC8vICAgICBvY2N1cnMgZHVyaW5nIHJlY29ubmVjdCwgaXQgZG9lc24ndCBnZXQgYW55IHNwZWNpYWwgaGFuZGxpbmcuKVxuICAgIC8vIGFsbCBkYXRhIG1lc3NhZ2VzIGFyZSBwcm9jZXNzZWQgaW4gb25lIHVwZGF0ZS5cbiAgICAvL1xuICAgIC8vIFRoZSBmb2xsb3dpbmcgZmllbGRzIGFyZSB1c2VkIGZvciB0aGlzIFwicXVpZXNjZW5jZVwiIHByb2Nlc3MuXG5cbiAgICAvLyBUaGlzIGJ1ZmZlcnMgdGhlIG1lc3NhZ2VzIHRoYXQgYXJlbid0IGJlaW5nIHByb2Nlc3NlZCB5ZXQuXG4gICAgc2VsZi5fbWVzc2FnZXNCdWZmZXJlZFVudGlsUXVpZXNjZW5jZSA9IFtdO1xuICAgIC8vIE1hcCBmcm9tIG1ldGhvZCBJRCAtPiB0cnVlLiBNZXRob2RzIGFyZSByZW1vdmVkIGZyb20gdGhpcyB3aGVuIHRoZWlyXG4gICAgLy8gXCJkYXRhIGRvbmVcIiBtZXNzYWdlIGlzIHJlY2VpdmVkLCBhbmQgd2Ugd2lsbCBub3QgcXVpZXNjZSB1bnRpbCBpdCBpc1xuICAgIC8vIGVtcHR5LlxuICAgIHNlbGYuX21ldGhvZHNCbG9ja2luZ1F1aWVzY2VuY2UgPSB7fTtcbiAgICAvLyBtYXAgZnJvbSBzdWIgSUQgLT4gdHJ1ZSBmb3Igc3VicyB0aGF0IHdlcmUgcmVhZHkgKGllLCBjYWxsZWQgdGhlIHN1YlxuICAgIC8vIHJlYWR5IGNhbGxiYWNrKSBiZWZvcmUgcmVjb25uZWN0IGJ1dCBoYXZlbid0IGJlY29tZSByZWFkeSBhZ2FpbiB5ZXRcbiAgICBzZWxmLl9zdWJzQmVpbmdSZXZpdmVkID0ge307IC8vIG1hcCBmcm9tIHN1Yi5faWQgLT4gdHJ1ZVxuICAgIC8vIGlmIHRydWUsIHRoZSBuZXh0IGRhdGEgdXBkYXRlIHNob3VsZCByZXNldCBhbGwgc3RvcmVzLiAoc2V0IGR1cmluZ1xuICAgIC8vIHJlY29ubmVjdC4pXG4gICAgc2VsZi5fcmVzZXRTdG9yZXMgPSBmYWxzZTtcblxuICAgIC8vIG5hbWUgLT4gYXJyYXkgb2YgdXBkYXRlcyBmb3IgKHlldCB0byBiZSBjcmVhdGVkKSBjb2xsZWN0aW9uc1xuICAgIHNlbGYuX3VwZGF0ZXNGb3JVbmtub3duU3RvcmVzID0ge307XG4gICAgLy8gaWYgd2UncmUgYmxvY2tpbmcgYSBtaWdyYXRpb24sIHRoZSByZXRyeSBmdW5jXG4gICAgc2VsZi5fcmV0cnlNaWdyYXRlID0gbnVsbDtcblxuICAgIHNlbGYuX19mbHVzaEJ1ZmZlcmVkV3JpdGVzID0gTWV0ZW9yLmJpbmRFbnZpcm9ubWVudChcbiAgICAgIHNlbGYuX2ZsdXNoQnVmZmVyZWRXcml0ZXMsXG4gICAgICAnZmx1c2hpbmcgRERQIGJ1ZmZlcmVkIHdyaXRlcycsXG4gICAgICBzZWxmXG4gICAgKTtcbiAgICAvLyBDb2xsZWN0aW9uIG5hbWUgLT4gYXJyYXkgb2YgbWVzc2FnZXMuXG4gICAgc2VsZi5fYnVmZmVyZWRXcml0ZXMgPSB7fTtcbiAgICAvLyBXaGVuIGN1cnJlbnQgYnVmZmVyIG9mIHVwZGF0ZXMgbXVzdCBiZSBmbHVzaGVkIGF0LCBpbiBtcyB0aW1lc3RhbXAuXG4gICAgc2VsZi5fYnVmZmVyZWRXcml0ZXNGbHVzaEF0ID0gbnVsbDtcbiAgICAvLyBUaW1lb3V0IGhhbmRsZSBmb3IgdGhlIG5leHQgcHJvY2Vzc2luZyBvZiBhbGwgcGVuZGluZyB3cml0ZXNcbiAgICBzZWxmLl9idWZmZXJlZFdyaXRlc0ZsdXNoSGFuZGxlID0gbnVsbDtcblxuICAgIHNlbGYuX2J1ZmZlcmVkV3JpdGVzSW50ZXJ2YWwgPSBvcHRpb25zLmJ1ZmZlcmVkV3JpdGVzSW50ZXJ2YWw7XG4gICAgc2VsZi5fYnVmZmVyZWRXcml0ZXNNYXhBZ2UgPSBvcHRpb25zLmJ1ZmZlcmVkV3JpdGVzTWF4QWdlO1xuXG4gICAgLy8gbWV0YWRhdGEgZm9yIHN1YnNjcmlwdGlvbnMuICBNYXAgZnJvbSBzdWIgSUQgdG8gb2JqZWN0IHdpdGgga2V5czpcbiAgICAvLyAgIC0gaWRcbiAgICAvLyAgIC0gbmFtZVxuICAgIC8vICAgLSBwYXJhbXNcbiAgICAvLyAgIC0gaW5hY3RpdmUgKGlmIHRydWUsIHdpbGwgYmUgY2xlYW5lZCB1cCBpZiBub3QgcmV1c2VkIGluIHJlLXJ1bilcbiAgICAvLyAgIC0gcmVhZHkgKGhhcyB0aGUgJ3JlYWR5JyBtZXNzYWdlIGJlZW4gcmVjZWl2ZWQ/KVxuICAgIC8vICAgLSByZWFkeUNhbGxiYWNrIChhbiBvcHRpb25hbCBjYWxsYmFjayB0byBjYWxsIHdoZW4gcmVhZHkpXG4gICAgLy8gICAtIGVycm9yQ2FsbGJhY2sgKGFuIG9wdGlvbmFsIGNhbGxiYWNrIHRvIGNhbGwgaWYgdGhlIHN1YiB0ZXJtaW5hdGVzIHdpdGhcbiAgICAvLyAgICAgICAgICAgICAgICAgICAgYW4gZXJyb3IsIFhYWCBDT01QQVQgV0lUSCAxLjAuMy4xKVxuICAgIC8vICAgLSBzdG9wQ2FsbGJhY2sgKGFuIG9wdGlvbmFsIGNhbGxiYWNrIHRvIGNhbGwgd2hlbiB0aGUgc3ViIHRlcm1pbmF0ZXNcbiAgICAvLyAgICAgZm9yIGFueSByZWFzb24sIHdpdGggYW4gZXJyb3IgYXJndW1lbnQgaWYgYW4gZXJyb3IgdHJpZ2dlcmVkIHRoZSBzdG9wKVxuICAgIHNlbGYuX3N1YnNjcmlwdGlvbnMgPSB7fTtcblxuICAgIC8vIFJlYWN0aXZlIHVzZXJJZC5cbiAgICBzZWxmLl91c2VySWQgPSBudWxsO1xuICAgIHNlbGYuX3VzZXJJZERlcHMgPSBuZXcgVHJhY2tlci5EZXBlbmRlbmN5KCk7XG5cbiAgICAvLyBCbG9jayBhdXRvLXJlbG9hZCB3aGlsZSB3ZSdyZSB3YWl0aW5nIGZvciBtZXRob2QgcmVzcG9uc2VzLlxuICAgIGlmIChNZXRlb3IuaXNDbGllbnQgJiZcbiAgICAgIFBhY2thZ2UucmVsb2FkICYmXG4gICAgICAhIG9wdGlvbnMucmVsb2FkV2l0aE91dHN0YW5kaW5nKSB7XG4gICAgICBQYWNrYWdlLnJlbG9hZC5SZWxvYWQuX29uTWlncmF0ZShyZXRyeSA9PiB7XG4gICAgICAgIGlmICghIHNlbGYuX3JlYWR5VG9NaWdyYXRlKCkpIHtcbiAgICAgICAgICBzZWxmLl9yZXRyeU1pZ3JhdGUgPSByZXRyeTtcbiAgICAgICAgICByZXR1cm4gW2ZhbHNlXTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZXR1cm4gW3RydWVdO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9XG5cbiAgICBjb25zdCBvbkRpc2Nvbm5lY3QgPSAoKSA9PiB7XG4gICAgICBpZiAoc2VsZi5faGVhcnRiZWF0KSB7XG4gICAgICAgIHNlbGYuX2hlYXJ0YmVhdC5zdG9wKCk7XG4gICAgICAgIHNlbGYuX2hlYXJ0YmVhdCA9IG51bGw7XG4gICAgICB9XG4gICAgfTtcblxuICAgIGlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcbiAgICAgIHNlbGYuX3N0cmVhbS5vbihcbiAgICAgICAgJ21lc3NhZ2UnLFxuICAgICAgICBNZXRlb3IuYmluZEVudmlyb25tZW50KFxuICAgICAgICAgIHRoaXMub25NZXNzYWdlLmJpbmQodGhpcyksXG4gICAgICAgICAgJ2hhbmRsaW5nIEREUCBtZXNzYWdlJ1xuICAgICAgICApXG4gICAgICApO1xuICAgICAgc2VsZi5fc3RyZWFtLm9uKFxuICAgICAgICAncmVzZXQnLFxuICAgICAgICBNZXRlb3IuYmluZEVudmlyb25tZW50KHRoaXMub25SZXNldC5iaW5kKHRoaXMpLCAnaGFuZGxpbmcgRERQIHJlc2V0JylcbiAgICAgICk7XG4gICAgICBzZWxmLl9zdHJlYW0ub24oXG4gICAgICAgICdkaXNjb25uZWN0JyxcbiAgICAgICAgTWV0ZW9yLmJpbmRFbnZpcm9ubWVudChvbkRpc2Nvbm5lY3QsICdoYW5kbGluZyBERFAgZGlzY29ubmVjdCcpXG4gICAgICApO1xuICAgIH0gZWxzZSB7XG4gICAgICBzZWxmLl9zdHJlYW0ub24oJ21lc3NhZ2UnLCB0aGlzLm9uTWVzc2FnZS5iaW5kKHRoaXMpKTtcbiAgICAgIHNlbGYuX3N0cmVhbS5vbigncmVzZXQnLCB0aGlzLm9uUmVzZXQuYmluZCh0aGlzKSk7XG4gICAgICBzZWxmLl9zdHJlYW0ub24oJ2Rpc2Nvbm5lY3QnLCBvbkRpc2Nvbm5lY3QpO1xuICAgIH1cbiAgfVxuXG4gIC8vICduYW1lJyBpcyB0aGUgbmFtZSBvZiB0aGUgZGF0YSBvbiB0aGUgd2lyZSB0aGF0IHNob3VsZCBnbyBpbiB0aGVcbiAgLy8gc3RvcmUuICd3cmFwcGVkU3RvcmUnIHNob3VsZCBiZSBhbiBvYmplY3Qgd2l0aCBtZXRob2RzIGJlZ2luVXBkYXRlLCB1cGRhdGUsXG4gIC8vIGVuZFVwZGF0ZSwgc2F2ZU9yaWdpbmFscywgcmV0cmlldmVPcmlnaW5hbHMuIHNlZSBDb2xsZWN0aW9uIGZvciBhbiBleGFtcGxlLlxuICBjcmVhdGVTdG9yZU1ldGhvZHMobmFtZSwgd3JhcHBlZFN0b3JlKSB7XG4gICAgY29uc3Qgc2VsZiA9IHRoaXM7XG5cbiAgICBpZiAobmFtZSBpbiBzZWxmLl9zdG9yZXMpIHJldHVybiBmYWxzZTtcblxuICAgIC8vIFdyYXAgdGhlIGlucHV0IG9iamVjdCBpbiBhbiBvYmplY3Qgd2hpY2ggbWFrZXMgYW55IHN0b3JlIG1ldGhvZCBub3RcbiAgICAvLyBpbXBsZW1lbnRlZCBieSAnc3RvcmUnIGludG8gYSBuby1vcC5cbiAgICBjb25zdCBzdG9yZSA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gICAgY29uc3Qga2V5c09mU3RvcmUgPSBbXG4gICAgICAndXBkYXRlJyxcbiAgICAgICdiZWdpblVwZGF0ZScsXG4gICAgICAnZW5kVXBkYXRlJyxcbiAgICAgICdzYXZlT3JpZ2luYWxzJyxcbiAgICAgICdyZXRyaWV2ZU9yaWdpbmFscycsXG4gICAgICAnZ2V0RG9jJyxcbiAgICAgICdfZ2V0Q29sbGVjdGlvbidcbiAgICBdO1xuICAgIGtleXNPZlN0b3JlLmZvckVhY2goKG1ldGhvZCkgPT4ge1xuICAgICAgc3RvcmVbbWV0aG9kXSA9ICguLi5hcmdzKSA9PiB7XG4gICAgICAgIGlmICh3cmFwcGVkU3RvcmVbbWV0aG9kXSkge1xuICAgICAgICAgIHJldHVybiB3cmFwcGVkU3RvcmVbbWV0aG9kXSguLi5hcmdzKTtcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICB9KTtcbiAgICBzZWxmLl9zdG9yZXNbbmFtZV0gPSBzdG9yZTtcbiAgICByZXR1cm4gc3RvcmU7XG4gIH1cblxuICByZWdpc3RlclN0b3JlQ2xpZW50KG5hbWUsIHdyYXBwZWRTdG9yZSkge1xuICAgIGNvbnN0IHNlbGYgPSB0aGlzO1xuXG4gICAgY29uc3Qgc3RvcmUgPSBzZWxmLmNyZWF0ZVN0b3JlTWV0aG9kcyhuYW1lLCB3cmFwcGVkU3RvcmUpO1xuXG4gICAgY29uc3QgcXVldWVkID0gc2VsZi5fdXBkYXRlc0ZvclVua25vd25TdG9yZXNbbmFtZV07XG4gICAgaWYgKEFycmF5LmlzQXJyYXkocXVldWVkKSkge1xuICAgICAgc3RvcmUuYmVnaW5VcGRhdGUocXVldWVkLmxlbmd0aCwgZmFsc2UpO1xuICAgICAgcXVldWVkLmZvckVhY2gobXNnID0+IHtcbiAgICAgICAgc3RvcmUudXBkYXRlKG1zZyk7XG4gICAgICB9KTtcbiAgICAgIHN0b3JlLmVuZFVwZGF0ZSgpO1xuICAgICAgZGVsZXRlIHNlbGYuX3VwZGF0ZXNGb3JVbmtub3duU3RvcmVzW25hbWVdO1xuICAgIH1cblxuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGFzeW5jIHJlZ2lzdGVyU3RvcmVTZXJ2ZXIobmFtZSwgd3JhcHBlZFN0b3JlKSB7XG4gICAgY29uc3Qgc2VsZiA9IHRoaXM7XG5cbiAgICBjb25zdCBzdG9yZSA9IHNlbGYuY3JlYXRlU3RvcmVNZXRob2RzKG5hbWUsIHdyYXBwZWRTdG9yZSk7XG5cbiAgICBjb25zdCBxdWV1ZWQgPSBzZWxmLl91cGRhdGVzRm9yVW5rbm93blN0b3Jlc1tuYW1lXTtcbiAgICBpZiAoQXJyYXkuaXNBcnJheShxdWV1ZWQpKSB7XG4gICAgICBhd2FpdCBzdG9yZS5iZWdpblVwZGF0ZShxdWV1ZWQubGVuZ3RoLCBmYWxzZSk7XG4gICAgICBmb3IgKGNvbnN0IG1zZyBvZiBxdWV1ZWQpIHtcbiAgICAgICAgYXdhaXQgc3RvcmUudXBkYXRlKG1zZyk7XG4gICAgICB9XG4gICAgICBhd2FpdCBzdG9yZS5lbmRVcGRhdGUoKTtcbiAgICAgIGRlbGV0ZSBzZWxmLl91cGRhdGVzRm9yVW5rbm93blN0b3Jlc1tuYW1lXTtcbiAgICB9XG5cbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuXG4gIC8qKlxuICAgKiBAbWVtYmVyT2YgTWV0ZW9yXG4gICAqIEBpbXBvcnRGcm9tUGFja2FnZSBtZXRlb3JcbiAgICogQGFsaWFzIE1ldGVvci5zdWJzY3JpYmVcbiAgICogQHN1bW1hcnkgU3Vic2NyaWJlIHRvIGEgcmVjb3JkIHNldC4gIFJldHVybnMgYSBoYW5kbGUgdGhhdCBwcm92aWRlc1xuICAgKiBgc3RvcCgpYCBhbmQgYHJlYWR5KClgIG1ldGhvZHMuXG4gICAqIEBsb2N1cyBDbGllbnRcbiAgICogQHBhcmFtIHtTdHJpbmd9IG5hbWUgTmFtZSBvZiB0aGUgc3Vic2NyaXB0aW9uLiAgTWF0Y2hlcyB0aGUgbmFtZSBvZiB0aGVcbiAgICogc2VydmVyJ3MgYHB1Ymxpc2goKWAgY2FsbC5cbiAgICogQHBhcmFtIHtFSlNPTmFibGV9IFthcmcxLGFyZzIuLi5dIE9wdGlvbmFsIGFyZ3VtZW50cyBwYXNzZWQgdG8gcHVibGlzaGVyXG4gICAqIGZ1bmN0aW9uIG9uIHNlcnZlci5cbiAgICogQHBhcmFtIHtGdW5jdGlvbnxPYmplY3R9IFtjYWxsYmFja3NdIE9wdGlvbmFsLiBNYXkgaW5jbHVkZSBgb25TdG9wYFxuICAgKiBhbmQgYG9uUmVhZHlgIGNhbGxiYWNrcy4gSWYgdGhlcmUgaXMgYW4gZXJyb3IsIGl0IGlzIHBhc3NlZCBhcyBhblxuICAgKiBhcmd1bWVudCB0byBgb25TdG9wYC4gSWYgYSBmdW5jdGlvbiBpcyBwYXNzZWQgaW5zdGVhZCBvZiBhbiBvYmplY3QsIGl0XG4gICAqIGlzIGludGVycHJldGVkIGFzIGFuIGBvblJlYWR5YCBjYWxsYmFjay5cbiAgICovXG4gIHN1YnNjcmliZShuYW1lIC8qIC4uIFthcmd1bWVudHNdIC4uIChjYWxsYmFja3xjYWxsYmFja3MpICovKSB7XG4gICAgY29uc3Qgc2VsZiA9IHRoaXM7XG5cbiAgICBjb25zdCBwYXJhbXMgPSBzbGljZS5jYWxsKGFyZ3VtZW50cywgMSk7XG4gICAgbGV0IGNhbGxiYWNrcyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gICAgaWYgKHBhcmFtcy5sZW5ndGgpIHtcbiAgICAgIGNvbnN0IGxhc3RQYXJhbSA9IHBhcmFtc1twYXJhbXMubGVuZ3RoIC0gMV07XG4gICAgICBpZiAodHlwZW9mIGxhc3RQYXJhbSA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICBjYWxsYmFja3Mub25SZWFkeSA9IHBhcmFtcy5wb3AoKTtcbiAgICAgIH0gZWxzZSBpZiAobGFzdFBhcmFtICYmIFtcbiAgICAgICAgbGFzdFBhcmFtLm9uUmVhZHksXG4gICAgICAgIC8vIFhYWCBDT01QQVQgV0lUSCAxLjAuMy4xIG9uRXJyb3IgdXNlZCB0byBleGlzdCwgYnV0IG5vdyB3ZSB1c2VcbiAgICAgICAgLy8gb25TdG9wIHdpdGggYW4gZXJyb3IgY2FsbGJhY2sgaW5zdGVhZC5cbiAgICAgICAgbGFzdFBhcmFtLm9uRXJyb3IsXG4gICAgICAgIGxhc3RQYXJhbS5vblN0b3BcbiAgICAgIF0uc29tZShmID0+IHR5cGVvZiBmID09PSBcImZ1bmN0aW9uXCIpKSB7XG4gICAgICAgIGNhbGxiYWNrcyA9IHBhcmFtcy5wb3AoKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBJcyB0aGVyZSBhbiBleGlzdGluZyBzdWIgd2l0aCB0aGUgc2FtZSBuYW1lIGFuZCBwYXJhbSwgcnVuIGluIGFuXG4gICAgLy8gaW52YWxpZGF0ZWQgQ29tcHV0YXRpb24/IFRoaXMgd2lsbCBoYXBwZW4gaWYgd2UgYXJlIHJlcnVubmluZyBhblxuICAgIC8vIGV4aXN0aW5nIGNvbXB1dGF0aW9uLlxuICAgIC8vXG4gICAgLy8gRm9yIGV4YW1wbGUsIGNvbnNpZGVyIGEgcmVydW4gb2Y6XG4gICAgLy9cbiAgICAvLyAgICAgVHJhY2tlci5hdXRvcnVuKGZ1bmN0aW9uICgpIHtcbiAgICAvLyAgICAgICBNZXRlb3Iuc3Vic2NyaWJlKFwiZm9vXCIsIFNlc3Npb24uZ2V0KFwiZm9vXCIpKTtcbiAgICAvLyAgICAgICBNZXRlb3Iuc3Vic2NyaWJlKFwiYmFyXCIsIFNlc3Npb24uZ2V0KFwiYmFyXCIpKTtcbiAgICAvLyAgICAgfSk7XG4gICAgLy9cbiAgICAvLyBJZiBcImZvb1wiIGhhcyBjaGFuZ2VkIGJ1dCBcImJhclwiIGhhcyBub3QsIHdlIHdpbGwgbWF0Y2ggdGhlIFwiYmFyXCJcbiAgICAvLyBzdWJjcmliZSB0byBhbiBleGlzdGluZyBpbmFjdGl2ZSBzdWJzY3JpcHRpb24gaW4gb3JkZXIgdG8gbm90XG4gICAgLy8gdW5zdWIgYW5kIHJlc3ViIHRoZSBzdWJzY3JpcHRpb24gdW5uZWNlc3NhcmlseS5cbiAgICAvL1xuICAgIC8vIFdlIG9ubHkgbG9vayBmb3Igb25lIHN1Y2ggc3ViOyBpZiB0aGVyZSBhcmUgTiBhcHBhcmVudGx5LWlkZW50aWNhbCBzdWJzXG4gICAgLy8gYmVpbmcgaW52YWxpZGF0ZWQsIHdlIHdpbGwgcmVxdWlyZSBOIG1hdGNoaW5nIHN1YnNjcmliZSBjYWxscyB0byBrZWVwXG4gICAgLy8gdGhlbSBhbGwgYWN0aXZlLlxuICAgIGNvbnN0IGV4aXN0aW5nID0gT2JqZWN0LnZhbHVlcyhzZWxmLl9zdWJzY3JpcHRpb25zKS5maW5kKFxuICAgICAgc3ViID0+IChzdWIuaW5hY3RpdmUgJiYgc3ViLm5hbWUgPT09IG5hbWUgJiYgRUpTT04uZXF1YWxzKHN1Yi5wYXJhbXMsIHBhcmFtcykpXG4gICAgKTtcblxuICAgIGxldCBpZDtcbiAgICBpZiAoZXhpc3RpbmcpIHtcbiAgICAgIGlkID0gZXhpc3RpbmcuaWQ7XG4gICAgICBleGlzdGluZy5pbmFjdGl2ZSA9IGZhbHNlOyAvLyByZWFjdGl2YXRlXG5cbiAgICAgIGlmIChjYWxsYmFja3Mub25SZWFkeSkge1xuICAgICAgICAvLyBJZiB0aGUgc3ViIGlzIG5vdCBhbHJlYWR5IHJlYWR5LCByZXBsYWNlIGFueSByZWFkeSBjYWxsYmFjayB3aXRoIHRoZVxuICAgICAgICAvLyBvbmUgcHJvdmlkZWQgbm93LiAoSXQncyBub3QgcmVhbGx5IGNsZWFyIHdoYXQgdXNlcnMgd291bGQgZXhwZWN0IGZvclxuICAgICAgICAvLyBhbiBvblJlYWR5IGNhbGxiYWNrIGluc2lkZSBhbiBhdXRvcnVuOyB0aGUgc2VtYW50aWNzIHdlIHByb3ZpZGUgaXNcbiAgICAgICAgLy8gdGhhdCBhdCB0aGUgdGltZSB0aGUgc3ViIGZpcnN0IGJlY29tZXMgcmVhZHksIHdlIGNhbGwgdGhlIGxhc3RcbiAgICAgICAgLy8gb25SZWFkeSBjYWxsYmFjayBwcm92aWRlZCwgaWYgYW55LilcbiAgICAgICAgLy8gSWYgdGhlIHN1YiBpcyBhbHJlYWR5IHJlYWR5LCBydW4gdGhlIHJlYWR5IGNhbGxiYWNrIHJpZ2h0IGF3YXkuXG4gICAgICAgIC8vIEl0IHNlZW1zIHRoYXQgdXNlcnMgd291bGQgZXhwZWN0IGFuIG9uUmVhZHkgY2FsbGJhY2sgaW5zaWRlIGFuXG4gICAgICAgIC8vIGF1dG9ydW4gdG8gdHJpZ2dlciBvbmNlIHRoZSBzdWIgZmlyc3QgYmVjb21lcyByZWFkeSBhbmQgYWxzb1xuICAgICAgICAvLyB3aGVuIHJlLXN1YnMgaGFwcGVucy5cbiAgICAgICAgaWYgKGV4aXN0aW5nLnJlYWR5KSB7XG4gICAgICAgICAgY2FsbGJhY2tzLm9uUmVhZHkoKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBleGlzdGluZy5yZWFkeUNhbGxiYWNrID0gY2FsbGJhY2tzLm9uUmVhZHk7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgLy8gWFhYIENPTVBBVCBXSVRIIDEuMC4zLjEgd2UgdXNlZCB0byBoYXZlIG9uRXJyb3IgYnV0IG5vdyB3ZSBjYWxsXG4gICAgICAvLyBvblN0b3Agd2l0aCBhbiBvcHRpb25hbCBlcnJvciBhcmd1bWVudFxuICAgICAgaWYgKGNhbGxiYWNrcy5vbkVycm9yKSB7XG4gICAgICAgIC8vIFJlcGxhY2UgZXhpc3RpbmcgY2FsbGJhY2sgaWYgYW55LCBzbyB0aGF0IGVycm9ycyBhcmVuJ3RcbiAgICAgICAgLy8gZG91YmxlLXJlcG9ydGVkLlxuICAgICAgICBleGlzdGluZy5lcnJvckNhbGxiYWNrID0gY2FsbGJhY2tzLm9uRXJyb3I7XG4gICAgICB9XG5cbiAgICAgIGlmIChjYWxsYmFja3Mub25TdG9wKSB7XG4gICAgICAgIGV4aXN0aW5nLnN0b3BDYWxsYmFjayA9IGNhbGxiYWNrcy5vblN0b3A7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIE5ldyBzdWIhIEdlbmVyYXRlIGFuIGlkLCBzYXZlIGl0IGxvY2FsbHksIGFuZCBzZW5kIG1lc3NhZ2UuXG4gICAgICBpZCA9IFJhbmRvbS5pZCgpO1xuICAgICAgc2VsZi5fc3Vic2NyaXB0aW9uc1tpZF0gPSB7XG4gICAgICAgIGlkOiBpZCxcbiAgICAgICAgbmFtZTogbmFtZSxcbiAgICAgICAgcGFyYW1zOiBFSlNPTi5jbG9uZShwYXJhbXMpLFxuICAgICAgICBpbmFjdGl2ZTogZmFsc2UsXG4gICAgICAgIHJlYWR5OiBmYWxzZSxcbiAgICAgICAgcmVhZHlEZXBzOiBuZXcgVHJhY2tlci5EZXBlbmRlbmN5KCksXG4gICAgICAgIHJlYWR5Q2FsbGJhY2s6IGNhbGxiYWNrcy5vblJlYWR5LFxuICAgICAgICAvLyBYWFggQ09NUEFUIFdJVEggMS4wLjMuMSAjZXJyb3JDYWxsYmFja1xuICAgICAgICBlcnJvckNhbGxiYWNrOiBjYWxsYmFja3Mub25FcnJvcixcbiAgICAgICAgc3RvcENhbGxiYWNrOiBjYWxsYmFja3Mub25TdG9wLFxuICAgICAgICBjb25uZWN0aW9uOiBzZWxmLFxuICAgICAgICByZW1vdmUoKSB7XG4gICAgICAgICAgZGVsZXRlIHRoaXMuY29ubmVjdGlvbi5fc3Vic2NyaXB0aW9uc1t0aGlzLmlkXTtcbiAgICAgICAgICB0aGlzLnJlYWR5ICYmIHRoaXMucmVhZHlEZXBzLmNoYW5nZWQoKTtcbiAgICAgICAgfSxcbiAgICAgICAgc3RvcCgpIHtcbiAgICAgICAgICB0aGlzLmNvbm5lY3Rpb24uX3NlbmRRdWV1ZWQoeyBtc2c6ICd1bnN1YicsIGlkOiBpZCB9KTtcbiAgICAgICAgICB0aGlzLnJlbW92ZSgpO1xuXG4gICAgICAgICAgaWYgKGNhbGxiYWNrcy5vblN0b3ApIHtcbiAgICAgICAgICAgIGNhbGxiYWNrcy5vblN0b3AoKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH07XG4gICAgICBzZWxmLl9zZW5kKHsgbXNnOiAnc3ViJywgaWQ6IGlkLCBuYW1lOiBuYW1lLCBwYXJhbXM6IHBhcmFtcyB9KTtcbiAgICB9XG5cbiAgICAvLyByZXR1cm4gYSBoYW5kbGUgdG8gdGhlIGFwcGxpY2F0aW9uLlxuICAgIGNvbnN0IGhhbmRsZSA9IHtcbiAgICAgIHN0b3AoKSB7XG4gICAgICAgIGlmICghIGhhc093bi5jYWxsKHNlbGYuX3N1YnNjcmlwdGlvbnMsIGlkKSkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBzZWxmLl9zdWJzY3JpcHRpb25zW2lkXS5zdG9wKCk7XG4gICAgICB9LFxuICAgICAgcmVhZHkoKSB7XG4gICAgICAgIC8vIHJldHVybiBmYWxzZSBpZiB3ZSd2ZSB1bnN1YnNjcmliZWQuXG4gICAgICAgIGlmICghaGFzT3duLmNhbGwoc2VsZi5fc3Vic2NyaXB0aW9ucywgaWQpKSB7XG4gICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHJlY29yZCA9IHNlbGYuX3N1YnNjcmlwdGlvbnNbaWRdO1xuICAgICAgICByZWNvcmQucmVhZHlEZXBzLmRlcGVuZCgpO1xuICAgICAgICByZXR1cm4gcmVjb3JkLnJlYWR5O1xuICAgICAgfSxcbiAgICAgIHN1YnNjcmlwdGlvbklkOiBpZFxuICAgIH07XG5cbiAgICBpZiAoVHJhY2tlci5hY3RpdmUpIHtcbiAgICAgIC8vIFdlJ3JlIGluIGEgcmVhY3RpdmUgY29tcHV0YXRpb24sIHNvIHdlJ2QgbGlrZSB0byB1bnN1YnNjcmliZSB3aGVuIHRoZVxuICAgICAgLy8gY29tcHV0YXRpb24gaXMgaW52YWxpZGF0ZWQuLi4gYnV0IG5vdCBpZiB0aGUgcmVydW4ganVzdCByZS1zdWJzY3JpYmVzXG4gICAgICAvLyB0byB0aGUgc2FtZSBzdWJzY3JpcHRpb24hICBXaGVuIGEgcmVydW4gaGFwcGVucywgd2UgdXNlIG9uSW52YWxpZGF0ZVxuICAgICAgLy8gYXMgYSBjaGFuZ2UgdG8gbWFyayB0aGUgc3Vic2NyaXB0aW9uIFwiaW5hY3RpdmVcIiBzbyB0aGF0IGl0IGNhblxuICAgICAgLy8gYmUgcmV1c2VkIGZyb20gdGhlIHJlcnVuLiAgSWYgaXQgaXNuJ3QgcmV1c2VkLCBpdCdzIGtpbGxlZCBmcm9tXG4gICAgICAvLyBhbiBhZnRlckZsdXNoLlxuICAgICAgVHJhY2tlci5vbkludmFsaWRhdGUoKGMpID0+IHtcbiAgICAgICAgaWYgKGhhc093bi5jYWxsKHNlbGYuX3N1YnNjcmlwdGlvbnMsIGlkKSkge1xuICAgICAgICAgIHNlbGYuX3N1YnNjcmlwdGlvbnNbaWRdLmluYWN0aXZlID0gdHJ1ZTtcbiAgICAgICAgfVxuXG4gICAgICAgIFRyYWNrZXIuYWZ0ZXJGbHVzaCgoKSA9PiB7XG4gICAgICAgICAgaWYgKGhhc093bi5jYWxsKHNlbGYuX3N1YnNjcmlwdGlvbnMsIGlkKSAmJlxuICAgICAgICAgICAgICBzZWxmLl9zdWJzY3JpcHRpb25zW2lkXS5pbmFjdGl2ZSkge1xuICAgICAgICAgICAgaGFuZGxlLnN0b3AoKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfSk7XG4gICAgfVxuXG4gICAgcmV0dXJuIGhhbmRsZTtcbiAgfVxuXG4gIC8qKlxuICAgKiBAc3VtbWFyeSBUZWxscyBpZiB0aGUgbWV0aG9kIGNhbGwgY2FtZSBmcm9tIGEgY2FsbCBvciBhIGNhbGxBc3luYy5cbiAgICogQGFsaWFzIE1ldGVvci5pc0FzeW5jQ2FsbFxuICAgKiBAbG9jdXMgQW55d2hlcmVcbiAgICogQG1lbWJlck9mIE1ldGVvclxuICAgKiBAaW1wb3J0RnJvbVBhY2thZ2UgbWV0ZW9yXG4gICAqIEByZXR1cm5zIGJvb2xlYW5cbiAgICovXG4gIGlzQXN5bmNDYWxsKCl7XG4gICAgcmV0dXJuIEREUC5fQ3VycmVudE1ldGhvZEludm9jYXRpb24uX2lzQ2FsbEFzeW5jTWV0aG9kUnVubmluZygpXG4gIH1cbiAgbWV0aG9kcyhtZXRob2RzKSB7XG4gICAgT2JqZWN0LmVudHJpZXMobWV0aG9kcykuZm9yRWFjaCgoW25hbWUsIGZ1bmNdKSA9PiB7XG4gICAgICBpZiAodHlwZW9mIGZ1bmMgIT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiTWV0aG9kICdcIiArIG5hbWUgKyBcIicgbXVzdCBiZSBhIGZ1bmN0aW9uXCIpO1xuICAgICAgfVxuICAgICAgaWYgKHRoaXMuX21ldGhvZEhhbmRsZXJzW25hbWVdKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcIkEgbWV0aG9kIG5hbWVkICdcIiArIG5hbWUgKyBcIicgaXMgYWxyZWFkeSBkZWZpbmVkXCIpO1xuICAgICAgfVxuICAgICAgdGhpcy5fbWV0aG9kSGFuZGxlcnNbbmFtZV0gPSBmdW5jO1xuICAgIH0pO1xuICB9XG5cbiAgX2dldElzU2ltdWxhdGlvbih7aXNGcm9tQ2FsbEFzeW5jLCBhbHJlYWR5SW5TaW11bGF0aW9ufSkge1xuICAgIGlmICghaXNGcm9tQ2FsbEFzeW5jKSB7XG4gICAgICByZXR1cm4gYWxyZWFkeUluU2ltdWxhdGlvbjtcbiAgICB9XG4gICAgcmV0dXJuIGFscmVhZHlJblNpbXVsYXRpb24gJiYgRERQLl9DdXJyZW50TWV0aG9kSW52b2NhdGlvbi5faXNDYWxsQXN5bmNNZXRob2RSdW5uaW5nKCk7XG4gIH1cblxuICAvKipcbiAgICogQG1lbWJlck9mIE1ldGVvclxuICAgKiBAaW1wb3J0RnJvbVBhY2thZ2UgbWV0ZW9yXG4gICAqIEBhbGlhcyBNZXRlb3IuY2FsbFxuICAgKiBAc3VtbWFyeSBJbnZva2VzIGEgbWV0aG9kIHdpdGggYSBzeW5jIHN0dWIsIHBhc3NpbmcgYW55IG51bWJlciBvZiBhcmd1bWVudHMuXG4gICAqIEBsb2N1cyBBbnl3aGVyZVxuICAgKiBAcGFyYW0ge1N0cmluZ30gbmFtZSBOYW1lIG9mIG1ldGhvZCB0byBpbnZva2VcbiAgICogQHBhcmFtIHtFSlNPTmFibGV9IFthcmcxLGFyZzIuLi5dIE9wdGlvbmFsIG1ldGhvZCBhcmd1bWVudHNcbiAgICogQHBhcmFtIHtGdW5jdGlvbn0gW2FzeW5jQ2FsbGJhY2tdIE9wdGlvbmFsIGNhbGxiYWNrLCB3aGljaCBpcyBjYWxsZWQgYXN5bmNocm9ub3VzbHkgd2l0aCB0aGUgZXJyb3Igb3IgcmVzdWx0IGFmdGVyIHRoZSBtZXRob2QgaXMgY29tcGxldGUuIElmIG5vdCBwcm92aWRlZCwgdGhlIG1ldGhvZCBydW5zIHN5bmNocm9ub3VzbHkgaWYgcG9zc2libGUgKHNlZSBiZWxvdykuXG4gICAqL1xuICBjYWxsKG5hbWUgLyogLi4gW2FyZ3VtZW50c10gLi4gY2FsbGJhY2sgKi8pIHtcbiAgICAvLyBpZiBpdCdzIGEgZnVuY3Rpb24sIHRoZSBsYXN0IGFyZ3VtZW50IGlzIHRoZSByZXN1bHQgY2FsbGJhY2ssXG4gICAgLy8gbm90IGEgcGFyYW1ldGVyIHRvIHRoZSByZW1vdGUgbWV0aG9kLlxuICAgIGNvbnN0IGFyZ3MgPSBzbGljZS5jYWxsKGFyZ3VtZW50cywgMSk7XG4gICAgbGV0IGNhbGxiYWNrO1xuICAgIGlmIChhcmdzLmxlbmd0aCAmJiB0eXBlb2YgYXJnc1thcmdzLmxlbmd0aCAtIDFdID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICBjYWxsYmFjayA9IGFyZ3MucG9wKCk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLmFwcGx5KG5hbWUsIGFyZ3MsIGNhbGxiYWNrKTtcbiAgfVxuICAvKipcbiAgICogQG1lbWJlck9mIE1ldGVvclxuICAgKiBAaW1wb3J0RnJvbVBhY2thZ2UgbWV0ZW9yXG4gICAqIEBhbGlhcyBNZXRlb3IuY2FsbEFzeW5jXG4gICAqIEBzdW1tYXJ5IEludm9rZXMgYSBtZXRob2Qgd2l0aCBhbiBhc3luYyBzdHViLCBwYXNzaW5nIGFueSBudW1iZXIgb2YgYXJndW1lbnRzLlxuICAgKiBAbG9jdXMgQW55d2hlcmVcbiAgICogQHBhcmFtIHtTdHJpbmd9IG5hbWUgTmFtZSBvZiBtZXRob2QgdG8gaW52b2tlXG4gICAqIEBwYXJhbSB7RUpTT05hYmxlfSBbYXJnMSxhcmcyLi4uXSBPcHRpb25hbCBtZXRob2QgYXJndW1lbnRzXG4gICAqIEByZXR1cm5zIHtQcm9taXNlfVxuICAgKi9cbiAgY2FsbEFzeW5jKG5hbWUgLyogLi4gW2FyZ3VtZW50c10gLi4gKi8pIHtcbiAgICBjb25zdCBhcmdzID0gc2xpY2UuY2FsbChhcmd1bWVudHMsIDEpO1xuICAgIGlmIChhcmdzLmxlbmd0aCAmJiB0eXBlb2YgYXJnc1thcmdzLmxlbmd0aCAtIDFdID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgIFwiTWV0ZW9yLmNhbGxBc3luYygpIGRvZXMgbm90IGFjY2VwdCBhIGNhbGxiYWNrLiBZb3Ugc2hvdWxkICdhd2FpdCcgdGhlIHJlc3VsdCwgb3IgdXNlIC50aGVuKCkuXCJcbiAgICAgICk7XG4gICAgfVxuXG4gICAgcmV0dXJuIHRoaXMuYXBwbHlBc3luYyhuYW1lLCBhcmdzLCB7IHJldHVyblNlcnZlclJlc3VsdFByb21pc2U6IHRydWUgfSk7XG4gIH1cblxuICAvKipcbiAgICogQG1lbWJlck9mIE1ldGVvclxuICAgKiBAaW1wb3J0RnJvbVBhY2thZ2UgbWV0ZW9yXG4gICAqIEBhbGlhcyBNZXRlb3IuYXBwbHlcbiAgICogQHN1bW1hcnkgSW52b2tlIGEgbWV0aG9kIHBhc3NpbmcgYW4gYXJyYXkgb2YgYXJndW1lbnRzLlxuICAgKiBAbG9jdXMgQW55d2hlcmVcbiAgICogQHBhcmFtIHtTdHJpbmd9IG5hbWUgTmFtZSBvZiBtZXRob2QgdG8gaW52b2tlXG4gICAqIEBwYXJhbSB7RUpTT05hYmxlW119IGFyZ3MgTWV0aG9kIGFyZ3VtZW50c1xuICAgKiBAcGFyYW0ge09iamVjdH0gW29wdGlvbnNdXG4gICAqIEBwYXJhbSB7Qm9vbGVhbn0gb3B0aW9ucy53YWl0IChDbGllbnQgb25seSkgSWYgdHJ1ZSwgZG9uJ3Qgc2VuZCB0aGlzIG1ldGhvZCB1bnRpbCBhbGwgcHJldmlvdXMgbWV0aG9kIGNhbGxzIGhhdmUgY29tcGxldGVkLCBhbmQgZG9uJ3Qgc2VuZCBhbnkgc3Vic2VxdWVudCBtZXRob2QgY2FsbHMgdW50aWwgdGhpcyBvbmUgaXMgY29tcGxldGVkLlxuICAgKiBAcGFyYW0ge0Z1bmN0aW9ufSBvcHRpb25zLm9uUmVzdWx0UmVjZWl2ZWQgKENsaWVudCBvbmx5KSBUaGlzIGNhbGxiYWNrIGlzIGludm9rZWQgd2l0aCB0aGUgZXJyb3Igb3IgcmVzdWx0IG9mIHRoZSBtZXRob2QgKGp1c3QgbGlrZSBgYXN5bmNDYWxsYmFja2ApIGFzIHNvb24gYXMgdGhlIGVycm9yIG9yIHJlc3VsdCBpcyBhdmFpbGFibGUuIFRoZSBsb2NhbCBjYWNoZSBtYXkgbm90IHlldCByZWZsZWN0IHRoZSB3cml0ZXMgcGVyZm9ybWVkIGJ5IHRoZSBtZXRob2QuXG4gICAqIEBwYXJhbSB7Qm9vbGVhbn0gb3B0aW9ucy5ub1JldHJ5IChDbGllbnQgb25seSkgaWYgdHJ1ZSwgZG9uJ3Qgc2VuZCB0aGlzIG1ldGhvZCBhZ2FpbiBvbiByZWxvYWQsIHNpbXBseSBjYWxsIHRoZSBjYWxsYmFjayBhbiBlcnJvciB3aXRoIHRoZSBlcnJvciBjb2RlICdpbnZvY2F0aW9uLWZhaWxlZCcuXG4gICAqIEBwYXJhbSB7Qm9vbGVhbn0gb3B0aW9ucy50aHJvd1N0dWJFeGNlcHRpb25zIChDbGllbnQgb25seSkgSWYgdHJ1ZSwgZXhjZXB0aW9ucyB0aHJvd24gYnkgbWV0aG9kIHN0dWJzIHdpbGwgYmUgdGhyb3duIGluc3RlYWQgb2YgbG9nZ2VkLCBhbmQgdGhlIG1ldGhvZCB3aWxsIG5vdCBiZSBpbnZva2VkIG9uIHRoZSBzZXJ2ZXIuXG4gICAqIEBwYXJhbSB7Qm9vbGVhbn0gb3B0aW9ucy5yZXR1cm5TdHViVmFsdWUgKENsaWVudCBvbmx5KSBJZiB0cnVlIHRoZW4gaW4gY2FzZXMgd2hlcmUgd2Ugd291bGQgaGF2ZSBvdGhlcndpc2UgZGlzY2FyZGVkIHRoZSBzdHViJ3MgcmV0dXJuIHZhbHVlIGFuZCByZXR1cm5lZCB1bmRlZmluZWQsIGluc3RlYWQgd2UgZ28gYWhlYWQgYW5kIHJldHVybiBpdC4gU3BlY2lmaWNhbGx5LCB0aGlzIGlzIGFueSB0aW1lIG90aGVyIHRoYW4gd2hlbiAoYSkgd2UgYXJlIGFscmVhZHkgaW5zaWRlIGEgc3R1YiBvciAoYikgd2UgYXJlIGluIE5vZGUgYW5kIG5vIGNhbGxiYWNrIHdhcyBwcm92aWRlZC4gQ3VycmVudGx5IHdlIHJlcXVpcmUgdGhpcyBmbGFnIHRvIGJlIGV4cGxpY2l0bHkgcGFzc2VkIHRvIHJlZHVjZSB0aGUgbGlrZWxpaG9vZCB0aGF0IHN0dWIgcmV0dXJuIHZhbHVlcyB3aWxsIGJlIGNvbmZ1c2VkIHdpdGggc2VydmVyIHJldHVybiB2YWx1ZXM7IHdlIG1heSBpbXByb3ZlIHRoaXMgaW4gZnV0dXJlLlxuICAgKiBAcGFyYW0ge0Z1bmN0aW9ufSBbYXN5bmNDYWxsYmFja10gT3B0aW9uYWwgY2FsbGJhY2s7IHNhbWUgc2VtYW50aWNzIGFzIGluIFtgTWV0ZW9yLmNhbGxgXSgjbWV0ZW9yX2NhbGwpLlxuICAgKi9cbiAgYXBwbHkobmFtZSwgYXJncywgb3B0aW9ucywgY2FsbGJhY2spIHtcbiAgICBjb25zdCB7IHN0dWJJbnZvY2F0aW9uLCBpbnZvY2F0aW9uLCAuLi5zdHViT3B0aW9ucyB9ID0gdGhpcy5fc3R1YkNhbGwobmFtZSwgRUpTT04uY2xvbmUoYXJncykpO1xuXG4gICAgaWYgKHN0dWJPcHRpb25zLmhhc1N0dWIpIHtcbiAgICAgIGlmIChcbiAgICAgICAgIXRoaXMuX2dldElzU2ltdWxhdGlvbih7XG4gICAgICAgICAgYWxyZWFkeUluU2ltdWxhdGlvbjogc3R1Yk9wdGlvbnMuYWxyZWFkeUluU2ltdWxhdGlvbixcbiAgICAgICAgICBpc0Zyb21DYWxsQXN5bmM6IHN0dWJPcHRpb25zLmlzRnJvbUNhbGxBc3luYyxcbiAgICAgICAgfSlcbiAgICAgICkge1xuICAgICAgICB0aGlzLl9zYXZlT3JpZ2luYWxzKCk7XG4gICAgICB9XG4gICAgICB0cnkge1xuICAgICAgICBzdHViT3B0aW9ucy5zdHViUmV0dXJuVmFsdWUgPSBERFAuX0N1cnJlbnRNZXRob2RJbnZvY2F0aW9uXG4gICAgICAgICAgLndpdGhWYWx1ZShpbnZvY2F0aW9uLCBzdHViSW52b2NhdGlvbik7XG4gICAgICAgIGlmIChNZXRlb3IuX2lzUHJvbWlzZShzdHViT3B0aW9ucy5zdHViUmV0dXJuVmFsdWUpKSB7XG4gICAgICAgICAgTWV0ZW9yLl9kZWJ1ZyhcbiAgICAgICAgICAgIGBNZXRob2QgJHtuYW1lfTogQ2FsbGluZyBhIG1ldGhvZCB0aGF0IGhhcyBhbiBhc3luYyBtZXRob2Qgc3R1YiB3aXRoIGNhbGwvYXBwbHkgY2FuIGxlYWQgdG8gdW5leHBlY3RlZCBiZWhhdmlvcnMuIFVzZSBjYWxsQXN5bmMvYXBwbHlBc3luYyBpbnN0ZWFkLmBcbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIHN0dWJPcHRpb25zLmV4Y2VwdGlvbiA9IGU7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiB0aGlzLl9hcHBseShuYW1lLCBzdHViT3B0aW9ucywgYXJncywgb3B0aW9ucywgY2FsbGJhY2spO1xuICB9XG5cbiAgLyoqXG4gICAqIEBtZW1iZXJPZiBNZXRlb3JcbiAgICogQGltcG9ydEZyb21QYWNrYWdlIG1ldGVvclxuICAgKiBAYWxpYXMgTWV0ZW9yLmFwcGx5QXN5bmNcbiAgICogQHN1bW1hcnkgSW52b2tlIGEgbWV0aG9kIHBhc3NpbmcgYW4gYXJyYXkgb2YgYXJndW1lbnRzLlxuICAgKiBAbG9jdXMgQW55d2hlcmVcbiAgICogQHBhcmFtIHtTdHJpbmd9IG5hbWUgTmFtZSBvZiBtZXRob2QgdG8gaW52b2tlXG4gICAqIEBwYXJhbSB7RUpTT05hYmxlW119IGFyZ3MgTWV0aG9kIGFyZ3VtZW50c1xuICAgKiBAcGFyYW0ge09iamVjdH0gW29wdGlvbnNdXG4gICAqIEBwYXJhbSB7Qm9vbGVhbn0gb3B0aW9ucy53YWl0IChDbGllbnQgb25seSkgSWYgdHJ1ZSwgZG9uJ3Qgc2VuZCB0aGlzIG1ldGhvZCB1bnRpbCBhbGwgcHJldmlvdXMgbWV0aG9kIGNhbGxzIGhhdmUgY29tcGxldGVkLCBhbmQgZG9uJ3Qgc2VuZCBhbnkgc3Vic2VxdWVudCBtZXRob2QgY2FsbHMgdW50aWwgdGhpcyBvbmUgaXMgY29tcGxldGVkLlxuICAgKiBAcGFyYW0ge0Z1bmN0aW9ufSBvcHRpb25zLm9uUmVzdWx0UmVjZWl2ZWQgKENsaWVudCBvbmx5KSBUaGlzIGNhbGxiYWNrIGlzIGludm9rZWQgd2l0aCB0aGUgZXJyb3Igb3IgcmVzdWx0IG9mIHRoZSBtZXRob2QgKGp1c3QgbGlrZSBgYXN5bmNDYWxsYmFja2ApIGFzIHNvb24gYXMgdGhlIGVycm9yIG9yIHJlc3VsdCBpcyBhdmFpbGFibGUuIFRoZSBsb2NhbCBjYWNoZSBtYXkgbm90IHlldCByZWZsZWN0IHRoZSB3cml0ZXMgcGVyZm9ybWVkIGJ5IHRoZSBtZXRob2QuXG4gICAqIEBwYXJhbSB7Qm9vbGVhbn0gb3B0aW9ucy5ub1JldHJ5IChDbGllbnQgb25seSkgaWYgdHJ1ZSwgZG9uJ3Qgc2VuZCB0aGlzIG1ldGhvZCBhZ2FpbiBvbiByZWxvYWQsIHNpbXBseSBjYWxsIHRoZSBjYWxsYmFjayBhbiBlcnJvciB3aXRoIHRoZSBlcnJvciBjb2RlICdpbnZvY2F0aW9uLWZhaWxlZCcuXG4gICAqIEBwYXJhbSB7Qm9vbGVhbn0gb3B0aW9ucy50aHJvd1N0dWJFeGNlcHRpb25zIChDbGllbnQgb25seSkgSWYgdHJ1ZSwgZXhjZXB0aW9ucyB0aHJvd24gYnkgbWV0aG9kIHN0dWJzIHdpbGwgYmUgdGhyb3duIGluc3RlYWQgb2YgbG9nZ2VkLCBhbmQgdGhlIG1ldGhvZCB3aWxsIG5vdCBiZSBpbnZva2VkIG9uIHRoZSBzZXJ2ZXIuXG4gICAqIEBwYXJhbSB7Qm9vbGVhbn0gb3B0aW9ucy5yZXR1cm5TdHViVmFsdWUgKENsaWVudCBvbmx5KSBJZiB0cnVlIHRoZW4gaW4gY2FzZXMgd2hlcmUgd2Ugd291bGQgaGF2ZSBvdGhlcndpc2UgZGlzY2FyZGVkIHRoZSBzdHViJ3MgcmV0dXJuIHZhbHVlIGFuZCByZXR1cm5lZCB1bmRlZmluZWQsIGluc3RlYWQgd2UgZ28gYWhlYWQgYW5kIHJldHVybiBpdC4gU3BlY2lmaWNhbGx5LCB0aGlzIGlzIGFueSB0aW1lIG90aGVyIHRoYW4gd2hlbiAoYSkgd2UgYXJlIGFscmVhZHkgaW5zaWRlIGEgc3R1YiBvciAoYikgd2UgYXJlIGluIE5vZGUgYW5kIG5vIGNhbGxiYWNrIHdhcyBwcm92aWRlZC4gQ3VycmVudGx5IHdlIHJlcXVpcmUgdGhpcyBmbGFnIHRvIGJlIGV4cGxpY2l0bHkgcGFzc2VkIHRvIHJlZHVjZSB0aGUgbGlrZWxpaG9vZCB0aGF0IHN0dWIgcmV0dXJuIHZhbHVlcyB3aWxsIGJlIGNvbmZ1c2VkIHdpdGggc2VydmVyIHJldHVybiB2YWx1ZXM7IHdlIG1heSBpbXByb3ZlIHRoaXMgaW4gZnV0dXJlLlxuICAgKi9cbiAgYXBwbHlBc3luYyhuYW1lLCBhcmdzLCBvcHRpb25zLCBjYWxsYmFjayA9IG51bGwpIHtcbiAgICBjb25zdCBzdHViUHJvbWlzZSA9IHRoaXMuX2FwcGx5QXN5bmNTdHViSW52b2NhdGlvbihuYW1lLCBhcmdzLCBvcHRpb25zKTtcblxuICAgIGNvbnN0IHByb21pc2UgPSB0aGlzLl9hcHBseUFzeW5jKHtcbiAgICAgIG5hbWUsXG4gICAgICBhcmdzLFxuICAgICAgb3B0aW9ucyxcbiAgICAgIGNhbGxiYWNrLFxuICAgICAgc3R1YlByb21pc2UsXG4gICAgfSk7XG4gICAgaWYgKE1ldGVvci5pc0NsaWVudCkge1xuICAgICAgLy8gb25seSByZXR1cm4gdGhlIHN0dWJSZXR1cm5WYWx1ZVxuICAgICAgcHJvbWlzZS5zdHViUHJvbWlzZSA9IHN0dWJQcm9taXNlLnRoZW4obyA9PiB7XG4gICAgICAgIGlmIChvLmV4Y2VwdGlvbikge1xuICAgICAgICAgIHRocm93IG8uZXhjZXB0aW9uO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBvLnN0dWJSZXR1cm5WYWx1ZTtcbiAgICAgIH0pO1xuICAgICAgLy8gdGhpcyBhdm9pZHMgYXR0cmlidXRlIHJlY3Vyc2lvblxuICAgICAgcHJvbWlzZS5zZXJ2ZXJQcm9taXNlID0gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT5cbiAgICAgICAgcHJvbWlzZS50aGVuKHJlc29sdmUpLmNhdGNoKHJlamVjdCksXG4gICAgICApO1xuICAgIH1cbiAgICByZXR1cm4gcHJvbWlzZTtcbiAgfVxuICBhc3luYyBfYXBwbHlBc3luY1N0dWJJbnZvY2F0aW9uKG5hbWUsIGFyZ3MsIG9wdGlvbnMpIHtcbiAgICBjb25zdCB7IHN0dWJJbnZvY2F0aW9uLCBpbnZvY2F0aW9uLCAuLi5zdHViT3B0aW9ucyB9ID0gdGhpcy5fc3R1YkNhbGwobmFtZSwgRUpTT04uY2xvbmUoYXJncyksIG9wdGlvbnMpO1xuICAgIGlmIChzdHViT3B0aW9ucy5oYXNTdHViKSB7XG4gICAgICBpZiAoXG4gICAgICAgICF0aGlzLl9nZXRJc1NpbXVsYXRpb24oe1xuICAgICAgICAgIGFscmVhZHlJblNpbXVsYXRpb246IHN0dWJPcHRpb25zLmFscmVhZHlJblNpbXVsYXRpb24sXG4gICAgICAgICAgaXNGcm9tQ2FsbEFzeW5jOiBzdHViT3B0aW9ucy5pc0Zyb21DYWxsQXN5bmMsXG4gICAgICAgIH0pXG4gICAgICApIHtcbiAgICAgICAgdGhpcy5fc2F2ZU9yaWdpbmFscygpO1xuICAgICAgfVxuICAgICAgdHJ5IHtcbiAgICAgICAgLypcbiAgICAgICAgICogVGhlIGNvZGUgYmVsb3cgZm9sbG93cyB0aGUgc2FtZSBsb2dpYyBhcyB0aGUgZnVuY3Rpb24gd2l0aFZhbHVlcygpLlxuICAgICAgICAgKlxuICAgICAgICAgKiBCdXQgYXMgdGhlIE1ldGVvciBwYWNrYWdlIGlzIG5vdCBjb21waWxlZCBieSBlY21hc2NyaXB0LCBpdCBpcyB1bmFibGUgdG8gdXNlIG5ld2VyIHN5bnRheCBpbiB0aGUgYnJvd3NlcixcbiAgICAgICAgICogc3VjaCBhcywgdGhlIGFzeW5jL2F3YWl0LlxuICAgICAgICAgKlxuICAgICAgICAgKiBTbywgdG8ga2VlcCBzdXBwb3J0aW5nIG9sZCBicm93c2VycywgbGlrZSBJRSAxMSwgd2UncmUgY3JlYXRpbmcgdGhlIGxvZ2ljIG9uZSBsZXZlbCBhYm92ZS5cbiAgICAgICAgICovXG4gICAgICAgIGNvbnN0IGN1cnJlbnRDb250ZXh0ID0gRERQLl9DdXJyZW50TWV0aG9kSW52b2NhdGlvbi5fc2V0TmV3Q29udGV4dEFuZEdldEN1cnJlbnQoXG4gICAgICAgICAgaW52b2NhdGlvblxuICAgICAgICApO1xuICAgICAgICB0cnkge1xuICAgICAgICAgIHN0dWJPcHRpb25zLnN0dWJSZXR1cm5WYWx1ZSA9IGF3YWl0IHN0dWJJbnZvY2F0aW9uKCk7XG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICBzdHViT3B0aW9ucy5leGNlcHRpb24gPSBlO1xuICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgIEREUC5fQ3VycmVudE1ldGhvZEludm9jYXRpb24uX3NldChjdXJyZW50Q29udGV4dCk7XG4gICAgICAgIH1cbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgc3R1Yk9wdGlvbnMuZXhjZXB0aW9uID0gZTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHN0dWJPcHRpb25zO1xuICB9XG4gIGFzeW5jIF9hcHBseUFzeW5jKHsgbmFtZSwgYXJncywgb3B0aW9ucywgY2FsbGJhY2ssIHN0dWJQcm9taXNlIH0pIHtcbiAgICBjb25zdCBzdHViT3B0aW9ucyA9IGF3YWl0IHN0dWJQcm9taXNlO1xuICAgIHJldHVybiB0aGlzLl9hcHBseShuYW1lLCBzdHViT3B0aW9ucywgYXJncywgb3B0aW9ucywgY2FsbGJhY2spO1xuICB9XG5cbiAgX2FwcGx5KG5hbWUsIHN0dWJDYWxsVmFsdWUsIGFyZ3MsIG9wdGlvbnMsIGNhbGxiYWNrKSB7XG4gICAgY29uc3Qgc2VsZiA9IHRoaXM7XG4gICAgLy8gV2Ugd2VyZSBwYXNzZWQgMyBhcmd1bWVudHMuIFRoZXkgbWF5IGJlIGVpdGhlciAobmFtZSwgYXJncywgb3B0aW9ucylcbiAgICAvLyBvciAobmFtZSwgYXJncywgY2FsbGJhY2spXG4gICAgaWYgKCFjYWxsYmFjayAmJiB0eXBlb2Ygb3B0aW9ucyA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgY2FsbGJhY2sgPSBvcHRpb25zO1xuICAgICAgb3B0aW9ucyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gICAgfVxuICAgIG9wdGlvbnMgPSBvcHRpb25zIHx8IE9iamVjdC5jcmVhdGUobnVsbCk7XG5cbiAgICBpZiAoY2FsbGJhY2spIHtcbiAgICAgIC8vIFhYWCB3b3VsZCBpdCBiZSBiZXR0ZXIgZm9ybSB0byBkbyB0aGUgYmluZGluZyBpbiBzdHJlYW0ub24sXG4gICAgICAvLyBvciBjYWxsZXIsIGluc3RlYWQgb2YgaGVyZT9cbiAgICAgIC8vIFhYWCBpbXByb3ZlIGVycm9yIG1lc3NhZ2UgKGFuZCBob3cgd2UgcmVwb3J0IGl0KVxuICAgICAgY2FsbGJhY2sgPSBNZXRlb3IuYmluZEVudmlyb25tZW50KFxuICAgICAgICBjYWxsYmFjayxcbiAgICAgICAgXCJkZWxpdmVyaW5nIHJlc3VsdCBvZiBpbnZva2luZyAnXCIgKyBuYW1lICsgXCInXCJcbiAgICAgICk7XG4gICAgfVxuICAgIGNvbnN0IHtcbiAgICAgIGhhc1N0dWIsXG4gICAgICBleGNlcHRpb24sXG4gICAgICBzdHViUmV0dXJuVmFsdWUsXG4gICAgICBhbHJlYWR5SW5TaW11bGF0aW9uLFxuICAgICAgcmFuZG9tU2VlZCxcbiAgICB9ID0gc3R1YkNhbGxWYWx1ZTtcblxuICAgIC8vIEtlZXAgb3VyIGFyZ3Mgc2FmZSBmcm9tIG11dGF0aW9uIChlZyBpZiB3ZSBkb24ndCBzZW5kIHRoZSBtZXNzYWdlIGZvciBhXG4gICAgLy8gd2hpbGUgYmVjYXVzZSBvZiBhIHdhaXQgbWV0aG9kKS5cbiAgICBhcmdzID0gRUpTT04uY2xvbmUoYXJncyk7XG4gICAgLy8gSWYgd2UncmUgaW4gYSBzaW11bGF0aW9uLCBzdG9wIGFuZCByZXR1cm4gdGhlIHJlc3VsdCB3ZSBoYXZlLFxuICAgIC8vIHJhdGhlciB0aGFuIGdvaW5nIG9uIHRvIGRvIGFuIFJQQy4gSWYgdGhlcmUgd2FzIG5vIHN0dWIsXG4gICAgLy8gd2UnbGwgZW5kIHVwIHJldHVybmluZyB1bmRlZmluZWQuXG4gICAgaWYgKFxuICAgICAgdGhpcy5fZ2V0SXNTaW11bGF0aW9uKHtcbiAgICAgICAgYWxyZWFkeUluU2ltdWxhdGlvbixcbiAgICAgICAgaXNGcm9tQ2FsbEFzeW5jOiBzdHViQ2FsbFZhbHVlLmlzRnJvbUNhbGxBc3luYyxcbiAgICAgIH0pXG4gICAgKSB7XG4gICAgICBpZiAoY2FsbGJhY2spIHtcbiAgICAgICAgY2FsbGJhY2soZXhjZXB0aW9uLCBzdHViUmV0dXJuVmFsdWUpO1xuICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgICAgfVxuICAgICAgaWYgKGV4Y2VwdGlvbikgdGhyb3cgZXhjZXB0aW9uO1xuICAgICAgcmV0dXJuIHN0dWJSZXR1cm5WYWx1ZTtcbiAgICB9XG5cbiAgICAvLyBXZSBvbmx5IGNyZWF0ZSB0aGUgbWV0aG9kSWQgaGVyZSBiZWNhdXNlIHdlIGRvbid0IGFjdHVhbGx5IG5lZWQgb25lIGlmXG4gICAgLy8gd2UncmUgYWxyZWFkeSBpbiBhIHNpbXVsYXRpb25cbiAgICBjb25zdCBtZXRob2RJZCA9ICcnICsgc2VsZi5fbmV4dE1ldGhvZElkKys7XG4gICAgaWYgKGhhc1N0dWIpIHtcbiAgICAgIHNlbGYuX3JldHJpZXZlQW5kU3RvcmVPcmlnaW5hbHMobWV0aG9kSWQpO1xuICAgIH1cblxuICAgIC8vIEdlbmVyYXRlIHRoZSBERFAgbWVzc2FnZSBmb3IgdGhlIG1ldGhvZCBjYWxsLiBOb3RlIHRoYXQgb24gdGhlIGNsaWVudCxcbiAgICAvLyBpdCBpcyBpbXBvcnRhbnQgdGhhdCB0aGUgc3R1YiBoYXZlIGZpbmlzaGVkIGJlZm9yZSB3ZSBzZW5kIHRoZSBSUEMsIHNvXG4gICAgLy8gdGhhdCB3ZSBrbm93IHdlIGhhdmUgYSBjb21wbGV0ZSBsaXN0IG9mIHdoaWNoIGxvY2FsIGRvY3VtZW50cyB0aGUgc3R1YlxuICAgIC8vIHdyb3RlLlxuICAgIGNvbnN0IG1lc3NhZ2UgPSB7XG4gICAgICBtc2c6ICdtZXRob2QnLFxuICAgICAgaWQ6IG1ldGhvZElkLFxuICAgICAgbWV0aG9kOiBuYW1lLFxuICAgICAgcGFyYW1zOiBhcmdzXG4gICAgfTtcblxuICAgIC8vIElmIGFuIGV4Y2VwdGlvbiBvY2N1cnJlZCBpbiBhIHN0dWIsIGFuZCB3ZSdyZSBpZ25vcmluZyBpdFxuICAgIC8vIGJlY2F1c2Ugd2UncmUgZG9pbmcgYW4gUlBDIGFuZCB3YW50IHRvIHVzZSB3aGF0IHRoZSBzZXJ2ZXJcbiAgICAvLyByZXR1cm5zIGluc3RlYWQsIGxvZyBpdCBzbyB0aGUgZGV2ZWxvcGVyIGtub3dzXG4gICAgLy8gKHVubGVzcyB0aGV5IGV4cGxpY2l0bHkgYXNrIHRvIHNlZSB0aGUgZXJyb3IpLlxuICAgIC8vXG4gICAgLy8gVGVzdHMgY2FuIHNldCB0aGUgJ19leHBlY3RlZEJ5VGVzdCcgZmxhZyBvbiBhbiBleGNlcHRpb24gc28gaXQgd29uJ3RcbiAgICAvLyBnbyB0byBsb2cuXG4gICAgaWYgKGV4Y2VwdGlvbikge1xuICAgICAgaWYgKG9wdGlvbnMudGhyb3dTdHViRXhjZXB0aW9ucykge1xuICAgICAgICB0aHJvdyBleGNlcHRpb247XG4gICAgICB9IGVsc2UgaWYgKCFleGNlcHRpb24uX2V4cGVjdGVkQnlUZXN0KSB7XG4gICAgICAgIE1ldGVvci5fZGVidWcoXG4gICAgICAgICAgXCJFeGNlcHRpb24gd2hpbGUgc2ltdWxhdGluZyB0aGUgZWZmZWN0IG9mIGludm9raW5nICdcIiArIG5hbWUgKyBcIidcIixcbiAgICAgICAgICBleGNlcHRpb25cbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBBdCB0aGlzIHBvaW50IHdlJ3JlIGRlZmluaXRlbHkgZG9pbmcgYW4gUlBDLCBhbmQgd2UncmUgZ29pbmcgdG9cbiAgICAvLyByZXR1cm4gdGhlIHZhbHVlIG9mIHRoZSBSUEMgdG8gdGhlIGNhbGxlci5cblxuICAgIC8vIElmIHRoZSBjYWxsZXIgZGlkbid0IGdpdmUgYSBjYWxsYmFjaywgZGVjaWRlIHdoYXQgdG8gZG8uXG4gICAgbGV0IGZ1dHVyZTtcbiAgICBpZiAoIWNhbGxiYWNrKSB7XG4gICAgICBpZiAoXG4gICAgICAgIE1ldGVvci5pc0NsaWVudCAmJlxuICAgICAgICAhb3B0aW9ucy5yZXR1cm5TZXJ2ZXJSZXN1bHRQcm9taXNlICYmXG4gICAgICAgICghb3B0aW9ucy5pc0Zyb21DYWxsQXN5bmMgfHwgb3B0aW9ucy5yZXR1cm5TdHViVmFsdWUpXG4gICAgICApIHtcbiAgICAgICAgLy8gT24gdGhlIGNsaWVudCwgd2UgZG9uJ3QgaGF2ZSBmaWJlcnMsIHNvIHdlIGNhbid0IGJsb2NrLiBUaGVcbiAgICAgICAgLy8gb25seSB0aGluZyB3ZSBjYW4gZG8gaXMgdG8gcmV0dXJuIHVuZGVmaW5lZCBhbmQgZGlzY2FyZCB0aGVcbiAgICAgICAgLy8gcmVzdWx0IG9mIHRoZSBSUEMuIElmIGFuIGVycm9yIG9jY3VycmVkIHRoZW4gcHJpbnQgdGhlIGVycm9yXG4gICAgICAgIC8vIHRvIHRoZSBjb25zb2xlLlxuICAgICAgICBjYWxsYmFjayA9IChlcnIpID0+IHtcbiAgICAgICAgICBlcnIgJiYgTWV0ZW9yLl9kZWJ1ZyhcIkVycm9yIGludm9raW5nIE1ldGhvZCAnXCIgKyBuYW1lICsgXCInXCIsIGVycik7XG4gICAgICAgIH07XG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvLyBPbiB0aGUgc2VydmVyLCBtYWtlIHRoZSBmdW5jdGlvbiBzeW5jaHJvbm91cy4gVGhyb3cgb25cbiAgICAgICAgLy8gZXJyb3JzLCByZXR1cm4gb24gc3VjY2Vzcy5cbiAgICAgICAgZnV0dXJlID0gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgICAgIGNhbGxiYWNrID0gKC4uLmFsbEFyZ3MpID0+IHtcbiAgICAgICAgICAgIGxldCBhcmdzID0gQXJyYXkuZnJvbShhbGxBcmdzKTtcbiAgICAgICAgICAgIGxldCBlcnIgPSBhcmdzLnNoaWZ0KCk7XG4gICAgICAgICAgICBpZiAoZXJyKSB7XG4gICAgICAgICAgICAgIHJlamVjdChlcnIpO1xuICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXNvbHZlKC4uLmFyZ3MpO1xuICAgICAgICAgIH07XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIFNlbmQgdGhlIHJhbmRvbVNlZWQgb25seSBpZiB3ZSB1c2VkIGl0XG4gICAgaWYgKHJhbmRvbVNlZWQudmFsdWUgIT09IG51bGwpIHtcbiAgICAgIG1lc3NhZ2UucmFuZG9tU2VlZCA9IHJhbmRvbVNlZWQudmFsdWU7XG4gICAgfVxuXG4gICAgY29uc3QgbWV0aG9kSW52b2tlciA9IG5ldyBNZXRob2RJbnZva2VyKHtcbiAgICAgIG1ldGhvZElkLFxuICAgICAgY2FsbGJhY2s6IGNhbGxiYWNrLFxuICAgICAgY29ubmVjdGlvbjogc2VsZixcbiAgICAgIG9uUmVzdWx0UmVjZWl2ZWQ6IG9wdGlvbnMub25SZXN1bHRSZWNlaXZlZCxcbiAgICAgIHdhaXQ6ICEhb3B0aW9ucy53YWl0LFxuICAgICAgbWVzc2FnZTogbWVzc2FnZSxcbiAgICAgIG5vUmV0cnk6ICEhb3B0aW9ucy5ub1JldHJ5XG4gICAgfSk7XG5cbiAgICBpZiAob3B0aW9ucy53YWl0KSB7XG4gICAgICAvLyBJdCdzIGEgd2FpdCBtZXRob2QhIFdhaXQgbWV0aG9kcyBnbyBpbiB0aGVpciBvd24gYmxvY2suXG4gICAgICBzZWxmLl9vdXRzdGFuZGluZ01ldGhvZEJsb2Nrcy5wdXNoKHtcbiAgICAgICAgd2FpdDogdHJ1ZSxcbiAgICAgICAgbWV0aG9kczogW21ldGhvZEludm9rZXJdXG4gICAgICB9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gTm90IGEgd2FpdCBtZXRob2QuIFN0YXJ0IGEgbmV3IGJsb2NrIGlmIHRoZSBwcmV2aW91cyBibG9jayB3YXMgYSB3YWl0XG4gICAgICAvLyBibG9jaywgYW5kIGFkZCBpdCB0byB0aGUgbGFzdCBibG9jayBvZiBtZXRob2RzLlxuICAgICAgaWYgKGlzRW1wdHkoc2VsZi5fb3V0c3RhbmRpbmdNZXRob2RCbG9ja3MpIHx8XG4gICAgICAgICAgbGFzdChzZWxmLl9vdXRzdGFuZGluZ01ldGhvZEJsb2Nrcykud2FpdCkge1xuICAgICAgICBzZWxmLl9vdXRzdGFuZGluZ01ldGhvZEJsb2Nrcy5wdXNoKHtcbiAgICAgICAgICB3YWl0OiBmYWxzZSxcbiAgICAgICAgICBtZXRob2RzOiBbXSxcbiAgICAgICAgfSk7XG4gICAgICB9XG5cbiAgICAgIGxhc3Qoc2VsZi5fb3V0c3RhbmRpbmdNZXRob2RCbG9ja3MpLm1ldGhvZHMucHVzaChtZXRob2RJbnZva2VyKTtcbiAgICB9XG5cbiAgICAvLyBJZiB3ZSBhZGRlZCBpdCB0byB0aGUgZmlyc3QgYmxvY2ssIHNlbmQgaXQgb3V0IG5vdy5cbiAgICBpZiAoc2VsZi5fb3V0c3RhbmRpbmdNZXRob2RCbG9ja3MubGVuZ3RoID09PSAxKSBtZXRob2RJbnZva2VyLnNlbmRNZXNzYWdlKCk7XG5cbiAgICAvLyBJZiB3ZSdyZSB1c2luZyB0aGUgZGVmYXVsdCBjYWxsYmFjayBvbiB0aGUgc2VydmVyLFxuICAgIC8vIGJsb2NrIHdhaXRpbmcgZm9yIHRoZSByZXN1bHQuXG4gICAgaWYgKGZ1dHVyZSkge1xuICAgICAgLy8gVGhpcyBpcyB0aGUgcmVzdWx0IG9mIHRoZSBtZXRob2QgcmFuIGluIHRoZSBjbGllbnQuXG4gICAgICAvLyBZb3UgY2FuIG9wdC1pbiBpbiBnZXR0aW5nIHRoZSBsb2NhbCByZXN1bHQgYnkgcnVubmluZzpcbiAgICAgIC8vIGNvbnN0IHsgc3R1YlByb21pc2UsIHNlcnZlclByb21pc2UgfSA9IE1ldGVvci5jYWxsQXN5bmMoLi4uKTtcbiAgICAgIC8vIGNvbnN0IHdoYXRTZXJ2ZXJEaWQgPSBhd2FpdCBzZXJ2ZXJQcm9taXNlO1xuICAgICAgaWYgKG9wdGlvbnMucmV0dXJuU3R1YlZhbHVlKSB7XG4gICAgICAgIHJldHVybiBmdXR1cmUudGhlbigoKSA9PiBzdHViUmV0dXJuVmFsdWUpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGZ1dHVyZTtcbiAgICB9XG4gICAgcmV0dXJuIG9wdGlvbnMucmV0dXJuU3R1YlZhbHVlID8gc3R1YlJldHVyblZhbHVlIDogdW5kZWZpbmVkO1xuICB9XG5cblxuICBfc3R1YkNhbGwobmFtZSwgYXJncywgb3B0aW9ucykge1xuICAgIC8vIFJ1biB0aGUgc3R1YiwgaWYgd2UgaGF2ZSBvbmUuIFRoZSBzdHViIGlzIHN1cHBvc2VkIHRvIG1ha2Ugc29tZVxuICAgIC8vIHRlbXBvcmFyeSB3cml0ZXMgdG8gdGhlIGRhdGFiYXNlIHRvIGdpdmUgdGhlIHVzZXIgYSBzbW9vdGggZXhwZXJpZW5jZVxuICAgIC8vIHVudGlsIHRoZSBhY3R1YWwgcmVzdWx0IG9mIGV4ZWN1dGluZyB0aGUgbWV0aG9kIGNvbWVzIGJhY2sgZnJvbSB0aGVcbiAgICAvLyBzZXJ2ZXIgKHdoZXJldXBvbiB0aGUgdGVtcG9yYXJ5IHdyaXRlcyB0byB0aGUgZGF0YWJhc2Ugd2lsbCBiZSByZXZlcnNlZFxuICAgIC8vIGR1cmluZyB0aGUgYmVnaW5VcGRhdGUvZW5kVXBkYXRlIHByb2Nlc3MuKVxuICAgIC8vXG4gICAgLy8gTm9ybWFsbHksIHdlIGlnbm9yZSB0aGUgcmV0dXJuIHZhbHVlIG9mIHRoZSBzdHViIChldmVuIGlmIGl0IGlzIGFuXG4gICAgLy8gZXhjZXB0aW9uKSwgaW4gZmF2b3Igb2YgdGhlIHJlYWwgcmV0dXJuIHZhbHVlIGZyb20gdGhlIHNlcnZlci4gVGhlXG4gICAgLy8gZXhjZXB0aW9uIGlzIGlmIHRoZSAqY2FsbGVyKiBpcyBhIHN0dWIuIEluIHRoYXQgY2FzZSwgd2UncmUgbm90IGdvaW5nXG4gICAgLy8gdG8gZG8gYSBSUEMsIHNvIHdlIHVzZSB0aGUgcmV0dXJuIHZhbHVlIG9mIHRoZSBzdHViIGFzIG91ciByZXR1cm5cbiAgICAvLyB2YWx1ZS5cbiAgICBjb25zdCBzZWxmID0gdGhpcztcbiAgICBjb25zdCBlbmNsb3NpbmcgPSBERFAuX0N1cnJlbnRNZXRob2RJbnZvY2F0aW9uLmdldCgpO1xuICAgIGNvbnN0IHN0dWIgPSBzZWxmLl9tZXRob2RIYW5kbGVyc1tuYW1lXTtcbiAgICBjb25zdCBhbHJlYWR5SW5TaW11bGF0aW9uID0gZW5jbG9zaW5nPy5pc1NpbXVsYXRpb247XG4gICAgY29uc3QgaXNGcm9tQ2FsbEFzeW5jID0gZW5jbG9zaW5nPy5faXNGcm9tQ2FsbEFzeW5jO1xuICAgIGNvbnN0IHJhbmRvbVNlZWQgPSB7IHZhbHVlOiBudWxsfTtcblxuICAgIGNvbnN0IGRlZmF1bHRSZXR1cm4gPSB7XG4gICAgICBhbHJlYWR5SW5TaW11bGF0aW9uLFxuICAgICAgcmFuZG9tU2VlZCxcbiAgICAgIGlzRnJvbUNhbGxBc3luYyxcbiAgICB9O1xuICAgIGlmICghc3R1Yikge1xuICAgICAgcmV0dXJuIHsgLi4uZGVmYXVsdFJldHVybiwgaGFzU3R1YjogZmFsc2UgfTtcbiAgICB9XG5cbiAgICAvLyBMYXppbHkgZ2VuZXJhdGUgYSByYW5kb21TZWVkLCBvbmx5IGlmIGl0IGlzIHJlcXVlc3RlZCBieSB0aGUgc3R1Yi5cbiAgICAvLyBUaGUgcmFuZG9tIHN0cmVhbXMgb25seSBoYXZlIHV0aWxpdHkgaWYgdGhleSdyZSB1c2VkIG9uIGJvdGggdGhlIGNsaWVudFxuICAgIC8vIGFuZCB0aGUgc2VydmVyOyBpZiB0aGUgY2xpZW50IGRvZXNuJ3QgZ2VuZXJhdGUgYW55ICdyYW5kb20nIHZhbHVlc1xuICAgIC8vIHRoZW4gd2UgZG9uJ3QgZXhwZWN0IHRoZSBzZXJ2ZXIgdG8gZ2VuZXJhdGUgYW55IGVpdGhlci5cbiAgICAvLyBMZXNzIGNvbW1vbmx5LCB0aGUgc2VydmVyIG1heSBwZXJmb3JtIGRpZmZlcmVudCBhY3Rpb25zIGZyb20gdGhlIGNsaWVudCxcbiAgICAvLyBhbmQgbWF5IGluIGZhY3QgZ2VuZXJhdGUgdmFsdWVzIHdoZXJlIHRoZSBjbGllbnQgZGlkIG5vdCwgYnV0IHdlIGRvbid0XG4gICAgLy8gaGF2ZSBhbnkgY2xpZW50LXNpZGUgdmFsdWVzIHRvIG1hdGNoLCBzbyBldmVuIGhlcmUgd2UgbWF5IGFzIHdlbGwganVzdFxuICAgIC8vIHVzZSBhIHJhbmRvbSBzZWVkIG9uIHRoZSBzZXJ2ZXIuICBJbiB0aGF0IGNhc2UsIHdlIGRvbid0IHBhc3MgdGhlXG4gICAgLy8gcmFuZG9tU2VlZCB0byBzYXZlIGJhbmR3aWR0aCwgYW5kIHdlIGRvbid0IGV2ZW4gZ2VuZXJhdGUgaXQgdG8gc2F2ZSBhXG4gICAgLy8gYml0IG9mIENQVSBhbmQgdG8gYXZvaWQgY29uc3VtaW5nIGVudHJvcHkuXG5cbiAgICBjb25zdCByYW5kb21TZWVkR2VuZXJhdG9yID0gKCkgPT4ge1xuICAgICAgaWYgKHJhbmRvbVNlZWQudmFsdWUgPT09IG51bGwpIHtcbiAgICAgICAgcmFuZG9tU2VlZC52YWx1ZSA9IEREUENvbW1vbi5tYWtlUnBjU2VlZChlbmNsb3NpbmcsIG5hbWUpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHJhbmRvbVNlZWQudmFsdWU7XG4gICAgfTtcblxuICAgIGNvbnN0IHNldFVzZXJJZCA9IHVzZXJJZCA9PiB7XG4gICAgICBzZWxmLnNldFVzZXJJZCh1c2VySWQpO1xuICAgIH07XG5cbiAgICBjb25zdCBpbnZvY2F0aW9uID0gbmV3IEREUENvbW1vbi5NZXRob2RJbnZvY2F0aW9uKHtcbiAgICAgIG5hbWUsXG4gICAgICBpc1NpbXVsYXRpb246IHRydWUsXG4gICAgICB1c2VySWQ6IHNlbGYudXNlcklkKCksXG4gICAgICBpc0Zyb21DYWxsQXN5bmM6IG9wdGlvbnM/LmlzRnJvbUNhbGxBc3luYyxcbiAgICAgIHNldFVzZXJJZDogc2V0VXNlcklkLFxuICAgICAgcmFuZG9tU2VlZCgpIHtcbiAgICAgICAgcmV0dXJuIHJhbmRvbVNlZWRHZW5lcmF0b3IoKTtcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIC8vIE5vdGUgdGhhdCB1bmxpa2UgaW4gdGhlIGNvcnJlc3BvbmRpbmcgc2VydmVyIGNvZGUsIHdlIG5ldmVyIGF1ZGl0XG4gICAgLy8gdGhhdCBzdHVicyBjaGVjaygpIHRoZWlyIGFyZ3VtZW50cy5cbiAgICBjb25zdCBzdHViSW52b2NhdGlvbiA9ICgpID0+IHtcbiAgICAgICAgaWYgKE1ldGVvci5pc1NlcnZlcikge1xuICAgICAgICAgIC8vIEJlY2F1c2Ugc2F2ZU9yaWdpbmFscyBhbmQgcmV0cmlldmVPcmlnaW5hbHMgYXJlbid0IHJlZW50cmFudCxcbiAgICAgICAgICAvLyBkb24ndCBhbGxvdyBzdHVicyB0byB5aWVsZC5cbiAgICAgICAgICByZXR1cm4gTWV0ZW9yLl9ub1lpZWxkc0FsbG93ZWQoKCkgPT4ge1xuICAgICAgICAgICAgLy8gcmUtY2xvbmUsIHNvIHRoYXQgdGhlIHN0dWIgY2FuJ3QgYWZmZWN0IG91ciBjYWxsZXIncyB2YWx1ZXNcbiAgICAgICAgICAgIHJldHVybiBzdHViLmFwcGx5KGludm9jYXRpb24sIEVKU09OLmNsb25lKGFyZ3MpKTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZXR1cm4gc3R1Yi5hcHBseShpbnZvY2F0aW9uLCBFSlNPTi5jbG9uZShhcmdzKSk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIHJldHVybiB7IC4uLmRlZmF1bHRSZXR1cm4sIGhhc1N0dWI6IHRydWUsIHN0dWJJbnZvY2F0aW9uLCBpbnZvY2F0aW9uIH07XG4gIH1cblxuICAvLyBCZWZvcmUgY2FsbGluZyBhIG1ldGhvZCBzdHViLCBwcmVwYXJlIGFsbCBzdG9yZXMgdG8gdHJhY2sgY2hhbmdlcyBhbmQgYWxsb3dcbiAgLy8gX3JldHJpZXZlQW5kU3RvcmVPcmlnaW5hbHMgdG8gZ2V0IHRoZSBvcmlnaW5hbCB2ZXJzaW9ucyBvZiBjaGFuZ2VkXG4gIC8vIGRvY3VtZW50cy5cbiAgX3NhdmVPcmlnaW5hbHMoKSB7XG4gICAgaWYgKCEgdGhpcy5fd2FpdGluZ0ZvclF1aWVzY2VuY2UoKSkge1xuICAgICAgdGhpcy5fZmx1c2hCdWZmZXJlZFdyaXRlc0NsaWVudCgpO1xuICAgIH1cblxuICAgIE9iamVjdC52YWx1ZXModGhpcy5fc3RvcmVzKS5mb3JFYWNoKChzdG9yZSkgPT4ge1xuICAgICAgc3RvcmUuc2F2ZU9yaWdpbmFscygpO1xuICAgIH0pO1xuICB9XG5cbiAgLy8gUmV0cmlldmVzIHRoZSBvcmlnaW5hbCB2ZXJzaW9ucyBvZiBhbGwgZG9jdW1lbnRzIG1vZGlmaWVkIGJ5IHRoZSBzdHViIGZvclxuICAvLyBtZXRob2QgJ21ldGhvZElkJyBmcm9tIGFsbCBzdG9yZXMgYW5kIHNhdmVzIHRoZW0gdG8gX3NlcnZlckRvY3VtZW50cyAoa2V5ZWRcbiAgLy8gYnkgZG9jdW1lbnQpIGFuZCBfZG9jdW1lbnRzV3JpdHRlbkJ5U3R1YiAoa2V5ZWQgYnkgbWV0aG9kIElEKS5cbiAgX3JldHJpZXZlQW5kU3RvcmVPcmlnaW5hbHMobWV0aG9kSWQpIHtcbiAgICBjb25zdCBzZWxmID0gdGhpcztcbiAgICBpZiAoc2VsZi5fZG9jdW1lbnRzV3JpdHRlbkJ5U3R1YlttZXRob2RJZF0pXG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0R1cGxpY2F0ZSBtZXRob2RJZCBpbiBfcmV0cmlldmVBbmRTdG9yZU9yaWdpbmFscycpO1xuXG4gICAgY29uc3QgZG9jc1dyaXR0ZW4gPSBbXTtcblxuICAgIE9iamVjdC5lbnRyaWVzKHNlbGYuX3N0b3JlcykuZm9yRWFjaCgoW2NvbGxlY3Rpb24sIHN0b3JlXSkgPT4ge1xuICAgICAgY29uc3Qgb3JpZ2luYWxzID0gc3RvcmUucmV0cmlldmVPcmlnaW5hbHMoKTtcbiAgICAgIC8vIG5vdCBhbGwgc3RvcmVzIGRlZmluZSByZXRyaWV2ZU9yaWdpbmFsc1xuICAgICAgaWYgKCEgb3JpZ2luYWxzKSByZXR1cm47XG4gICAgICBvcmlnaW5hbHMuZm9yRWFjaCgoZG9jLCBpZCkgPT4ge1xuICAgICAgICBkb2NzV3JpdHRlbi5wdXNoKHsgY29sbGVjdGlvbiwgaWQgfSk7XG4gICAgICAgIGlmICghIGhhc093bi5jYWxsKHNlbGYuX3NlcnZlckRvY3VtZW50cywgY29sbGVjdGlvbikpIHtcbiAgICAgICAgICBzZWxmLl9zZXJ2ZXJEb2N1bWVudHNbY29sbGVjdGlvbl0gPSBuZXcgTW9uZ29JRE1hcCgpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHNlcnZlckRvYyA9IHNlbGYuX3NlcnZlckRvY3VtZW50c1tjb2xsZWN0aW9uXS5zZXREZWZhdWx0KFxuICAgICAgICAgIGlkLFxuICAgICAgICAgIE9iamVjdC5jcmVhdGUobnVsbClcbiAgICAgICAgKTtcbiAgICAgICAgaWYgKHNlcnZlckRvYy53cml0dGVuQnlTdHVicykge1xuICAgICAgICAgIC8vIFdlJ3JlIG5vdCB0aGUgZmlyc3Qgc3R1YiB0byB3cml0ZSB0aGlzIGRvYy4gSnVzdCBhZGQgb3VyIG1ldGhvZCBJRFxuICAgICAgICAgIC8vIHRvIHRoZSByZWNvcmQuXG4gICAgICAgICAgc2VydmVyRG9jLndyaXR0ZW5CeVN0dWJzW21ldGhvZElkXSA9IHRydWU7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgLy8gRmlyc3Qgc3R1YiEgU2F2ZSB0aGUgb3JpZ2luYWwgdmFsdWUgYW5kIG91ciBtZXRob2QgSUQuXG4gICAgICAgICAgc2VydmVyRG9jLmRvY3VtZW50ID0gZG9jO1xuICAgICAgICAgIHNlcnZlckRvYy5mbHVzaENhbGxiYWNrcyA9IFtdO1xuICAgICAgICAgIHNlcnZlckRvYy53cml0dGVuQnlTdHVicyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gICAgICAgICAgc2VydmVyRG9jLndyaXR0ZW5CeVN0dWJzW21ldGhvZElkXSA9IHRydWU7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0pO1xuICAgIGlmICghIGlzRW1wdHkoZG9jc1dyaXR0ZW4pKSB7XG4gICAgICBzZWxmLl9kb2N1bWVudHNXcml0dGVuQnlTdHViW21ldGhvZElkXSA9IGRvY3NXcml0dGVuO1xuICAgIH1cbiAgfVxuXG4gIC8vIFRoaXMgaXMgdmVyeSBtdWNoIGEgcHJpdmF0ZSBmdW5jdGlvbiB3ZSB1c2UgdG8gbWFrZSB0aGUgdGVzdHNcbiAgLy8gdGFrZSB1cCBmZXdlciBzZXJ2ZXIgcmVzb3VyY2VzIGFmdGVyIHRoZXkgY29tcGxldGUuXG4gIF91bnN1YnNjcmliZUFsbCgpIHtcbiAgICBPYmplY3QudmFsdWVzKHRoaXMuX3N1YnNjcmlwdGlvbnMpLmZvckVhY2goKHN1YikgPT4ge1xuICAgICAgLy8gQXZvaWQga2lsbGluZyB0aGUgYXV0b3VwZGF0ZSBzdWJzY3JpcHRpb24gc28gdGhhdCBkZXZlbG9wZXJzXG4gICAgICAvLyBzdGlsbCBnZXQgaG90IGNvZGUgcHVzaGVzIHdoZW4gd3JpdGluZyB0ZXN0cy5cbiAgICAgIC8vXG4gICAgICAvLyBYWFggaXQncyBhIGhhY2sgdG8gZW5jb2RlIGtub3dsZWRnZSBhYm91dCBhdXRvdXBkYXRlIGhlcmUsXG4gICAgICAvLyBidXQgaXQgZG9lc24ndCBzZWVtIHdvcnRoIGl0IHlldCB0byBoYXZlIGEgc3BlY2lhbCBBUEkgZm9yXG4gICAgICAvLyBzdWJzY3JpcHRpb25zIHRvIHByZXNlcnZlIGFmdGVyIHVuaXQgdGVzdHMuXG4gICAgICBpZiAoc3ViLm5hbWUgIT09ICdtZXRlb3JfYXV0b3VwZGF0ZV9jbGllbnRWZXJzaW9ucycpIHtcbiAgICAgICAgc3ViLnN0b3AoKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuXG4gIC8vIFNlbmRzIHRoZSBERFAgc3RyaW5naWZpY2F0aW9uIG9mIHRoZSBnaXZlbiBtZXNzYWdlIG9iamVjdFxuICBfc2VuZChvYmopIHtcbiAgICB0aGlzLl9zdHJlYW0uc2VuZChERFBDb21tb24uc3RyaW5naWZ5RERQKG9iaikpO1xuICB9XG5cbiAgLy8gQWx3YXlzIHF1ZXVlcyB0aGUgY2FsbCBiZWZvcmUgc2VuZGluZyB0aGUgbWVzc2FnZVxuICAvLyBVc2VkLCBmb3IgZXhhbXBsZSwgb24gc3Vic2NyaXB0aW9uLltpZF0uc3RvcCgpIHRvIG1ha2Ugc3VyZSBhIFwic3ViXCIgbWVzc2FnZSBpcyBhbHdheXMgY2FsbGVkIGJlZm9yZSBhbiBcInVuc3ViXCIgbWVzc2FnZVxuICAvLyBodHRwczovL2dpdGh1Yi5jb20vbWV0ZW9yL21ldGVvci9pc3N1ZXMvMTMyMTJcbiAgLy9cbiAgLy8gVGhpcyBpcyBwYXJ0IG9mIHRoZSBhY3R1YWwgZml4IGZvciB0aGUgcmVzdCBjaGVjazpcbiAgLy8gaHR0cHM6Ly9naXRodWIuY29tL21ldGVvci9tZXRlb3IvcHVsbC8xMzIzNlxuICBfc2VuZFF1ZXVlZChvYmopIHtcbiAgICB0aGlzLl9zZW5kKG9iaiwgdHJ1ZSk7XG4gIH1cblxuICAvLyBXZSBkZXRlY3RlZCB2aWEgRERQLWxldmVsIGhlYXJ0YmVhdHMgdGhhdCB3ZSd2ZSBsb3N0IHRoZVxuICAvLyBjb25uZWN0aW9uLiAgVW5saWtlIGBkaXNjb25uZWN0YCBvciBgY2xvc2VgLCBhIGxvc3QgY29ubmVjdGlvblxuICAvLyB3aWxsIGJlIGF1dG9tYXRpY2FsbHkgcmV0cmllZC5cbiAgX2xvc3RDb25uZWN0aW9uKGVycm9yKSB7XG4gICAgdGhpcy5fc3RyZWFtLl9sb3N0Q29ubmVjdGlvbihlcnJvcik7XG4gIH1cblxuICAvKipcbiAgICogQG1lbWJlck9mIE1ldGVvclxuICAgKiBAaW1wb3J0RnJvbVBhY2thZ2UgbWV0ZW9yXG4gICAqIEBhbGlhcyBNZXRlb3Iuc3RhdHVzXG4gICAqIEBzdW1tYXJ5IEdldCB0aGUgY3VycmVudCBjb25uZWN0aW9uIHN0YXR1cy4gQSByZWFjdGl2ZSBkYXRhIHNvdXJjZS5cbiAgICogQGxvY3VzIENsaWVudFxuICAgKi9cbiAgc3RhdHVzKC4uLmFyZ3MpIHtcbiAgICByZXR1cm4gdGhpcy5fc3RyZWFtLnN0YXR1cyguLi5hcmdzKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBAc3VtbWFyeSBGb3JjZSBhbiBpbW1lZGlhdGUgcmVjb25uZWN0aW9uIGF0dGVtcHQgaWYgdGhlIGNsaWVudCBpcyBub3QgY29ubmVjdGVkIHRvIHRoZSBzZXJ2ZXIuXG5cbiAgVGhpcyBtZXRob2QgZG9lcyBub3RoaW5nIGlmIHRoZSBjbGllbnQgaXMgYWxyZWFkeSBjb25uZWN0ZWQuXG4gICAqIEBtZW1iZXJPZiBNZXRlb3JcbiAgICogQGltcG9ydEZyb21QYWNrYWdlIG1ldGVvclxuICAgKiBAYWxpYXMgTWV0ZW9yLnJlY29ubmVjdFxuICAgKiBAbG9jdXMgQ2xpZW50XG4gICAqL1xuICByZWNvbm5lY3QoLi4uYXJncykge1xuICAgIHJldHVybiB0aGlzLl9zdHJlYW0ucmVjb25uZWN0KC4uLmFyZ3MpO1xuICB9XG5cbiAgLyoqXG4gICAqIEBtZW1iZXJPZiBNZXRlb3JcbiAgICogQGltcG9ydEZyb21QYWNrYWdlIG1ldGVvclxuICAgKiBAYWxpYXMgTWV0ZW9yLmRpc2Nvbm5lY3RcbiAgICogQHN1bW1hcnkgRGlzY29ubmVjdCB0aGUgY2xpZW50IGZyb20gdGhlIHNlcnZlci5cbiAgICogQGxvY3VzIENsaWVudFxuICAgKi9cbiAgZGlzY29ubmVjdCguLi5hcmdzKSB7XG4gICAgcmV0dXJuIHRoaXMuX3N0cmVhbS5kaXNjb25uZWN0KC4uLmFyZ3MpO1xuICB9XG5cbiAgY2xvc2UoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3N0cmVhbS5kaXNjb25uZWN0KHsgX3Blcm1hbmVudDogdHJ1ZSB9KTtcbiAgfVxuXG4gIC8vL1xuICAvLy8gUmVhY3RpdmUgdXNlciBzeXN0ZW1cbiAgLy8vXG4gIHVzZXJJZCgpIHtcbiAgICBpZiAodGhpcy5fdXNlcklkRGVwcykgdGhpcy5fdXNlcklkRGVwcy5kZXBlbmQoKTtcbiAgICByZXR1cm4gdGhpcy5fdXNlcklkO1xuICB9XG5cbiAgc2V0VXNlcklkKHVzZXJJZCkge1xuICAgIC8vIEF2b2lkIGludmFsaWRhdGluZyBkZXBlbmRlbnRzIGlmIHNldFVzZXJJZCBpcyBjYWxsZWQgd2l0aCBjdXJyZW50IHZhbHVlLlxuICAgIGlmICh0aGlzLl91c2VySWQgPT09IHVzZXJJZCkgcmV0dXJuO1xuICAgIHRoaXMuX3VzZXJJZCA9IHVzZXJJZDtcbiAgICBpZiAodGhpcy5fdXNlcklkRGVwcykgdGhpcy5fdXNlcklkRGVwcy5jaGFuZ2VkKCk7XG4gIH1cblxuICAvLyBSZXR1cm5zIHRydWUgaWYgd2UgYXJlIGluIGEgc3RhdGUgYWZ0ZXIgcmVjb25uZWN0IG9mIHdhaXRpbmcgZm9yIHN1YnMgdG8gYmVcbiAgLy8gcmV2aXZlZCBvciBlYXJseSBtZXRob2RzIHRvIGZpbmlzaCB0aGVpciBkYXRhLCBvciB3ZSBhcmUgd2FpdGluZyBmb3IgYVxuICAvLyBcIndhaXRcIiBtZXRob2QgdG8gZmluaXNoLlxuICBfd2FpdGluZ0ZvclF1aWVzY2VuY2UoKSB7XG4gICAgcmV0dXJuIChcbiAgICAgICEgaXNFbXB0eSh0aGlzLl9zdWJzQmVpbmdSZXZpdmVkKSB8fFxuICAgICAgISBpc0VtcHR5KHRoaXMuX21ldGhvZHNCbG9ja2luZ1F1aWVzY2VuY2UpXG4gICAgKTtcbiAgfVxuXG4gIC8vIFJldHVybnMgdHJ1ZSBpZiBhbnkgbWV0aG9kIHdob3NlIG1lc3NhZ2UgaGFzIGJlZW4gc2VudCB0byB0aGUgc2VydmVyIGhhc1xuICAvLyBub3QgeWV0IGludm9rZWQgaXRzIHVzZXIgY2FsbGJhY2suXG4gIF9hbnlNZXRob2RzQXJlT3V0c3RhbmRpbmcoKSB7XG4gICAgY29uc3QgaW52b2tlcnMgPSB0aGlzLl9tZXRob2RJbnZva2VycztcbiAgICByZXR1cm4gT2JqZWN0LnZhbHVlcyhpbnZva2Vycykuc29tZSgoaW52b2tlcikgPT4gISFpbnZva2VyLnNlbnRNZXNzYWdlKTtcbiAgfVxuXG4gIGFzeW5jIF9saXZlZGF0YV9jb25uZWN0ZWQobXNnKSB7XG4gICAgY29uc3Qgc2VsZiA9IHRoaXM7XG5cbiAgICBpZiAoc2VsZi5fdmVyc2lvbiAhPT0gJ3ByZTEnICYmIHNlbGYuX2hlYXJ0YmVhdEludGVydmFsICE9PSAwKSB7XG4gICAgICBzZWxmLl9oZWFydGJlYXQgPSBuZXcgRERQQ29tbW9uLkhlYXJ0YmVhdCh7XG4gICAgICAgIGhlYXJ0YmVhdEludGVydmFsOiBzZWxmLl9oZWFydGJlYXRJbnRlcnZhbCxcbiAgICAgICAgaGVhcnRiZWF0VGltZW91dDogc2VsZi5faGVhcnRiZWF0VGltZW91dCxcbiAgICAgICAgb25UaW1lb3V0KCkge1xuICAgICAgICAgIHNlbGYuX2xvc3RDb25uZWN0aW9uKFxuICAgICAgICAgICAgbmV3IEREUC5Db25uZWN0aW9uRXJyb3IoJ0REUCBoZWFydGJlYXQgdGltZWQgb3V0JylcbiAgICAgICAgICApO1xuICAgICAgICB9LFxuICAgICAgICBzZW5kUGluZygpIHtcbiAgICAgICAgICBzZWxmLl9zZW5kKHsgbXNnOiAncGluZycgfSk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgICAgc2VsZi5faGVhcnRiZWF0LnN0YXJ0KCk7XG4gICAgfVxuXG4gICAgLy8gSWYgdGhpcyBpcyBhIHJlY29ubmVjdCwgd2UnbGwgaGF2ZSB0byByZXNldCBhbGwgc3RvcmVzLlxuICAgIGlmIChzZWxmLl9sYXN0U2Vzc2lvbklkKSBzZWxmLl9yZXNldFN0b3JlcyA9IHRydWU7XG5cbiAgICBsZXQgcmVjb25uZWN0ZWRUb1ByZXZpb3VzU2Vzc2lvbjtcbiAgICBpZiAodHlwZW9mIG1zZy5zZXNzaW9uID09PSAnc3RyaW5nJykge1xuICAgICAgcmVjb25uZWN0ZWRUb1ByZXZpb3VzU2Vzc2lvbiA9IHNlbGYuX2xhc3RTZXNzaW9uSWQgPT09IG1zZy5zZXNzaW9uO1xuICAgICAgc2VsZi5fbGFzdFNlc3Npb25JZCA9IG1zZy5zZXNzaW9uO1xuICAgIH1cblxuICAgIGlmIChyZWNvbm5lY3RlZFRvUHJldmlvdXNTZXNzaW9uKSB7XG4gICAgICAvLyBTdWNjZXNzZnVsIHJlY29ubmVjdGlvbiAtLSBwaWNrIHVwIHdoZXJlIHdlIGxlZnQgb2ZmLiAgTm90ZSB0aGF0IHJpZ2h0XG4gICAgICAvLyBub3csIHRoaXMgbmV2ZXIgaGFwcGVuczogdGhlIHNlcnZlciBuZXZlciBjb25uZWN0cyB1cyB0byBhIHByZXZpb3VzXG4gICAgICAvLyBzZXNzaW9uLCBiZWNhdXNlIEREUCBkb2Vzbid0IHByb3ZpZGUgZW5vdWdoIGRhdGEgZm9yIHRoZSBzZXJ2ZXIgdG8ga25vd1xuICAgICAgLy8gd2hhdCBtZXNzYWdlcyB0aGUgY2xpZW50IGhhcyBwcm9jZXNzZWQuIFdlIG5lZWQgdG8gaW1wcm92ZSBERFAgdG8gbWFrZVxuICAgICAgLy8gdGhpcyBwb3NzaWJsZSwgYXQgd2hpY2ggcG9pbnQgd2UnbGwgcHJvYmFibHkgbmVlZCBtb3JlIGNvZGUgaGVyZS5cbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICAvLyBTZXJ2ZXIgZG9lc24ndCBoYXZlIG91ciBkYXRhIGFueSBtb3JlLiBSZS1zeW5jIGEgbmV3IHNlc3Npb24uXG5cbiAgICAvLyBGb3JnZXQgYWJvdXQgbWVzc2FnZXMgd2Ugd2VyZSBidWZmZXJpbmcgZm9yIHVua25vd24gY29sbGVjdGlvbnMuIFRoZXknbGxcbiAgICAvLyBiZSByZXNlbnQgaWYgc3RpbGwgcmVsZXZhbnQuXG4gICAgc2VsZi5fdXBkYXRlc0ZvclVua25vd25TdG9yZXMgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuXG4gICAgaWYgKHNlbGYuX3Jlc2V0U3RvcmVzKSB7XG4gICAgICAvLyBGb3JnZXQgYWJvdXQgdGhlIGVmZmVjdHMgb2Ygc3R1YnMuIFdlJ2xsIGJlIHJlc2V0dGluZyBhbGwgY29sbGVjdGlvbnNcbiAgICAgIC8vIGFueXdheS5cbiAgICAgIHNlbGYuX2RvY3VtZW50c1dyaXR0ZW5CeVN0dWIgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuICAgICAgc2VsZi5fc2VydmVyRG9jdW1lbnRzID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgICB9XG5cbiAgICAvLyBDbGVhciBfYWZ0ZXJVcGRhdGVDYWxsYmFja3MuXG4gICAgc2VsZi5fYWZ0ZXJVcGRhdGVDYWxsYmFja3MgPSBbXTtcblxuICAgIC8vIE1hcmsgYWxsIG5hbWVkIHN1YnNjcmlwdGlvbnMgd2hpY2ggYXJlIHJlYWR5IChpZSwgd2UgYWxyZWFkeSBjYWxsZWQgdGhlXG4gICAgLy8gcmVhZHkgY2FsbGJhY2spIGFzIG5lZWRpbmcgdG8gYmUgcmV2aXZlZC5cbiAgICAvLyBYWFggV2Ugc2hvdWxkIGFsc28gYmxvY2sgcmVjb25uZWN0IHF1aWVzY2VuY2UgdW50aWwgdW5uYW1lZCBzdWJzY3JpcHRpb25zXG4gICAgLy8gICAgIChlZywgYXV0b3B1Ymxpc2gpIGFyZSBkb25lIHJlLXB1Ymxpc2hpbmcgdG8gYXZvaWQgZmxpY2tlciFcbiAgICBzZWxmLl9zdWJzQmVpbmdSZXZpdmVkID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgICBPYmplY3QuZW50cmllcyhzZWxmLl9zdWJzY3JpcHRpb25zKS5mb3JFYWNoKChbaWQsIHN1Yl0pID0+IHtcbiAgICAgIGlmIChzdWIucmVhZHkpIHtcbiAgICAgICAgc2VsZi5fc3Vic0JlaW5nUmV2aXZlZFtpZF0gPSB0cnVlO1xuICAgICAgfVxuICAgIH0pO1xuXG4gICAgLy8gQXJyYW5nZSBmb3IgXCJoYWxmLWZpbmlzaGVkXCIgbWV0aG9kcyB0byBoYXZlIHRoZWlyIGNhbGxiYWNrcyBydW4sIGFuZFxuICAgIC8vIHRyYWNrIG1ldGhvZHMgdGhhdCB3ZXJlIHNlbnQgb24gdGhpcyBjb25uZWN0aW9uIHNvIHRoYXQgd2UgZG9uJ3RcbiAgICAvLyBxdWllc2NlIHVudGlsIHRoZXkgYXJlIGFsbCBkb25lLlxuICAgIC8vXG4gICAgLy8gU3RhcnQgYnkgY2xlYXJpbmcgX21ldGhvZHNCbG9ja2luZ1F1aWVzY2VuY2U6IG1ldGhvZHMgc2VudCBiZWZvcmVcbiAgICAvLyByZWNvbm5lY3QgZG9uJ3QgbWF0dGVyLCBhbmQgYW55IFwid2FpdFwiIG1ldGhvZHMgc2VudCBvbiB0aGUgbmV3IGNvbm5lY3Rpb25cbiAgICAvLyB0aGF0IHdlIGRyb3AgaGVyZSB3aWxsIGJlIHJlc3RvcmVkIGJ5IHRoZSBsb29wIGJlbG93LlxuICAgIHNlbGYuX21ldGhvZHNCbG9ja2luZ1F1aWVzY2VuY2UgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuICAgIGlmIChzZWxmLl9yZXNldFN0b3Jlcykge1xuICAgICAgY29uc3QgaW52b2tlcnMgPSBzZWxmLl9tZXRob2RJbnZva2VycztcbiAgICAgIGtleXMoaW52b2tlcnMpLmZvckVhY2goaWQgPT4ge1xuICAgICAgICBjb25zdCBpbnZva2VyID0gaW52b2tlcnNbaWRdO1xuICAgICAgICBpZiAoaW52b2tlci5nb3RSZXN1bHQoKSkge1xuICAgICAgICAgIC8vIFRoaXMgbWV0aG9kIGFscmVhZHkgZ290IGl0cyByZXN1bHQsIGJ1dCBpdCBkaWRuJ3QgY2FsbCBpdHMgY2FsbGJhY2tcbiAgICAgICAgICAvLyBiZWNhdXNlIGl0cyBkYXRhIGRpZG4ndCBiZWNvbWUgdmlzaWJsZS4gV2UgZGlkIG5vdCByZXNlbmQgdGhlXG4gICAgICAgICAgLy8gbWV0aG9kIFJQQy4gV2UnbGwgY2FsbCBpdHMgY2FsbGJhY2sgd2hlbiB3ZSBnZXQgYSBmdWxsIHF1aWVzY2UsXG4gICAgICAgICAgLy8gc2luY2UgdGhhdCdzIGFzIGNsb3NlIGFzIHdlJ2xsIGdldCB0byBcImRhdGEgbXVzdCBiZSB2aXNpYmxlXCIuXG4gICAgICAgICAgc2VsZi5fYWZ0ZXJVcGRhdGVDYWxsYmFja3MucHVzaChcbiAgICAgICAgICAgICguLi5hcmdzKSA9PiBpbnZva2VyLmRhdGFWaXNpYmxlKC4uLmFyZ3MpXG4gICAgICAgICAgKTtcbiAgICAgICAgfSBlbHNlIGlmIChpbnZva2VyLnNlbnRNZXNzYWdlKSB7XG4gICAgICAgICAgLy8gVGhpcyBtZXRob2QgaGFzIGJlZW4gc2VudCBvbiB0aGlzIGNvbm5lY3Rpb24gKG1heWJlIGFzIGEgcmVzZW5kXG4gICAgICAgICAgLy8gZnJvbSB0aGUgbGFzdCBjb25uZWN0aW9uLCBtYXliZSBmcm9tIG9uUmVjb25uZWN0LCBtYXliZSBqdXN0IHZlcnlcbiAgICAgICAgICAvLyBxdWlja2x5IGJlZm9yZSBwcm9jZXNzaW5nIHRoZSBjb25uZWN0ZWQgbWVzc2FnZSkuXG4gICAgICAgICAgLy9cbiAgICAgICAgICAvLyBXZSBkb24ndCBuZWVkIHRvIGRvIGFueXRoaW5nIHNwZWNpYWwgdG8gZW5zdXJlIGl0cyBjYWxsYmFja3MgZ2V0XG4gICAgICAgICAgLy8gY2FsbGVkLCBidXQgd2UnbGwgY291bnQgaXQgYXMgYSBtZXRob2Qgd2hpY2ggaXMgcHJldmVudGluZ1xuICAgICAgICAgIC8vIHJlY29ubmVjdCBxdWllc2NlbmNlLiAoZWcsIGl0IG1pZ2h0IGJlIGEgbG9naW4gbWV0aG9kIHRoYXQgd2FzIHJ1blxuICAgICAgICAgIC8vIGZyb20gb25SZWNvbm5lY3QsIGFuZCB3ZSBkb24ndCB3YW50IHRvIHNlZSBmbGlja2VyIGJ5IHNlZWluZyBhXG4gICAgICAgICAgLy8gbG9nZ2VkLW91dCBzdGF0ZS4pXG4gICAgICAgICAgc2VsZi5fbWV0aG9kc0Jsb2NraW5nUXVpZXNjZW5jZVtpbnZva2VyLm1ldGhvZElkXSA9IHRydWU7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH1cblxuICAgIHNlbGYuX21lc3NhZ2VzQnVmZmVyZWRVbnRpbFF1aWVzY2VuY2UgPSBbXTtcblxuICAgIC8vIElmIHdlJ3JlIG5vdCB3YWl0aW5nIG9uIGFueSBtZXRob2RzIG9yIHN1YnMsIHdlIGNhbiByZXNldCB0aGUgc3RvcmVzIGFuZFxuICAgIC8vIGNhbGwgdGhlIGNhbGxiYWNrcyBpbW1lZGlhdGVseS5cbiAgICBpZiAoISBzZWxmLl93YWl0aW5nRm9yUXVpZXNjZW5jZSgpKSB7XG4gICAgICBpZiAoc2VsZi5fcmVzZXRTdG9yZXMpIHtcbiAgICAgICAgZm9yIChjb25zdCBzdG9yZSBvZiBPYmplY3QudmFsdWVzKHNlbGYuX3N0b3JlcykpIHtcbiAgICAgICAgICBhd2FpdCBzdG9yZS5iZWdpblVwZGF0ZSgwLCB0cnVlKTtcbiAgICAgICAgICBhd2FpdCBzdG9yZS5lbmRVcGRhdGUoKTtcbiAgICAgICAgfVxuICAgICAgICBzZWxmLl9yZXNldFN0b3JlcyA9IGZhbHNlO1xuICAgICAgfVxuICAgICAgc2VsZi5fcnVuQWZ0ZXJVcGRhdGVDYWxsYmFja3MoKTtcbiAgICB9XG4gIH1cblxuICBhc3luYyBfcHJvY2Vzc09uZURhdGFNZXNzYWdlKG1zZywgdXBkYXRlcykge1xuICAgIGNvbnN0IG1lc3NhZ2VUeXBlID0gbXNnLm1zZztcblxuICAgIC8vIG1zZyBpcyBvbmUgb2YgWydhZGRlZCcsICdjaGFuZ2VkJywgJ3JlbW92ZWQnLCAncmVhZHknLCAndXBkYXRlZCddXG4gICAgaWYgKG1lc3NhZ2VUeXBlID09PSAnYWRkZWQnKSB7XG4gICAgICBhd2FpdCB0aGlzLl9wcm9jZXNzX2FkZGVkKG1zZywgdXBkYXRlcyk7XG4gICAgfSBlbHNlIGlmIChtZXNzYWdlVHlwZSA9PT0gJ2NoYW5nZWQnKSB7XG4gICAgICB0aGlzLl9wcm9jZXNzX2NoYW5nZWQobXNnLCB1cGRhdGVzKTtcbiAgICB9IGVsc2UgaWYgKG1lc3NhZ2VUeXBlID09PSAncmVtb3ZlZCcpIHtcbiAgICAgIHRoaXMuX3Byb2Nlc3NfcmVtb3ZlZChtc2csIHVwZGF0ZXMpO1xuICAgIH0gZWxzZSBpZiAobWVzc2FnZVR5cGUgPT09ICdyZWFkeScpIHtcbiAgICAgIHRoaXMuX3Byb2Nlc3NfcmVhZHkobXNnLCB1cGRhdGVzKTtcbiAgICB9IGVsc2UgaWYgKG1lc3NhZ2VUeXBlID09PSAndXBkYXRlZCcpIHtcbiAgICAgIHRoaXMuX3Byb2Nlc3NfdXBkYXRlZChtc2csIHVwZGF0ZXMpO1xuICAgIH0gZWxzZSBpZiAobWVzc2FnZVR5cGUgPT09ICdub3N1YicpIHtcbiAgICAgIC8vIGlnbm9yZSB0aGlzXG4gICAgfSBlbHNlIHtcbiAgICAgIE1ldGVvci5fZGVidWcoJ2Rpc2NhcmRpbmcgdW5rbm93biBsaXZlZGF0YSBkYXRhIG1lc3NhZ2UgdHlwZScsIG1zZyk7XG4gICAgfVxuICB9XG5cbiAgYXN5bmMgX2xpdmVkYXRhX2RhdGEobXNnKSB7XG4gICAgY29uc3Qgc2VsZiA9IHRoaXM7XG5cbiAgICBpZiAoc2VsZi5fd2FpdGluZ0ZvclF1aWVzY2VuY2UoKSkge1xuICAgICAgc2VsZi5fbWVzc2FnZXNCdWZmZXJlZFVudGlsUXVpZXNjZW5jZS5wdXNoKG1zZyk7XG5cbiAgICAgIGlmIChtc2cubXNnID09PSAnbm9zdWInKSB7XG4gICAgICAgIGRlbGV0ZSBzZWxmLl9zdWJzQmVpbmdSZXZpdmVkW21zZy5pZF07XG4gICAgICB9XG5cbiAgICAgIGlmIChtc2cuc3Vicykge1xuICAgICAgICBtc2cuc3Vicy5mb3JFYWNoKHN1YklkID0+IHtcbiAgICAgICAgICBkZWxldGUgc2VsZi5fc3Vic0JlaW5nUmV2aXZlZFtzdWJJZF07XG4gICAgICAgIH0pO1xuICAgICAgfVxuXG4gICAgICBpZiAobXNnLm1ldGhvZHMpIHtcbiAgICAgICAgbXNnLm1ldGhvZHMuZm9yRWFjaChtZXRob2RJZCA9PiB7XG4gICAgICAgICAgZGVsZXRlIHNlbGYuX21ldGhvZHNCbG9ja2luZ1F1aWVzY2VuY2VbbWV0aG9kSWRdO1xuICAgICAgICB9KTtcbiAgICAgIH1cblxuICAgICAgaWYgKHNlbGYuX3dhaXRpbmdGb3JRdWllc2NlbmNlKCkpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICAvLyBObyBtZXRob2RzIG9yIHN1YnMgYXJlIGJsb2NraW5nIHF1aWVzY2VuY2UhXG4gICAgICAvLyBXZSdsbCBub3cgcHJvY2VzcyBhbmQgYWxsIG9mIG91ciBidWZmZXJlZCBtZXNzYWdlcywgcmVzZXQgYWxsIHN0b3JlcyxcbiAgICAgIC8vIGFuZCBhcHBseSB0aGVtIGFsbCBhdCBvbmNlLlxuXG4gICAgICBjb25zdCBidWZmZXJlZE1lc3NhZ2VzID0gc2VsZi5fbWVzc2FnZXNCdWZmZXJlZFVudGlsUXVpZXNjZW5jZTtcbiAgICAgIGZvciAoY29uc3QgYnVmZmVyZWRNZXNzYWdlIG9mIE9iamVjdC52YWx1ZXMoYnVmZmVyZWRNZXNzYWdlcykpIHtcbiAgICAgICAgYXdhaXQgc2VsZi5fcHJvY2Vzc09uZURhdGFNZXNzYWdlKFxuICAgICAgICAgIGJ1ZmZlcmVkTWVzc2FnZSxcbiAgICAgICAgICBzZWxmLl9idWZmZXJlZFdyaXRlc1xuICAgICAgICApO1xuICAgICAgfVxuXG4gICAgICBzZWxmLl9tZXNzYWdlc0J1ZmZlcmVkVW50aWxRdWllc2NlbmNlID0gW107XG5cbiAgICB9IGVsc2Uge1xuICAgICAgYXdhaXQgc2VsZi5fcHJvY2Vzc09uZURhdGFNZXNzYWdlKG1zZywgc2VsZi5fYnVmZmVyZWRXcml0ZXMpO1xuICAgIH1cblxuICAgIC8vIEltbWVkaWF0ZWx5IGZsdXNoIHdyaXRlcyB3aGVuOlxuICAgIC8vICAxLiBCdWZmZXJpbmcgaXMgZGlzYWJsZWQuIE9yO1xuICAgIC8vICAyLiBhbnkgbm9uLShhZGRlZC9jaGFuZ2VkL3JlbW92ZWQpIG1lc3NhZ2UgYXJyaXZlcy5cbiAgICBjb25zdCBzdGFuZGFyZFdyaXRlID1cbiAgICAgIG1zZy5tc2cgPT09IFwiYWRkZWRcIiB8fFxuICAgICAgbXNnLm1zZyA9PT0gXCJjaGFuZ2VkXCIgfHxcbiAgICAgIG1zZy5tc2cgPT09IFwicmVtb3ZlZFwiO1xuXG4gICAgaWYgKHNlbGYuX2J1ZmZlcmVkV3JpdGVzSW50ZXJ2YWwgPT09IDAgfHwgISBzdGFuZGFyZFdyaXRlKSB7XG4gICAgICBhd2FpdCBzZWxmLl9mbHVzaEJ1ZmZlcmVkV3JpdGVzKCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgaWYgKHNlbGYuX2J1ZmZlcmVkV3JpdGVzRmx1c2hBdCA9PT0gbnVsbCkge1xuICAgICAgc2VsZi5fYnVmZmVyZWRXcml0ZXNGbHVzaEF0ID1cbiAgICAgICAgbmV3IERhdGUoKS52YWx1ZU9mKCkgKyBzZWxmLl9idWZmZXJlZFdyaXRlc01heEFnZTtcbiAgICB9IGVsc2UgaWYgKHNlbGYuX2J1ZmZlcmVkV3JpdGVzRmx1c2hBdCA8IG5ldyBEYXRlKCkudmFsdWVPZigpKSB7XG4gICAgICBhd2FpdCBzZWxmLl9mbHVzaEJ1ZmZlcmVkV3JpdGVzKCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgaWYgKHNlbGYuX2J1ZmZlcmVkV3JpdGVzRmx1c2hIYW5kbGUpIHtcbiAgICAgIGNsZWFyVGltZW91dChzZWxmLl9idWZmZXJlZFdyaXRlc0ZsdXNoSGFuZGxlKTtcbiAgICB9XG4gICAgc2VsZi5fYnVmZmVyZWRXcml0ZXNGbHVzaEhhbmRsZSA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgLy8gX19mbHVzaEJ1ZmZlcmVkV3JpdGVzIGlzIGEgcHJvbWlzZSwgc28gd2l0aCB0aGlzIHdlIGNhbiB3YWl0IHRoZSBwcm9taXNlIHRvIGZpbmlzaFxuICAgICAgLy8gYmVmb3JlIGRvaW5nIHNvbWV0aGluZ1xuICAgICAgc2VsZi5fbGl2ZURhdGFXcml0ZXNQcm9taXNlID0gc2VsZi5fX2ZsdXNoQnVmZmVyZWRXcml0ZXMoKTtcblxuICAgICAgaWYgKE1ldGVvci5faXNQcm9taXNlKHNlbGYuX2xpdmVEYXRhV3JpdGVzUHJvbWlzZSkpIHtcbiAgICAgICAgc2VsZi5fbGl2ZURhdGFXcml0ZXNQcm9taXNlLmZpbmFsbHkoXG4gICAgICAgICAgKCkgPT4gKHNlbGYuX2xpdmVEYXRhV3JpdGVzUHJvbWlzZSA9IHVuZGVmaW5lZClcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9LCBzZWxmLl9idWZmZXJlZFdyaXRlc0ludGVydmFsKTtcbiAgfVxuXG4gIF9wcmVwYXJlQnVmZmVyc1RvRmx1c2goKSB7XG4gICAgY29uc3Qgc2VsZiA9IHRoaXM7XG4gICAgaWYgKHNlbGYuX2J1ZmZlcmVkV3JpdGVzRmx1c2hIYW5kbGUpIHtcbiAgICAgIGNsZWFyVGltZW91dChzZWxmLl9idWZmZXJlZFdyaXRlc0ZsdXNoSGFuZGxlKTtcbiAgICAgIHNlbGYuX2J1ZmZlcmVkV3JpdGVzRmx1c2hIYW5kbGUgPSBudWxsO1xuICAgIH1cblxuICAgIHNlbGYuX2J1ZmZlcmVkV3JpdGVzRmx1c2hBdCA9IG51bGw7XG4gICAgLy8gV2UgbmVlZCB0byBjbGVhciB0aGUgYnVmZmVyIGJlZm9yZSBwYXNzaW5nIGl0IHRvXG4gICAgLy8gIHBlcmZvcm1Xcml0ZXMuIEFzIHRoZXJlJ3Mgbm8gZ3VhcmFudGVlIHRoYXQgaXRcbiAgICAvLyAgd2lsbCBleGl0IGNsZWFubHkuXG4gICAgY29uc3Qgd3JpdGVzID0gc2VsZi5fYnVmZmVyZWRXcml0ZXM7XG4gICAgc2VsZi5fYnVmZmVyZWRXcml0ZXMgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuICAgIHJldHVybiB3cml0ZXM7XG4gIH1cblxuICBhc3luYyBfZmx1c2hCdWZmZXJlZFdyaXRlc1NlcnZlcigpIHtcbiAgICBjb25zdCBzZWxmID0gdGhpcztcbiAgICBjb25zdCB3cml0ZXMgPSBzZWxmLl9wcmVwYXJlQnVmZmVyc1RvRmx1c2goKTtcbiAgICBhd2FpdCBzZWxmLl9wZXJmb3JtV3JpdGVzU2VydmVyKHdyaXRlcyk7XG4gIH1cbiAgX2ZsdXNoQnVmZmVyZWRXcml0ZXNDbGllbnQoKSB7XG4gICAgY29uc3Qgc2VsZiA9IHRoaXM7XG4gICAgY29uc3Qgd3JpdGVzID0gc2VsZi5fcHJlcGFyZUJ1ZmZlcnNUb0ZsdXNoKCk7XG4gICAgc2VsZi5fcGVyZm9ybVdyaXRlc0NsaWVudCh3cml0ZXMpO1xuICB9XG4gIF9mbHVzaEJ1ZmZlcmVkV3JpdGVzKCkge1xuICAgIGNvbnN0IHNlbGYgPSB0aGlzO1xuICAgIHJldHVybiBNZXRlb3IuaXNDbGllbnRcbiAgICAgID8gc2VsZi5fZmx1c2hCdWZmZXJlZFdyaXRlc0NsaWVudCgpXG4gICAgICA6IHNlbGYuX2ZsdXNoQnVmZmVyZWRXcml0ZXNTZXJ2ZXIoKTtcbiAgfVxuICBhc3luYyBfcGVyZm9ybVdyaXRlc1NlcnZlcih1cGRhdGVzKSB7XG4gICAgY29uc3Qgc2VsZiA9IHRoaXM7XG5cbiAgICBpZiAoc2VsZi5fcmVzZXRTdG9yZXMgfHwgISBpc0VtcHR5KHVwZGF0ZXMpKSB7XG4gICAgICAvLyBCZWdpbiBhIHRyYW5zYWN0aW9uYWwgdXBkYXRlIG9mIGVhY2ggc3RvcmUuXG5cbiAgICAgIGZvciAoY29uc3QgW3N0b3JlTmFtZSwgc3RvcmVdIG9mIE9iamVjdC5lbnRyaWVzKHNlbGYuX3N0b3JlcykpIHtcbiAgICAgICAgYXdhaXQgc3RvcmUuYmVnaW5VcGRhdGUoXG4gICAgICAgICAgaGFzT3duLmNhbGwodXBkYXRlcywgc3RvcmVOYW1lKVxuICAgICAgICAgICAgPyB1cGRhdGVzW3N0b3JlTmFtZV0ubGVuZ3RoXG4gICAgICAgICAgICA6IDAsXG4gICAgICAgICAgc2VsZi5fcmVzZXRTdG9yZXNcbiAgICAgICAgKTtcbiAgICAgIH1cblxuICAgICAgc2VsZi5fcmVzZXRTdG9yZXMgPSBmYWxzZTtcblxuICAgICAgZm9yIChjb25zdCBbc3RvcmVOYW1lLCB1cGRhdGVNZXNzYWdlc10gb2YgT2JqZWN0LmVudHJpZXModXBkYXRlcykpIHtcbiAgICAgICAgY29uc3Qgc3RvcmUgPSBzZWxmLl9zdG9yZXNbc3RvcmVOYW1lXTtcbiAgICAgICAgaWYgKHN0b3JlKSB7XG4gICAgICAgICAgZm9yIChjb25zdCB1cGRhdGVNZXNzYWdlIG9mIHVwZGF0ZU1lc3NhZ2VzKSB7XG4gICAgICAgICAgICBhd2FpdCBzdG9yZS51cGRhdGUodXBkYXRlTWVzc2FnZSk7XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIC8vIE5vYm9keSdzIGxpc3RlbmluZyBmb3IgdGhpcyBkYXRhLiBRdWV1ZSBpdCB1cCB1bnRpbFxuICAgICAgICAgIC8vIHNvbWVvbmUgd2FudHMgaXQuXG4gICAgICAgICAgLy8gWFhYIG1lbW9yeSB1c2Ugd2lsbCBncm93IHdpdGhvdXQgYm91bmQgaWYgeW91IGZvcmdldCB0b1xuICAgICAgICAgIC8vIGNyZWF0ZSBhIGNvbGxlY3Rpb24gb3IganVzdCBkb24ndCBjYXJlIGFib3V0IGl0Li4uIGdvaW5nXG4gICAgICAgICAgLy8gdG8gaGF2ZSB0byBkbyBzb21ldGhpbmcgYWJvdXQgdGhhdC5cbiAgICAgICAgICBjb25zdCB1cGRhdGVzID0gc2VsZi5fdXBkYXRlc0ZvclVua25vd25TdG9yZXM7XG5cbiAgICAgICAgICBpZiAoISBoYXNPd24uY2FsbCh1cGRhdGVzLCBzdG9yZU5hbWUpKSB7XG4gICAgICAgICAgICB1cGRhdGVzW3N0b3JlTmFtZV0gPSBbXTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICB1cGRhdGVzW3N0b3JlTmFtZV0ucHVzaCguLi51cGRhdGVNZXNzYWdlcyk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIC8vIEVuZCB1cGRhdGUgdHJhbnNhY3Rpb24uXG4gICAgICBmb3IgKGNvbnN0IHN0b3JlIG9mIE9iamVjdC52YWx1ZXMoc2VsZi5fc3RvcmVzKSkge1xuICAgICAgICBhd2FpdCBzdG9yZS5lbmRVcGRhdGUoKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBzZWxmLl9ydW5BZnRlclVwZGF0ZUNhbGxiYWNrcygpO1xuICB9XG4gIF9wZXJmb3JtV3JpdGVzQ2xpZW50KHVwZGF0ZXMpIHtcbiAgICBjb25zdCBzZWxmID0gdGhpcztcblxuICAgIGlmIChzZWxmLl9yZXNldFN0b3JlcyB8fCAhIGlzRW1wdHkodXBkYXRlcykpIHtcbiAgICAgIC8vIEJlZ2luIGEgdHJhbnNhY3Rpb25hbCB1cGRhdGUgb2YgZWFjaCBzdG9yZS5cblxuICAgICAgZm9yIChjb25zdCBbc3RvcmVOYW1lLCBzdG9yZV0gb2YgT2JqZWN0LmVudHJpZXMoc2VsZi5fc3RvcmVzKSkge1xuICAgICAgICBzdG9yZS5iZWdpblVwZGF0ZShcbiAgICAgICAgICBoYXNPd24uY2FsbCh1cGRhdGVzLCBzdG9yZU5hbWUpXG4gICAgICAgICAgICA/IHVwZGF0ZXNbc3RvcmVOYW1lXS5sZW5ndGhcbiAgICAgICAgICAgIDogMCxcbiAgICAgICAgICBzZWxmLl9yZXNldFN0b3Jlc1xuICAgICAgICApO1xuICAgICAgfVxuXG4gICAgICBzZWxmLl9yZXNldFN0b3JlcyA9IGZhbHNlO1xuXG4gICAgICBmb3IgKGNvbnN0IFtzdG9yZU5hbWUsIHVwZGF0ZU1lc3NhZ2VzXSBvZiBPYmplY3QuZW50cmllcyh1cGRhdGVzKSkge1xuICAgICAgICBjb25zdCBzdG9yZSA9IHNlbGYuX3N0b3Jlc1tzdG9yZU5hbWVdO1xuICAgICAgICBpZiAoc3RvcmUpIHtcbiAgICAgICAgICBmb3IgKGNvbnN0IHVwZGF0ZU1lc3NhZ2Ugb2YgdXBkYXRlTWVzc2FnZXMpIHtcbiAgICAgICAgICAgIHN0b3JlLnVwZGF0ZSh1cGRhdGVNZXNzYWdlKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgLy8gTm9ib2R5J3MgbGlzdGVuaW5nIGZvciB0aGlzIGRhdGEuIFF1ZXVlIGl0IHVwIHVudGlsXG4gICAgICAgICAgLy8gc29tZW9uZSB3YW50cyBpdC5cbiAgICAgICAgICAvLyBYWFggbWVtb3J5IHVzZSB3aWxsIGdyb3cgd2l0aG91dCBib3VuZCBpZiB5b3UgZm9yZ2V0IHRvXG4gICAgICAgICAgLy8gY3JlYXRlIGEgY29sbGVjdGlvbiBvciBqdXN0IGRvbid0IGNhcmUgYWJvdXQgaXQuLi4gZ29pbmdcbiAgICAgICAgICAvLyB0byBoYXZlIHRvIGRvIHNvbWV0aGluZyBhYm91dCB0aGF0LlxuICAgICAgICAgIGNvbnN0IHVwZGF0ZXMgPSBzZWxmLl91cGRhdGVzRm9yVW5rbm93blN0b3JlcztcblxuICAgICAgICAgIGlmICghIGhhc093bi5jYWxsKHVwZGF0ZXMsIHN0b3JlTmFtZSkpIHtcbiAgICAgICAgICAgIHVwZGF0ZXNbc3RvcmVOYW1lXSA9IFtdO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIHVwZGF0ZXNbc3RvcmVOYW1lXS5wdXNoKC4uLnVwZGF0ZU1lc3NhZ2VzKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgLy8gRW5kIHVwZGF0ZSB0cmFuc2FjdGlvbi5cbiAgICAgIGZvciAoY29uc3Qgc3RvcmUgb2YgT2JqZWN0LnZhbHVlcyhzZWxmLl9zdG9yZXMpKSB7XG4gICAgICAgIHN0b3JlLmVuZFVwZGF0ZSgpO1xuICAgICAgfVxuICAgIH1cblxuICAgIHNlbGYuX3J1bkFmdGVyVXBkYXRlQ2FsbGJhY2tzKCk7XG4gIH1cblxuICAvLyBDYWxsIGFueSBjYWxsYmFja3MgZGVmZXJyZWQgd2l0aCBfcnVuV2hlbkFsbFNlcnZlckRvY3NBcmVGbHVzaGVkIHdob3NlXG4gIC8vIHJlbGV2YW50IGRvY3MgaGF2ZSBiZWVuIGZsdXNoZWQsIGFzIHdlbGwgYXMgZGF0YVZpc2libGUgY2FsbGJhY2tzIGF0XG4gIC8vIHJlY29ubmVjdC1xdWllc2NlbmNlIHRpbWUuXG4gIF9ydW5BZnRlclVwZGF0ZUNhbGxiYWNrcygpIHtcbiAgICBjb25zdCBzZWxmID0gdGhpcztcbiAgICBjb25zdCBjYWxsYmFja3MgPSBzZWxmLl9hZnRlclVwZGF0ZUNhbGxiYWNrcztcbiAgICBzZWxmLl9hZnRlclVwZGF0ZUNhbGxiYWNrcyA9IFtdO1xuICAgIGNhbGxiYWNrcy5mb3JFYWNoKChjKSA9PiB7XG4gICAgICBjKCk7XG4gICAgfSk7XG4gIH1cblxuICBfcHVzaFVwZGF0ZSh1cGRhdGVzLCBjb2xsZWN0aW9uLCBtc2cpIHtcbiAgICBpZiAoISBoYXNPd24uY2FsbCh1cGRhdGVzLCBjb2xsZWN0aW9uKSkge1xuICAgICAgdXBkYXRlc1tjb2xsZWN0aW9uXSA9IFtdO1xuICAgIH1cbiAgICB1cGRhdGVzW2NvbGxlY3Rpb25dLnB1c2gobXNnKTtcbiAgfVxuXG4gIF9nZXRTZXJ2ZXJEb2MoY29sbGVjdGlvbiwgaWQpIHtcbiAgICBjb25zdCBzZWxmID0gdGhpcztcbiAgICBpZiAoISBoYXNPd24uY2FsbChzZWxmLl9zZXJ2ZXJEb2N1bWVudHMsIGNvbGxlY3Rpb24pKSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgY29uc3Qgc2VydmVyRG9jc0ZvckNvbGxlY3Rpb24gPSBzZWxmLl9zZXJ2ZXJEb2N1bWVudHNbY29sbGVjdGlvbl07XG4gICAgcmV0dXJuIHNlcnZlckRvY3NGb3JDb2xsZWN0aW9uLmdldChpZCkgfHwgbnVsbDtcbiAgfVxuXG4gIGFzeW5jIF9wcm9jZXNzX2FkZGVkKG1zZywgdXBkYXRlcykge1xuICAgIGNvbnN0IHNlbGYgPSB0aGlzO1xuICAgIGNvbnN0IGlkID0gTW9uZ29JRC5pZFBhcnNlKG1zZy5pZCk7XG4gICAgY29uc3Qgc2VydmVyRG9jID0gc2VsZi5fZ2V0U2VydmVyRG9jKG1zZy5jb2xsZWN0aW9uLCBpZCk7XG4gICAgaWYgKHNlcnZlckRvYykge1xuICAgICAgLy8gU29tZSBvdXRzdGFuZGluZyBzdHViIHdyb3RlIGhlcmUuXG4gICAgICBjb25zdCBpc0V4aXN0aW5nID0gc2VydmVyRG9jLmRvY3VtZW50ICE9PSB1bmRlZmluZWQ7XG5cbiAgICAgIHNlcnZlckRvYy5kb2N1bWVudCA9IG1zZy5maWVsZHMgfHwgT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgICAgIHNlcnZlckRvYy5kb2N1bWVudC5faWQgPSBpZDtcblxuICAgICAgaWYgKHNlbGYuX3Jlc2V0U3RvcmVzKSB7XG4gICAgICAgIC8vIER1cmluZyByZWNvbm5lY3QgdGhlIHNlcnZlciBpcyBzZW5kaW5nIGFkZHMgZm9yIGV4aXN0aW5nIGlkcy5cbiAgICAgICAgLy8gQWx3YXlzIHB1c2ggYW4gdXBkYXRlIHNvIHRoYXQgZG9jdW1lbnQgc3RheXMgaW4gdGhlIHN0b3JlIGFmdGVyXG4gICAgICAgIC8vIHJlc2V0LiBVc2UgY3VycmVudCB2ZXJzaW9uIG9mIHRoZSBkb2N1bWVudCBmb3IgdGhpcyB1cGRhdGUsIHNvXG4gICAgICAgIC8vIHRoYXQgc3R1Yi13cml0dGVuIHZhbHVlcyBhcmUgcHJlc2VydmVkLlxuICAgICAgICBjb25zdCBjdXJyZW50RG9jID0gYXdhaXQgc2VsZi5fc3RvcmVzW21zZy5jb2xsZWN0aW9uXS5nZXREb2MobXNnLmlkKTtcbiAgICAgICAgaWYgKGN1cnJlbnREb2MgIT09IHVuZGVmaW5lZCkgbXNnLmZpZWxkcyA9IGN1cnJlbnREb2M7XG5cbiAgICAgICAgc2VsZi5fcHVzaFVwZGF0ZSh1cGRhdGVzLCBtc2cuY29sbGVjdGlvbiwgbXNnKTtcbiAgICAgIH0gZWxzZSBpZiAoaXNFeGlzdGluZykge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1NlcnZlciBzZW50IGFkZCBmb3IgZXhpc3RpbmcgaWQ6ICcgKyBtc2cuaWQpO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBzZWxmLl9wdXNoVXBkYXRlKHVwZGF0ZXMsIG1zZy5jb2xsZWN0aW9uLCBtc2cpO1xuICAgIH1cbiAgfVxuXG4gIF9wcm9jZXNzX2NoYW5nZWQobXNnLCB1cGRhdGVzKSB7XG4gICAgY29uc3Qgc2VsZiA9IHRoaXM7XG4gICAgY29uc3Qgc2VydmVyRG9jID0gc2VsZi5fZ2V0U2VydmVyRG9jKG1zZy5jb2xsZWN0aW9uLCBNb25nb0lELmlkUGFyc2UobXNnLmlkKSk7XG4gICAgaWYgKHNlcnZlckRvYykge1xuICAgICAgaWYgKHNlcnZlckRvYy5kb2N1bWVudCA9PT0gdW5kZWZpbmVkKVxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1NlcnZlciBzZW50IGNoYW5nZWQgZm9yIG5vbmV4aXN0aW5nIGlkOiAnICsgbXNnLmlkKTtcbiAgICAgIERpZmZTZXF1ZW5jZS5hcHBseUNoYW5nZXMoc2VydmVyRG9jLmRvY3VtZW50LCBtc2cuZmllbGRzKTtcbiAgICB9IGVsc2Uge1xuICAgICAgc2VsZi5fcHVzaFVwZGF0ZSh1cGRhdGVzLCBtc2cuY29sbGVjdGlvbiwgbXNnKTtcbiAgICB9XG4gIH1cblxuICBfcHJvY2Vzc19yZW1vdmVkKG1zZywgdXBkYXRlcykge1xuICAgIGNvbnN0IHNlbGYgPSB0aGlzO1xuICAgIGNvbnN0IHNlcnZlckRvYyA9IHNlbGYuX2dldFNlcnZlckRvYyhtc2cuY29sbGVjdGlvbiwgTW9uZ29JRC5pZFBhcnNlKG1zZy5pZCkpO1xuICAgIGlmIChzZXJ2ZXJEb2MpIHtcbiAgICAgIC8vIFNvbWUgb3V0c3RhbmRpbmcgc3R1YiB3cm90ZSBoZXJlLlxuICAgICAgaWYgKHNlcnZlckRvYy5kb2N1bWVudCA9PT0gdW5kZWZpbmVkKVxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1NlcnZlciBzZW50IHJlbW92ZWQgZm9yIG5vbmV4aXN0aW5nIGlkOicgKyBtc2cuaWQpO1xuICAgICAgc2VydmVyRG9jLmRvY3VtZW50ID0gdW5kZWZpbmVkO1xuICAgIH0gZWxzZSB7XG4gICAgICBzZWxmLl9wdXNoVXBkYXRlKHVwZGF0ZXMsIG1zZy5jb2xsZWN0aW9uLCB7XG4gICAgICAgIG1zZzogJ3JlbW92ZWQnLFxuICAgICAgICBjb2xsZWN0aW9uOiBtc2cuY29sbGVjdGlvbixcbiAgICAgICAgaWQ6IG1zZy5pZFxuICAgICAgfSk7XG4gICAgfVxuICB9XG5cbiAgX3Byb2Nlc3NfdXBkYXRlZChtc2csIHVwZGF0ZXMpIHtcbiAgICBjb25zdCBzZWxmID0gdGhpcztcbiAgICAvLyBQcm9jZXNzIFwibWV0aG9kIGRvbmVcIiBtZXNzYWdlcy5cblxuICAgIG1zZy5tZXRob2RzLmZvckVhY2goKG1ldGhvZElkKSA9PiB7XG4gICAgICBjb25zdCBkb2NzID0gc2VsZi5fZG9jdW1lbnRzV3JpdHRlbkJ5U3R1YlttZXRob2RJZF0gfHwge307XG4gICAgICBPYmplY3QudmFsdWVzKGRvY3MpLmZvckVhY2goKHdyaXR0ZW4pID0+IHtcbiAgICAgICAgY29uc3Qgc2VydmVyRG9jID0gc2VsZi5fZ2V0U2VydmVyRG9jKHdyaXR0ZW4uY29sbGVjdGlvbiwgd3JpdHRlbi5pZCk7XG4gICAgICAgIGlmICghIHNlcnZlckRvYykge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcignTG9zdCBzZXJ2ZXJEb2MgZm9yICcgKyBKU09OLnN0cmluZ2lmeSh3cml0dGVuKSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCEgc2VydmVyRG9jLndyaXR0ZW5CeVN0dWJzW21ldGhvZElkXSkge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgICAgICdEb2MgJyArXG4gICAgICAgICAgICAgIEpTT04uc3RyaW5naWZ5KHdyaXR0ZW4pICtcbiAgICAgICAgICAgICAgJyBub3Qgd3JpdHRlbiBieSAgbWV0aG9kICcgK1xuICAgICAgICAgICAgICBtZXRob2RJZFxuICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgICAgZGVsZXRlIHNlcnZlckRvYy53cml0dGVuQnlTdHVic1ttZXRob2RJZF07XG4gICAgICAgIGlmIChpc0VtcHR5KHNlcnZlckRvYy53cml0dGVuQnlTdHVicykpIHtcbiAgICAgICAgICAvLyBBbGwgbWV0aG9kcyB3aG9zZSBzdHVicyB3cm90ZSB0aGlzIG1ldGhvZCBoYXZlIGNvbXBsZXRlZCEgV2UgY2FuXG4gICAgICAgICAgLy8gbm93IGNvcHkgdGhlIHNhdmVkIGRvY3VtZW50IHRvIHRoZSBkYXRhYmFzZSAocmV2ZXJ0aW5nIHRoZSBzdHViJ3NcbiAgICAgICAgICAvLyBjaGFuZ2UgaWYgdGhlIHNlcnZlciBkaWQgbm90IHdyaXRlIHRvIHRoaXMgb2JqZWN0LCBvciBhcHBseWluZyB0aGVcbiAgICAgICAgICAvLyBzZXJ2ZXIncyB3cml0ZXMgaWYgaXQgZGlkKS5cblxuICAgICAgICAgIC8vIFRoaXMgaXMgYSBmYWtlIGRkcCAncmVwbGFjZScgbWVzc2FnZS4gIEl0J3MganVzdCBmb3IgdGFsa2luZ1xuICAgICAgICAgIC8vIGJldHdlZW4gbGl2ZWRhdGEgY29ubmVjdGlvbnMgYW5kIG1pbmltb25nby4gIChXZSBoYXZlIHRvIHN0cmluZ2lmeVxuICAgICAgICAgIC8vIHRoZSBJRCBiZWNhdXNlIGl0J3Mgc3VwcG9zZWQgdG8gbG9vayBsaWtlIGEgd2lyZSBtZXNzYWdlLilcbiAgICAgICAgICBzZWxmLl9wdXNoVXBkYXRlKHVwZGF0ZXMsIHdyaXR0ZW4uY29sbGVjdGlvbiwge1xuICAgICAgICAgICAgbXNnOiAncmVwbGFjZScsXG4gICAgICAgICAgICBpZDogTW9uZ29JRC5pZFN0cmluZ2lmeSh3cml0dGVuLmlkKSxcbiAgICAgICAgICAgIHJlcGxhY2U6IHNlcnZlckRvYy5kb2N1bWVudFxuICAgICAgICAgIH0pO1xuICAgICAgICAgIC8vIENhbGwgYWxsIGZsdXNoIGNhbGxiYWNrcy5cblxuICAgICAgICAgIHNlcnZlckRvYy5mbHVzaENhbGxiYWNrcy5mb3JFYWNoKChjKSA9PiB7XG4gICAgICAgICAgICBjKCk7XG4gICAgICAgICAgfSk7XG5cbiAgICAgICAgICAvLyBEZWxldGUgdGhpcyBjb21wbGV0ZWQgc2VydmVyRG9jdW1lbnQuIERvbid0IGJvdGhlciB0byBHQyBlbXB0eVxuICAgICAgICAgIC8vIElkTWFwcyBpbnNpZGUgc2VsZi5fc2VydmVyRG9jdW1lbnRzLCBzaW5jZSB0aGVyZSBwcm9iYWJseSBhcmVuJ3RcbiAgICAgICAgICAvLyBtYW55IGNvbGxlY3Rpb25zIGFuZCB0aGV5J2xsIGJlIHdyaXR0ZW4gcmVwZWF0ZWRseS5cbiAgICAgICAgICBzZWxmLl9zZXJ2ZXJEb2N1bWVudHNbd3JpdHRlbi5jb2xsZWN0aW9uXS5yZW1vdmUod3JpdHRlbi5pZCk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgICAgZGVsZXRlIHNlbGYuX2RvY3VtZW50c1dyaXR0ZW5CeVN0dWJbbWV0aG9kSWRdO1xuXG4gICAgICAvLyBXZSB3YW50IHRvIGNhbGwgdGhlIGRhdGEtd3JpdHRlbiBjYWxsYmFjaywgYnV0IHdlIGNhbid0IGRvIHNvIHVudGlsIGFsbFxuICAgICAgLy8gY3VycmVudGx5IGJ1ZmZlcmVkIG1lc3NhZ2VzIGFyZSBmbHVzaGVkLlxuICAgICAgY29uc3QgY2FsbGJhY2tJbnZva2VyID0gc2VsZi5fbWV0aG9kSW52b2tlcnNbbWV0aG9kSWRdO1xuICAgICAgaWYgKCEgY2FsbGJhY2tJbnZva2VyKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignTm8gY2FsbGJhY2sgaW52b2tlciBmb3IgbWV0aG9kICcgKyBtZXRob2RJZCk7XG4gICAgICB9XG5cbiAgICAgIHNlbGYuX3J1bldoZW5BbGxTZXJ2ZXJEb2NzQXJlRmx1c2hlZChcbiAgICAgICAgKC4uLmFyZ3MpID0+IGNhbGxiYWNrSW52b2tlci5kYXRhVmlzaWJsZSguLi5hcmdzKVxuICAgICAgKTtcbiAgICB9KTtcbiAgfVxuXG4gIF9wcm9jZXNzX3JlYWR5KG1zZywgdXBkYXRlcykge1xuICAgIGNvbnN0IHNlbGYgPSB0aGlzO1xuICAgIC8vIFByb2Nlc3MgXCJzdWIgcmVhZHlcIiBtZXNzYWdlcy4gXCJzdWIgcmVhZHlcIiBtZXNzYWdlcyBkb24ndCB0YWtlIGVmZmVjdFxuICAgIC8vIHVudGlsIGFsbCBjdXJyZW50IHNlcnZlciBkb2N1bWVudHMgaGF2ZSBiZWVuIGZsdXNoZWQgdG8gdGhlIGxvY2FsXG4gICAgLy8gZGF0YWJhc2UuIFdlIGNhbiB1c2UgYSB3cml0ZSBmZW5jZSB0byBpbXBsZW1lbnQgdGhpcy5cblxuICAgIG1zZy5zdWJzLmZvckVhY2goKHN1YklkKSA9PiB7XG4gICAgICBzZWxmLl9ydW5XaGVuQWxsU2VydmVyRG9jc0FyZUZsdXNoZWQoKCkgPT4ge1xuICAgICAgICBjb25zdCBzdWJSZWNvcmQgPSBzZWxmLl9zdWJzY3JpcHRpb25zW3N1YklkXTtcbiAgICAgICAgLy8gRGlkIHdlIGFscmVhZHkgdW5zdWJzY3JpYmU/XG4gICAgICAgIGlmICghc3ViUmVjb3JkKSByZXR1cm47XG4gICAgICAgIC8vIERpZCB3ZSBhbHJlYWR5IHJlY2VpdmUgYSByZWFkeSBtZXNzYWdlPyAoT29wcyEpXG4gICAgICAgIGlmIChzdWJSZWNvcmQucmVhZHkpIHJldHVybjtcbiAgICAgICAgc3ViUmVjb3JkLnJlYWR5ID0gdHJ1ZTtcbiAgICAgICAgc3ViUmVjb3JkLnJlYWR5Q2FsbGJhY2sgJiYgc3ViUmVjb3JkLnJlYWR5Q2FsbGJhY2soKTtcbiAgICAgICAgc3ViUmVjb3JkLnJlYWR5RGVwcy5jaGFuZ2VkKCk7XG4gICAgICB9KTtcbiAgICB9KTtcbiAgfVxuXG4gIC8vIEVuc3VyZXMgdGhhdCBcImZcIiB3aWxsIGJlIGNhbGxlZCBhZnRlciBhbGwgZG9jdW1lbnRzIGN1cnJlbnRseSBpblxuICAvLyBfc2VydmVyRG9jdW1lbnRzIGhhdmUgYmVlbiB3cml0dGVuIHRvIHRoZSBsb2NhbCBjYWNoZS4gZiB3aWxsIG5vdCBiZSBjYWxsZWRcbiAgLy8gaWYgdGhlIGNvbm5lY3Rpb24gaXMgbG9zdCBiZWZvcmUgdGhlbiFcbiAgX3J1bldoZW5BbGxTZXJ2ZXJEb2NzQXJlRmx1c2hlZChmKSB7XG4gICAgY29uc3Qgc2VsZiA9IHRoaXM7XG4gICAgY29uc3QgcnVuRkFmdGVyVXBkYXRlcyA9ICgpID0+IHtcbiAgICAgIHNlbGYuX2FmdGVyVXBkYXRlQ2FsbGJhY2tzLnB1c2goZik7XG4gICAgfTtcbiAgICBsZXQgdW5mbHVzaGVkU2VydmVyRG9jQ291bnQgPSAwO1xuICAgIGNvbnN0IG9uU2VydmVyRG9jRmx1c2ggPSAoKSA9PiB7XG4gICAgICAtLXVuZmx1c2hlZFNlcnZlckRvY0NvdW50O1xuICAgICAgaWYgKHVuZmx1c2hlZFNlcnZlckRvY0NvdW50ID09PSAwKSB7XG4gICAgICAgIC8vIFRoaXMgd2FzIHRoZSBsYXN0IGRvYyB0byBmbHVzaCEgQXJyYW5nZSB0byBydW4gZiBhZnRlciB0aGUgdXBkYXRlc1xuICAgICAgICAvLyBoYXZlIGJlZW4gYXBwbGllZC5cbiAgICAgICAgcnVuRkFmdGVyVXBkYXRlcygpO1xuICAgICAgfVxuICAgIH07XG5cbiAgICBPYmplY3QudmFsdWVzKHNlbGYuX3NlcnZlckRvY3VtZW50cykuZm9yRWFjaCgoc2VydmVyRG9jdW1lbnRzKSA9PiB7XG4gICAgICBzZXJ2ZXJEb2N1bWVudHMuZm9yRWFjaCgoc2VydmVyRG9jKSA9PiB7XG4gICAgICAgIGNvbnN0IHdyaXR0ZW5CeVN0dWJGb3JBTWV0aG9kV2l0aFNlbnRNZXNzYWdlID1cbiAgICAgICAgICBrZXlzKHNlcnZlckRvYy53cml0dGVuQnlTdHVicykuc29tZShtZXRob2RJZCA9PiB7XG4gICAgICAgICAgICBjb25zdCBpbnZva2VyID0gc2VsZi5fbWV0aG9kSW52b2tlcnNbbWV0aG9kSWRdO1xuICAgICAgICAgICAgcmV0dXJuIGludm9rZXIgJiYgaW52b2tlci5zZW50TWVzc2FnZTtcbiAgICAgICAgICB9KTtcblxuICAgICAgICBpZiAod3JpdHRlbkJ5U3R1YkZvckFNZXRob2RXaXRoU2VudE1lc3NhZ2UpIHtcbiAgICAgICAgICArK3VuZmx1c2hlZFNlcnZlckRvY0NvdW50O1xuICAgICAgICAgIHNlcnZlckRvYy5mbHVzaENhbGxiYWNrcy5wdXNoKG9uU2VydmVyRG9jRmx1c2gpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9KTtcbiAgICBpZiAodW5mbHVzaGVkU2VydmVyRG9jQ291bnQgPT09IDApIHtcbiAgICAgIC8vIFRoZXJlIGFyZW4ndCBhbnkgYnVmZmVyZWQgZG9jcyAtLS0gd2UgY2FuIGNhbGwgZiBhcyBzb29uIGFzIHRoZSBjdXJyZW50XG4gICAgICAvLyByb3VuZCBvZiB1cGRhdGVzIGlzIGFwcGxpZWQhXG4gICAgICBydW5GQWZ0ZXJVcGRhdGVzKCk7XG4gICAgfVxuICB9XG5cbiAgYXN5bmMgX2xpdmVkYXRhX25vc3ViKG1zZykge1xuICAgIGNvbnN0IHNlbGYgPSB0aGlzO1xuXG4gICAgLy8gRmlyc3QgcGFzcyBpdCB0aHJvdWdoIF9saXZlZGF0YV9kYXRhLCB3aGljaCBvbmx5IHVzZXMgaXQgdG8gaGVscCBnZXRcbiAgICAvLyB0b3dhcmRzIHF1aWVzY2VuY2UuXG4gICAgYXdhaXQgc2VsZi5fbGl2ZWRhdGFfZGF0YShtc2cpO1xuXG4gICAgLy8gRG8gdGhlIHJlc3Qgb2Ygb3VyIHByb2Nlc3NpbmcgaW1tZWRpYXRlbHksIHdpdGggbm9cbiAgICAvLyBidWZmZXJpbmctdW50aWwtcXVpZXNjZW5jZS5cblxuICAgIC8vIHdlIHdlcmVuJ3Qgc3ViYmVkIGFueXdheSwgb3Igd2UgaW5pdGlhdGVkIHRoZSB1bnN1Yi5cbiAgICBpZiAoISBoYXNPd24uY2FsbChzZWxmLl9zdWJzY3JpcHRpb25zLCBtc2cuaWQpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgLy8gWFhYIENPTVBBVCBXSVRIIDEuMC4zLjEgI2Vycm9yQ2FsbGJhY2tcbiAgICBjb25zdCBlcnJvckNhbGxiYWNrID0gc2VsZi5fc3Vic2NyaXB0aW9uc1ttc2cuaWRdLmVycm9yQ2FsbGJhY2s7XG4gICAgY29uc3Qgc3RvcENhbGxiYWNrID0gc2VsZi5fc3Vic2NyaXB0aW9uc1ttc2cuaWRdLnN0b3BDYWxsYmFjaztcblxuICAgIHNlbGYuX3N1YnNjcmlwdGlvbnNbbXNnLmlkXS5yZW1vdmUoKTtcblxuICAgIGNvbnN0IG1ldGVvckVycm9yRnJvbU1zZyA9IG1zZ0FyZyA9PiB7XG4gICAgICByZXR1cm4gKFxuICAgICAgICBtc2dBcmcgJiZcbiAgICAgICAgbXNnQXJnLmVycm9yICYmXG4gICAgICAgIG5ldyBNZXRlb3IuRXJyb3IoXG4gICAgICAgICAgbXNnQXJnLmVycm9yLmVycm9yLFxuICAgICAgICAgIG1zZ0FyZy5lcnJvci5yZWFzb24sXG4gICAgICAgICAgbXNnQXJnLmVycm9yLmRldGFpbHNcbiAgICAgICAgKVxuICAgICAgKTtcbiAgICB9O1xuXG4gICAgLy8gWFhYIENPTVBBVCBXSVRIIDEuMC4zLjEgI2Vycm9yQ2FsbGJhY2tcbiAgICBpZiAoZXJyb3JDYWxsYmFjayAmJiBtc2cuZXJyb3IpIHtcbiAgICAgIGVycm9yQ2FsbGJhY2sobWV0ZW9yRXJyb3JGcm9tTXNnKG1zZykpO1xuICAgIH1cblxuICAgIGlmIChzdG9wQ2FsbGJhY2spIHtcbiAgICAgIHN0b3BDYWxsYmFjayhtZXRlb3JFcnJvckZyb21Nc2cobXNnKSk7XG4gICAgfVxuICB9XG5cbiAgYXN5bmMgX2xpdmVkYXRhX3Jlc3VsdChtc2cpIHtcbiAgICAvLyBpZCwgcmVzdWx0IG9yIGVycm9yLiBlcnJvciBoYXMgZXJyb3IgKGNvZGUpLCByZWFzb24sIGRldGFpbHNcblxuICAgIGNvbnN0IHNlbGYgPSB0aGlzO1xuXG4gICAgLy8gTGV0cyBtYWtlIHN1cmUgdGhlcmUgYXJlIG5vIGJ1ZmZlcmVkIHdyaXRlcyBiZWZvcmUgcmV0dXJuaW5nIHJlc3VsdC5cbiAgICBpZiAoISBpc0VtcHR5KHNlbGYuX2J1ZmZlcmVkV3JpdGVzKSkge1xuICAgICAgYXdhaXQgc2VsZi5fZmx1c2hCdWZmZXJlZFdyaXRlcygpO1xuICAgIH1cblxuICAgIC8vIGZpbmQgdGhlIG91dHN0YW5kaW5nIHJlcXVlc3RcbiAgICAvLyBzaG91bGQgYmUgTygxKSBpbiBuZWFybHkgYWxsIHJlYWxpc3RpYyB1c2UgY2FzZXNcbiAgICBpZiAoaXNFbXB0eShzZWxmLl9vdXRzdGFuZGluZ01ldGhvZEJsb2NrcykpIHtcbiAgICAgIE1ldGVvci5fZGVidWcoJ1JlY2VpdmVkIG1ldGhvZCByZXN1bHQgYnV0IG5vIG1ldGhvZHMgb3V0c3RhbmRpbmcnKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgY3VycmVudE1ldGhvZEJsb2NrID0gc2VsZi5fb3V0c3RhbmRpbmdNZXRob2RCbG9ja3NbMF0ubWV0aG9kcztcbiAgICBsZXQgaTtcbiAgICBjb25zdCBtID0gY3VycmVudE1ldGhvZEJsb2NrLmZpbmQoKG1ldGhvZCwgaWR4KSA9PiB7XG4gICAgICBjb25zdCBmb3VuZCA9IG1ldGhvZC5tZXRob2RJZCA9PT0gbXNnLmlkO1xuICAgICAgaWYgKGZvdW5kKSBpID0gaWR4O1xuICAgICAgcmV0dXJuIGZvdW5kO1xuICAgIH0pO1xuICAgIGlmICghbSkge1xuICAgICAgTWV0ZW9yLl9kZWJ1ZyhcIkNhbid0IG1hdGNoIG1ldGhvZCByZXNwb25zZSB0byBvcmlnaW5hbCBtZXRob2QgY2FsbFwiLCBtc2cpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIC8vIFJlbW92ZSBmcm9tIGN1cnJlbnQgbWV0aG9kIGJsb2NrLiBUaGlzIG1heSBsZWF2ZSB0aGUgYmxvY2sgZW1wdHksIGJ1dCB3ZVxuICAgIC8vIGRvbid0IG1vdmUgb24gdG8gdGhlIG5leHQgYmxvY2sgdW50aWwgdGhlIGNhbGxiYWNrIGhhcyBiZWVuIGRlbGl2ZXJlZCwgaW5cbiAgICAvLyBfb3V0c3RhbmRpbmdNZXRob2RGaW5pc2hlZC5cbiAgICBjdXJyZW50TWV0aG9kQmxvY2suc3BsaWNlKGksIDEpO1xuXG4gICAgaWYgKGhhc093bi5jYWxsKG1zZywgJ2Vycm9yJykpIHtcbiAgICAgIG0ucmVjZWl2ZVJlc3VsdChcbiAgICAgICAgbmV3IE1ldGVvci5FcnJvcihtc2cuZXJyb3IuZXJyb3IsIG1zZy5lcnJvci5yZWFzb24sIG1zZy5lcnJvci5kZXRhaWxzKVxuICAgICAgKTtcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gbXNnLnJlc3VsdCBtYXkgYmUgdW5kZWZpbmVkIGlmIHRoZSBtZXRob2QgZGlkbid0IHJldHVybiBhXG4gICAgICAvLyB2YWx1ZVxuICAgICAgbS5yZWNlaXZlUmVzdWx0KHVuZGVmaW5lZCwgbXNnLnJlc3VsdCk7XG4gICAgfVxuICB9XG5cbiAgLy8gQ2FsbGVkIGJ5IE1ldGhvZEludm9rZXIgYWZ0ZXIgYSBtZXRob2QncyBjYWxsYmFjayBpcyBpbnZva2VkLiAgSWYgdGhpcyB3YXNcbiAgLy8gdGhlIGxhc3Qgb3V0c3RhbmRpbmcgbWV0aG9kIGluIHRoZSBjdXJyZW50IGJsb2NrLCBydW5zIHRoZSBuZXh0IGJsb2NrLiBJZlxuICAvLyB0aGVyZSBhcmUgbm8gbW9yZSBtZXRob2RzLCBjb25zaWRlciBhY2NlcHRpbmcgYSBob3QgY29kZSBwdXNoLlxuICBfb3V0c3RhbmRpbmdNZXRob2RGaW5pc2hlZCgpIHtcbiAgICBjb25zdCBzZWxmID0gdGhpcztcbiAgICBpZiAoc2VsZi5fYW55TWV0aG9kc0FyZU91dHN0YW5kaW5nKCkpIHJldHVybjtcblxuICAgIC8vIE5vIG1ldGhvZHMgYXJlIG91dHN0YW5kaW5nLiBUaGlzIHNob3VsZCBtZWFuIHRoYXQgdGhlIGZpcnN0IGJsb2NrIG9mXG4gICAgLy8gbWV0aG9kcyBpcyBlbXB0eS4gKE9yIGl0IG1pZ2h0IG5vdCBleGlzdCwgaWYgdGhpcyB3YXMgYSBtZXRob2QgdGhhdFxuICAgIC8vIGhhbGYtZmluaXNoZWQgYmVmb3JlIGRpc2Nvbm5lY3QvcmVjb25uZWN0LilcbiAgICBpZiAoISBpc0VtcHR5KHNlbGYuX291dHN0YW5kaW5nTWV0aG9kQmxvY2tzKSkge1xuICAgICAgY29uc3QgZmlyc3RCbG9jayA9IHNlbGYuX291dHN0YW5kaW5nTWV0aG9kQmxvY2tzLnNoaWZ0KCk7XG4gICAgICBpZiAoISBpc0VtcHR5KGZpcnN0QmxvY2subWV0aG9kcykpXG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgICAnTm8gbWV0aG9kcyBvdXRzdGFuZGluZyBidXQgbm9uZW1wdHkgYmxvY2s6ICcgK1xuICAgICAgICAgICAgSlNPTi5zdHJpbmdpZnkoZmlyc3RCbG9jaylcbiAgICAgICAgKTtcblxuICAgICAgLy8gU2VuZCB0aGUgb3V0c3RhbmRpbmcgbWV0aG9kcyBub3cgaW4gdGhlIGZpcnN0IGJsb2NrLlxuICAgICAgaWYgKCEgaXNFbXB0eShzZWxmLl9vdXRzdGFuZGluZ01ldGhvZEJsb2NrcykpXG4gICAgICAgIHNlbGYuX3NlbmRPdXRzdGFuZGluZ01ldGhvZHMoKTtcbiAgICB9XG5cbiAgICAvLyBNYXliZSBhY2NlcHQgYSBob3QgY29kZSBwdXNoLlxuICAgIHNlbGYuX21heWJlTWlncmF0ZSgpO1xuICB9XG5cbiAgLy8gU2VuZHMgbWVzc2FnZXMgZm9yIGFsbCB0aGUgbWV0aG9kcyBpbiB0aGUgZmlyc3QgYmxvY2sgaW5cbiAgLy8gX291dHN0YW5kaW5nTWV0aG9kQmxvY2tzLlxuICBfc2VuZE91dHN0YW5kaW5nTWV0aG9kcygpIHtcbiAgICBjb25zdCBzZWxmID0gdGhpcztcblxuICAgIGlmIChpc0VtcHR5KHNlbGYuX291dHN0YW5kaW5nTWV0aG9kQmxvY2tzKSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHNlbGYuX291dHN0YW5kaW5nTWV0aG9kQmxvY2tzWzBdLm1ldGhvZHMuZm9yRWFjaChtID0+IHtcbiAgICAgIG0uc2VuZE1lc3NhZ2UoKTtcbiAgICB9KTtcbiAgfVxuXG4gIF9saXZlZGF0YV9lcnJvcihtc2cpIHtcbiAgICBNZXRlb3IuX2RlYnVnKCdSZWNlaXZlZCBlcnJvciBmcm9tIHNlcnZlcjogJywgbXNnLnJlYXNvbik7XG4gICAgaWYgKG1zZy5vZmZlbmRpbmdNZXNzYWdlKSBNZXRlb3IuX2RlYnVnKCdGb3I6ICcsIG1zZy5vZmZlbmRpbmdNZXNzYWdlKTtcbiAgfVxuXG4gIF9zZW5kT3V0c3RhbmRpbmdNZXRob2RCbG9ja3NNZXNzYWdlcyhvbGRPdXRzdGFuZGluZ01ldGhvZEJsb2Nrcykge1xuICAgIGNvbnN0IHNlbGYgPSB0aGlzO1xuICAgIGlmIChpc0VtcHR5KG9sZE91dHN0YW5kaW5nTWV0aG9kQmxvY2tzKSkgcmV0dXJuO1xuXG4gICAgLy8gV2UgaGF2ZSBhdCBsZWFzdCBvbmUgYmxvY2sgd29ydGggb2Ygb2xkIG91dHN0YW5kaW5nIG1ldGhvZHMgdG8gdHJ5XG4gICAgLy8gYWdhaW4uIEZpcnN0OiBkaWQgb25SZWNvbm5lY3QgYWN0dWFsbHkgc2VuZCBhbnl0aGluZz8gSWYgbm90LCB3ZSBqdXN0XG4gICAgLy8gcmVzdG9yZSBhbGwgb3V0c3RhbmRpbmcgbWV0aG9kcyBhbmQgcnVuIHRoZSBmaXJzdCBibG9jay5cbiAgICBpZiAoaXNFbXB0eShzZWxmLl9vdXRzdGFuZGluZ01ldGhvZEJsb2NrcykpIHtcbiAgICAgIHNlbGYuX291dHN0YW5kaW5nTWV0aG9kQmxvY2tzID0gb2xkT3V0c3RhbmRpbmdNZXRob2RCbG9ja3M7XG4gICAgICBzZWxmLl9zZW5kT3V0c3RhbmRpbmdNZXRob2RzKCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgLy8gT0ssIHRoZXJlIGFyZSBibG9ja3Mgb24gYm90aCBzaWRlcy4gU3BlY2lhbCBjYXNlOiBtZXJnZSB0aGUgbGFzdCBibG9jayBvZlxuICAgIC8vIHRoZSByZWNvbm5lY3QgbWV0aG9kcyB3aXRoIHRoZSBmaXJzdCBibG9jayBvZiB0aGUgb3JpZ2luYWwgbWV0aG9kcywgaWZcbiAgICAvLyBuZWl0aGVyIG9mIHRoZW0gYXJlIFwid2FpdFwiIGJsb2Nrcy5cbiAgICBpZiAoXG4gICAgICAhbGFzdChzZWxmLl9vdXRzdGFuZGluZ01ldGhvZEJsb2Nrcykud2FpdCAmJlxuICAgICAgIW9sZE91dHN0YW5kaW5nTWV0aG9kQmxvY2tzWzBdLndhaXRcbiAgICApIHtcbiAgICAgIG9sZE91dHN0YW5kaW5nTWV0aG9kQmxvY2tzWzBdLm1ldGhvZHMuZm9yRWFjaCgobSkgPT4ge1xuICAgICAgICBsYXN0KHNlbGYuX291dHN0YW5kaW5nTWV0aG9kQmxvY2tzKS5tZXRob2RzLnB1c2gobSk7XG5cbiAgICAgICAgLy8gSWYgdGhpcyBcImxhc3QgYmxvY2tcIiBpcyBhbHNvIHRoZSBmaXJzdCBibG9jaywgc2VuZCB0aGUgbWVzc2FnZS5cbiAgICAgICAgaWYgKHNlbGYuX291dHN0YW5kaW5nTWV0aG9kQmxvY2tzLmxlbmd0aCA9PT0gMSkge1xuICAgICAgICAgIG0uc2VuZE1lc3NhZ2UoKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG5cbiAgICAgIG9sZE91dHN0YW5kaW5nTWV0aG9kQmxvY2tzLnNoaWZ0KCk7XG4gICAgfVxuXG4gICAgLy8gTm93IGFkZCB0aGUgcmVzdCBvZiB0aGUgb3JpZ2luYWwgYmxvY2tzIG9uLlxuICAgIHNlbGYuX291dHN0YW5kaW5nTWV0aG9kQmxvY2tzLnB1c2goLi4ub2xkT3V0c3RhbmRpbmdNZXRob2RCbG9ja3MpO1xuICB9XG4gIF9jYWxsT25SZWNvbm5lY3RBbmRTZW5kQXBwcm9wcmlhdGVPdXRzdGFuZGluZ01ldGhvZHMoKSB7XG4gICAgY29uc3Qgc2VsZiA9IHRoaXM7XG4gICAgY29uc3Qgb2xkT3V0c3RhbmRpbmdNZXRob2RCbG9ja3MgPSBzZWxmLl9vdXRzdGFuZGluZ01ldGhvZEJsb2NrcztcbiAgICBzZWxmLl9vdXRzdGFuZGluZ01ldGhvZEJsb2NrcyA9IFtdO1xuXG4gICAgc2VsZi5vblJlY29ubmVjdCAmJiBzZWxmLm9uUmVjb25uZWN0KCk7XG4gICAgRERQLl9yZWNvbm5lY3RIb29rLmVhY2goKGNhbGxiYWNrKSA9PiB7XG4gICAgICBjYWxsYmFjayhzZWxmKTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH0pO1xuXG4gICAgc2VsZi5fc2VuZE91dHN0YW5kaW5nTWV0aG9kQmxvY2tzTWVzc2FnZXMob2xkT3V0c3RhbmRpbmdNZXRob2RCbG9ja3MpO1xuICB9XG5cbiAgLy8gV2UgY2FuIGFjY2VwdCBhIGhvdCBjb2RlIHB1c2ggaWYgdGhlcmUgYXJlIG5vIG1ldGhvZHMgaW4gZmxpZ2h0LlxuICBfcmVhZHlUb01pZ3JhdGUoKSB7XG4gICAgcmV0dXJuIGlzRW1wdHkodGhpcy5fbWV0aG9kSW52b2tlcnMpO1xuICB9XG5cbiAgLy8gSWYgd2Ugd2VyZSBibG9ja2luZyBhIG1pZ3JhdGlvbiwgc2VlIGlmIGl0J3Mgbm93IHBvc3NpYmxlIHRvIGNvbnRpbnVlLlxuICAvLyBDYWxsIHdoZW5ldmVyIHRoZSBzZXQgb2Ygb3V0c3RhbmRpbmcvYmxvY2tlZCBtZXRob2RzIHNocmlua3MuXG4gIF9tYXliZU1pZ3JhdGUoKSB7XG4gICAgY29uc3Qgc2VsZiA9IHRoaXM7XG4gICAgaWYgKHNlbGYuX3JldHJ5TWlncmF0ZSAmJiBzZWxmLl9yZWFkeVRvTWlncmF0ZSgpKSB7XG4gICAgICBzZWxmLl9yZXRyeU1pZ3JhdGUoKTtcbiAgICAgIHNlbGYuX3JldHJ5TWlncmF0ZSA9IG51bGw7XG4gICAgfVxuICB9XG5cbiAgYXN5bmMgb25NZXNzYWdlKHJhd19tc2cpIHtcbiAgICBsZXQgbXNnO1xuICAgIHRyeSB7XG4gICAgICBtc2cgPSBERFBDb21tb24ucGFyc2VERFAocmF3X21zZyk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgTWV0ZW9yLl9kZWJ1ZygnRXhjZXB0aW9uIHdoaWxlIHBhcnNpbmcgRERQJywgZSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgLy8gQW55IG1lc3NhZ2UgY291bnRzIGFzIHJlY2VpdmluZyBhIHBvbmcsIGFzIGl0IGRlbW9uc3RyYXRlcyB0aGF0XG4gICAgLy8gdGhlIHNlcnZlciBpcyBzdGlsbCBhbGl2ZS5cbiAgICBpZiAodGhpcy5faGVhcnRiZWF0KSB7XG4gICAgICB0aGlzLl9oZWFydGJlYXQubWVzc2FnZVJlY2VpdmVkKCk7XG4gICAgfVxuXG4gICAgaWYgKG1zZyA9PT0gbnVsbCB8fCAhbXNnLm1zZykge1xuICAgICAgaWYoIW1zZyB8fCAhbXNnLnRlc3RNZXNzYWdlT25Db25uZWN0KSB7XG4gICAgICAgIGlmIChPYmplY3Qua2V5cyhtc2cpLmxlbmd0aCA9PT0gMSAmJiBtc2cuc2VydmVyX2lkKSByZXR1cm47XG4gICAgICAgIE1ldGVvci5fZGVidWcoJ2Rpc2NhcmRpbmcgaW52YWxpZCBsaXZlZGF0YSBtZXNzYWdlJywgbXNnKTtcbiAgICAgIH1cbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBpZiAobXNnLm1zZyA9PT0gJ2Nvbm5lY3RlZCcpIHtcbiAgICAgIHRoaXMuX3ZlcnNpb24gPSB0aGlzLl92ZXJzaW9uU3VnZ2VzdGlvbjtcbiAgICAgIGF3YWl0IHRoaXMuX2xpdmVkYXRhX2Nvbm5lY3RlZChtc2cpO1xuICAgICAgdGhpcy5vcHRpb25zLm9uQ29ubmVjdGVkKCk7XG4gICAgfSBlbHNlIGlmIChtc2cubXNnID09PSAnZmFpbGVkJykge1xuICAgICAgaWYgKHRoaXMuX3N1cHBvcnRlZEREUFZlcnNpb25zLmluZGV4T2YobXNnLnZlcnNpb24pID49IDApIHtcbiAgICAgICAgdGhpcy5fdmVyc2lvblN1Z2dlc3Rpb24gPSBtc2cudmVyc2lvbjtcbiAgICAgICAgdGhpcy5fc3RyZWFtLnJlY29ubmVjdCh7IF9mb3JjZTogdHJ1ZSB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnN0IGRlc2NyaXB0aW9uID1cbiAgICAgICAgICAnRERQIHZlcnNpb24gbmVnb3RpYXRpb24gZmFpbGVkOyBzZXJ2ZXIgcmVxdWVzdGVkIHZlcnNpb24gJyArXG4gICAgICAgICAgbXNnLnZlcnNpb247XG4gICAgICAgIHRoaXMuX3N0cmVhbS5kaXNjb25uZWN0KHsgX3Blcm1hbmVudDogdHJ1ZSwgX2Vycm9yOiBkZXNjcmlwdGlvbiB9KTtcbiAgICAgICAgdGhpcy5vcHRpb25zLm9uRERQVmVyc2lvbk5lZ290aWF0aW9uRmFpbHVyZShkZXNjcmlwdGlvbik7XG4gICAgICB9XG4gICAgfSBlbHNlIGlmIChtc2cubXNnID09PSAncGluZycgJiYgdGhpcy5vcHRpb25zLnJlc3BvbmRUb1BpbmdzKSB7XG4gICAgICB0aGlzLl9zZW5kKHsgbXNnOiAncG9uZycsIGlkOiBtc2cuaWQgfSk7XG4gICAgfSBlbHNlIGlmIChtc2cubXNnID09PSAncG9uZycpIHtcbiAgICAgIC8vIG5vb3AsIGFzIHdlIGFzc3VtZSBldmVyeXRoaW5nJ3MgYSBwb25nXG4gICAgfSBlbHNlIGlmIChcbiAgICAgIFsnYWRkZWQnLCAnY2hhbmdlZCcsICdyZW1vdmVkJywgJ3JlYWR5JywgJ3VwZGF0ZWQnXS5pbmNsdWRlcyhtc2cubXNnKVxuICAgICkge1xuICAgICAgYXdhaXQgdGhpcy5fbGl2ZWRhdGFfZGF0YShtc2cpO1xuICAgIH0gZWxzZSBpZiAobXNnLm1zZyA9PT0gJ25vc3ViJykge1xuICAgICAgYXdhaXQgdGhpcy5fbGl2ZWRhdGFfbm9zdWIobXNnKTtcbiAgICB9IGVsc2UgaWYgKG1zZy5tc2cgPT09ICdyZXN1bHQnKSB7XG4gICAgICBhd2FpdCB0aGlzLl9saXZlZGF0YV9yZXN1bHQobXNnKTtcbiAgICB9IGVsc2UgaWYgKG1zZy5tc2cgPT09ICdlcnJvcicpIHtcbiAgICAgIHRoaXMuX2xpdmVkYXRhX2Vycm9yKG1zZyk7XG4gICAgfSBlbHNlIHtcbiAgICAgIE1ldGVvci5fZGVidWcoJ2Rpc2NhcmRpbmcgdW5rbm93biBsaXZlZGF0YSBtZXNzYWdlIHR5cGUnLCBtc2cpO1xuICAgIH1cbiAgfVxuXG4gIG9uUmVzZXQoKSB7XG4gICAgLy8gU2VuZCBhIGNvbm5lY3QgbWVzc2FnZSBhdCB0aGUgYmVnaW5uaW5nIG9mIHRoZSBzdHJlYW0uXG4gICAgLy8gTk9URTogcmVzZXQgaXMgY2FsbGVkIGV2ZW4gb24gdGhlIGZpcnN0IGNvbm5lY3Rpb24sIHNvIHRoaXMgaXNcbiAgICAvLyB0aGUgb25seSBwbGFjZSB3ZSBzZW5kIHRoaXMgbWVzc2FnZS5cbiAgICBjb25zdCBtc2cgPSB7IG1zZzogJ2Nvbm5lY3QnIH07XG4gICAgaWYgKHRoaXMuX2xhc3RTZXNzaW9uSWQpIG1zZy5zZXNzaW9uID0gdGhpcy5fbGFzdFNlc3Npb25JZDtcbiAgICBtc2cudmVyc2lvbiA9IHRoaXMuX3ZlcnNpb25TdWdnZXN0aW9uIHx8IHRoaXMuX3N1cHBvcnRlZEREUFZlcnNpb25zWzBdO1xuICAgIHRoaXMuX3ZlcnNpb25TdWdnZXN0aW9uID0gbXNnLnZlcnNpb247XG4gICAgbXNnLnN1cHBvcnQgPSB0aGlzLl9zdXBwb3J0ZWRERFBWZXJzaW9ucztcbiAgICB0aGlzLl9zZW5kKG1zZyk7XG5cbiAgICAvLyBNYXJrIG5vbi1yZXRyeSBjYWxscyBhcyBmYWlsZWQuIFRoaXMgaGFzIHRvIGJlIGRvbmUgZWFybHkgYXMgZ2V0dGluZyB0aGVzZSBtZXRob2RzIG91dCBvZiB0aGVcbiAgICAvLyBjdXJyZW50IGJsb2NrIGlzIHByZXR0eSBpbXBvcnRhbnQgdG8gbWFraW5nIHN1cmUgdGhhdCBxdWllc2NlbmNlIGlzIHByb3Blcmx5IGNhbGN1bGF0ZWQsIGFzXG4gICAgLy8gd2VsbCBhcyBwb3NzaWJseSBtb3Zpbmcgb24gdG8gYW5vdGhlciB1c2VmdWwgYmxvY2suXG5cbiAgICAvLyBPbmx5IGJvdGhlciB0ZXN0aW5nIGlmIHRoZXJlIGlzIGFuIG91dHN0YW5kaW5nTWV0aG9kQmxvY2sgKHRoZXJlIG1pZ2h0IG5vdCBiZSwgZXNwZWNpYWxseSBpZlxuICAgIC8vIHdlIGFyZSBjb25uZWN0aW5nIGZvciB0aGUgZmlyc3QgdGltZS5cbiAgICBpZiAodGhpcy5fb3V0c3RhbmRpbmdNZXRob2RCbG9ja3MubGVuZ3RoID4gMCkge1xuICAgICAgLy8gSWYgdGhlcmUgaXMgYW4gb3V0c3RhbmRpbmcgbWV0aG9kIGJsb2NrLCB3ZSBvbmx5IGNhcmUgYWJvdXQgdGhlIGZpcnN0IG9uZSBhcyB0aGF0IGlzIHRoZVxuICAgICAgLy8gb25lIHRoYXQgY291bGQgaGF2ZSBhbHJlYWR5IHNlbnQgbWVzc2FnZXMgd2l0aCBubyByZXNwb25zZSwgdGhhdCBhcmUgbm90IGFsbG93ZWQgdG8gcmV0cnkuXG4gICAgICBjb25zdCBjdXJyZW50TWV0aG9kQmxvY2sgPSB0aGlzLl9vdXRzdGFuZGluZ01ldGhvZEJsb2Nrc1swXS5tZXRob2RzO1xuICAgICAgdGhpcy5fb3V0c3RhbmRpbmdNZXRob2RCbG9ja3NbMF0ubWV0aG9kcyA9IGN1cnJlbnRNZXRob2RCbG9jay5maWx0ZXIoXG4gICAgICAgIG1ldGhvZEludm9rZXIgPT4ge1xuICAgICAgICAgIC8vIE1ldGhvZHMgd2l0aCAnbm9SZXRyeScgb3B0aW9uIHNldCBhcmUgbm90IGFsbG93ZWQgdG8gcmUtc2VuZCBhZnRlclxuICAgICAgICAgIC8vIHJlY292ZXJpbmcgZHJvcHBlZCBjb25uZWN0aW9uLlxuICAgICAgICAgIGlmIChtZXRob2RJbnZva2VyLnNlbnRNZXNzYWdlICYmIG1ldGhvZEludm9rZXIubm9SZXRyeSkge1xuICAgICAgICAgICAgLy8gTWFrZSBzdXJlIHRoYXQgdGhlIG1ldGhvZCBpcyB0b2xkIHRoYXQgaXQgZmFpbGVkLlxuICAgICAgICAgICAgbWV0aG9kSW52b2tlci5yZWNlaXZlUmVzdWx0KFxuICAgICAgICAgICAgICBuZXcgTWV0ZW9yLkVycm9yKFxuICAgICAgICAgICAgICAgICdpbnZvY2F0aW9uLWZhaWxlZCcsXG4gICAgICAgICAgICAgICAgJ01ldGhvZCBpbnZvY2F0aW9uIG1pZ2h0IGhhdmUgZmFpbGVkIGR1ZSB0byBkcm9wcGVkIGNvbm5lY3Rpb24uICcgK1xuICAgICAgICAgICAgICAgICAgJ0ZhaWxpbmcgYmVjYXVzZSBgbm9SZXRyeWAgb3B0aW9uIHdhcyBwYXNzZWQgdG8gTWV0ZW9yLmFwcGx5LidcbiAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICAvLyBPbmx5IGtlZXAgYSBtZXRob2QgaWYgaXQgd2Fzbid0IHNlbnQgb3IgaXQncyBhbGxvd2VkIHRvIHJldHJ5LlxuICAgICAgICAgIC8vIFRoaXMgbWF5IGxlYXZlIHRoZSBibG9jayBlbXB0eSwgYnV0IHdlIGRvbid0IG1vdmUgb24gdG8gdGhlIG5leHRcbiAgICAgICAgICAvLyBibG9jayB1bnRpbCB0aGUgY2FsbGJhY2sgaGFzIGJlZW4gZGVsaXZlcmVkLCBpbiBfb3V0c3RhbmRpbmdNZXRob2RGaW5pc2hlZC5cbiAgICAgICAgICByZXR1cm4gIShtZXRob2RJbnZva2VyLnNlbnRNZXNzYWdlICYmIG1ldGhvZEludm9rZXIubm9SZXRyeSk7XG4gICAgICAgIH1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgLy8gTm93LCB0byBtaW5pbWl6ZSBzZXR1cCBsYXRlbmN5LCBnbyBhaGVhZCBhbmQgYmxhc3Qgb3V0IGFsbCBvZlxuICAgIC8vIG91ciBwZW5kaW5nIG1ldGhvZHMgYW5kcyBzdWJzY3JpcHRpb25zIGJlZm9yZSB3ZSd2ZSBldmVuIHRha2VuXG4gICAgLy8gdGhlIG5lY2Vzc2FyeSBSVFQgdG8ga25vdyBpZiB3ZSBzdWNjZXNzZnVsbHkgcmVjb25uZWN0ZWQuICgxKVxuICAgIC8vIFRoZXkncmUgc3VwcG9zZWQgdG8gYmUgaWRlbXBvdGVudCwgYW5kIHdoZXJlIHRoZXkgYXJlIG5vdCxcbiAgICAvLyB0aGV5IGNhbiBibG9jayByZXRyeSBpbiBhcHBseTsgKDIpIGV2ZW4gaWYgd2UgZGlkIHJlY29ubmVjdCxcbiAgICAvLyB3ZSdyZSBub3Qgc3VyZSB3aGF0IG1lc3NhZ2VzIG1pZ2h0IGhhdmUgZ290dGVuIGxvc3RcbiAgICAvLyAoaW4gZWl0aGVyIGRpcmVjdGlvbikgc2luY2Ugd2Ugd2VyZSBkaXNjb25uZWN0ZWQgKFRDUCBiZWluZ1xuICAgIC8vIHNsb3BweSBhYm91dCB0aGF0LilcblxuICAgIC8vIElmIHRoZSBjdXJyZW50IGJsb2NrIG9mIG1ldGhvZHMgYWxsIGdvdCB0aGVpciByZXN1bHRzIChidXQgZGlkbid0IGFsbCBnZXRcbiAgICAvLyB0aGVpciBkYXRhIHZpc2libGUpLCBkaXNjYXJkIHRoZSBlbXB0eSBibG9jayBub3cuXG4gICAgaWYgKFxuICAgICAgdGhpcy5fb3V0c3RhbmRpbmdNZXRob2RCbG9ja3MubGVuZ3RoID4gMCAmJlxuICAgICAgdGhpcy5fb3V0c3RhbmRpbmdNZXRob2RCbG9ja3NbMF0ubWV0aG9kcy5sZW5ndGggPT09IDBcbiAgICApIHtcbiAgICAgIHRoaXMuX291dHN0YW5kaW5nTWV0aG9kQmxvY2tzLnNoaWZ0KCk7XG4gICAgfVxuXG4gICAgLy8gTWFyayBhbGwgbWVzc2FnZXMgYXMgdW5zZW50LCB0aGV5IGhhdmUgbm90IHlldCBiZWVuIHNlbnQgb24gdGhpc1xuICAgIC8vIGNvbm5lY3Rpb24uXG4gICAga2V5cyh0aGlzLl9tZXRob2RJbnZva2VycykuZm9yRWFjaChpZCA9PiB7XG4gICAgICB0aGlzLl9tZXRob2RJbnZva2Vyc1tpZF0uc2VudE1lc3NhZ2UgPSBmYWxzZTtcbiAgICB9KTtcblxuICAgIC8vIElmIGFuIGBvblJlY29ubmVjdGAgaGFuZGxlciBpcyBzZXQsIGNhbGwgaXQgZmlyc3QuIEdvIHRocm91Z2hcbiAgICAvLyBzb21lIGhvb3BzIHRvIGVuc3VyZSB0aGF0IG1ldGhvZHMgdGhhdCBhcmUgY2FsbGVkIGZyb20gd2l0aGluXG4gICAgLy8gYG9uUmVjb25uZWN0YCBnZXQgZXhlY3V0ZWQgX2JlZm9yZV8gb25lcyB0aGF0IHdlcmUgb3JpZ2luYWxseVxuICAgIC8vIG91dHN0YW5kaW5nIChzaW5jZSBgb25SZWNvbm5lY3RgIGlzIHVzZWQgdG8gcmUtZXN0YWJsaXNoIGF1dGhcbiAgICAvLyBjZXJ0aWZpY2F0ZXMpXG4gICAgdGhpcy5fY2FsbE9uUmVjb25uZWN0QW5kU2VuZEFwcHJvcHJpYXRlT3V0c3RhbmRpbmdNZXRob2RzKCk7XG5cbiAgICAvLyBhZGQgbmV3IHN1YnNjcmlwdGlvbnMgYXQgdGhlIGVuZC4gdGhpcyB3YXkgdGhleSB0YWtlIGVmZmVjdCBhZnRlclxuICAgIC8vIHRoZSBoYW5kbGVycyBhbmQgd2UgZG9uJ3Qgc2VlIGZsaWNrZXIuXG4gICAgT2JqZWN0LmVudHJpZXModGhpcy5fc3Vic2NyaXB0aW9ucykuZm9yRWFjaCgoW2lkLCBzdWJdKSA9PiB7XG4gICAgICB0aGlzLl9zZW5kKHtcbiAgICAgICAgbXNnOiAnc3ViJyxcbiAgICAgICAgaWQ6IGlkLFxuICAgICAgICBuYW1lOiBzdWIubmFtZSxcbiAgICAgICAgcGFyYW1zOiBzdWIucGFyYW1zXG4gICAgICB9KTtcbiAgICB9KTtcbiAgfVxufVxuIiwiaW1wb3J0IHsgRERQQ29tbW9uIH0gZnJvbSAnbWV0ZW9yL2RkcC1jb21tb24nO1xuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5cbmltcG9ydCB7IENvbm5lY3Rpb24gfSBmcm9tICcuL2xpdmVkYXRhX2Nvbm5lY3Rpb24uanMnO1xuXG4vLyBUaGlzIGFycmF5IGFsbG93cyB0aGUgYF9hbGxTdWJzY3JpcHRpb25zUmVhZHlgIG1ldGhvZCBiZWxvdywgd2hpY2hcbi8vIGlzIHVzZWQgYnkgdGhlIGBzcGlkZXJhYmxlYCBwYWNrYWdlLCB0byBrZWVwIHRyYWNrIG9mIHdoZXRoZXIgYWxsXG4vLyBkYXRhIGlzIHJlYWR5LlxuY29uc3QgYWxsQ29ubmVjdGlvbnMgPSBbXTtcblxuLyoqXG4gKiBAbmFtZXNwYWNlIEREUFxuICogQHN1bW1hcnkgTmFtZXNwYWNlIGZvciBERFAtcmVsYXRlZCBtZXRob2RzL2NsYXNzZXMuXG4gKi9cbmV4cG9ydCBjb25zdCBERFAgPSB7fTtcblxuLy8gVGhpcyBpcyBwcml2YXRlIGJ1dCBpdCdzIHVzZWQgaW4gYSBmZXcgcGxhY2VzLiBhY2NvdW50cy1iYXNlIHVzZXNcbi8vIGl0IHRvIGdldCB0aGUgY3VycmVudCB1c2VyLiBNZXRlb3Iuc2V0VGltZW91dCBhbmQgZnJpZW5kcyBjbGVhclxuLy8gaXQuIFdlIGNhbiBwcm9iYWJseSBmaW5kIGEgYmV0dGVyIHdheSB0byBmYWN0b3IgdGhpcy5cbkREUC5fQ3VycmVudE1ldGhvZEludm9jYXRpb24gPSBuZXcgTWV0ZW9yLkVudmlyb25tZW50VmFyaWFibGUoKTtcbkREUC5fQ3VycmVudFB1YmxpY2F0aW9uSW52b2NhdGlvbiA9IG5ldyBNZXRlb3IuRW52aXJvbm1lbnRWYXJpYWJsZSgpO1xuXG4vLyBYWFg6IEtlZXAgRERQLl9DdXJyZW50SW52b2NhdGlvbiBmb3IgYmFja3dhcmRzLWNvbXBhdGliaWxpdHkuXG5ERFAuX0N1cnJlbnRJbnZvY2F0aW9uID0gRERQLl9DdXJyZW50TWV0aG9kSW52b2NhdGlvbjtcblxuRERQLl9DdXJyZW50Q2FsbEFzeW5jSW52b2NhdGlvbiA9IG5ldyBNZXRlb3IuRW52aXJvbm1lbnRWYXJpYWJsZSgpO1xuXG4vLyBUaGlzIGlzIHBhc3NlZCBpbnRvIGEgd2VpcmQgYG1ha2VFcnJvclR5cGVgIGZ1bmN0aW9uIHRoYXQgZXhwZWN0cyBpdHMgdGhpbmdcbi8vIHRvIGJlIGEgY29uc3RydWN0b3JcbmZ1bmN0aW9uIGNvbm5lY3Rpb25FcnJvckNvbnN0cnVjdG9yKG1lc3NhZ2UpIHtcbiAgdGhpcy5tZXNzYWdlID0gbWVzc2FnZTtcbn1cblxuRERQLkNvbm5lY3Rpb25FcnJvciA9IE1ldGVvci5tYWtlRXJyb3JUeXBlKFxuICAnRERQLkNvbm5lY3Rpb25FcnJvcicsXG4gIGNvbm5lY3Rpb25FcnJvckNvbnN0cnVjdG9yXG4pO1xuXG5ERFAuRm9yY2VkUmVjb25uZWN0RXJyb3IgPSBNZXRlb3IubWFrZUVycm9yVHlwZShcbiAgJ0REUC5Gb3JjZWRSZWNvbm5lY3RFcnJvcicsXG4gICgpID0+IHt9XG4pO1xuXG4vLyBSZXR1cm5zIHRoZSBuYW1lZCBzZXF1ZW5jZSBvZiBwc2V1ZG8tcmFuZG9tIHZhbHVlcy5cbi8vIFRoZSBzY29wZSB3aWxsIGJlIEREUC5fQ3VycmVudE1ldGhvZEludm9jYXRpb24uZ2V0KCksIHNvIHRoZSBzdHJlYW0gd2lsbCBwcm9kdWNlXG4vLyBjb25zaXN0ZW50IHZhbHVlcyBmb3IgbWV0aG9kIGNhbGxzIG9uIHRoZSBjbGllbnQgYW5kIHNlcnZlci5cbkREUC5yYW5kb21TdHJlYW0gPSBuYW1lID0+IHtcbiAgY29uc3Qgc2NvcGUgPSBERFAuX0N1cnJlbnRNZXRob2RJbnZvY2F0aW9uLmdldCgpO1xuICByZXR1cm4gRERQQ29tbW9uLlJhbmRvbVN0cmVhbS5nZXQoc2NvcGUsIG5hbWUpO1xufTtcblxuLy8gQHBhcmFtIHVybCB7U3RyaW5nfSBVUkwgdG8gTWV0ZW9yIGFwcCxcbi8vICAgICBlLmcuOlxuLy8gICAgIFwic3ViZG9tYWluLm1ldGVvci5jb21cIixcbi8vICAgICBcImh0dHA6Ly9zdWJkb21haW4ubWV0ZW9yLmNvbVwiLFxuLy8gICAgIFwiL1wiLFxuLy8gICAgIFwiZGRwK3NvY2tqczovL2RkcC0tKioqKi1mb28ubWV0ZW9yLmNvbS9zb2NranNcIlxuXG4vKipcbiAqIEBzdW1tYXJ5IENvbm5lY3QgdG8gdGhlIHNlcnZlciBvZiBhIGRpZmZlcmVudCBNZXRlb3IgYXBwbGljYXRpb24gdG8gc3Vic2NyaWJlIHRvIGl0cyBkb2N1bWVudCBzZXRzIGFuZCBpbnZva2UgaXRzIHJlbW90ZSBtZXRob2RzLlxuICogQGxvY3VzIEFueXdoZXJlXG4gKiBAcGFyYW0ge1N0cmluZ30gdXJsIFRoZSBVUkwgb2YgYW5vdGhlciBNZXRlb3IgYXBwbGljYXRpb24uXG4gKiBAcGFyYW0ge09iamVjdH0gW29wdGlvbnNdXG4gKiBAcGFyYW0ge0Jvb2xlYW59IG9wdGlvbnMucmVsb2FkV2l0aE91dHN0YW5kaW5nIGlzIGl0IE9LIHRvIHJlbG9hZCBpZiB0aGVyZSBhcmUgb3V0c3RhbmRpbmcgbWV0aG9kcz9cbiAqIEBwYXJhbSB7T2JqZWN0fSBvcHRpb25zLmhlYWRlcnMgZXh0cmEgaGVhZGVycyB0byBzZW5kIG9uIHRoZSB3ZWJzb2NrZXRzIGNvbm5lY3Rpb24sIGZvciBzZXJ2ZXItdG8tc2VydmVyIEREUCBvbmx5XG4gKiBAcGFyYW0ge09iamVjdH0gb3B0aW9ucy5fc29ja2pzT3B0aW9ucyBTcGVjaWZpZXMgb3B0aW9ucyB0byBwYXNzIHRocm91Z2ggdG8gdGhlIHNvY2tqcyBjbGllbnRcbiAqIEBwYXJhbSB7RnVuY3Rpb259IG9wdGlvbnMub25ERFBOZWdvdGlhdGlvblZlcnNpb25GYWlsdXJlIGNhbGxiYWNrIHdoZW4gdmVyc2lvbiBuZWdvdGlhdGlvbiBmYWlscy5cbiAqL1xuRERQLmNvbm5lY3QgPSAodXJsLCBvcHRpb25zKSA9PiB7XG4gIGNvbnN0IHJldCA9IG5ldyBDb25uZWN0aW9uKHVybCwgb3B0aW9ucyk7XG4gIGFsbENvbm5lY3Rpb25zLnB1c2gocmV0KTsgLy8gaGFjay4gc2VlIGJlbG93LlxuICByZXR1cm4gcmV0O1xufTtcblxuRERQLl9yZWNvbm5lY3RIb29rID0gbmV3IEhvb2soeyBiaW5kRW52aXJvbm1lbnQ6IGZhbHNlIH0pO1xuXG4vKipcbiAqIEBzdW1tYXJ5IFJlZ2lzdGVyIGEgZnVuY3Rpb24gdG8gY2FsbCBhcyB0aGUgZmlyc3Qgc3RlcCBvZlxuICogcmVjb25uZWN0aW5nLiBUaGlzIGZ1bmN0aW9uIGNhbiBjYWxsIG1ldGhvZHMgd2hpY2ggd2lsbCBiZSBleGVjdXRlZCBiZWZvcmVcbiAqIGFueSBvdGhlciBvdXRzdGFuZGluZyBtZXRob2RzLiBGb3IgZXhhbXBsZSwgdGhpcyBjYW4gYmUgdXNlZCB0byByZS1lc3RhYmxpc2hcbiAqIHRoZSBhcHByb3ByaWF0ZSBhdXRoZW50aWNhdGlvbiBjb250ZXh0IG9uIHRoZSBjb25uZWN0aW9uLlxuICogQGxvY3VzIEFueXdoZXJlXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSBjYWxsYmFjayBUaGUgZnVuY3Rpb24gdG8gY2FsbC4gSXQgd2lsbCBiZSBjYWxsZWQgd2l0aCBhXG4gKiBzaW5nbGUgYXJndW1lbnQsIHRoZSBbY29ubmVjdGlvbiBvYmplY3RdKCNkZHBfY29ubmVjdCkgdGhhdCBpcyByZWNvbm5lY3RpbmcuXG4gKi9cbkREUC5vblJlY29ubmVjdCA9IGNhbGxiYWNrID0+IEREUC5fcmVjb25uZWN0SG9vay5yZWdpc3RlcihjYWxsYmFjayk7XG5cbi8vIEhhY2sgZm9yIGBzcGlkZXJhYmxlYCBwYWNrYWdlOiBhIHdheSB0byBzZWUgaWYgdGhlIHBhZ2UgaXMgZG9uZVxuLy8gbG9hZGluZyBhbGwgdGhlIGRhdGEgaXQgbmVlZHMuXG4vL1xuRERQLl9hbGxTdWJzY3JpcHRpb25zUmVhZHkgPSAoKSA9PiBhbGxDb25uZWN0aW9ucy5ldmVyeShcbiAgY29ubiA9PiBPYmplY3QudmFsdWVzKGNvbm4uX3N1YnNjcmlwdGlvbnMpLmV2ZXJ5KHN1YiA9PiBzdWIucmVhZHkpXG4pO1xuIl19
