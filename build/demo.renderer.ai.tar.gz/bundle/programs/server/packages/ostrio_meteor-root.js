Package["core-runtime"].queue("ostrio:meteor-root",function () {/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var EmitterPromise = Package.meteor.EmitterPromise;
var ECMAScript = Package.ecmascript.ECMAScript;
var meteorInstall = Package.modules.meteorInstall;
var Promise = Package.promise.Promise;

var require = meteorInstall({"node_modules":{"meteor":{"ostrio:meteor-root":{"meteor-root.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                        //
// packages/ostrio_meteor-root/meteor-root.js                                             //
//                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////
                                                                                          //
!module.wrapAsync(async function (module, __reifyWaitForDeps__, __reify_async_result__) {
  "use strict";
  try {
    let Meteor;
    module.link("meteor/meteor", {
      Meteor(v) {
        Meteor = v;
      }
    }, 0);
    let path;
    module.link("path", {
      default(v) {
        path = v;
      }
    }, 1);
    if (__reifyWaitForDeps__()) (await __reifyWaitForDeps__())();
    Meteor.rootPath = path.resolve('.');
    Meteor.absolutePath = Meteor.rootPath.split("".concat(path.sep, ".meteor"))[0];
    __reify_async_result__();
  } catch (_reifyError) {
    return __reify_async_result__(_reifyError);
  }
  __reify_async_result__()
}, {
  self: this,
  async: false
});
////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});


/* Exports */
return {
  require: require,
  eagerModulePaths: [
    "/node_modules/meteor/ostrio:meteor-root/meteor-root.js"
  ],
  mainModulePath: "/node_modules/meteor/ostrio:meteor-root/meteor-root.js"
}});

//# sourceURL=meteor://💻app/packages/ostrio_meteor-root.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvb3N0cmlvOm1ldGVvci1yb290L21ldGVvci1yb290LmpzIl0sIm5hbWVzIjpbIk1ldGVvciIsIm1vZHVsZSIsImxpbmsiLCJ2IiwicGF0aCIsImRlZmF1bHQiLCJfX3JlaWZ5V2FpdEZvckRlcHNfXyIsInJvb3RQYXRoIiwicmVzb2x2ZSIsImFic29sdXRlUGF0aCIsInNwbGl0IiwiY29uY2F0Iiwic2VwIiwiX19yZWlmeV9hc3luY19yZXN1bHRfXyIsIl9yZWlmeUVycm9yIiwic2VsZiIsImFzeW5jIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztJQUFBLElBQUlBLE1BQU07SUFBQ0MsTUFBTSxDQUFDQyxJQUFJLENBQUMsZUFBZSxFQUFDO01BQUNGLE1BQU1BLENBQUNHLENBQUMsRUFBQztRQUFDSCxNQUFNLEdBQUNHLENBQUM7TUFBQTtJQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7SUFBQyxJQUFJQyxJQUFJO0lBQUNILE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLE1BQU0sRUFBQztNQUFDRyxPQUFPQSxDQUFDRixDQUFDLEVBQUM7UUFBQ0MsSUFBSSxHQUFDRCxDQUFDO01BQUE7SUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0lBQUMsSUFBSUcsb0JBQW9CLENBQUMsQ0FBQyxFQUFFLENBQUMsTUFBTUEsb0JBQW9CLENBQUMsQ0FBQyxFQUFFLENBQUM7SUFHaExOLE1BQU0sQ0FBQ08sUUFBUSxHQUFHSCxJQUFJLENBQUNJLE9BQU8sQ0FBQyxHQUFHLENBQUM7SUFDbkNSLE1BQU0sQ0FBQ1MsWUFBWSxHQUFHVCxNQUFNLENBQUNPLFFBQVEsQ0FBQ0csS0FBSyxJQUFBQyxNQUFBLENBQUlQLElBQUksQ0FBQ1EsR0FBRyxZQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFBQ0Msc0JBQUE7RUFBQSxTQUFBQyxXQUFBO0lBQUEsT0FBQUQsc0JBQUEsQ0FBQUMsV0FBQTtFQUFBO0VBQUFELHNCQUFBO0FBQUE7RUFBQUUsSUFBQTtFQUFBQyxLQUFBO0FBQUEsRyIsImZpbGUiOiIvcGFja2FnZXMvb3N0cmlvX21ldGVvci1yb290LmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgcGF0aCBmcm9tICdwYXRoJztcblxuTWV0ZW9yLnJvb3RQYXRoID0gcGF0aC5yZXNvbHZlKCcuJyk7XG5NZXRlb3IuYWJzb2x1dGVQYXRoID0gTWV0ZW9yLnJvb3RQYXRoLnNwbGl0KGAke3BhdGguc2VwfS5tZXRlb3JgKVswXTtcbiJdfQ==
