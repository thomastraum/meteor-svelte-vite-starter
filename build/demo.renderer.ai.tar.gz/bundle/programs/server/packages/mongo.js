Package["core-runtime"].queue("mongo",function () {/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var EmitterPromise = Package.meteor.EmitterPromise;
var NpmModuleMongodb = Package['npm-mongo'].NpmModuleMongodb;
var NpmModuleMongodbVersion = Package['npm-mongo'].NpmModuleMongodbVersion;
var AllowDeny = Package['allow-deny'].AllowDeny;
var Random = Package.random.Random;
var EJSON = Package.ejson.EJSON;
var LocalCollection = Package.minimongo.LocalCollection;
var Minimongo = Package.minimongo.Minimongo;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var DiffSequence = Package['diff-sequence'].DiffSequence;
var MongoID = Package['mongo-id'].MongoID;
var check = Package.check.check;
var Match = Package.check.Match;
var ECMAScript = Package.ecmascript.ECMAScript;
var Log = Package.logging.Log;
var Decimal = Package['mongo-decimal'].Decimal;
var _ = Package.underscore._;
var MaxHeap = Package['binary-heap'].MaxHeap;
var MinHeap = Package['binary-heap'].MinHeap;
var MinMaxHeap = Package['binary-heap'].MinMaxHeap;
var Hook = Package['callback-hook'].Hook;
var meteorInstall = Package.modules.meteorInstall;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var MongoInternals, MongoConnection, callback, CursorDescription, Cursor, listenAll, forEachTrigger, OPLOG_COLLECTION, idForOp, OplogHandle, ObserveMultiplexer, options, ObserveHandle, PollingObserveDriver, OplogObserveDriver, Mongo, selector;

var require = meteorInstall({"node_modules":{"meteor":{"mongo":{"mongo_driver.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/mongo/mongo_driver.js                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
!module.wrapAsync(async function (module1, __reifyWaitForDeps__, __reify_async_result__) {
  "use strict";
  try {
    let _objectSpread;
    module1.link("@babel/runtime/helpers/objectSpread2", {
      default(v) {
        _objectSpread = v;
      }
    }, 0);
    let normalizeProjection;
    module1.link("./mongo_utils", {
      normalizeProjection(v) {
        normalizeProjection = v;
      }
    }, 0);
    let DocFetcher;
    module1.link("./doc_fetcher.js", {
      DocFetcher(v) {
        DocFetcher = v;
      }
    }, 1);
    let ASYNC_CURSOR_METHODS, CLIENT_ONLY_METHODS, getAsyncMethodName;
    module1.link("meteor/minimongo/constants", {
      ASYNC_CURSOR_METHODS(v) {
        ASYNC_CURSOR_METHODS = v;
      },
      CLIENT_ONLY_METHODS(v) {
        CLIENT_ONLY_METHODS = v;
      },
      getAsyncMethodName(v) {
        getAsyncMethodName = v;
      }
    }, 2);
    let Meteor;
    module1.link("meteor/meteor", {
      Meteor(v) {
        Meteor = v;
      }
    }, 3);
    if (__reifyWaitForDeps__()) (await __reifyWaitForDeps__())();
    /**
     * Provide a synchronous Collection API using fibers, backed by
     * MongoDB.  This is only for use on the server, and mostly identical
     * to the client API.
     *
     * NOTE: the public API methods must be run within a fiber. If you call
     * these outside of a fiber they will explode!
     */

    const path = require("path");
    const util = require("util");

    /** @type {import('mongodb')} */
    var MongoDB = NpmModuleMongodb;
    MongoInternals = {};
    MongoInternals.__packageName = 'mongo';
    MongoInternals.NpmModules = {
      mongodb: {
        version: NpmModuleMongodbVersion,
        module: MongoDB
      }
    };

    // Older version of what is now available via
    // MongoInternals.NpmModules.mongodb.module.  It was never documented, but
    // people do use it.
    // XXX COMPAT WITH 1.0.3.2
    MongoInternals.NpmModule = MongoDB;
    const FILE_ASSET_SUFFIX = 'Asset';
    const ASSETS_FOLDER = 'assets';
    const APP_FOLDER = 'app';

    // This is used to add or remove EJSON from the beginning of everything nested
    // inside an EJSON custom type. It should only be called on pure JSON!
    var replaceNames = function (filter, thing) {
      if (typeof thing === "object" && thing !== null) {
        if (_.isArray(thing)) {
          return _.map(thing, _.bind(replaceNames, null, filter));
        }
        var ret = {};
        _.each(thing, function (value, key) {
          ret[filter(key)] = replaceNames(filter, value);
        });
        return ret;
      }
      return thing;
    };

    // Ensure that EJSON.clone keeps a Timestamp as a Timestamp (instead of just
    // doing a structural clone).
    // XXX how ok is this? what if there are multiple copies of MongoDB loaded?
    MongoDB.Timestamp.prototype.clone = function () {
      // Timestamps should be immutable.
      return this;
    };
    var makeMongoLegal = function (name) {
      return "EJSON" + name;
    };
    var unmakeMongoLegal = function (name) {
      return name.substr(5);
    };
    var replaceMongoAtomWithMeteor = function (document) {
      if (document instanceof MongoDB.Binary) {
        // for backwards compatibility
        if (document.sub_type !== 0) {
          return document;
        }
        var buffer = document.value(true);
        return new Uint8Array(buffer);
      }
      if (document instanceof MongoDB.ObjectID) {
        return new Mongo.ObjectID(document.toHexString());
      }
      if (document instanceof MongoDB.Decimal128) {
        return Decimal(document.toString());
      }
      if (document["EJSON$type"] && document["EJSON$value"] && _.size(document) === 2) {
        return EJSON.fromJSONValue(replaceNames(unmakeMongoLegal, document));
      }
      if (document instanceof MongoDB.Timestamp) {
        // For now, the Meteor representation of a Mongo timestamp type (not a date!
        // this is a weird internal thing used in the oplog!) is the same as the
        // Mongo representation. We need to do this explicitly or else we would do a
        // structural clone and lose the prototype.
        return document;
      }
      return undefined;
    };
    var replaceMeteorAtomWithMongo = function (document) {
      if (EJSON.isBinary(document)) {
        // This does more copies than we'd like, but is necessary because
        // MongoDB.BSON only looks like it takes a Uint8Array (and doesn't actually
        // serialize it correctly).
        return new MongoDB.Binary(Buffer.from(document));
      }
      if (document instanceof MongoDB.Binary) {
        return document;
      }
      if (document instanceof Mongo.ObjectID) {
        return new MongoDB.ObjectID(document.toHexString());
      }
      if (document instanceof MongoDB.Timestamp) {
        // For now, the Meteor representation of a Mongo timestamp type (not a date!
        // this is a weird internal thing used in the oplog!) is the same as the
        // Mongo representation. We need to do this explicitly or else we would do a
        // structural clone and lose the prototype.
        return document;
      }
      if (document instanceof Decimal) {
        return MongoDB.Decimal128.fromString(document.toString());
      }
      if (EJSON._isCustomType(document)) {
        return replaceNames(makeMongoLegal, EJSON.toJSONValue(document));
      }
      // It is not ordinarily possible to stick dollar-sign keys into mongo
      // so we don't bother checking for things that need escaping at this time.
      return undefined;
    };
    var replaceTypes = function (document, atomTransformer) {
      if (typeof document !== 'object' || document === null) return document;
      var replacedTopLevelAtom = atomTransformer(document);
      if (replacedTopLevelAtom !== undefined) return replacedTopLevelAtom;
      var ret = document;
      _.each(document, function (val, key) {
        var valReplaced = replaceTypes(val, atomTransformer);
        if (val !== valReplaced) {
          // Lazy clone. Shallow copy.
          if (ret === document) ret = _.clone(document);
          ret[key] = valReplaced;
        }
      });
      return ret;
    };
    MongoConnection = function (url, options) {
      var _Meteor$settings, _Meteor$settings$pack, _Meteor$settings$pack2;
      var self = this;
      options = options || {};
      self._observeMultiplexers = {};
      self._onFailoverHook = new Hook();
      const userOptions = _objectSpread(_objectSpread({}, Mongo._connectionOptions || {}), ((_Meteor$settings = Meteor.settings) === null || _Meteor$settings === void 0 ? void 0 : (_Meteor$settings$pack = _Meteor$settings.packages) === null || _Meteor$settings$pack === void 0 ? void 0 : (_Meteor$settings$pack2 = _Meteor$settings$pack.mongo) === null || _Meteor$settings$pack2 === void 0 ? void 0 : _Meteor$settings$pack2.options) || {});
      var mongoOptions = Object.assign({
        ignoreUndefined: true
      }, userOptions);

      // Internally the oplog connections specify their own maxPoolSize
      // which we don't want to overwrite with any user defined value
      if (_.has(options, 'maxPoolSize')) {
        // If we just set this for "server", replSet will override it. If we just
        // set it for replSet, it will be ignored if we're not using a replSet.
        mongoOptions.maxPoolSize = options.maxPoolSize;
      }
      if (_.has(options, 'minPoolSize')) {
        mongoOptions.minPoolSize = options.minPoolSize;
      }

      // Transform options like "tlsCAFileAsset": "filename.pem" into
      // "tlsCAFile": "/<fullpath>/filename.pem"
      Object.entries(mongoOptions || {}).filter(_ref => {
        let [key] = _ref;
        return key && key.endsWith(FILE_ASSET_SUFFIX);
      }).forEach(_ref2 => {
        let [key, value] = _ref2;
        const optionName = key.replace(FILE_ASSET_SUFFIX, '');
        mongoOptions[optionName] = path.join(Assets.getServerDir(), ASSETS_FOLDER, APP_FOLDER, value);
        delete mongoOptions[key];
      });
      self.db = null;
      self._oplogHandle = null;
      self._docFetcher = null;
      self.client = new MongoDB.MongoClient(url, mongoOptions);
      self.db = self.client.db();
      self.client.on('serverDescriptionChanged', Meteor.bindEnvironment(event => {
        // When the connection is no longer against the primary node, execute all
        // failover hooks. This is important for the driver as it has to re-pool the
        // query when it happens.
        if (event.previousDescription.type !== 'RSPrimary' && event.newDescription.type === 'RSPrimary') {
          self._onFailoverHook.each(callback => {
            callback();
            return true;
          });
        }
      }));
      if (options.oplogUrl && !Package['disable-oplog']) {
        self._oplogHandle = new OplogHandle(options.oplogUrl, self.db.databaseName);
        self._docFetcher = new DocFetcher(self);
      }
    };
    MongoConnection.prototype._close = async function () {
      var self = this;
      if (!self.db) throw Error("close called before Connection created?");

      // XXX probably untested
      var oplogHandle = self._oplogHandle;
      self._oplogHandle = null;
      if (oplogHandle) await oplogHandle.stop();

      // Use Future.wrap so that errors get thrown. This happens to
      // work even outside a fiber since the 'close' method is not
      // actually asynchronous.
      await self.client.close();
    };
    MongoConnection.prototype.close = function () {
      return this._close();
    };
    MongoConnection.prototype._setOplogHandle = function (oplogHandle) {
      this._oplogHandle = oplogHandle;
      return this;
    };

    // Returns the Mongo Collection object; may yield.
    MongoConnection.prototype.rawCollection = function (collectionName) {
      var self = this;
      if (!self.db) throw Error("rawCollection called before Connection created?");
      return self.db.collection(collectionName);
    };
    MongoConnection.prototype.createCappedCollectionAsync = async function (collectionName, byteSize, maxDocuments) {
      var self = this;
      if (!self.db) throw Error("createCappedCollectionAsync called before Connection created?");
      await self.db.createCollection(collectionName, {
        capped: true,
        size: byteSize,
        max: maxDocuments
      });
    };

    // This should be called synchronously with a write, to create a
    // transaction on the current write fence, if any. After we can read
    // the write, and after observers have been notified (or at least,
    // after the observer notifiers have added themselves to the write
    // fence), you should call 'committed()' on the object returned.
    MongoConnection.prototype._maybeBeginWrite = function () {
      const fence = DDPServer._getCurrentFence();
      if (fence) {
        return fence.beginWrite();
      } else {
        return {
          committed: function () {}
        };
      }
    };

    // Internal interface: adds a callback which is called when the Mongo primary
    // changes. Returns a stop handle.
    MongoConnection.prototype._onFailover = function (callback) {
      return this._onFailoverHook.register(callback);
    };

    //////////// Public API //////////

    // The write methods block until the database has confirmed the write (it may
    // not be replicated or stable on disk, but one server has confirmed it) if no
    // callback is provided. If a callback is provided, then they call the callback
    // when the write is confirmed. They return nothing on success, and raise an
    // exception on failure.
    //
    // After making a write (with insert, update, remove), observers are
    // notified asynchronously. If you want to receive a callback once all
    // of the observer notifications have landed for your write, do the
    // writes inside a write fence (set DDPServer._CurrentWriteFence to a new
    // _WriteFence, and then set a callback on the write fence.)
    //
    // Since our execution environment is single-threaded, this is
    // well-defined -- a write "has been made" if it's returned, and an
    // observer "has been notified" if its callback has returned.

    var writeCallback = function (write, refresh, callback) {
      return function (err, result) {
        if (!err) {
          // XXX We don't have to run this on error, right?
          try {
            refresh();
          } catch (refreshErr) {
            if (callback) {
              callback(refreshErr);
              return;
            } else {
              throw refreshErr;
            }
          }
        }
        write.committed();
        if (callback) {
          callback(err, result);
        } else if (err) {
          throw err;
        }
      };
    };
    var bindEnvironmentForWrite = function (callback) {
      return Meteor.bindEnvironment(callback, "Mongo write");
    };
    MongoConnection.prototype.insertAsync = async function (collection_name, document) {
      const self = this;
      if (collection_name === "___meteor_failure_test_collection") {
        const e = new Error("Failure test");
        e._expectedByTest = true;
        throw e;
      }
      if (!(LocalCollection._isPlainObject(document) && !EJSON._isCustomType(document))) {
        throw new Error("Only plain objects may be inserted into MongoDB");
      }
      var write = self._maybeBeginWrite();
      var refresh = async function () {
        await Meteor.refresh({
          collection: collection_name,
          id: document._id
        });
      };
      return self.rawCollection(collection_name).insertOne(replaceTypes(document, replaceMeteorAtomWithMongo), {
        safe: true
      }).then(async _ref3 => {
        let {
          insertedId
        } = _ref3;
        await refresh();
        await write.committed();
        return insertedId;
      }).catch(async e => {
        await write.committed();
        throw e;
      });
    };

    // Cause queries that may be affected by the selector to poll in this write
    // fence.
    MongoConnection.prototype._refresh = async function (collectionName, selector) {
      var refreshKey = {
        collection: collectionName
      };
      // If we know which documents we're removing, don't poll queries that are
      // specific to other documents. (Note that multiple notifications here should
      // not cause multiple polls, since all our listener is doing is enqueueing a
      // poll.)
      var specificIds = LocalCollection._idsMatchedBySelector(selector);
      if (specificIds) {
        for (const id of specificIds) {
          await Meteor.refresh(_.extend({
            id: id
          }, refreshKey));
        }
      } else {
        await Meteor.refresh(refreshKey);
      }
    };
    MongoConnection.prototype.removeAsync = async function (collection_name, selector) {
      var self = this;
      if (collection_name === "___meteor_failure_test_collection") {
        var e = new Error("Failure test");
        e._expectedByTest = true;
        throw e;
      }
      var write = self._maybeBeginWrite();
      var refresh = async function () {
        await self._refresh(collection_name, selector);
      };
      return self.rawCollection(collection_name).deleteMany(replaceTypes(selector, replaceMeteorAtomWithMongo), {
        safe: true
      }).then(async _ref4 => {
        let {
          deletedCount
        } = _ref4;
        await refresh();
        await write.committed();
        return transformResult({
          result: {
            modifiedCount: deletedCount
          }
        }).numberAffected;
      }).catch(async err => {
        await write.committed();
        throw err;
      });
    };
    MongoConnection.prototype.dropCollectionAsync = async function (collectionName) {
      var self = this;
      var write = self._maybeBeginWrite();
      var refresh = function () {
        return Meteor.refresh({
          collection: collectionName,
          id: null,
          dropCollection: true
        });
      };
      return self.rawCollection(collectionName).drop().then(async result => {
        await refresh();
        await write.committed();
        return result;
      }).catch(async e => {
        await write.committed();
        throw e;
      });
    };

    // For testing only.  Slightly better than `c.rawDatabase().dropDatabase()`
    // because it lets the test's fence wait for it to be complete.
    MongoConnection.prototype.dropDatabaseAsync = async function () {
      var self = this;
      var write = self._maybeBeginWrite();
      var refresh = async function () {
        await Meteor.refresh({
          dropDatabase: true
        });
      };
      try {
        await self.db._dropDatabase();
        await refresh();
        await write.committed();
      } catch (e) {
        await write.committed();
        throw e;
      }
    };
    MongoConnection.prototype.updateAsync = async function (collection_name, selector, mod, options) {
      var self = this;
      if (collection_name === "___meteor_failure_test_collection") {
        var e = new Error("Failure test");
        e._expectedByTest = true;
        throw e;
      }

      // explicit safety check. null and undefined can crash the mongo
      // driver. Although the node driver and minimongo do 'support'
      // non-object modifier in that they don't crash, they are not
      // meaningful operations and do not do anything. Defensively throw an
      // error here.
      if (!mod || typeof mod !== 'object') {
        const error = new Error("Invalid modifier. Modifier must be an object.");
        throw error;
      }
      if (!(LocalCollection._isPlainObject(mod) && !EJSON._isCustomType(mod))) {
        const error = new Error("Only plain objects may be used as replacement" + " documents in MongoDB");
        throw error;
      }
      if (!options) options = {};
      var write = self._maybeBeginWrite();
      var refresh = async function () {
        await self._refresh(collection_name, selector);
      };
      var collection = self.rawCollection(collection_name);
      var mongoOpts = {
        safe: true
      };
      // Add support for filtered positional operator
      if (options.arrayFilters !== undefined) mongoOpts.arrayFilters = options.arrayFilters;
      // explictly enumerate options that minimongo supports
      if (options.upsert) mongoOpts.upsert = true;
      if (options.multi) mongoOpts.multi = true;
      // Lets you get a more more full result from MongoDB. Use with caution:
      // might not work with C.upsert (as opposed to C.update({upsert:true}) or
      // with simulated upsert.
      if (options.fullResult) mongoOpts.fullResult = true;
      var mongoSelector = replaceTypes(selector, replaceMeteorAtomWithMongo);
      var mongoMod = replaceTypes(mod, replaceMeteorAtomWithMongo);
      var isModify = LocalCollection._isModificationMod(mongoMod);
      if (options._forbidReplace && !isModify) {
        var err = new Error("Invalid modifier. Replacements are forbidden.");
        throw err;
      }

      // We've already run replaceTypes/replaceMeteorAtomWithMongo on
      // selector and mod.  We assume it doesn't matter, as far as
      // the behavior of modifiers is concerned, whether `_modify`
      // is run on EJSON or on mongo-converted EJSON.

      // Run this code up front so that it fails fast if someone uses
      // a Mongo update operator we don't support.
      let knownId;
      if (options.upsert) {
        try {
          let newDoc = LocalCollection._createUpsertDocument(selector, mod);
          knownId = newDoc._id;
        } catch (err) {
          throw err;
        }
      }
      if (options.upsert && !isModify && !knownId && options.insertedId && !(options.insertedId instanceof Mongo.ObjectID && options.generatedId)) {
        // In case of an upsert with a replacement, where there is no _id defined
        // in either the query or the replacement doc, mongo will generate an id itself.
        // Therefore we need this special strategy if we want to control the id ourselves.

        // We don't need to do this when:
        // - This is not a replacement, so we can add an _id to $setOnInsert
        // - The id is defined by query or mod we can just add it to the replacement doc
        // - The user did not specify any id preference and the id is a Mongo ObjectId,
        //     then we can just let Mongo generate the id
        return await simulateUpsertWithInsertedId(collection, mongoSelector, mongoMod, options).then(async result => {
          await refresh();
          await write.committed();
          if (result && !options._returnObject) {
            return result.numberAffected;
          } else {
            return result;
          }
        });
      } else {
        if (options.upsert && !knownId && options.insertedId && isModify) {
          if (!mongoMod.hasOwnProperty('$setOnInsert')) {
            mongoMod.$setOnInsert = {};
          }
          knownId = options.insertedId;
          Object.assign(mongoMod.$setOnInsert, replaceTypes({
            _id: options.insertedId
          }, replaceMeteorAtomWithMongo));
        }
        const strings = Object.keys(mongoMod).filter(key => !key.startsWith("$"));
        let updateMethod = strings.length > 0 ? 'replaceOne' : 'updateMany';
        updateMethod = updateMethod === 'updateMany' && !mongoOpts.multi ? 'updateOne' : updateMethod;
        return collection[updateMethod].bind(collection)(mongoSelector, mongoMod, mongoOpts).then(async result => {
          var meteorResult = transformResult({
            result
          });
          if (meteorResult && options._returnObject) {
            // If this was an upsertAsync() call, and we ended up
            // inserting a new doc and we know its id, then
            // return that id as well.
            if (options.upsert && meteorResult.insertedId) {
              if (knownId) {
                meteorResult.insertedId = knownId;
              } else if (meteorResult.insertedId instanceof MongoDB.ObjectID) {
                meteorResult.insertedId = new Mongo.ObjectID(meteorResult.insertedId.toHexString());
              }
            }
            await refresh();
            await write.committed();
            return meteorResult;
          } else {
            await refresh();
            await write.committed();
            return meteorResult.numberAffected;
          }
        }).catch(async err => {
          await write.committed();
          throw err;
        });
      }
    };
    var transformResult = function (driverResult) {
      var meteorResult = {
        numberAffected: 0
      };
      if (driverResult) {
        var mongoResult = driverResult.result;
        // On updates with upsert:true, the inserted values come as a list of
        // upserted values -- even with options.multi, when the upsert does insert,
        // it only inserts one element.
        if (mongoResult.upsertedCount) {
          meteorResult.numberAffected = mongoResult.upsertedCount;
          if (mongoResult.upsertedId) {
            meteorResult.insertedId = mongoResult.upsertedId;
          }
        } else {
          // n was used before Mongo 5.0, in Mongo 5.0 we are not receiving this n
          // field and so we are using modifiedCount instead
          meteorResult.numberAffected = mongoResult.n || mongoResult.matchedCount || mongoResult.modifiedCount;
        }
      }
      return meteorResult;
    };
    var NUM_OPTIMISTIC_TRIES = 3;

    // exposed for testing
    MongoConnection._isCannotChangeIdError = function (err) {
      // Mongo 3.2.* returns error as next Object:
      // {name: String, code: Number, errmsg: String}
      // Older Mongo returns:
      // {name: String, code: Number, err: String}
      var error = err.errmsg || err.err;

      // We don't use the error code here
      // because the error code we observed it producing (16837) appears to be
      // a far more generic error code based on examining the source.
      if (error.indexOf('The _id field cannot be changed') === 0 || error.indexOf("the (immutable) field '_id' was found to have been altered to _id") !== -1) {
        return true;
      }
      return false;
    };
    var simulateUpsertWithInsertedId = async function (collection, selector, mod, options) {
      // STRATEGY: First try doing an upsert with a generated ID.
      // If this throws an error about changing the ID on an existing document
      // then without affecting the database, we know we should probably try
      // an update without the generated ID. If it affected 0 documents,
      // then without affecting the database, we the document that first
      // gave the error is probably removed and we need to try an insert again
      // We go back to step one and repeat.
      // Like all "optimistic write" schemes, we rely on the fact that it's
      // unlikely our writes will continue to be interfered with under normal
      // circumstances (though sufficiently heavy contention with writers
      // disagreeing on the existence of an object will cause writes to fail
      // in theory).

      var insertedId = options.insertedId; // must exist
      var mongoOptsForUpdate = {
        safe: true,
        multi: options.multi
      };
      var mongoOptsForInsert = {
        safe: true,
        upsert: true
      };
      var replacementWithId = Object.assign(replaceTypes({
        _id: insertedId
      }, replaceMeteorAtomWithMongo), mod);
      var tries = NUM_OPTIMISTIC_TRIES;
      var doUpdate = async function () {
        tries--;
        if (!tries) {
          throw new Error("Upsert failed after " + NUM_OPTIMISTIC_TRIES + " tries.");
        } else {
          let method = collection.updateMany;
          if (!Object.keys(mod).some(key => key.startsWith("$"))) {
            method = collection.replaceOne.bind(collection);
          }
          return method(selector, mod, mongoOptsForUpdate).then(result => {
            if (result && (result.modifiedCount || result.upsertedCount)) {
              return {
                numberAffected: result.modifiedCount || result.upsertedCount,
                insertedId: result.upsertedId || undefined
              };
            } else {
              return doConditionalInsert();
            }
          });
        }
      };
      var doConditionalInsert = function () {
        return collection.replaceOne(selector, replacementWithId, mongoOptsForInsert).then(result => ({
          numberAffected: result.upsertedCount,
          insertedId: result.upsertedId
        })).catch(err => {
          if (MongoConnection._isCannotChangeIdError(err)) {
            return doUpdate();
          } else {
            throw err;
          }
        });
      };
      return doUpdate();
    };

    // XXX MongoConnection.upsertAsync() does not return the id of the inserted document
    // unless you set it explicitly in the selector or modifier (as a replacement
    // doc).
    MongoConnection.prototype.upsertAsync = async function (collectionName, selector, mod, options) {
      var self = this;
      if (typeof options === "function" && !callback) {
        callback = options;
        options = {};
      }
      return self.updateAsync(collectionName, selector, mod, _.extend({}, options, {
        upsert: true,
        _returnObject: true
      }));
    };
    MongoConnection.prototype.find = function (collectionName, selector, options) {
      var self = this;
      if (arguments.length === 1) selector = {};
      return new Cursor(self, new CursorDescription(collectionName, selector, options));
    };
    MongoConnection.prototype.findOneAsync = async function (collection_name, selector, options) {
      var self = this;
      if (arguments.length === 1) {
        selector = {};
      }
      options = options || {};
      options.limit = 1;
      const results = await self.find(collection_name, selector, options).fetch();
      return results[0];
    };

    // We'll actually design an index API later. For now, we just pass through to
    // Mongo's, but make it synchronous.
    MongoConnection.prototype.createIndexAsync = async function (collectionName, index, options) {
      var self = this;

      // We expect this function to be called at startup, not from within a method,
      // so we don't interact with the write fence.
      var collection = self.rawCollection(collectionName);
      await collection.createIndex(index, options);
    };

    // just to be consistent with the other methods
    MongoConnection.prototype.createIndex = MongoConnection.prototype.createIndexAsync;
    MongoConnection.prototype.countDocuments = function (collectionName) {
      for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
        args[_key - 1] = arguments[_key];
      }
      args = args.map(arg => replaceTypes(arg, replaceMeteorAtomWithMongo));
      const collection = this.rawCollection(collectionName);
      return collection.countDocuments(...args);
    };
    MongoConnection.prototype.estimatedDocumentCount = function (collectionName) {
      for (var _len2 = arguments.length, args = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
        args[_key2 - 1] = arguments[_key2];
      }
      args = args.map(arg => replaceTypes(arg, replaceMeteorAtomWithMongo));
      const collection = this.rawCollection(collectionName);
      return collection.estimatedDocumentCount(...args);
    };
    MongoConnection.prototype.ensureIndexAsync = MongoConnection.prototype.createIndexAsync;
    MongoConnection.prototype.dropIndexAsync = async function (collectionName, index) {
      var self = this;

      // This function is only used by test code, not within a method, so we don't
      // interact with the write fence.
      var collection = self.rawCollection(collectionName);
      var indexName = await collection.dropIndex(index);
    };
    CLIENT_ONLY_METHODS.forEach(function (m) {
      MongoConnection.prototype[m] = function () {
        throw new Error("".concat(m, " +  is not available on the server. Please use ").concat(getAsyncMethodName(m), "() instead."));
      };
    });

    // CURSORS

    // There are several classes which relate to cursors:
    //
    // CursorDescription represents the arguments used to construct a cursor:
    // collectionName, selector, and (find) options.  Because it is used as a key
    // for cursor de-dup, everything in it should either be JSON-stringifiable or
    // not affect observeChanges output (eg, options.transform functions are not
    // stringifiable but do not affect observeChanges).
    //
    // SynchronousCursor is a wrapper around a MongoDB cursor
    // which includes fully-synchronous versions of forEach, etc.
    //
    // Cursor is the cursor object returned from find(), which implements the
    // documented Mongo.Collection cursor API.  It wraps a CursorDescription and a
    // SynchronousCursor (lazily: it doesn't contact Mongo until you call a method
    // like fetch or forEach on it).
    //
    // ObserveHandle is the "observe handle" returned from observeChanges. It has a
    // reference to an ObserveMultiplexer.
    //
    // ObserveMultiplexer allows multiple identical ObserveHandles to be driven by a
    // single observe driver.
    //
    // There are two "observe drivers" which drive ObserveMultiplexers:
    //   - PollingObserveDriver caches the results of a query and reruns it when
    //     necessary.
    //   - OplogObserveDriver follows the Mongo operation log to directly observe
    //     database changes.
    // Both implementations follow the same simple interface: when you create them,
    // they start sending observeChanges callbacks (and a ready() invocation) to
    // their ObserveMultiplexer, and you stop them by calling their stop() method.

    CursorDescription = function (collectionName, selector, options) {
      var self = this;
      self.collectionName = collectionName;
      self.selector = Mongo.Collection._rewriteSelector(selector);
      self.options = options || {};
    };
    Cursor = function (mongo, cursorDescription) {
      var self = this;
      self._mongo = mongo;
      self._cursorDescription = cursorDescription;
      self._synchronousCursor = null;
    };
    function setupSynchronousCursor(cursor, method) {
      // You can only observe a tailable cursor.
      if (cursor._cursorDescription.options.tailable) throw new Error('Cannot call ' + method + ' on a tailable cursor');
      if (!cursor._synchronousCursor) {
        cursor._synchronousCursor = cursor._mongo._createSynchronousCursor(cursor._cursorDescription, {
          // Make sure that the "cursor" argument to forEach/map callbacks is the
          // Cursor, not the SynchronousCursor.
          selfForIteration: cursor,
          useTransform: true
        });
      }
      return cursor._synchronousCursor;
    }
    Cursor.prototype.countAsync = async function () {
      const collection = this._mongo.rawCollection(this._cursorDescription.collectionName);
      return await collection.countDocuments(replaceTypes(this._cursorDescription.selector, replaceMeteorAtomWithMongo), replaceTypes(this._cursorDescription.options, replaceMeteorAtomWithMongo));
    };
    Cursor.prototype.count = function () {
      throw new Error("count() is not avaible on the server. Please use countAsync() instead.");
    };
    [...ASYNC_CURSOR_METHODS, Symbol.iterator, Symbol.asyncIterator].forEach(methodName => {
      // count is handled specially since we don't want to create a cursor.
      // it is still included in ASYNC_CURSOR_METHODS because we still want an async version of it to exist.
      if (methodName === 'count') {
        return;
      }
      Cursor.prototype[methodName] = function () {
        const cursor = setupSynchronousCursor(this, methodName);
        return cursor[methodName](...arguments);
      };

      // These methods are handled separately.
      if (methodName === Symbol.iterator || methodName === Symbol.asyncIterator) {
        return;
      }
      const methodNameAsync = getAsyncMethodName(methodName);
      Cursor.prototype[methodNameAsync] = function () {
        try {
          return Promise.resolve(this[methodName](...arguments));
        } catch (error) {
          return Promise.reject(error);
        }
      };
    });
    Cursor.prototype.getTransform = function () {
      return this._cursorDescription.options.transform;
    };

    // When you call Meteor.publish() with a function that returns a Cursor, we need
    // to transmute it into the equivalent subscription.  This is the function that
    // does that.
    Cursor.prototype._publishCursor = function (sub) {
      var self = this;
      var collection = self._cursorDescription.collectionName;
      return Mongo.Collection._publishCursor(self, sub, collection);
    };

    // Used to guarantee that publish functions return at most one cursor per
    // collection. Private, because we might later have cursors that include
    // documents from multiple collections somehow.
    Cursor.prototype._getCollectionName = function () {
      var self = this;
      return self._cursorDescription.collectionName;
    };
    Cursor.prototype.observe = function (callbacks) {
      var self = this;
      return LocalCollection._observeFromObserveChanges(self, callbacks);
    };
    Cursor.prototype.observeAsync = function (callbacks) {
      return new Promise(resolve => resolve(this.observe(callbacks)));
    };
    Cursor.prototype.observeChanges = function (callbacks) {
      let options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
      var self = this;
      var methods = ['addedAt', 'added', 'changedAt', 'changed', 'removedAt', 'removed', 'movedTo'];
      var ordered = LocalCollection._observeChangesCallbacksAreOrdered(callbacks);
      let exceptionName = callbacks._fromObserve ? 'observe' : 'observeChanges';
      exceptionName += ' callback';
      methods.forEach(function (method) {
        if (callbacks[method] && typeof callbacks[method] == "function") {
          callbacks[method] = Meteor.bindEnvironment(callbacks[method], method + exceptionName);
        }
      });
      return self._mongo._observeChanges(self._cursorDescription, ordered, callbacks, options.nonMutatingCallbacks);
    };
    Cursor.prototype.observeChangesAsync = async function (callbacks) {
      let options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
      return this.observeChanges(callbacks, options);
    };
    MongoConnection.prototype._createSynchronousCursor = function (cursorDescription, options) {
      var self = this;
      options = _.pick(options || {}, 'selfForIteration', 'useTransform');
      var collection = self.rawCollection(cursorDescription.collectionName);
      var cursorOptions = cursorDescription.options;
      var mongoOptions = {
        sort: cursorOptions.sort,
        limit: cursorOptions.limit,
        skip: cursorOptions.skip,
        projection: cursorOptions.fields || cursorOptions.projection,
        readPreference: cursorOptions.readPreference
      };

      // Do we want a tailable cursor (which only works on capped collections)?
      if (cursorOptions.tailable) {
        mongoOptions.numberOfRetries = -1;
      }
      var dbCursor = collection.find(replaceTypes(cursorDescription.selector, replaceMeteorAtomWithMongo), mongoOptions);

      // Do we want a tailable cursor (which only works on capped collections)?
      if (cursorOptions.tailable) {
        // We want a tailable cursor...
        dbCursor.addCursorFlag("tailable", true);
        // ... and for the server to wait a bit if any getMore has no data (rather
        // than making us put the relevant sleeps in the client)...
        dbCursor.addCursorFlag("awaitData", true);

        // And if this is on the oplog collection and the cursor specifies a 'ts',
        // then set the undocumented oplog replay flag, which does a special scan to
        // find the first document (instead of creating an index on ts). This is a
        // very hard-coded Mongo flag which only works on the oplog collection and
        // only works with the ts field.
        if (cursorDescription.collectionName === OPLOG_COLLECTION && cursorDescription.selector.ts) {
          dbCursor.addCursorFlag("oplogReplay", true);
        }
      }
      if (typeof cursorOptions.maxTimeMs !== 'undefined') {
        dbCursor = dbCursor.maxTimeMS(cursorOptions.maxTimeMs);
      }
      if (typeof cursorOptions.hint !== 'undefined') {
        dbCursor = dbCursor.hint(cursorOptions.hint);
      }
      return new AsynchronousCursor(dbCursor, cursorDescription, options, collection);
    };

    /**
     * This is just a light wrapper for the cursor. The goal here is to ensure compatibility even if
     * there are breaking changes on the MongoDB driver.
     *
     * @constructor
     */
    class AsynchronousCursor {
      constructor(dbCursor, cursorDescription, options) {
        this._dbCursor = dbCursor;
        this._cursorDescription = cursorDescription;
        this._selfForIteration = options.selfForIteration || this;
        if (options.useTransform && cursorDescription.options.transform) {
          this._transform = LocalCollection.wrapTransform(cursorDescription.options.transform);
        } else {
          this._transform = null;
        }
        this._visitedIds = new LocalCollection._IdMap();
      }
      [Symbol.asyncIterator]() {
        var cursor = this;
        return {
          async next() {
            const value = await cursor._nextObjectPromise();
            return {
              done: !value,
              value
            };
          }
        };
      }

      // Returns a Promise for the next object from the underlying cursor (before
      // the Mongo->Meteor type replacement).
      async _rawNextObjectPromise() {
        try {
          return this._dbCursor.next();
        } catch (e) {
          console.error(e);
        }
      }

      // Returns a Promise for the next object from the cursor, skipping those whose
      // IDs we've already seen and replacing Mongo atoms with Meteor atoms.
      async _nextObjectPromise() {
        while (true) {
          var doc = await this._rawNextObjectPromise();
          if (!doc) return null;
          doc = replaceTypes(doc, replaceMongoAtomWithMeteor);
          if (!this._cursorDescription.options.tailable && _.has(doc, '_id')) {
            // Did Mongo give us duplicate documents in the same cursor? If so,
            // ignore this one. (Do this before the transform, since transform might
            // return some unrelated value.) We don't do this for tailable cursors,
            // because we want to maintain O(1) memory usage. And if there isn't _id
            // for some reason (maybe it's the oplog), then we don't do this either.
            // (Be careful to do this for falsey but existing _id, though.)
            if (this._visitedIds.has(doc._id)) continue;
            this._visitedIds.set(doc._id, true);
          }
          if (this._transform) doc = this._transform(doc);
          return doc;
        }
      }

      // Returns a promise which is resolved with the next object (like with
      // _nextObjectPromise) or rejected if the cursor doesn't return within
      // timeoutMS ms.
      _nextObjectPromiseWithTimeout(timeoutMS) {
        if (!timeoutMS) {
          return this._nextObjectPromise();
        }
        const nextObjectPromise = this._nextObjectPromise();
        const timeoutErr = new Error('Client-side timeout waiting for next object');
        const timeoutPromise = new Promise((resolve, reject) => {
          setTimeout(() => {
            reject(timeoutErr);
          }, timeoutMS);
        });
        return Promise.race([nextObjectPromise, timeoutPromise]).catch(err => {
          if (err === timeoutErr) {
            this.close();
          }
          throw err;
        });
      }
      async forEach(callback, thisArg) {
        // Get back to the beginning.
        this._rewind();
        let idx = 0;
        while (true) {
          const doc = await this._nextObjectPromise();
          if (!doc) return;
          await callback.call(thisArg, doc, idx++, this._selfForIteration);
        }
      }
      async map(callback, thisArg) {
        const results = [];
        await this.forEach(async (doc, index) => {
          results.push(await callback.call(thisArg, doc, index, this._selfForIteration));
        });
        return results;
      }
      _rewind() {
        // known to be synchronous
        this._dbCursor.rewind();
        this._visitedIds = new LocalCollection._IdMap();
      }

      // Mostly usable for tailable cursors.
      close() {
        this._dbCursor.close();
      }
      fetch() {
        return this.map(_.identity);
      }

      /**
       * FIXME: (node:34680) [MONGODB DRIVER] Warning: cursor.count is deprecated and will be
       *  removed in the next major version, please use `collection.estimatedDocumentCount` or
       *  `collection.countDocuments` instead.
       */
      count() {
        return this._dbCursor.count();
      }

      // This method is NOT wrapped in Cursor.
      async getRawObjects(ordered) {
        var self = this;
        if (ordered) {
          return self.fetch();
        } else {
          var results = new LocalCollection._IdMap();
          await self.forEach(function (doc) {
            results.set(doc._id, doc);
          });
          return results;
        }
      }
    }
    var SynchronousCursor = function (dbCursor, cursorDescription, options, collection) {
      var self = this;
      options = _.pick(options || {}, 'selfForIteration', 'useTransform');
      self._dbCursor = dbCursor;
      self._cursorDescription = cursorDescription;
      // The "self" argument passed to forEach/map callbacks. If we're wrapped
      // inside a user-visible Cursor, we want to provide the outer cursor!
      self._selfForIteration = options.selfForIteration || self;
      if (options.useTransform && cursorDescription.options.transform) {
        self._transform = LocalCollection.wrapTransform(cursorDescription.options.transform);
      } else {
        self._transform = null;
      }
      self._synchronousCount = Future.wrap(collection.countDocuments.bind(collection, replaceTypes(cursorDescription.selector, replaceMeteorAtomWithMongo), replaceTypes(cursorDescription.options, replaceMeteorAtomWithMongo)));
      self._visitedIds = new LocalCollection._IdMap();
    };
    _.extend(SynchronousCursor.prototype, {
      // Returns a Promise for the next object from the underlying cursor (before
      // the Mongo->Meteor type replacement).
      _rawNextObjectPromise: function () {
        const self = this;
        return new Promise((resolve, reject) => {
          self._dbCursor.next((err, doc) => {
            if (err) {
              reject(err);
            } else {
              resolve(doc);
            }
          });
        });
      },
      // Returns a Promise for the next object from the cursor, skipping those whose
      // IDs we've already seen and replacing Mongo atoms with Meteor atoms.
      _nextObjectPromise: async function () {
        var self = this;
        while (true) {
          var doc = await self._rawNextObjectPromise();
          if (!doc) return null;
          doc = replaceTypes(doc, replaceMongoAtomWithMeteor);
          if (!self._cursorDescription.options.tailable && _.has(doc, '_id')) {
            // Did Mongo give us duplicate documents in the same cursor? If so,
            // ignore this one. (Do this before the transform, since transform might
            // return some unrelated value.) We don't do this for tailable cursors,
            // because we want to maintain O(1) memory usage. And if there isn't _id
            // for some reason (maybe it's the oplog), then we don't do this either.
            // (Be careful to do this for falsey but existing _id, though.)
            if (self._visitedIds.has(doc._id)) continue;
            self._visitedIds.set(doc._id, true);
          }
          if (self._transform) doc = self._transform(doc);
          return doc;
        }
      },
      // Returns a promise which is resolved with the next object (like with
      // _nextObjectPromise) or rejected if the cursor doesn't return within
      // timeoutMS ms.
      _nextObjectPromiseWithTimeout: function (timeoutMS) {
        const self = this;
        if (!timeoutMS) {
          return self._nextObjectPromise();
        }
        const nextObjectPromise = self._nextObjectPromise();
        const timeoutErr = new Error('Client-side timeout waiting for next object');
        const timeoutPromise = new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            reject(timeoutErr);
          }, timeoutMS);
        });
        return Promise.race([nextObjectPromise, timeoutPromise]).catch(err => {
          if (err === timeoutErr) {
            self.close();
          }
          throw err;
        });
      },
      _nextObject: function () {
        var self = this;
        return self._nextObjectPromise().await();
      },
      forEach: function (callback, thisArg) {
        var self = this;
        const wrappedFn = Meteor.wrapFn(callback);

        // Get back to the beginning.
        self._rewind();

        // We implement the loop ourself instead of using self._dbCursor.each,
        // because "each" will call its callback outside of a fiber which makes it
        // much more complex to make this function synchronous.
        var index = 0;
        while (true) {
          var doc = self._nextObject();
          if (!doc) return;
          wrappedFn.call(thisArg, doc, index++, self._selfForIteration);
        }
      },
      // XXX Allow overlapping callback executions if callback yields.
      map: function (callback, thisArg) {
        var self = this;
        const wrappedFn = Meteor.wrapFn(callback);
        var res = [];
        self.forEach(function (doc, index) {
          res.push(wrappedFn.call(thisArg, doc, index, self._selfForIteration));
        });
        return res;
      },
      _rewind: function () {
        var self = this;

        // known to be synchronous
        self._dbCursor.rewind();
        self._visitedIds = new LocalCollection._IdMap();
      },
      // Mostly usable for tailable cursors.
      close: function () {
        var self = this;
        self._dbCursor.close();
      },
      fetch: function () {
        var self = this;
        return self.map(_.identity);
      },
      count: function () {
        var self = this;
        return self._synchronousCount().wait();
      },
      // This method is NOT wrapped in Cursor.
      getRawObjects: function (ordered) {
        var self = this;
        if (ordered) {
          return self.fetch();
        } else {
          var results = new LocalCollection._IdMap();
          self.forEach(function (doc) {
            results.set(doc._id, doc);
          });
          return results;
        }
      }
    });
    SynchronousCursor.prototype[Symbol.iterator] = function () {
      var self = this;

      // Get back to the beginning.
      self._rewind();
      return {
        next() {
          const doc = self._nextObject();
          return doc ? {
            value: doc
          } : {
            done: true
          };
        }
      };
    };
    SynchronousCursor.prototype[Symbol.asyncIterator] = function () {
      const syncResult = this[Symbol.iterator]();
      return {
        async next() {
          return Promise.resolve(syncResult.next());
        }
      };
    };

    // Tails the cursor described by cursorDescription, most likely on the
    // oplog. Calls docCallback with each document found. Ignores errors and just
    // restarts the tail on error.
    //
    // If timeoutMS is set, then if we don't get a new document every timeoutMS,
    // kill and restart the cursor. This is primarily a workaround for #8598.
    MongoConnection.prototype.tail = function (cursorDescription, docCallback, timeoutMS) {
      var self = this;
      if (!cursorDescription.options.tailable) throw new Error("Can only tail a tailable cursor");
      var cursor = self._createSynchronousCursor(cursorDescription);
      var stopped = false;
      var lastTS;
      Meteor.defer(async function loop() {
        var doc = null;
        while (true) {
          if (stopped) return;
          try {
            doc = await cursor._nextObjectPromiseWithTimeout(timeoutMS);
          } catch (err) {
            // There's no good way to figure out if this was actually an error from
            // Mongo, or just client-side (including our own timeout error). Ah
            // well. But either way, we need to retry the cursor (unless the failure
            // was because the observe got stopped).
            doc = null;
          }
          // Since we awaited a promise above, we need to check again to see if
          // we've been stopped before calling the callback.
          if (stopped) return;
          if (doc) {
            // If a tailable cursor contains a "ts" field, use it to recreate the
            // cursor on error. ("ts" is a standard that Mongo uses internally for
            // the oplog, and there's a special flag that lets you do binary search
            // on it instead of needing to use an index.)
            lastTS = doc.ts;
            docCallback(doc);
          } else {
            var newSelector = _.clone(cursorDescription.selector);
            if (lastTS) {
              newSelector.ts = {
                $gt: lastTS
              };
            }
            cursor = self._createSynchronousCursor(new CursorDescription(cursorDescription.collectionName, newSelector, cursorDescription.options));
            // Mongo failover takes many seconds.  Retry in a bit.  (Without this
            // setTimeout, we peg the CPU at 100% and never notice the actual
            // failover.
            setTimeout(loop, 100);
            break;
          }
        }
      });
      return {
        stop: function () {
          stopped = true;
          cursor.close();
        }
      };
    };
    const oplogCollectionWarnings = [];
    Object.assign(MongoConnection.prototype, {
      _observeChanges: async function (cursorDescription, ordered, callbacks, nonMutatingCallbacks) {
        var _self$_oplogHandle;
        var self = this;
        const collectionName = cursorDescription.collectionName;
        if (cursorDescription.options.tailable) {
          return self._observeChangesTailable(cursorDescription, ordered, callbacks);
        }

        // You may not filter out _id when observing changes, because the id is a core
        // part of the observeChanges API.
        const fieldsOptions = cursorDescription.options.projection || cursorDescription.options.fields;
        if (fieldsOptions && (fieldsOptions._id === 0 || fieldsOptions._id === false)) {
          throw Error("You may not observe a cursor with {fields: {_id: 0}}");
        }
        var observeKey = EJSON.stringify(_.extend({
          ordered: ordered
        }, cursorDescription));
        var multiplexer, observeDriver;
        var firstHandle = false;

        // Find a matching ObserveMultiplexer, or create a new one. This next block is
        // guaranteed to not yield (and it doesn't call anything that can observe a
        // new query), so no other calls to this function can interleave with it.
        if (_.has(self._observeMultiplexers, observeKey)) {
          multiplexer = self._observeMultiplexers[observeKey];
        } else {
          firstHandle = true;
          // Create a new ObserveMultiplexer.
          multiplexer = new ObserveMultiplexer({
            ordered: ordered,
            onStop: function () {
              delete self._observeMultiplexers[observeKey];
              return observeDriver.stop();
            }
          });
        }
        var observeHandle = new ObserveHandle(multiplexer, callbacks, nonMutatingCallbacks);
        const oplogOptions = (self === null || self === void 0 ? void 0 : (_self$_oplogHandle = self._oplogHandle) === null || _self$_oplogHandle === void 0 ? void 0 : _self$_oplogHandle._oplogOptions) || {};
        const {
          includeCollections,
          excludeCollections
        } = oplogOptions;
        if (firstHandle) {
          var matcher, sorter;
          var canUseOplog = _.all([function () {
            // At a bare minimum, using the oplog requires us to have an oplog, to
            // want unordered callbacks, and to not want a callback on the polls
            // that won't happen.
            return self._oplogHandle && !ordered && !callbacks._testOnlyPollCallback;
          }, function () {
            // We also need to check, if the collection of this Cursor is actually being "watched" by the Oplog handle
            // if not, we have to fallback to long polling
            if (excludeCollections !== null && excludeCollections !== void 0 && excludeCollections.length && excludeCollections.includes(collectionName)) {
              if (!oplogCollectionWarnings.includes(collectionName)) {
                console.warn("Meteor.settings.packages.mongo.oplogExcludeCollections includes the collection ".concat(collectionName, " - your subscriptions will only use long polling!"));
                oplogCollectionWarnings.push(collectionName); // we only want to show the warnings once per collection!
              }
              return false;
            }
            if (includeCollections !== null && includeCollections !== void 0 && includeCollections.length && !includeCollections.includes(collectionName)) {
              if (!oplogCollectionWarnings.includes(collectionName)) {
                console.warn("Meteor.settings.packages.mongo.oplogIncludeCollections does not include the collection ".concat(collectionName, " - your subscriptions will only use long polling!"));
                oplogCollectionWarnings.push(collectionName); // we only want to show the warnings once per collection!
              }
              return false;
            }
            return true;
          }, function () {
            // We need to be able to compile the selector. Fall back to polling for
            // some newfangled $selector that minimongo doesn't support yet.
            try {
              matcher = new Minimongo.Matcher(cursorDescription.selector);
              return true;
            } catch (e) {
              // XXX make all compilation errors MinimongoError or something
              //     so that this doesn't ignore unrelated exceptions
              return false;
            }
          }, function () {
            // ... and the selector itself needs to support oplog.
            return OplogObserveDriver.cursorSupported(cursorDescription, matcher);
          }, function () {
            // And we need to be able to compile the sort, if any.  eg, can't be
            // {$natural: 1}.
            if (!cursorDescription.options.sort) return true;
            try {
              sorter = new Minimongo.Sorter(cursorDescription.options.sort);
              return true;
            } catch (e) {
              // XXX make all compilation errors MinimongoError or something
              //     so that this doesn't ignore unrelated exceptions
              return false;
            }
          }], function (f) {
            return f();
          }); // invoke each function

          var driverClass = canUseOplog ? OplogObserveDriver : PollingObserveDriver;
          observeDriver = new driverClass({
            cursorDescription: cursorDescription,
            mongoHandle: self,
            multiplexer: multiplexer,
            ordered: ordered,
            matcher: matcher,
            // ignored by polling
            sorter: sorter,
            // ignored by polling
            _testOnlyPollCallback: callbacks._testOnlyPollCallback
          });
          if (observeDriver._init) {
            await observeDriver._init();
          }

          // This field is only set for use in tests.
          multiplexer._observeDriver = observeDriver;
        }
        self._observeMultiplexers[observeKey] = multiplexer;
        // Blocks until the initial adds have been sent.
        await multiplexer.addHandleAndSendInitialAdds(observeHandle);
        return observeHandle;
      }
    });

    // Listen for the invalidation messages that will trigger us to poll the
    // database for changes. If this selector specifies specific IDs, specify them
    // here, so that updates to different specific IDs don't cause us to poll.
    // listenCallback is the same kind of (notification, complete) callback passed
    // to InvalidationCrossbar.listen.

    listenAll = async function (cursorDescription, listenCallback) {
      const listeners = [];
      await forEachTrigger(cursorDescription, function (trigger) {
        listeners.push(DDPServer._InvalidationCrossbar.listen(trigger, listenCallback));
      });
      return {
        stop: function () {
          _.each(listeners, function (listener) {
            listener.stop();
          });
        }
      };
    };
    forEachTrigger = async function (cursorDescription, triggerCallback) {
      const key = {
        collection: cursorDescription.collectionName
      };
      const specificIds = LocalCollection._idsMatchedBySelector(cursorDescription.selector);
      if (specificIds) {
        for (const id of specificIds) {
          await triggerCallback(_.extend({
            id: id
          }, key));
        }
        await triggerCallback(_.extend({
          dropCollection: true,
          id: null
        }, key));
      } else {
        await triggerCallback(key);
      }
      // Everyone cares about the database being dropped.
      await triggerCallback({
        dropDatabase: true
      });
    };

    // observeChanges for tailable cursors on capped collections.
    //
    // Some differences from normal cursors:
    //   - Will never produce anything other than 'added' or 'addedBefore'. If you
    //     do update a document that has already been produced, this will not notice
    //     it.
    //   - If you disconnect and reconnect from Mongo, it will essentially restart
    //     the query, which will lead to duplicate results. This is pretty bad,
    //     but if you include a field called 'ts' which is inserted as
    //     new MongoInternals.MongoTimestamp(0, 0) (which is initialized to the
    //     current Mongo-style timestamp), we'll be able to find the place to
    //     restart properly. (This field is specifically understood by Mongo with an
    //     optimization which allows it to find the right place to start without
    //     an index on ts. It's how the oplog works.)
    //   - No callbacks are triggered synchronously with the call (there's no
    //     differentiation between "initial data" and "later changes"; everything
    //     that matches the query gets sent asynchronously).
    //   - De-duplication is not implemented.
    //   - Does not yet interact with the write fence. Probably, this should work by
    //     ignoring removes (which don't work on capped collections) and updates
    //     (which don't affect tailable cursors), and just keeping track of the ID
    //     of the inserted object, and closing the write fence once you get to that
    //     ID (or timestamp?).  This doesn't work well if the document doesn't match
    //     the query, though.  On the other hand, the write fence can close
    //     immediately if it does not match the query. So if we trust minimongo
    //     enough to accurately evaluate the query against the write fence, we
    //     should be able to do this...  Of course, minimongo doesn't even support
    //     Mongo Timestamps yet.
    MongoConnection.prototype._observeChangesTailable = function (cursorDescription, ordered, callbacks) {
      var self = this;

      // Tailable cursors only ever call added/addedBefore callbacks, so it's an
      // error if you didn't provide them.
      if (ordered && !callbacks.addedBefore || !ordered && !callbacks.added) {
        throw new Error("Can't observe an " + (ordered ? "ordered" : "unordered") + " tailable cursor without a " + (ordered ? "addedBefore" : "added") + " callback");
      }
      return self.tail(cursorDescription, function (doc) {
        var id = doc._id;
        delete doc._id;
        // The ts is an implementation detail. Hide it.
        delete doc.ts;
        if (ordered) {
          callbacks.addedBefore(id, doc, null);
        } else {
          callbacks.added(id, doc);
        }
      });
    };

    // XXX We probably need to find a better way to expose this. Right now
    // it's only used by tests, but in fact you need it in normal
    // operation to interact with capped collections.
    MongoInternals.MongoTimestamp = MongoDB.Timestamp;
    MongoInternals.Connection = MongoConnection;
    __reify_async_result__();
  } catch (_reifyError) {
    return __reify_async_result__(_reifyError);
  }
  __reify_async_result__()
}, {
  self: this,
  async: false
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"oplog_tailing.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/mongo/oplog_tailing.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
!module.wrapAsync(async function (module, __reifyWaitForDeps__, __reify_async_result__) {
  "use strict";
  try {
    let NpmModuleMongodb;
    module.link("meteor/npm-mongo", {
      NpmModuleMongodb(v) {
        NpmModuleMongodb = v;
      }
    }, 0);
    if (__reifyWaitForDeps__()) (await __reifyWaitForDeps__())();
    const {
      Long
    } = NpmModuleMongodb;
    OPLOG_COLLECTION = 'oplog.rs';
    var TOO_FAR_BEHIND = process.env.METEOR_OPLOG_TOO_FAR_BEHIND || 2000;
    var TAIL_TIMEOUT = +process.env.METEOR_OPLOG_TAIL_TIMEOUT || 30000;
    idForOp = function (op) {
      if (op.op === 'd') return op.o._id;else if (op.op === 'i') return op.o._id;else if (op.op === 'u') return op.o2._id;else if (op.op === 'c') throw Error("Operator 'c' doesn't supply an object with id: " + EJSON.stringify(op));else throw Error("Unknown op: " + EJSON.stringify(op));
    };
    OplogHandle = function (oplogUrl, dbName) {
      var self = this;
      self._oplogUrl = oplogUrl;
      self._dbName = dbName;
      self._oplogLastEntryConnection = null;
      self._oplogTailConnection = null;
      self._oplogOptions = null;
      self._stopped = false;
      self._tailHandle = null;
      self._readyPromiseResolver = null;
      self._readyPromise = new Promise(r => self._readyPromiseResolver = r);
      self._crossbar = new DDPServer._Crossbar({
        factPackage: "mongo-livedata",
        factName: "oplog-watchers"
      });
      self._baseOplogSelector = {
        ns: new RegExp("^(?:" + [Meteor._escapeRegExp(self._dbName + "."), Meteor._escapeRegExp("admin.$cmd")].join("|") + ")"),
        $or: [{
          op: {
            $in: ['i', 'u', 'd']
          }
        },
        // drop collection
        {
          op: 'c',
          'o.drop': {
            $exists: true
          }
        }, {
          op: 'c',
          'o.dropDatabase': 1
        }, {
          op: 'c',
          'o.applyOps': {
            $exists: true
          }
        }]
      };

      // Data structures to support waitUntilCaughtUp(). Each oplog entry has a
      // MongoTimestamp object on it (which is not the same as a Date --- it's a
      // combination of time and an incrementing counter; see
      // http://docs.mongodb.org/manual/reference/bson-types/#timestamps).
      //
      // _catchingUpFutures is an array of {ts: MongoTimestamp, future: Future}
      // objects, sorted by ascending timestamp. _lastProcessedTS is the
      // MongoTimestamp of the last oplog entry we've processed.
      //
      // Each time we call waitUntilCaughtUp, we take a peek at the final oplog
      // entry in the db.  If we've already processed it (ie, it is not greater than
      // _lastProcessedTS), waitUntilCaughtUp immediately returns. Otherwise,
      // waitUntilCaughtUp makes a new Future and inserts it along with the final
      // timestamp entry that it read, into _catchingUpFutures. waitUntilCaughtUp
      // then waits on that future, which is resolved once _lastProcessedTS is
      // incremented to be past its timestamp by the worker fiber.
      //
      // XXX use a priority queue or something else that's faster than an array
      self._catchingUpResolvers = [];
      self._lastProcessedTS = null;
      self._onSkippedEntriesHook = new Hook({
        debugPrintExceptions: "onSkippedEntries callback"
      });
      self._entryQueue = new Meteor._DoubleEndedQueue();
      self._workerActive = false;
      self._startTrailingPromise = self._startTailing();
      //TODO[fibers] Why wait?
    };
    MongoInternals.OplogHandle = OplogHandle;
    Object.assign(OplogHandle.prototype, {
      stop: async function () {
        var self = this;
        if (self._stopped) return;
        self._stopped = true;
        if (self._tailHandle) await self._tailHandle.stop();
        // XXX should close connections too
      },
      _onOplogEntry: async function (trigger, callback) {
        var self = this;
        if (self._stopped) throw new Error("Called onOplogEntry on stopped handle!");

        // Calling onOplogEntry requires us to wait for the tailing to be ready.
        await self._readyPromise;
        var originalCallback = callback;
        callback = Meteor.bindEnvironment(function (notification) {
          originalCallback(notification);
        }, function (err) {
          Meteor._debug("Error in oplog callback", err);
        });
        var listenHandle = self._crossbar.listen(trigger, callback);
        return {
          stop: async function () {
            await listenHandle.stop();
          }
        };
      },
      onOplogEntry: function (trigger, callback) {
        return this._onOplogEntry(trigger, callback);
      },
      // Register a callback to be invoked any time we skip oplog entries (eg,
      // because we are too far behind).
      onSkippedEntries: function (callback) {
        var self = this;
        if (self._stopped) throw new Error("Called onSkippedEntries on stopped handle!");
        return self._onSkippedEntriesHook.register(callback);
      },
      async _waitUntilCaughtUp() {
        var self = this;
        if (self._stopped) throw new Error("Called waitUntilCaughtUp on stopped handle!");

        // Calling waitUntilCaughtUp requries us to wait for the oplog connection to
        // be ready.
        await self._readyPromise;
        var lastEntry;
        while (!self._stopped) {
          // We need to make the selector at least as restrictive as the actual
          // tailing selector (ie, we need to specify the DB name) or else we might
          // find a TS that won't show up in the actual tail stream.
          try {
            lastEntry = await self._oplogLastEntryConnection.findOneAsync(OPLOG_COLLECTION, self._baseOplogSelector, {
              projection: {
                ts: 1
              },
              sort: {
                $natural: -1
              }
            });
            break;
          } catch (e) {
            // During failover (eg) if we get an exception we should log and retry
            // instead of crashing.
            Meteor._debug("Got exception while reading last entry", e);
            await Meteor._sleepForMs(100);
          }
        }
        if (self._stopped) return;
        if (!lastEntry) {
          // Really, nothing in the oplog? Well, we've processed everything.
          return;
        }
        var ts = lastEntry.ts;
        if (!ts) throw Error("oplog entry without ts: " + EJSON.stringify(lastEntry));
        if (self._lastProcessedTS && ts.lessThanOrEqual(self._lastProcessedTS)) {
          // We've already caught up to here.
          return;
        }

        // Insert the future into our list. Almost always, this will be at the end,
        // but it's conceivable that if we fail over from one primary to another,
        // the oplog entries we see will go backwards.
        var insertAfter = self._catchingUpResolvers.length;
        while (insertAfter - 1 > 0 && self._catchingUpResolvers[insertAfter - 1].ts.greaterThan(ts)) {
          insertAfter--;
        }
        let promiseResolver = null;
        const promiseToAwait = new Promise(r => promiseResolver = r);
        self._catchingUpResolvers.splice(insertAfter, 0, {
          ts: ts,
          resolver: promiseResolver
        });
        await promiseToAwait;
      },
      // Calls `callback` once the oplog has been processed up to a point that is
      // roughly "now": specifically, once we've processed all ops that are
      // currently visible.
      // XXX become convinced that this is actually safe even if oplogConnection
      // is some kind of pool
      waitUntilCaughtUp: async function () {
        return this._waitUntilCaughtUp();
      },
      _startTailing: async function () {
        var _Meteor$settings, _Meteor$settings$pack, _Meteor$settings$pack2, _Meteor$settings2, _Meteor$settings2$pac, _Meteor$settings2$pac2;
        var self = this;
        // First, make sure that we're talking to the local database.
        var mongodbUri = Npm.require('mongodb-uri');
        if (mongodbUri.parse(self._oplogUrl).database !== 'local') {
          throw Error("$MONGO_OPLOG_URL must be set to the 'local' database of " + "a Mongo replica set");
        }

        // We make two separate connections to Mongo. The Node Mongo driver
        // implements a naive round-robin connection pool: each "connection" is a
        // pool of several (5 by default) TCP connections, and each request is
        // rotated through the pools. Tailable cursor queries block on the server
        // until there is some data to return (or until a few seconds have
        // passed). So if the connection pool used for tailing cursors is the same
        // pool used for other queries, the other queries will be delayed by seconds
        // 1/5 of the time.
        //
        // The tail connection will only ever be running a single tail command, so
        // it only needs to make one underlying TCP connection.
        self._oplogTailConnection = new MongoConnection(self._oplogUrl, {
          maxPoolSize: 1,
          minPoolSize: 1
        });
        // XXX better docs, but: it's to get monotonic results
        // XXX is it safe to say "if there's an in flight query, just use its
        //     results"? I don't think so but should consider that
        self._oplogLastEntryConnection = new MongoConnection(self._oplogUrl, {
          maxPoolSize: 1,
          minPoolSize: 1
        });

        // Now, make sure that there actually is a repl set here. If not, oplog
        // tailing won't ever find anything!
        // More on the isMasterDoc
        // https://docs.mongodb.com/manual/reference/command/isMaster/
        const isMasterDoc = await new Promise(function (resolve, reject) {
          self._oplogLastEntryConnection.db.admin().command({
            ismaster: 1
          }, function (err, result) {
            if (err) reject(err);else resolve(result);
          });
        });
        if (!(isMasterDoc && isMasterDoc.setName)) {
          throw Error("$MONGO_OPLOG_URL must be set to the 'local' database of " + "a Mongo replica set");
        }

        // Find the last oplog entry.
        var lastOplogEntry = await self._oplogLastEntryConnection.findOneAsync(OPLOG_COLLECTION, {}, {
          sort: {
            $natural: -1
          },
          projection: {
            ts: 1
          }
        });
        var oplogSelector = Object.assign({}, self._baseOplogSelector);
        if (lastOplogEntry) {
          // Start after the last entry that currently exists.
          oplogSelector.ts = {
            $gt: lastOplogEntry.ts
          };
          // If there are any calls to callWhenProcessedLatest before any other
          // oplog entries show up, allow callWhenProcessedLatest to call its
          // callback immediately.
          self._lastProcessedTS = lastOplogEntry.ts;
        }

        // These 2 settings allow you to either only watch certain collections (oplogIncludeCollections), or exclude some collections you don't want to watch for oplog updates (oplogExcludeCollections)
        // Usage:
        // settings.json = {
        //   "packages": {
        //     "mongo": {
        //       "oplogExcludeCollections": ["products", "prices"] // This would exclude both collections "products" and "prices" from any oplog tailing. 
        //                                                            Beware! This means, that no subscriptions on these 2 collections will update anymore!
        //     }
        //   }
        // }
        const includeCollections = (_Meteor$settings = Meteor.settings) === null || _Meteor$settings === void 0 ? void 0 : (_Meteor$settings$pack = _Meteor$settings.packages) === null || _Meteor$settings$pack === void 0 ? void 0 : (_Meteor$settings$pack2 = _Meteor$settings$pack.mongo) === null || _Meteor$settings$pack2 === void 0 ? void 0 : _Meteor$settings$pack2.oplogIncludeCollections;
        const excludeCollections = (_Meteor$settings2 = Meteor.settings) === null || _Meteor$settings2 === void 0 ? void 0 : (_Meteor$settings2$pac = _Meteor$settings2.packages) === null || _Meteor$settings2$pac === void 0 ? void 0 : (_Meteor$settings2$pac2 = _Meteor$settings2$pac.mongo) === null || _Meteor$settings2$pac2 === void 0 ? void 0 : _Meteor$settings2$pac2.oplogExcludeCollections;
        if (includeCollections !== null && includeCollections !== void 0 && includeCollections.length && excludeCollections !== null && excludeCollections !== void 0 && excludeCollections.length) {
          throw new Error("Can't use both mongo oplog settings oplogIncludeCollections and oplogExcludeCollections at the same time.");
        }
        if (excludeCollections !== null && excludeCollections !== void 0 && excludeCollections.length) {
          oplogSelector.ns = {
            $regex: oplogSelector.ns,
            $nin: excludeCollections.map(collName => "".concat(self._dbName, ".").concat(collName))
          };
          self._oplogOptions = {
            excludeCollections
          };
        } else if (includeCollections !== null && includeCollections !== void 0 && includeCollections.length) {
          oplogSelector = {
            $and: [{
              $or: [{
                ns: /^admin\.\$cmd/
              }, {
                ns: {
                  $in: includeCollections.map(collName => "".concat(self._dbName, ".").concat(collName))
                }
              }]
            }, {
              $or: oplogSelector.$or
            },
            // the initial $or to select only certain operations (op)
            {
              ts: oplogSelector.ts
            }]
          };
          self._oplogOptions = {
            includeCollections
          };
        }
        var cursorDescription = new CursorDescription(OPLOG_COLLECTION, oplogSelector, {
          tailable: true
        });

        // Start tailing the oplog.
        //
        // We restart the low-level oplog query every 30 seconds if we didn't get a
        // doc. This is a workaround for #8598: the Node Mongo driver has at least
        // one bug that can lead to query callbacks never getting called (even with
        // an error) when leadership failover occur.
        self._tailHandle = self._oplogTailConnection.tail(cursorDescription, function (doc) {
          self._entryQueue.push(doc);
          self._maybeStartWorker();
        }, TAIL_TIMEOUT);
        self._readyPromiseResolver();
      },
      _maybeStartWorker: function () {
        var self = this;
        if (self._workerActive) return;
        self._workerActive = true;
        Meteor.defer(async function () {
          // May be called recursively in case of transactions.
          async function handleDoc(doc) {
            if (doc.ns === "admin.$cmd") {
              if (doc.o.applyOps) {
                // This was a successful transaction, so we need to apply the
                // operations that were involved.
                let nextTimestamp = doc.ts;
                for (const op of doc.o.applyOps) {
                  // See https://github.com/meteor/meteor/issues/10420.
                  if (!op.ts) {
                    op.ts = nextTimestamp;
                    nextTimestamp = nextTimestamp.add(Long.ONE);
                  }
                  await handleDoc(op);
                }
                return;
              }
              throw new Error("Unknown command " + EJSON.stringify(doc));
            }
            const trigger = {
              dropCollection: false,
              dropDatabase: false,
              op: doc
            };
            if (typeof doc.ns === "string" && doc.ns.startsWith(self._dbName + ".")) {
              trigger.collection = doc.ns.slice(self._dbName.length + 1);
            }

            // Is it a special command and the collection name is hidden
            // somewhere in operator?
            if (trigger.collection === "$cmd") {
              if (doc.o.dropDatabase) {
                delete trigger.collection;
                trigger.dropDatabase = true;
              } else if (_.has(doc.o, "drop")) {
                trigger.collection = doc.o.drop;
                trigger.dropCollection = true;
                trigger.id = null;
              } else if ("create" in doc.o && "idIndex" in doc.o) {
                // A collection got implicitly created within a transaction. There's
                // no need to do anything about it.
              } else {
                throw Error("Unknown command " + EJSON.stringify(doc));
              }
            } else {
              // All other ops have an id.
              trigger.id = idForOp(doc);
            }
            await self._crossbar.fire(trigger);
          }
          try {
            while (!self._stopped && !self._entryQueue.isEmpty()) {
              // Are we too far behind? Just tell our observers that they need to
              // repoll, and drop our queue.
              if (self._entryQueue.length > TOO_FAR_BEHIND) {
                var lastEntry = self._entryQueue.pop();
                self._entryQueue.clear();
                self._onSkippedEntriesHook.each(function (callback) {
                  callback();
                  return true;
                });

                // Free any waitUntilCaughtUp() calls that were waiting for us to
                // pass something that we just skipped.
                self._setLastProcessedTS(lastEntry.ts);
                continue;
              }
              const doc = self._entryQueue.shift();

              // Fire trigger(s) for this doc.
              await handleDoc(doc);

              // Now that we've processed this operation, process pending
              // sequencers.
              if (doc.ts) {
                self._setLastProcessedTS(doc.ts);
              } else {
                throw Error("oplog entry without ts: " + EJSON.stringify(doc));
              }
            }
          } finally {
            self._workerActive = false;
          }
        });
      },
      _setLastProcessedTS: function (ts) {
        var self = this;
        self._lastProcessedTS = ts;
        while (!_.isEmpty(self._catchingUpResolvers) && self._catchingUpResolvers[0].ts.lessThanOrEqual(self._lastProcessedTS)) {
          var sequencer = self._catchingUpResolvers.shift();
          sequencer.resolver();
        }
      },
      //Methods used on tests to dinamically change TOO_FAR_BEHIND
      _defineTooFarBehind: function (value) {
        TOO_FAR_BEHIND = value;
      },
      _resetTooFarBehind: function () {
        TOO_FAR_BEHIND = process.env.METEOR_OPLOG_TOO_FAR_BEHIND || 2000;
      }
    });
    __reify_async_result__();
  } catch (_reifyError) {
    return __reify_async_result__(_reifyError);
  }
  __reify_async_result__()
}, {
  self: this,
  async: false
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"observe_multiplex.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/mongo/observe_multiplex.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
!module.wrapAsync(async function (module, __reifyWaitForDeps__, __reify_async_result__) {
  "use strict";
  try {
    let _objectWithoutProperties;
    module.link("@babel/runtime/helpers/objectWithoutProperties", {
      default(v) {
        _objectWithoutProperties = v;
      }
    }, 0);
    if (__reifyWaitForDeps__()) (await __reifyWaitForDeps__())();
    const _excluded = ["_id"];
    let nextObserveHandleId = 1;
    ObserveMultiplexer = class {
      constructor() {
        let {
          ordered,
          onStop = () => {}
        } = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
        if (ordered === undefined) throw Error("must specify ordered");
        Package['facts-base'] && Package['facts-base'].Facts.incrementServerFact("mongo-livedata", "observe-multiplexers", 1);
        this._ordered = ordered;
        this._onStop = onStop;
        this._queue = new Meteor._AsynchronousQueue();
        this._handles = {};
        this._resolver = null;
        this._readyPromise = new Promise(r => this._resolver = r).then(() => this._isReady = true);
        this._cache = new LocalCollection._CachingChangeObserver({
          ordered
        });
        // Number of addHandleAndSendInitialAdds tasks scheduled but not yet
        // running. removeHandle uses this to know if it's time to call the onStop
        // callback.
        this._addHandleTasksScheduledButNotPerformed = 0;
        const self = this;
        this.callbackNames().forEach(callbackName => {
          this[callbackName] = function /* ... */
          () {
            self._applyCallback(callbackName, _.toArray(arguments));
          };
        });
      }
      addHandleAndSendInitialAdds(handle) {
        return this._addHandleAndSendInitialAdds(handle);
      }
      async _addHandleAndSendInitialAdds(handle) {
        ++this._addHandleTasksScheduledButNotPerformed;
        Package['facts-base'] && Package['facts-base'].Facts.incrementServerFact("mongo-livedata", "observe-handles", 1);
        const self = this;
        await this._queue.runTask(async function () {
          self._handles[handle._id] = handle;
          // Send out whatever adds we have so far (whether the
          // multiplexer is ready).
          await self._sendAdds(handle);
          --self._addHandleTasksScheduledButNotPerformed;
        });
        await this._readyPromise;
      }

      // Remove an observe handle. If it was the last observe handle, call the
      // onStop callback; you cannot add any more observe handles after this.
      //
      // This is not synchronized with polls and handle additions: this means that
      // you can safely call it from within an observe callback, but it also means
      // that we have to be careful when we iterate over _handles.
      async removeHandle(id) {
        // This should not be possible: you can only call removeHandle by having
        // access to the ObserveHandle, which isn't returned to user code until the
        // multiplex is ready.
        if (!this._ready()) throw new Error("Can't remove handles until the multiplex is ready");
        delete this._handles[id];
        Package['facts-base'] && Package['facts-base'].Facts.incrementServerFact("mongo-livedata", "observe-handles", -1);
        if (_.isEmpty(this._handles) && this._addHandleTasksScheduledButNotPerformed === 0) {
          await this._stop();
        }
      }
      async _stop(options) {
        options = options || {};

        // It shouldn't be possible for us to stop when all our handles still
        // haven't been returned from observeChanges!
        if (!this._ready() && !options.fromQueryError) throw Error("surprising _stop: not ready");

        // Call stop callback (which kills the underlying process which sends us
        // callbacks and removes us from the connection's dictionary).
        await this._onStop();
        Package['facts-base'] && Package['facts-base'].Facts.incrementServerFact("mongo-livedata", "observe-multiplexers", -1);

        // Cause future addHandleAndSendInitialAdds calls to throw (but the onStop
        // callback should make our connection forget about us).
        this._handles = null;
      }

      // Allows all addHandleAndSendInitialAdds calls to return, once all preceding
      // adds have been processed. Does not block.
      async ready() {
        const self = this;
        this._queue.queueTask(function () {
          if (self._ready()) throw Error("can't make ObserveMultiplex ready twice!");
          if (!self._resolver) {
            throw new Error("Missing resolver");
          }
          self._resolver();
          self._isReady = true;
        });
      }

      // If trying to execute the query results in an error, call this. This is
      // intended for permanent errors, not transient network errors that could be
      // fixed. It should only be called before ready(), because if you called ready
      // that meant that you managed to run the query once. It will stop this
      // ObserveMultiplex and cause addHandleAndSendInitialAdds calls (and thus
      // observeChanges calls) to throw the error.
      async queryError(err) {
        var self = this;
        await this._queue.runTask(function () {
          if (self._ready()) throw Error("can't claim query has an error after it worked!");
          self._stop({
            fromQueryError: true
          });
          throw err;
        });
      }

      // Calls "cb" once the effects of all "ready", "addHandleAndSendInitialAdds"
      // and observe callbacks which came before this call have been propagated to
      // all handles. "ready" must have already been called on this multiplexer.
      async onFlush(cb) {
        var self = this;
        await this._queue.queueTask(async function () {
          if (!self._ready()) throw Error("only call onFlush on a multiplexer that will be ready");
          await cb();
        });
      }
      callbackNames() {
        if (this._ordered) return ["addedBefore", "changed", "movedBefore", "removed"];else return ["added", "changed", "removed"];
      }
      _ready() {
        return !!this._isReady;
      }
      _applyCallback(callbackName, args) {
        const self = this;
        this._queue.queueTask(async function () {
          // If we stopped in the meantime, do nothing.
          if (!self._handles) return;

          // First, apply the change to the cache.
          await self._cache.applyChange[callbackName].apply(null, args);
          // If we haven't finished the initial adds, then we should only be getting
          // adds.
          if (!self._ready() && callbackName !== 'added' && callbackName !== 'addedBefore') {
            throw new Error("Got " + callbackName + " during initial adds");
          }

          // Now multiplex the callbacks out to all observe handles. It's OK if
          // these calls yield; since we're inside a task, no other use of our queue
          // can continue until these are done. (But we do have to be careful to not
          // use a handle that got removed, because removeHandle does not use the
          // queue; thus, we iterate over an array of keys that we control.)
          for (const handleId of Object.keys(self._handles)) {
            var handle = self._handles && self._handles[handleId];
            if (!handle) return;
            var callback = handle['_' + callbackName];
            // clone arguments so that callbacks can mutate their arguments

            callback && (await callback.apply(null, handle.nonMutatingCallbacks ? args : EJSON.clone(args)));
          }
        });
      }

      // Sends initial adds to a handle. It should only be called from within a task
      // (the task that is processing the addHandleAndSendInitialAdds call). It
      // synchronously invokes the handle's added or addedBefore; there's no need to
      // flush the queue afterwards to ensure that the callbacks get out.
      async _sendAdds(handle) {
        var add = this._ordered ? handle._addedBefore : handle._added;
        if (!add) return;
        // note: docs may be an _IdMap or an OrderedDict
        await this._cache.docs.forEachAsync(async (doc, id) => {
          if (!_.has(this._handles, handle._id)) throw Error("handle got removed before sending initial adds!");
          const _ref = handle.nonMutatingCallbacks ? doc : EJSON.clone(doc),
            {
              _id
            } = _ref,
            fields = _objectWithoutProperties(_ref, _excluded);
          if (this._ordered) await add(id, fields, null); // we're going in order, so add at end
          else await add(id, fields);
        });
      }
    };

    // When the callbacks do not mutate the arguments, we can skip a lot of data clones
    ObserveHandle = class {
      constructor(multiplexer, callbacks) {
        let nonMutatingCallbacks = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;
        this._multiplexer = multiplexer;
        multiplexer.callbackNames().forEach(name => {
          if (callbacks[name]) {
            this['_' + name] = callbacks[name];
          } else if (name === "addedBefore" && callbacks.added) {
            // Special case: if you specify "added" and "movedBefore", you get an
            // ordered observe where for some reason you don't get ordering data on
            // the adds.  I dunno, we wrote tests for it, there must have been a
            // reason.
            this._addedBefore = async function (id, fields, before) {
              await callbacks.added(id, fields);
            };
          }
        });
        this._stopped = false;
        this._id = nextObserveHandleId++;
        this.nonMutatingCallbacks = nonMutatingCallbacks;
      }
      async stop() {
        if (this._stopped) return;
        this._stopped = true;
        await this._multiplexer.removeHandle(this._id);
      }
    };
    __reify_async_result__();
  } catch (_reifyError) {
    return __reify_async_result__(_reifyError);
  }
  __reify_async_result__()
}, {
  self: this,
  async: false
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"doc_fetcher.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/mongo/doc_fetcher.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  DocFetcher: () => DocFetcher
});
class DocFetcher {
  constructor(mongoConnection) {
    this._mongoConnection = mongoConnection;
    // Map from op -> [callback]
    this._callbacksForOp = new Map();
  }

  // Fetches document "id" from collectionName, returning it or null if not
  // found.
  //
  // If you make multiple calls to fetch() with the same op reference,
  // DocFetcher may assume that they all return the same document. (It does
  // not check to see if collectionName/id match.)
  //
  // You may assume that callback is never called synchronously (and in fact
  // OplogObserveDriver does so).
  async fetch(collectionName, id, op, callback) {
    const self = this;
    check(collectionName, String);
    check(op, Object);

    // If there's already an in-progress fetch for this cache key, yield until
    // it's done and return whatever it returns.
    if (self._callbacksForOp.has(op)) {
      self._callbacksForOp.get(op).push(callback);
      return;
    }
    const callbacks = [callback];
    self._callbacksForOp.set(op, callbacks);
    try {
      var doc = (await self._mongoConnection.findOneAsync(collectionName, {
        _id: id
      })) || null;
      // Return doc to all relevant callbacks. Note that this array can
      // continue to grow during callback excecution.
      while (callbacks.length > 0) {
        // Clone the document so that the various calls to fetch don't return
        // objects that are intertwingled with each other. Clone before
        // popping the future, so that if clone throws, the error gets passed
        // to the next callback.
        callbacks.pop()(null, EJSON.clone(doc));
      }
    } catch (e) {
      while (callbacks.length > 0) {
        callbacks.pop()(e);
      }
    } finally {
      // XXX consider keeping the doc around for a period of time before
      // removing from the cache
      self._callbacksForOp.delete(op);
    }
  }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"polling_observe_driver.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/mongo/polling_observe_driver.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var POLLING_THROTTLE_MS = +process.env.METEOR_POLLING_THROTTLE_MS || 50;
var POLLING_INTERVAL_MS = +process.env.METEOR_POLLING_INTERVAL_MS || 10 * 1000;
PollingObserveDriver = function (options) {
  const self = this;
  self._options = options;
  self._cursorDescription = options.cursorDescription;
  self._mongoHandle = options.mongoHandle;
  self._ordered = options.ordered;
  self._multiplexer = options.multiplexer;
  self._stopCallbacks = [];
  self._stopped = false;
  self._cursor = self._mongoHandle._createSynchronousCursor(self._cursorDescription);

  // previous results snapshot.  on each poll cycle, diffs against
  // results drives the callbacks.
  self._results = null;

  // The number of _pollMongo calls that have been added to self._taskQueue but
  // have not started running. Used to make sure we never schedule more than one
  // _pollMongo (other than possibly the one that is currently running). It's
  // also used by _suspendPolling to pretend there's a poll scheduled. Usually,
  // it's either 0 (for "no polls scheduled other than maybe one currently
  // running") or 1 (for "a poll scheduled that isn't running yet"), but it can
  // also be 2 if incremented by _suspendPolling.
  self._pollsScheduledButNotStarted = 0;
  self._pendingWrites = []; // people to notify when polling completes

  // Make sure to create a separately throttled function for each
  // PollingObserveDriver object.
  self._ensurePollIsScheduled = _.throttle(self._unthrottledEnsurePollIsScheduled, self._cursorDescription.options.pollingThrottleMs || POLLING_THROTTLE_MS /* ms */);

  // XXX figure out if we still need a queue
  self._taskQueue = new Meteor._AsynchronousQueue();
};
_.extend(PollingObserveDriver.prototype, {
  _init: async function () {
    const self = this;
    const options = self._options;
    const listenersHandle = await listenAll(self._cursorDescription, function (notification) {
      // When someone does a transaction that might affect us, schedule a poll
      // of the database. If that transaction happens inside of a write fence,
      // block the fence until we've polled and notified observers.
      const fence = DDPServer._getCurrentFence();
      if (fence) self._pendingWrites.push(fence.beginWrite());
      // Ensure a poll is scheduled... but if we already know that one is,
      // don't hit the throttled _ensurePollIsScheduled function (which might
      // lead to us calling it unnecessarily in <pollingThrottleMs> ms).
      if (self._pollsScheduledButNotStarted === 0) self._ensurePollIsScheduled();
    });
    self._stopCallbacks.push(async function () {
      await listenersHandle.stop();
    });

    // every once and a while, poll even if we don't think we're dirty, for
    // eventual consistency with database writes from outside the Meteor
    // universe.
    //
    // For testing, there's an undocumented callback argument to observeChanges
    // which disables time-based polling and gets called at the beginning of each
    // poll.
    if (options._testOnlyPollCallback) {
      self._testOnlyPollCallback = options._testOnlyPollCallback;
    } else {
      const pollingInterval = self._cursorDescription.options.pollingIntervalMs || self._cursorDescription.options._pollingInterval ||
      // COMPAT with 1.2
      POLLING_INTERVAL_MS;
      const intervalHandle = Meteor.setInterval(_.bind(self._ensurePollIsScheduled, self), pollingInterval);
      self._stopCallbacks.push(function () {
        Meteor.clearInterval(intervalHandle);
      });
    }

    // Make sure we actually poll soon!
    await this._unthrottledEnsurePollIsScheduled();
    Package['facts-base'] && Package['facts-base'].Facts.incrementServerFact("mongo-livedata", "observe-drivers-polling", 1);
  },
  // This is always called through _.throttle (except once at startup).
  _unthrottledEnsurePollIsScheduled: async function () {
    var self = this;
    if (self._pollsScheduledButNotStarted > 0) return;
    ++self._pollsScheduledButNotStarted;
    await self._taskQueue.runTask(async function () {
      await self._pollMongo();
    });
  },
  // test-only interface for controlling polling.
  //
  // _suspendPolling blocks until any currently running and scheduled polls are
  // done, and prevents any further polls from being scheduled. (new
  // ObserveHandles can be added and receive their initial added callbacks,
  // though.)
  //
  // _resumePolling immediately polls, and allows further polls to occur.
  _suspendPolling: function () {
    var self = this;
    // Pretend that there's another poll scheduled (which will prevent
    // _ensurePollIsScheduled from queueing any more polls).
    ++self._pollsScheduledButNotStarted;
    // Now block until all currently running or scheduled polls are done.
    self._taskQueue.runTask(function () {});

    // Confirm that there is only one "poll" (the fake one we're pretending to
    // have) scheduled.
    if (self._pollsScheduledButNotStarted !== 1) throw new Error("_pollsScheduledButNotStarted is " + self._pollsScheduledButNotStarted);
  },
  _resumePolling: async function () {
    var self = this;
    // We should be in the same state as in the end of _suspendPolling.
    if (self._pollsScheduledButNotStarted !== 1) throw new Error("_pollsScheduledButNotStarted is " + self._pollsScheduledButNotStarted);
    // Run a poll synchronously (which will counteract the
    // ++_pollsScheduledButNotStarted from _suspendPolling).
    await self._taskQueue.runTask(async function () {
      await self._pollMongo();
    });
  },
  async _pollMongo() {
    var self = this;
    --self._pollsScheduledButNotStarted;
    if (self._stopped) return;
    var first = false;
    var newResults;
    var oldResults = self._results;
    if (!oldResults) {
      first = true;
      // XXX maybe use OrderedDict instead?
      oldResults = self._ordered ? [] : new LocalCollection._IdMap();
    }
    self._testOnlyPollCallback && self._testOnlyPollCallback();

    // Save the list of pending writes which this round will commit.
    var writesForCycle = self._pendingWrites;
    self._pendingWrites = [];

    // Get the new query results. (This yields.)
    try {
      newResults = await self._cursor.getRawObjects(self._ordered);
    } catch (e) {
      if (first && typeof e.code === 'number') {
        // This is an error document sent to us by mongod, not a connection
        // error generated by the client. And we've never seen this query work
        // successfully. Probably it's a bad selector or something, so we should
        // NOT retry. Instead, we should halt the observe (which ends up calling
        // `stop` on us).
        await self._multiplexer.queryError(new Error("Exception while polling query " + JSON.stringify(self._cursorDescription) + ": " + e.message));
      }

      // getRawObjects can throw if we're having trouble talking to the
      // database.  That's fine --- we will repoll later anyway. But we should
      // make sure not to lose track of this cycle's writes.
      // (It also can throw if there's just something invalid about this query;
      // unfortunately the ObserveDriver API doesn't provide a good way to
      // "cancel" the observe from the inside in this case.
      Array.prototype.push.apply(self._pendingWrites, writesForCycle);
      Meteor._debug("Exception while polling query " + JSON.stringify(self._cursorDescription), e);
      return;
    }

    // Run diffs.
    if (!self._stopped) {
      LocalCollection._diffQueryChanges(self._ordered, oldResults, newResults, self._multiplexer);
    }

    // Signals the multiplexer to allow all observeChanges calls that share this
    // multiplexer to return. (This happens asynchronously, via the
    // multiplexer's queue.)
    if (first) self._multiplexer.ready();

    // Replace self._results atomically.  (This assignment is what makes `first`
    // stay through on the next cycle, so we've waited until after we've
    // committed to ready-ing the multiplexer.)
    self._results = newResults;

    // Once the ObserveMultiplexer has processed everything we've done in this
    // round, mark all the writes which existed before this call as
    // commmitted. (If new writes have shown up in the meantime, there'll
    // already be another _pollMongo task scheduled.)
    await self._multiplexer.onFlush(async function () {
      for (const w of writesForCycle) {
        await w.committed();
      }
    });
  },
  stop: function () {
    var self = this;
    self._stopped = true;
    const stopCallbacksCaller = async function (c) {
      await c();
    };
    _.each(self._stopCallbacks, stopCallbacksCaller);
    // Release any write fences that are waiting on us.
    _.each(self._pendingWrites, async function (w) {
      await w.committed();
    });
    Package['facts-base'] && Package['facts-base'].Facts.incrementServerFact("mongo-livedata", "observe-drivers-polling", -1);
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"oplog_observe_driver.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/mongo/oplog_observe_driver.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
!module.wrapAsync(async function (module, __reifyWaitForDeps__, __reify_async_result__) {
  "use strict";
  try {
    let _asyncIterator;
    module.link("@babel/runtime/helpers/asyncIterator", {
      default(v) {
        _asyncIterator = v;
      }
    }, 0);
    let oplogV2V1Converter;
    module.link("./oplog_v2_converter", {
      oplogV2V1Converter(v) {
        oplogV2V1Converter = v;
      }
    }, 0);
    let check, Match;
    module.link("meteor/check", {
      check(v) {
        check = v;
      },
      Match(v) {
        Match = v;
      }
    }, 1);
    if (__reifyWaitForDeps__()) (await __reifyWaitForDeps__())();
    var PHASE = {
      QUERYING: "QUERYING",
      FETCHING: "FETCHING",
      STEADY: "STEADY"
    };

    // Exception thrown by _needToPollQuery which unrolls the stack up to the
    // enclosing call to finishIfNeedToPollQuery.
    var SwitchedToQuery = function () {};
    var finishIfNeedToPollQuery = function (f) {
      return function () {
        try {
          f.apply(this, arguments);
        } catch (e) {
          if (!(e instanceof SwitchedToQuery)) throw e;
        }
      };
    };
    var currentId = 0;

    // OplogObserveDriver is an alternative to PollingObserveDriver which follows
    // the Mongo operation log instead of just re-polling the query. It obeys the
    // same simple interface: constructing it starts sending observeChanges
    // callbacks (and a ready() invocation) to the ObserveMultiplexer, and you stop
    // it by calling the stop() method.
    OplogObserveDriver = function (options) {
      const self = this;
      self._usesOplog = true; // tests look at this

      self._id = currentId;
      currentId++;
      self._cursorDescription = options.cursorDescription;
      self._mongoHandle = options.mongoHandle;
      self._multiplexer = options.multiplexer;
      if (options.ordered) {
        throw Error("OplogObserveDriver only supports unordered observeChanges");
      }
      const sorter = options.sorter;
      // We don't support $near and other geo-queries so it's OK to initialize the
      // comparator only once in the constructor.
      const comparator = sorter && sorter.getComparator();
      if (options.cursorDescription.options.limit) {
        // There are several properties ordered driver implements:
        // - _limit is a positive number
        // - _comparator is a function-comparator by which the query is ordered
        // - _unpublishedBuffer is non-null Min/Max Heap,
        //                      the empty buffer in STEADY phase implies that the
        //                      everything that matches the queries selector fits
        //                      into published set.
        // - _published - Max Heap (also implements IdMap methods)

        const heapOptions = {
          IdMap: LocalCollection._IdMap
        };
        self._limit = self._cursorDescription.options.limit;
        self._comparator = comparator;
        self._sorter = sorter;
        self._unpublishedBuffer = new MinMaxHeap(comparator, heapOptions);
        // We need something that can find Max value in addition to IdMap interface
        self._published = new MaxHeap(comparator, heapOptions);
      } else {
        self._limit = 0;
        self._comparator = null;
        self._sorter = null;
        self._unpublishedBuffer = null;
        self._published = new LocalCollection._IdMap();
      }

      // Indicates if it is safe to insert a new document at the end of the buffer
      // for this query. i.e. it is known that there are no documents matching the
      // selector those are not in published or buffer.
      self._safeAppendToBuffer = false;
      self._stopped = false;
      self._stopHandles = [];
      self._addStopHandles = function (newStopHandles) {
        const expectedPattern = Match.ObjectIncluding({
          stop: Function
        });
        // Single item or array
        check(newStopHandles, Match.OneOf([expectedPattern], expectedPattern));
        self._stopHandles.push(newStopHandles);
      };
      Package['facts-base'] && Package['facts-base'].Facts.incrementServerFact("mongo-livedata", "observe-drivers-oplog", 1);
      self._registerPhaseChange(PHASE.QUERYING);
      self._matcher = options.matcher;
      // we are now using projection, not fields in the cursor description even if you pass {fields}
      // in the cursor construction
      const projection = self._cursorDescription.options.fields || self._cursorDescription.options.projection || {};
      self._projectionFn = LocalCollection._compileProjection(projection);
      // Projection function, result of combining important fields for selector and
      // existing fields projection
      self._sharedProjection = self._matcher.combineIntoProjection(projection);
      if (sorter) self._sharedProjection = sorter.combineIntoProjection(self._sharedProjection);
      self._sharedProjectionFn = LocalCollection._compileProjection(self._sharedProjection);
      self._needToFetch = new LocalCollection._IdMap();
      self._currentlyFetching = null;
      self._fetchGeneration = 0;
      self._requeryWhenDoneThisQuery = false;
      self._writesToCommitWhenWeReachSteady = [];
    };
    _.extend(OplogObserveDriver.prototype, {
      _init: async function () {
        const self = this;

        // If the oplog handle tells us that it skipped some entries (because it got
        // behind, say), re-poll.
        self._addStopHandles(self._mongoHandle._oplogHandle.onSkippedEntries(finishIfNeedToPollQuery(function () {
          return self._needToPollQuery();
        })));
        await forEachTrigger(self._cursorDescription, async function (trigger) {
          self._addStopHandles(await self._mongoHandle._oplogHandle.onOplogEntry(trigger, function (notification) {
            finishIfNeedToPollQuery(function () {
              const op = notification.op;
              if (notification.dropCollection || notification.dropDatabase) {
                // Note: this call is not allowed to block on anything (especially
                // on waiting for oplog entries to catch up) because that will block
                // onOplogEntry!
                return self._needToPollQuery();
              } else {
                // All other operators should be handled depending on phase
                if (self._phase === PHASE.QUERYING) {
                  return self._handleOplogEntryQuerying(op);
                } else {
                  return self._handleOplogEntrySteadyOrFetching(op);
                }
              }
            })();
          }));
        });

        // XXX ordering w.r.t. everything else?
        self._addStopHandles(await listenAll(self._cursorDescription, function () {
          // If we're not in a pre-fire write fence, we don't have to do anything.
          const fence = DDPServer._getCurrentFence();
          if (!fence || fence.fired) return;
          if (fence._oplogObserveDrivers) {
            fence._oplogObserveDrivers[self._id] = self;
            return;
          }
          fence._oplogObserveDrivers = {};
          fence._oplogObserveDrivers[self._id] = self;
          fence.onBeforeFire(async function () {
            const drivers = fence._oplogObserveDrivers;
            delete fence._oplogObserveDrivers;

            // This fence cannot fire until we've caught up to "this point" in the
            // oplog, and all observers made it back to the steady state.
            await self._mongoHandle._oplogHandle.waitUntilCaughtUp();
            for (const driver of Object.values(drivers)) {
              if (driver._stopped) continue;
              const write = await fence.beginWrite();
              if (driver._phase === PHASE.STEADY) {
                // Make sure that all of the callbacks have made it through the
                // multiplexer and been delivered to ObserveHandles before committing
                // writes.
                await driver._multiplexer.onFlush(write.committed);
              } else {
                driver._writesToCommitWhenWeReachSteady.push(write);
              }
            }
          });
        }));

        // When Mongo fails over, we need to repoll the query, in case we processed an
        // oplog entry that got rolled back.
        self._addStopHandles(self._mongoHandle._onFailover(finishIfNeedToPollQuery(function () {
          return self._needToPollQuery();
        })));

        // Give _observeChanges a chance to add the new ObserveHandle to our
        // multiplexer, so that the added calls get streamed.
        return self._runInitialQuery();
      },
      _addPublished: function (id, doc) {
        var self = this;
        Meteor._noYieldsAllowed(function () {
          var fields = _.clone(doc);
          delete fields._id;
          self._published.set(id, self._sharedProjectionFn(doc));
          self._multiplexer.added(id, self._projectionFn(fields));

          // After adding this document, the published set might be overflowed
          // (exceeding capacity specified by limit). If so, push the maximum
          // element to the buffer, we might want to save it in memory to reduce the
          // amount of Mongo lookups in the future.
          if (self._limit && self._published.size() > self._limit) {
            // XXX in theory the size of published is no more than limit+1
            if (self._published.size() !== self._limit + 1) {
              throw new Error("After adding to published, " + (self._published.size() - self._limit) + " documents are overflowing the set");
            }
            var overflowingDocId = self._published.maxElementId();
            var overflowingDoc = self._published.get(overflowingDocId);
            if (EJSON.equals(overflowingDocId, id)) {
              throw new Error("The document just added is overflowing the published set");
            }
            self._published.remove(overflowingDocId);
            self._multiplexer.removed(overflowingDocId);
            self._addBuffered(overflowingDocId, overflowingDoc);
          }
        });
      },
      _removePublished: function (id) {
        var self = this;
        Meteor._noYieldsAllowed(function () {
          self._published.remove(id);
          self._multiplexer.removed(id);
          if (!self._limit || self._published.size() === self._limit) return;
          if (self._published.size() > self._limit) throw Error("self._published got too big");

          // OK, we are publishing less than the limit. Maybe we should look in the
          // buffer to find the next element past what we were publishing before.

          if (!self._unpublishedBuffer.empty()) {
            // There's something in the buffer; move the first thing in it to
            // _published.
            var newDocId = self._unpublishedBuffer.minElementId();
            var newDoc = self._unpublishedBuffer.get(newDocId);
            self._removeBuffered(newDocId);
            self._addPublished(newDocId, newDoc);
            return;
          }

          // There's nothing in the buffer.  This could mean one of a few things.

          // (a) We could be in the middle of re-running the query (specifically, we
          // could be in _publishNewResults). In that case, _unpublishedBuffer is
          // empty because we clear it at the beginning of _publishNewResults. In
          // this case, our caller already knows the entire answer to the query and
          // we don't need to do anything fancy here.  Just return.
          if (self._phase === PHASE.QUERYING) return;

          // (b) We're pretty confident that the union of _published and
          // _unpublishedBuffer contain all documents that match selector. Because
          // _unpublishedBuffer is empty, that means we're confident that _published
          // contains all documents that match selector. So we have nothing to do.
          if (self._safeAppendToBuffer) return;

          // (c) Maybe there are other documents out there that should be in our
          // buffer. But in that case, when we emptied _unpublishedBuffer in
          // _removeBuffered, we should have called _needToPollQuery, which will
          // either put something in _unpublishedBuffer or set _safeAppendToBuffer
          // (or both), and it will put us in QUERYING for that whole time. So in
          // fact, we shouldn't be able to get here.

          throw new Error("Buffer inexplicably empty");
        });
      },
      _changePublished: function (id, oldDoc, newDoc) {
        var self = this;
        Meteor._noYieldsAllowed(function () {
          self._published.set(id, self._sharedProjectionFn(newDoc));
          var projectedNew = self._projectionFn(newDoc);
          var projectedOld = self._projectionFn(oldDoc);
          var changed = DiffSequence.makeChangedFields(projectedNew, projectedOld);
          if (!_.isEmpty(changed)) self._multiplexer.changed(id, changed);
        });
      },
      _addBuffered: function (id, doc) {
        var self = this;
        Meteor._noYieldsAllowed(function () {
          self._unpublishedBuffer.set(id, self._sharedProjectionFn(doc));

          // If something is overflowing the buffer, we just remove it from cache
          if (self._unpublishedBuffer.size() > self._limit) {
            var maxBufferedId = self._unpublishedBuffer.maxElementId();
            self._unpublishedBuffer.remove(maxBufferedId);

            // Since something matching is removed from cache (both published set and
            // buffer), set flag to false
            self._safeAppendToBuffer = false;
          }
        });
      },
      // Is called either to remove the doc completely from matching set or to move
      // it to the published set later.
      _removeBuffered: function (id) {
        var self = this;
        Meteor._noYieldsAllowed(function () {
          self._unpublishedBuffer.remove(id);
          // To keep the contract "buffer is never empty in STEADY phase unless the
          // everything matching fits into published" true, we poll everything as
          // soon as we see the buffer becoming empty.
          if (!self._unpublishedBuffer.size() && !self._safeAppendToBuffer) self._needToPollQuery();
        });
      },
      // Called when a document has joined the "Matching" results set.
      // Takes responsibility of keeping _unpublishedBuffer in sync with _published
      // and the effect of limit enforced.
      _addMatching: function (doc) {
        var self = this;
        Meteor._noYieldsAllowed(function () {
          var id = doc._id;
          if (self._published.has(id)) throw Error("tried to add something already published " + id);
          if (self._limit && self._unpublishedBuffer.has(id)) throw Error("tried to add something already existed in buffer " + id);
          var limit = self._limit;
          var comparator = self._comparator;
          var maxPublished = limit && self._published.size() > 0 ? self._published.get(self._published.maxElementId()) : null;
          var maxBuffered = limit && self._unpublishedBuffer.size() > 0 ? self._unpublishedBuffer.get(self._unpublishedBuffer.maxElementId()) : null;
          // The query is unlimited or didn't publish enough documents yet or the
          // new document would fit into published set pushing the maximum element
          // out, then we need to publish the doc.
          var toPublish = !limit || self._published.size() < limit || comparator(doc, maxPublished) < 0;

          // Otherwise we might need to buffer it (only in case of limited query).
          // Buffering is allowed if the buffer is not filled up yet and all
          // matching docs are either in the published set or in the buffer.
          var canAppendToBuffer = !toPublish && self._safeAppendToBuffer && self._unpublishedBuffer.size() < limit;

          // Or if it is small enough to be safely inserted to the middle or the
          // beginning of the buffer.
          var canInsertIntoBuffer = !toPublish && maxBuffered && comparator(doc, maxBuffered) <= 0;
          var toBuffer = canAppendToBuffer || canInsertIntoBuffer;
          if (toPublish) {
            self._addPublished(id, doc);
          } else if (toBuffer) {
            self._addBuffered(id, doc);
          } else {
            // dropping it and not saving to the cache
            self._safeAppendToBuffer = false;
          }
        });
      },
      // Called when a document leaves the "Matching" results set.
      // Takes responsibility of keeping _unpublishedBuffer in sync with _published
      // and the effect of limit enforced.
      _removeMatching: function (id) {
        var self = this;
        Meteor._noYieldsAllowed(function () {
          if (!self._published.has(id) && !self._limit) throw Error("tried to remove something matching but not cached " + id);
          if (self._published.has(id)) {
            self._removePublished(id);
          } else if (self._unpublishedBuffer.has(id)) {
            self._removeBuffered(id);
          }
        });
      },
      _handleDoc: function (id, newDoc) {
        var self = this;
        Meteor._noYieldsAllowed(function () {
          var matchesNow = newDoc && self._matcher.documentMatches(newDoc).result;
          var publishedBefore = self._published.has(id);
          var bufferedBefore = self._limit && self._unpublishedBuffer.has(id);
          var cachedBefore = publishedBefore || bufferedBefore;
          if (matchesNow && !cachedBefore) {
            self._addMatching(newDoc);
          } else if (cachedBefore && !matchesNow) {
            self._removeMatching(id);
          } else if (cachedBefore && matchesNow) {
            var oldDoc = self._published.get(id);
            var comparator = self._comparator;
            var minBuffered = self._limit && self._unpublishedBuffer.size() && self._unpublishedBuffer.get(self._unpublishedBuffer.minElementId());
            var maxBuffered;
            if (publishedBefore) {
              // Unlimited case where the document stays in published once it
              // matches or the case when we don't have enough matching docs to
              // publish or the changed but matching doc will stay in published
              // anyways.
              //
              // XXX: We rely on the emptiness of buffer. Be sure to maintain the
              // fact that buffer can't be empty if there are matching documents not
              // published. Notably, we don't want to schedule repoll and continue
              // relying on this property.
              var staysInPublished = !self._limit || self._unpublishedBuffer.size() === 0 || comparator(newDoc, minBuffered) <= 0;
              if (staysInPublished) {
                self._changePublished(id, oldDoc, newDoc);
              } else {
                // after the change doc doesn't stay in the published, remove it
                self._removePublished(id);
                // but it can move into buffered now, check it
                maxBuffered = self._unpublishedBuffer.get(self._unpublishedBuffer.maxElementId());
                var toBuffer = self._safeAppendToBuffer || maxBuffered && comparator(newDoc, maxBuffered) <= 0;
                if (toBuffer) {
                  self._addBuffered(id, newDoc);
                } else {
                  // Throw away from both published set and buffer
                  self._safeAppendToBuffer = false;
                }
              }
            } else if (bufferedBefore) {
              oldDoc = self._unpublishedBuffer.get(id);
              // remove the old version manually instead of using _removeBuffered so
              // we don't trigger the querying immediately.  if we end this block
              // with the buffer empty, we will need to trigger the query poll
              // manually too.
              self._unpublishedBuffer.remove(id);
              var maxPublished = self._published.get(self._published.maxElementId());
              maxBuffered = self._unpublishedBuffer.size() && self._unpublishedBuffer.get(self._unpublishedBuffer.maxElementId());

              // the buffered doc was updated, it could move to published
              var toPublish = comparator(newDoc, maxPublished) < 0;

              // or stays in buffer even after the change
              var staysInBuffer = !toPublish && self._safeAppendToBuffer || !toPublish && maxBuffered && comparator(newDoc, maxBuffered) <= 0;
              if (toPublish) {
                self._addPublished(id, newDoc);
              } else if (staysInBuffer) {
                // stays in buffer but changes
                self._unpublishedBuffer.set(id, newDoc);
              } else {
                // Throw away from both published set and buffer
                self._safeAppendToBuffer = false;
                // Normally this check would have been done in _removeBuffered but
                // we didn't use it, so we need to do it ourself now.
                if (!self._unpublishedBuffer.size()) {
                  self._needToPollQuery();
                }
              }
            } else {
              throw new Error("cachedBefore implies either of publishedBefore or bufferedBefore is true.");
            }
          }
        });
      },
      _fetchModifiedDocuments: function () {
        var self = this;
        self._registerPhaseChange(PHASE.FETCHING);
        // Defer, because nothing called from the oplog entry handler may yield,
        // but fetch() yields.
        Meteor.defer(finishIfNeedToPollQuery(async function () {
          while (!self._stopped && !self._needToFetch.empty()) {
            if (self._phase === PHASE.QUERYING) {
              // While fetching, we decided to go into QUERYING mode, and then we
              // saw another oplog entry, so _needToFetch is not empty. But we
              // shouldn't fetch these documents until AFTER the query is done.
              break;
            }

            // Being in steady phase here would be surprising.
            if (self._phase !== PHASE.FETCHING) throw new Error("phase in fetchModifiedDocuments: " + self._phase);
            self._currentlyFetching = self._needToFetch;
            var thisGeneration = ++self._fetchGeneration;
            self._needToFetch = new LocalCollection._IdMap();
            var waiting = 0;
            let promiseResolver = null;
            const awaitablePromise = new Promise(r => promiseResolver = r);
            // This loop is safe, because _currentlyFetching will not be updated
            // during this loop (in fact, it is never mutated).
            await self._currentlyFetching.forEachAsync(async function (op, id) {
              waiting++;
              await self._mongoHandle._docFetcher.fetch(self._cursorDescription.collectionName, id, op, finishIfNeedToPollQuery(function (err, doc) {
                if (err) {
                  Meteor._debug('Got exception while fetching documents', err);
                  // If we get an error from the fetcher (eg, trouble
                  // connecting to Mongo), let's just abandon the fetch phase
                  // altogether and fall back to polling. It's not like we're
                  // getting live updates anyway.
                  if (self._phase !== PHASE.QUERYING) {
                    self._needToPollQuery();
                  }
                  waiting--;
                  // Because fetch() never calls its callback synchronously,
                  // this is safe (ie, we won't call fut.return() before the
                  // forEach is done).
                  if (waiting === 0) promiseResolver();
                  return;
                }
                try {
                  if (!self._stopped && self._phase === PHASE.FETCHING && self._fetchGeneration === thisGeneration) {
                    // We re-check the generation in case we've had an explicit
                    // _pollQuery call (eg, in another fiber) which should
                    // effectively cancel this round of fetches.  (_pollQuery
                    // increments the generation.)

                    self._handleDoc(id, doc);
                  }
                } finally {
                  waiting--;
                  // Because fetch() never calls its callback synchronously,
                  // this is safe (ie, we won't call fut.return() before the
                  // forEach is done).
                  if (waiting === 0) promiseResolver();
                }
              }));
            });
            await awaitablePromise;
            // Exit now if we've had a _pollQuery call (here or in another fiber).
            if (self._phase === PHASE.QUERYING) return;
            self._currentlyFetching = null;
          }
          // We're done fetching, so we can be steady, unless we've had a
          // _pollQuery call (here or in another fiber).
          if (self._phase !== PHASE.QUERYING) await self._beSteady();
        }));
      },
      _beSteady: async function () {
        var self = this;
        self._registerPhaseChange(PHASE.STEADY);
        var writes = self._writesToCommitWhenWeReachSteady || [];
        self._writesToCommitWhenWeReachSteady = [];
        await self._multiplexer.onFlush(async function () {
          try {
            for (const w of writes) {
              await w.committed();
            }
          } catch (e) {
            console.error("_beSteady error", {
              writes
            }, e);
          }
        });
      },
      _handleOplogEntryQuerying: function (op) {
        var self = this;
        Meteor._noYieldsAllowed(function () {
          self._needToFetch.set(idForOp(op), op);
        });
      },
      _handleOplogEntrySteadyOrFetching: function (op) {
        var self = this;
        Meteor._noYieldsAllowed(function () {
          var id = idForOp(op);
          // If we're already fetching this one, or about to, we can't optimize;
          // make sure that we fetch it again if necessary.

          if (self._phase === PHASE.FETCHING && (self._currentlyFetching && self._currentlyFetching.has(id) || self._needToFetch.has(id))) {
            self._needToFetch.set(id, op);
            return;
          }
          if (op.op === 'd') {
            if (self._published.has(id) || self._limit && self._unpublishedBuffer.has(id)) self._removeMatching(id);
          } else if (op.op === 'i') {
            if (self._published.has(id)) throw new Error("insert found for already-existing ID in published");
            if (self._unpublishedBuffer && self._unpublishedBuffer.has(id)) throw new Error("insert found for already-existing ID in buffer");

            // XXX what if selector yields?  for now it can't but later it could
            // have $where
            if (self._matcher.documentMatches(op.o).result) self._addMatching(op.o);
          } else if (op.op === 'u') {
            // we are mapping the new oplog format on mongo 5
            // to what we know better, $set
            op.o = oplogV2V1Converter(op.o);
            // Is this a modifier ($set/$unset, which may require us to poll the
            // database to figure out if the whole document matches the selector) or
            // a replacement (in which case we can just directly re-evaluate the
            // selector)?
            // oplog format has changed on mongodb 5, we have to support both now
            // diff is the format in Mongo 5+ (oplog v2)
            var isReplace = !_.has(op.o, '$set') && !_.has(op.o, 'diff') && !_.has(op.o, '$unset');
            // If this modifier modifies something inside an EJSON custom type (ie,
            // anything with EJSON$), then we can't try to use
            // LocalCollection._modify, since that just mutates the EJSON encoding,
            // not the actual object.
            var canDirectlyModifyDoc = !isReplace && modifierCanBeDirectlyApplied(op.o);
            var publishedBefore = self._published.has(id);
            var bufferedBefore = self._limit && self._unpublishedBuffer.has(id);
            if (isReplace) {
              self._handleDoc(id, _.extend({
                _id: id
              }, op.o));
            } else if ((publishedBefore || bufferedBefore) && canDirectlyModifyDoc) {
              // Oh great, we actually know what the document is, so we can apply
              // this directly.
              var newDoc = self._published.has(id) ? self._published.get(id) : self._unpublishedBuffer.get(id);
              newDoc = EJSON.clone(newDoc);
              newDoc._id = id;
              try {
                LocalCollection._modify(newDoc, op.o);
              } catch (e) {
                if (e.name !== "MinimongoError") throw e;
                // We didn't understand the modifier.  Re-fetch.
                self._needToFetch.set(id, op);
                if (self._phase === PHASE.STEADY) {
                  self._fetchModifiedDocuments();
                }
                return;
              }
              self._handleDoc(id, self._sharedProjectionFn(newDoc));
            } else if (!canDirectlyModifyDoc || self._matcher.canBecomeTrueByModifier(op.o) || self._sorter && self._sorter.affectedByModifier(op.o)) {
              self._needToFetch.set(id, op);
              if (self._phase === PHASE.STEADY) self._fetchModifiedDocuments();
            }
          } else {
            throw Error("XXX SURPRISING OPERATION: " + op);
          }
        });
      },
      async _runInitialQueryAsync() {
        var self = this;
        if (self._stopped) throw new Error("oplog stopped surprisingly early");
        await self._runQuery({
          initial: true
        }); // yields

        if (self._stopped) return; // can happen on queryError

        // Allow observeChanges calls to return. (After this, it's possible for
        // stop() to be called.)
        await self._multiplexer.ready();
        await self._doneQuerying(); // yields
      },
      // Yields!
      _runInitialQuery: function () {
        return this._runInitialQueryAsync();
      },
      // In various circumstances, we may just want to stop processing the oplog and
      // re-run the initial query, just as if we were a PollingObserveDriver.
      //
      // This function may not block, because it is called from an oplog entry
      // handler.
      //
      // XXX We should call this when we detect that we've been in FETCHING for "too
      // long".
      //
      // XXX We should call this when we detect Mongo failover (since that might
      // mean that some of the oplog entries we have processed have been rolled
      // back). The Node Mongo driver is in the middle of a bunch of huge
      // refactorings, including the way that it notifies you when primary
      // changes. Will put off implementing this until driver 1.4 is out.
      _pollQuery: function () {
        var self = this;
        Meteor._noYieldsAllowed(function () {
          if (self._stopped) return;

          // Yay, we get to forget about all the things we thought we had to fetch.
          self._needToFetch = new LocalCollection._IdMap();
          self._currentlyFetching = null;
          ++self._fetchGeneration; // ignore any in-flight fetches
          self._registerPhaseChange(PHASE.QUERYING);

          // Defer so that we don't yield.  We don't need finishIfNeedToPollQuery
          // here because SwitchedToQuery is not thrown in QUERYING mode.
          Meteor.defer(async function () {
            await self._runQuery();
            await self._doneQuerying();
          });
        });
      },
      // Yields!
      async _runQueryAsync(options) {
        var self = this;
        options = options || {};
        var newResults, newBuffer;

        // This while loop is just to retry failures.
        while (true) {
          // If we've been stopped, we don't have to run anything any more.
          if (self._stopped) return;
          newResults = new LocalCollection._IdMap();
          newBuffer = new LocalCollection._IdMap();

          // Query 2x documents as the half excluded from the original query will go
          // into unpublished buffer to reduce additional Mongo lookups in cases
          // when documents are removed from the published set and need a
          // replacement.
          // XXX needs more thought on non-zero skip
          // XXX 2 is a "magic number" meaning there is an extra chunk of docs for
          // buffer if such is needed.
          var cursor = self._cursorForQuery({
            limit: self._limit * 2
          });
          try {
            await cursor.forEach(function (doc, i) {
              // yields
              if (!self._limit || i < self._limit) {
                newResults.set(doc._id, doc);
              } else {
                newBuffer.set(doc._id, doc);
              }
            });
            break;
          } catch (e) {
            if (options.initial && typeof e.code === 'number') {
              // This is an error document sent to us by mongod, not a connection
              // error generated by the client. And we've never seen this query work
              // successfully. Probably it's a bad selector or something, so we
              // should NOT retry. Instead, we should halt the observe (which ends
              // up calling `stop` on us).
              await self._multiplexer.queryError(e);
              return;
            }

            // During failover (eg) if we get an exception we should log and retry
            // instead of crashing.
            Meteor._debug("Got exception while polling query", e);
            await Meteor._sleepForMs(100);
          }
        }
        if (self._stopped) return;
        self._publishNewResults(newResults, newBuffer);
      },
      // Yields!
      _runQuery: function (options) {
        return this._runQueryAsync(options);
      },
      // Transitions to QUERYING and runs another query, or (if already in QUERYING)
      // ensures that we will query again later.
      //
      // This function may not block, because it is called from an oplog entry
      // handler. However, if we were not already in the QUERYING phase, it throws
      // an exception that is caught by the closest surrounding
      // finishIfNeedToPollQuery call; this ensures that we don't continue running
      // close that was designed for another phase inside PHASE.QUERYING.
      //
      // (It's also necessary whenever logic in this file yields to check that other
      // phases haven't put us into QUERYING mode, though; eg,
      // _fetchModifiedDocuments does this.)
      _needToPollQuery: function () {
        var self = this;
        Meteor._noYieldsAllowed(function () {
          if (self._stopped) return;

          // If we're not already in the middle of a query, we can query now
          // (possibly pausing FETCHING).
          if (self._phase !== PHASE.QUERYING) {
            self._pollQuery();
            throw new SwitchedToQuery();
          }

          // We're currently in QUERYING. Set a flag to ensure that we run another
          // query when we're done.
          self._requeryWhenDoneThisQuery = true;
        });
      },
      // Yields!
      _doneQuerying: async function () {
        var self = this;
        if (self._stopped) return;
        await self._mongoHandle._oplogHandle.waitUntilCaughtUp();
        if (self._stopped) return;
        if (self._phase !== PHASE.QUERYING) throw Error("Phase unexpectedly " + self._phase);
        if (self._requeryWhenDoneThisQuery) {
          self._requeryWhenDoneThisQuery = false;
          self._pollQuery();
        } else if (self._needToFetch.empty()) {
          await self._beSteady();
        } else {
          self._fetchModifiedDocuments();
        }
      },
      _cursorForQuery: function (optionsOverwrite) {
        var self = this;
        return Meteor._noYieldsAllowed(function () {
          // The query we run is almost the same as the cursor we are observing,
          // with a few changes. We need to read all the fields that are relevant to
          // the selector, not just the fields we are going to publish (that's the
          // "shared" projection). And we don't want to apply any transform in the
          // cursor, because observeChanges shouldn't use the transform.
          var options = _.clone(self._cursorDescription.options);

          // Allow the caller to modify the options. Useful to specify different
          // skip and limit values.
          _.extend(options, optionsOverwrite);
          options.fields = self._sharedProjection;
          delete options.transform;
          // We are NOT deep cloning fields or selector here, which should be OK.
          var description = new CursorDescription(self._cursorDescription.collectionName, self._cursorDescription.selector, options);
          return new Cursor(self._mongoHandle, description);
        });
      },
      // Replace self._published with newResults (both are IdMaps), invoking observe
      // callbacks on the multiplexer.
      // Replace self._unpublishedBuffer with newBuffer.
      //
      // XXX This is very similar to LocalCollection._diffQueryUnorderedChanges. We
      // should really: (a) Unify IdMap and OrderedDict into Unordered/OrderedDict
      // (b) Rewrite diff.js to use these classes instead of arrays and objects.
      _publishNewResults: function (newResults, newBuffer) {
        var self = this;
        Meteor._noYieldsAllowed(function () {
          // If the query is limited and there is a buffer, shut down so it doesn't
          // stay in a way.
          if (self._limit) {
            self._unpublishedBuffer.clear();
          }

          // First remove anything that's gone. Be careful not to modify
          // self._published while iterating over it.
          var idsToRemove = [];
          self._published.forEach(function (doc, id) {
            if (!newResults.has(id)) idsToRemove.push(id);
          });
          _.each(idsToRemove, function (id) {
            self._removePublished(id);
          });

          // Now do adds and changes.
          // If self has a buffer and limit, the new fetched result will be
          // limited correctly as the query has sort specifier.
          newResults.forEach(function (doc, id) {
            self._handleDoc(id, doc);
          });

          // Sanity-check that everything we tried to put into _published ended up
          // there.
          // XXX if this is slow, remove it later
          if (self._published.size() !== newResults.size()) {
            Meteor._debug('The Mongo server and the Meteor query disagree on how ' + 'many documents match your query. Cursor description: ', self._cursorDescription);
          }
          self._published.forEach(function (doc, id) {
            if (!newResults.has(id)) throw Error("_published has a doc that newResults doesn't; " + id);
          });

          // Finally, replace the buffer
          newBuffer.forEach(function (doc, id) {
            self._addBuffered(id, doc);
          });
          self._safeAppendToBuffer = newBuffer.size() < self._limit;
        });
      },
      // This stop function is invoked from the onStop of the ObserveMultiplexer, so
      // it shouldn't actually be possible to call it until the multiplexer is
      // ready.
      //
      // It's important to check self._stopped after every call in this file that
      // can yield!
      _stop: async function () {
        var self = this;
        if (self._stopped) return;
        self._stopped = true;

        // Note: we *don't* use multiplexer.onFlush here because this stop
        // callback is actually invoked by the multiplexer itself when it has
        // determined that there are no handles left. So nothing is actually going
        // to get flushed (and it's probably not valid to call methods on the
        // dying multiplexer).
        for (const w of self._writesToCommitWhenWeReachSteady) {
          await w.committed();
        }
        self._writesToCommitWhenWeReachSteady = null;

        // Proactively drop references to potentially big things.
        self._published = null;
        self._unpublishedBuffer = null;
        self._needToFetch = null;
        self._currentlyFetching = null;
        self._oplogEntryHandle = null;
        self._listenersHandle = null;
        Package['facts-base'] && Package['facts-base'].Facts.incrementServerFact("mongo-livedata", "observe-drivers-oplog", -1);
        var _iteratorAbruptCompletion = false;
        var _didIteratorError = false;
        var _iteratorError;
        try {
          for (var _iterator = _asyncIterator(self._stopHandles), _step; _iteratorAbruptCompletion = !(_step = await _iterator.next()).done; _iteratorAbruptCompletion = false) {
            const handle = _step.value;
            {
              await handle.stop();
            }
          }
        } catch (err) {
          _didIteratorError = true;
          _iteratorError = err;
        } finally {
          try {
            if (_iteratorAbruptCompletion && _iterator.return != null) {
              await _iterator.return();
            }
          } finally {
            if (_didIteratorError) {
              throw _iteratorError;
            }
          }
        }
      },
      stop: async function () {
        const self = this;
        return await self._stop();
      },
      _registerPhaseChange: function (phase) {
        var self = this;
        Meteor._noYieldsAllowed(function () {
          var now = new Date();
          if (self._phase) {
            var timeDiff = now - self._phaseStartTime;
            Package['facts-base'] && Package['facts-base'].Facts.incrementServerFact("mongo-livedata", "time-spent-in-" + self._phase + "-phase", timeDiff);
          }
          self._phase = phase;
          self._phaseStartTime = now;
        });
      }
    });

    // Does our oplog tailing code support this cursor? For now, we are being very
    // conservative and allowing only simple queries with simple options.
    // (This is a "static method".)
    OplogObserveDriver.cursorSupported = function (cursorDescription, matcher) {
      // First, check the options.
      var options = cursorDescription.options;

      // Did the user say no explicitly?
      // underscored version of the option is COMPAT with 1.2
      if (options.disableOplog || options._disableOplog) return false;

      // skip is not supported: to support it we would need to keep track of all
      // "skipped" documents or at least their ids.
      // limit w/o a sort specifier is not supported: current implementation needs a
      // deterministic way to order documents.
      if (options.skip || options.limit && !options.sort) return false;

      // If a fields projection option is given check if it is supported by
      // minimongo (some operators are not supported).
      const fields = options.fields || options.projection;
      if (fields) {
        try {
          LocalCollection._checkSupportedProjection(fields);
        } catch (e) {
          if (e.name === "MinimongoError") {
            return false;
          } else {
            throw e;
          }
        }
      }

      // We don't allow the following selectors:
      //   - $where (not confident that we provide the same JS environment
      //             as Mongo, and can yield!)
      //   - $near (has "interesting" properties in MongoDB, like the possibility
      //            of returning an ID multiple times, though even polling maybe
      //            have a bug there)
      //           XXX: once we support it, we would need to think more on how we
      //           initialize the comparators when we create the driver.
      return !matcher.hasWhere() && !matcher.hasGeoQuery();
    };
    var modifierCanBeDirectlyApplied = function (modifier) {
      return _.all(modifier, function (fields, operation) {
        return _.all(fields, function (value, field) {
          return !/EJSON\$/.test(field);
        });
      });
    };
    MongoInternals.OplogObserveDriver = OplogObserveDriver;
    __reify_async_result__();
  } catch (_reifyError) {
    return __reify_async_result__(_reifyError);
  }
  __reify_async_result__()
}, {
  self: this,
  async: false
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"oplog_v2_converter.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/mongo/oplog_v2_converter.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  oplogV2V1Converter: () => oplogV2V1Converter
});
// Converter of the new MongoDB Oplog format (>=5.0) to the one that Meteor
// handles well, i.e., `$set` and `$unset`. The new format is completely new,
// and looks as follows:
//
//   { $v: 2, diff: Diff }
//
// where `Diff` is a recursive structure:
//
//   {
//     // Nested updates (sometimes also represented with an s-field).
//     // Example: `{ $set: { 'foo.bar': 1 } }`.
//     i: { <key>: <value>, ... },
//
//     // Top-level updates.
//     // Example: `{ $set: { foo: { bar: 1 } } }`.
//     u: { <key>: <value>, ... },
//
//     // Unsets.
//     // Example: `{ $unset: { foo: '' } }`.
//     d: { <key>: false, ... },
//
//     // Array operations.
//     // Example: `{ $push: { foo: 'bar' } }`.
//     s<key>: { a: true, u<index>: <value>, ... },
//     ...
//
//     // Nested operations (sometimes also represented in the `i` field).
//     // Example: `{ $set: { 'foo.bar': 1 } }`.
//     s<key>: Diff,
//     ...
//   }
//
// (all fields are optional).

function join(prefix, key) {
  return prefix ? "".concat(prefix, ".").concat(key) : key;
}
const arrayOperatorKeyRegex = /^(a|[su]\d+)$/;
function isArrayOperatorKey(field) {
  return arrayOperatorKeyRegex.test(field);
}
function isArrayOperator(operator) {
  return operator.a === true && Object.keys(operator).every(isArrayOperatorKey);
}
function flattenObjectInto(target, source, prefix) {
  if (Array.isArray(source) || typeof source !== 'object' || source === null || source instanceof Mongo.ObjectID) {
    target[prefix] = source;
  } else {
    const entries = Object.entries(source);
    if (entries.length) {
      entries.forEach(_ref => {
        let [key, value] = _ref;
        flattenObjectInto(target, value, join(prefix, key));
      });
    } else {
      target[prefix] = source;
    }
  }
}
const logDebugMessages = !!process.env.OPLOG_CONVERTER_DEBUG;
function convertOplogDiff(oplogEntry, diff, prefix) {
  if (logDebugMessages) {
    console.log("convertOplogDiff(".concat(JSON.stringify(oplogEntry), ", ").concat(JSON.stringify(diff), ", ").concat(JSON.stringify(prefix), ")"));
  }
  Object.entries(diff).forEach(_ref2 => {
    let [diffKey, value] = _ref2;
    if (diffKey === 'd') {
      var _oplogEntry$$unset;
      // Handle `$unset`s.
      (_oplogEntry$$unset = oplogEntry.$unset) !== null && _oplogEntry$$unset !== void 0 ? _oplogEntry$$unset : oplogEntry.$unset = {};
      Object.keys(value).forEach(key => {
        oplogEntry.$unset[join(prefix, key)] = true;
      });
    } else if (diffKey === 'i') {
      var _oplogEntry$$set;
      // Handle (potentially) nested `$set`s.
      (_oplogEntry$$set = oplogEntry.$set) !== null && _oplogEntry$$set !== void 0 ? _oplogEntry$$set : oplogEntry.$set = {};
      flattenObjectInto(oplogEntry.$set, value, prefix);
    } else if (diffKey === 'u') {
      var _oplogEntry$$set2;
      // Handle flat `$set`s.
      (_oplogEntry$$set2 = oplogEntry.$set) !== null && _oplogEntry$$set2 !== void 0 ? _oplogEntry$$set2 : oplogEntry.$set = {};
      Object.entries(value).forEach(_ref3 => {
        let [key, value] = _ref3;
        oplogEntry.$set[join(prefix, key)] = value;
      });
    } else {
      // Handle s-fields.
      const key = diffKey.slice(1);
      if (isArrayOperator(value)) {
        // Array operator.
        Object.entries(value).forEach(_ref4 => {
          let [position, value] = _ref4;
          if (position === 'a') {
            return;
          }
          const positionKey = join(join(prefix, key), position.slice(1));
          if (position[0] === 's') {
            convertOplogDiff(oplogEntry, value, positionKey);
          } else if (value === null) {
            var _oplogEntry$$unset2;
            (_oplogEntry$$unset2 = oplogEntry.$unset) !== null && _oplogEntry$$unset2 !== void 0 ? _oplogEntry$$unset2 : oplogEntry.$unset = {};
            oplogEntry.$unset[positionKey] = true;
          } else {
            var _oplogEntry$$set3;
            (_oplogEntry$$set3 = oplogEntry.$set) !== null && _oplogEntry$$set3 !== void 0 ? _oplogEntry$$set3 : oplogEntry.$set = {};
            oplogEntry.$set[positionKey] = value;
          }
        });
      } else if (key) {
        // Nested object.
        convertOplogDiff(oplogEntry, value, join(prefix, key));
      }
    }
  });
}
function oplogV2V1Converter(oplogEntry) {
  // Pass-through v1 and (probably) invalid entries.
  if (oplogEntry.$v !== 2 || !oplogEntry.diff) {
    return oplogEntry;
  }
  const convertedOplogEntry = {
    $v: 2
  };
  convertOplogDiff(convertedOplogEntry, oplogEntry.diff, '');
  return convertedOplogEntry;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"local_collection_driver.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/mongo/local_collection_driver.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({
  LocalCollectionDriver: () => LocalCollectionDriver
});
const LocalCollectionDriver = new class LocalCollectionDriver {
  constructor() {
    this.noConnCollections = Object.create(null);
  }
  open(name, conn) {
    if (!name) {
      return new LocalCollection();
    }
    if (!conn) {
      return ensureCollection(name, this.noConnCollections);
    }
    if (!conn._mongo_livedata_collections) {
      conn._mongo_livedata_collections = Object.create(null);
    }

    // XXX is there a way to keep track of a connection's collections without
    // dangling it off the connection object?
    return ensureCollection(name, conn._mongo_livedata_collections);
  }
}();
function ensureCollection(name, collections) {
  return name in collections ? collections[name] : collections[name] = new LocalCollection(name);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"remote_collection_driver.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/mongo/remote_collection_driver.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
!module.wrapAsync(async function (module, __reifyWaitForDeps__, __reify_async_result__) {
  "use strict";
  try {
    let ASYNC_COLLECTION_METHODS, getAsyncMethodName, CLIENT_ONLY_METHODS;
    module.link("meteor/minimongo/constants", {
      ASYNC_COLLECTION_METHODS(v) {
        ASYNC_COLLECTION_METHODS = v;
      },
      getAsyncMethodName(v) {
        getAsyncMethodName = v;
      },
      CLIENT_ONLY_METHODS(v) {
        CLIENT_ONLY_METHODS = v;
      }
    }, 0);
    if (__reifyWaitForDeps__()) (await __reifyWaitForDeps__())();
    MongoInternals.RemoteCollectionDriver = function (mongo_url, options) {
      var self = this;
      self.mongo = new MongoConnection(mongo_url, options);
    };
    const REMOTE_COLLECTION_METHODS = ['createCappedCollectionAsync', 'dropIndexAsync', 'ensureIndexAsync', 'createIndexAsync', 'countDocuments', 'dropCollectionAsync', 'estimatedDocumentCount', 'find', 'findOneAsync', 'insertAsync', 'rawCollection', 'removeAsync', 'updateAsync', 'upsertAsync'];
    Object.assign(MongoInternals.RemoteCollectionDriver.prototype, {
      open: function (name) {
        var self = this;
        var ret = {};
        REMOTE_COLLECTION_METHODS.forEach(function (m) {
          ret[m] = _.bind(self.mongo[m], self.mongo, name);
          if (!ASYNC_COLLECTION_METHODS.includes(m)) return;
          const asyncMethodName = getAsyncMethodName(m);
          ret[asyncMethodName] = function () {
            try {
              return Promise.resolve(ret[m](...arguments));
            } catch (error) {
              return Promise.reject(error);
            }
          };
        });
        CLIENT_ONLY_METHODS.forEach(function (m) {
          ret[m] = _.bind(self.mongo[m], self.mongo, name);
          ret[m] = function () {
            throw new Error("".concat(m, " +  is not available on the server. Please use ").concat(getAsyncMethodName(m), "() instead."));
          };
        });
        return ret;
      }
    });

    // Create the singleton RemoteCollectionDriver only on demand, so we
    // only require Mongo configuration if it's actually used (eg, not if
    // you're only trying to receive data from a remote DDP server.)
    MongoInternals.defaultRemoteCollectionDriver = _.once(function () {
      var connectionOptions = {};
      var mongoUrl = process.env.MONGO_URL;
      if (process.env.MONGO_OPLOG_URL) {
        connectionOptions.oplogUrl = process.env.MONGO_OPLOG_URL;
      }
      if (!mongoUrl) throw new Error("MONGO_URL must be set in environment");
      const driver = new MongoInternals.RemoteCollectionDriver(mongoUrl, connectionOptions);

      // As many deployment tools, including Meteor Up, send requests to the app in
      // order to confirm that the deployment finished successfully, it's required
      // to know about a database connection problem before the app starts. Doing so
      // in a `Meteor.startup` is fine, as the `WebApp` handles requests only after
      // all are finished.
      Meteor.startup(async () => {
        await driver.mongo.client.connect();
      });
      return driver;
    });
    __reify_async_result__();
  } catch (_reifyError) {
    return __reify_async_result__(_reifyError);
  }
  __reify_async_result__()
}, {
  self: this,
  async: false
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"collection.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/mongo/collection.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
!module.wrapAsync(async function (module1, __reifyWaitForDeps__, __reify_async_result__) {
  "use strict";
  try {
    let _objectSpread;
    module1.link("@babel/runtime/helpers/objectSpread2", {
      default(v) {
        _objectSpread = v;
      }
    }, 0);
    let ASYNC_COLLECTION_METHODS, getAsyncMethodName;
    module1.link("meteor/minimongo/constants", {
      ASYNC_COLLECTION_METHODS(v) {
        ASYNC_COLLECTION_METHODS = v;
      },
      getAsyncMethodName(v) {
        getAsyncMethodName = v;
      }
    }, 0);
    let normalizeProjection;
    module1.link("./mongo_utils", {
      normalizeProjection(v) {
        normalizeProjection = v;
      }
    }, 1);
    if (__reifyWaitForDeps__()) (await __reifyWaitForDeps__())();
    /**
     * @summary Namespace for MongoDB-related items
     * @namespace
     */
    Mongo = {};

    /**
     * @summary Constructor for a Collection
     * @locus Anywhere
     * @instancename collection
     * @class
     * @param {String} name The name of the collection.  If null, creates an unmanaged (unsynchronized) local collection.
     * @param {Object} [options]
     * @param {Object} options.connection The server connection that will manage this collection. Uses the default connection if not specified.  Pass the return value of calling [`DDP.connect`](#DDP-connect) to specify a different server. Pass `null` to specify no connection. Unmanaged (`name` is null) collections cannot specify a connection.
     * @param {String} options.idGeneration The method of generating the `_id` fields of new documents in this collection.  Possible values:
    
     - **`'STRING'`**: random strings
     - **`'MONGO'`**:  random [`Mongo.ObjectID`](#mongo_object_id) values
    
    The default id generation technique is `'STRING'`.
     * @param {Function} options.transform An optional transformation function. Documents will be passed through this function before being returned from `fetch` or `findOneAsync`, and before being passed to callbacks of `observe`, `map`, `forEach`, `allow`, and `deny`. Transforms are *not* applied for the callbacks of `observeChanges` or to cursors returned from publish functions.
     * @param {Boolean} options.defineMutationMethods Set to `false` to skip setting up the mutation methods that enable insert/update/remove from client code. Default `true`.
     */
    Mongo.Collection = function Collection(name, options) {
      if (!name && name !== null) {
        Meteor._debug('Warning: creating anonymous collection. It will not be ' + 'saved or synchronized over the network. (Pass null for ' + 'the collection name to turn off this warning.)');
        name = null;
      }
      if (name !== null && typeof name !== 'string') {
        throw new Error('First argument to new Mongo.Collection must be a string or null');
      }
      if (options && options.methods) {
        // Backwards compatibility hack with original signature (which passed
        // "connection" directly instead of in options. (Connections must have a "methods"
        // method.)
        // XXX remove before 1.0
        options = {
          connection: options
        };
      }
      // Backwards compatibility: "connection" used to be called "manager".
      if (options && options.manager && !options.connection) {
        options.connection = options.manager;
      }
      options = _objectSpread({
        connection: undefined,
        idGeneration: 'STRING',
        transform: null,
        _driver: undefined,
        _preventAutopublish: false
      }, options);
      switch (options.idGeneration) {
        case 'MONGO':
          this._makeNewID = function () {
            var src = name ? DDP.randomStream('/collection/' + name) : Random.insecure;
            return new Mongo.ObjectID(src.hexString(24));
          };
          break;
        case 'STRING':
        default:
          this._makeNewID = function () {
            var src = name ? DDP.randomStream('/collection/' + name) : Random.insecure;
            return src.id();
          };
          break;
      }
      this._transform = LocalCollection.wrapTransform(options.transform);
      this.resolverType = options.resolverType;
      if (!name || options.connection === null)
        // note: nameless collections never have a connection
        this._connection = null;else if (options.connection) this._connection = options.connection;else if (Meteor.isClient) this._connection = Meteor.connection;else this._connection = Meteor.server;
      if (!options._driver) {
        // XXX This check assumes that webapp is loaded so that Meteor.server !==
        // null. We should fully support the case of "want to use a Mongo-backed
        // collection from Node code without webapp", but we don't yet.
        // #MeteorServerNull
        if (name && this._connection === Meteor.server && typeof MongoInternals !== 'undefined' && MongoInternals.defaultRemoteCollectionDriver) {
          options._driver = MongoInternals.defaultRemoteCollectionDriver();
        } else {
          const {
            LocalCollectionDriver
          } = require('./local_collection_driver.js');
          options._driver = LocalCollectionDriver;
        }
      }
      this._collection = options._driver.open(name, this._connection);
      this._name = name;
      this._driver = options._driver;

      // TODO[fibers]: _maybeSetUpReplication is now async. Let's watch how not waiting for this function to finish
      // will affect everything
      this._settingUpReplicationPromise = this._maybeSetUpReplication(name, options);

      // XXX don't define these until allow or deny is actually used for this
      // collection. Could be hard if the security rules are only defined on the
      // server.
      if (options.defineMutationMethods !== false) {
        try {
          this._defineMutationMethods({
            useExisting: options._suppressSameNameError === true
          });
        } catch (error) {
          // Throw a more understandable error on the server for same collection name
          if (error.message === "A method named '/".concat(name, "/insertAsync' is already defined")) throw new Error("There is already a collection named \"".concat(name, "\""));
          throw error;
        }
      }

      // autopublish
      if (Package.autopublish && !options._preventAutopublish && this._connection && this._connection.publish) {
        this._connection.publish(null, () => this.find(), {
          is_auto: true
        });
      }
    };
    Object.assign(Mongo.Collection.prototype, {
      async _maybeSetUpReplication(name) {
        var _registerStoreResult, _registerStoreResult$;
        const self = this;
        if (!(self._connection && self._connection.registerStoreClient && self._connection.registerStoreServer)) {
          return;
        }
        const wrappedStoreCommon = {
          // Called around method stub invocations to capture the original versions
          // of modified documents.
          saveOriginals() {
            self._collection.saveOriginals();
          },
          retrieveOriginals() {
            return self._collection.retrieveOriginals();
          },
          // To be able to get back to the collection from the store.
          _getCollection() {
            return self;
          }
        };
        const wrappedStoreClient = _objectSpread({
          // Called at the beginning of a batch of updates. batchSize is the number
          // of update calls to expect.
          //
          // XXX This interface is pretty janky. reset probably ought to go back to
          // being its own function, and callers shouldn't have to calculate
          // batchSize. The optimization of not calling pause/remove should be
          // delayed until later: the first call to update() should buffer its
          // message, and then we can either directly apply it at endUpdate time if
          // it was the only update, or do pauseObservers/apply/apply at the next
          // update() if there's another one.
          async beginUpdate(batchSize, reset) {
            // pause observers so users don't see flicker when updating several
            // objects at once (including the post-reconnect reset-and-reapply
            // stage), and so that a re-sorting of a query can take advantage of the
            // full _diffQuery moved calculation instead of applying change one at a
            // time.
            if (batchSize > 1 || reset) self._collection.pauseObservers();
            if (reset) await self._collection.remove({});
          },
          // Apply an update.
          // XXX better specify this interface (not in terms of a wire message)?
          update(msg) {
            var mongoId = MongoID.idParse(msg.id);
            var doc = self._collection._docs.get(mongoId);

            //When the server's mergebox is disabled for a collection, the client must gracefully handle it when:
            // *We receive an added message for a document that is already there. Instead, it will be changed
            // *We reeive a change message for a document that is not there. Instead, it will be added
            // *We receive a removed messsage for a document that is not there. Instead, noting wil happen.

            //Code is derived from client-side code originally in peerlibrary:control-mergebox
            //https://github.com/peerlibrary/meteor-control-mergebox/blob/master/client.coffee

            //For more information, refer to discussion "Initial support for publication strategies in livedata server":
            //https://github.com/meteor/meteor/pull/11151
            if (Meteor.isClient) {
              if (msg.msg === 'added' && doc) {
                msg.msg = 'changed';
              } else if (msg.msg === 'removed' && !doc) {
                return;
              } else if (msg.msg === 'changed' && !doc) {
                msg.msg = 'added';
                const _ref = msg.fields;
                for (let field in _ref) {
                  const value = _ref[field];
                  if (value === void 0) {
                    delete msg.fields[field];
                  }
                }
              }
            }
            // Is this a "replace the whole doc" message coming from the quiescence
            // of method writes to an object? (Note that 'undefined' is a valid
            // value meaning "remove it".)
            if (msg.msg === 'replace') {
              var replace = msg.replace;
              if (!replace) {
                if (doc) self._collection.remove(mongoId);
              } else if (!doc) {
                self._collection.insert(replace);
              } else {
                // XXX check that replace has no $ ops
                self._collection.update(mongoId, replace);
              }
              return;
            } else if (msg.msg === 'added') {
              if (doc) {
                throw new Error('Expected not to find a document already present for an add');
              }
              self._collection.insert(_objectSpread({
                _id: mongoId
              }, msg.fields));
            } else if (msg.msg === 'removed') {
              if (!doc) throw new Error('Expected to find a document already present for removed');
              self._collection.remove(mongoId);
            } else if (msg.msg === 'changed') {
              if (!doc) throw new Error('Expected to find a document to change');
              const keys = Object.keys(msg.fields);
              if (keys.length > 0) {
                var modifier = {};
                keys.forEach(key => {
                  const value = msg.fields[key];
                  if (EJSON.equals(doc[key], value)) {
                    return;
                  }
                  if (typeof value === 'undefined') {
                    if (!modifier.$unset) {
                      modifier.$unset = {};
                    }
                    modifier.$unset[key] = 1;
                  } else {
                    if (!modifier.$set) {
                      modifier.$set = {};
                    }
                    modifier.$set[key] = value;
                  }
                });
                if (Object.keys(modifier).length > 0) {
                  self._collection.update(mongoId, modifier);
                }
              }
            } else {
              throw new Error("I don't know how to deal with this message");
            }
          },
          // Called at the end of a batch of updates.livedata_connection.js:1287
          endUpdate() {
            self._collection.resumeObserversClient();
          },
          // Used to preserve current versions of documents across a store reset.
          getDoc(id) {
            return self.findOne(id);
          }
        }, wrappedStoreCommon);
        const wrappedStoreServer = _objectSpread({
          async beginUpdate(batchSize, reset) {
            if (batchSize > 1 || reset) self._collection.pauseObservers();
            if (reset) await self._collection.removeAsync({});
          },
          async update(msg) {
            var mongoId = MongoID.idParse(msg.id);
            var doc = self._collection._docs.get(mongoId);

            // Is this a "replace the whole doc" message coming from the quiescence
            // of method writes to an object? (Note that 'undefined' is a valid
            // value meaning "remove it".)
            if (msg.msg === 'replace') {
              var replace = msg.replace;
              if (!replace) {
                if (doc) await self._collection.removeAsync(mongoId);
              } else if (!doc) {
                await self._collection.insertAsync(replace);
              } else {
                // XXX check that replace has no $ ops
                await self._collection.updateAsync(mongoId, replace);
              }
              return;
            } else if (msg.msg === 'added') {
              if (doc) {
                throw new Error('Expected not to find a document already present for an add');
              }
              await self._collection.insertAsync(_objectSpread({
                _id: mongoId
              }, msg.fields));
            } else if (msg.msg === 'removed') {
              if (!doc) throw new Error('Expected to find a document already present for removed');
              await self._collection.removeAsync(mongoId);
            } else if (msg.msg === 'changed') {
              if (!doc) throw new Error('Expected to find a document to change');
              const keys = Object.keys(msg.fields);
              if (keys.length > 0) {
                var modifier = {};
                keys.forEach(key => {
                  const value = msg.fields[key];
                  if (EJSON.equals(doc[key], value)) {
                    return;
                  }
                  if (typeof value === 'undefined') {
                    if (!modifier.$unset) {
                      modifier.$unset = {};
                    }
                    modifier.$unset[key] = 1;
                  } else {
                    if (!modifier.$set) {
                      modifier.$set = {};
                    }
                    modifier.$set[key] = value;
                  }
                });
                if (Object.keys(modifier).length > 0) {
                  await self._collection.updateAsync(mongoId, modifier);
                }
              }
            } else {
              throw new Error("I don't know how to deal with this message");
            }
          },
          // Called at the end of a batch of updates.
          async endUpdate() {
            await self._collection.resumeObserversServer();
          },
          // Used to preserve current versions of documents across a store reset.
          async getDoc(id) {
            return self.findOneAsync(id);
          }
        }, wrappedStoreCommon);

        // OK, we're going to be a slave, replicating some remote
        // database, except possibly with some temporary divergence while
        // we have unacknowledged RPC's.
        let registerStoreResult;
        if (Meteor.isClient) {
          registerStoreResult = self._connection.registerStoreClient(name, wrappedStoreClient);
        } else {
          registerStoreResult = self._connection.registerStoreServer(name, wrappedStoreServer);
        }
        const message = "There is already a collection named \"".concat(name, "\"");
        const logWarn = () => {
          console.warn ? console.warn(message) : console.log(message);
        };
        if (!registerStoreResult) {
          return logWarn();
        }
        return (_registerStoreResult = registerStoreResult) === null || _registerStoreResult === void 0 ? void 0 : (_registerStoreResult$ = _registerStoreResult.then) === null || _registerStoreResult$ === void 0 ? void 0 : _registerStoreResult$.call(_registerStoreResult, ok => {
          if (!ok) {
            logWarn();
          }
        });
      },
      ///
      /// Main collection API
      ///
      /**
       * @summary Gets the number of documents matching the filter. For a fast count of the total documents in a collection see `estimatedDocumentCount`.
       * @locus Anywhere
       * @method countDocuments
       * @memberof Mongo.Collection
       * @instance
       * @param {MongoSelector} [selector] A query describing the documents to count
       * @param {Object} [options] All options are listed in [MongoDB documentation](https://mongodb.github.io/node-mongodb-native/4.11/interfaces/CountDocumentsOptions.html). Please note that not all of them are available on the client.
       * @returns {Promise<number>}
       */
      countDocuments() {
        return this._collection.countDocuments(...arguments);
      },
      /**
       * @summary Gets an estimate of the count of documents in a collection using collection metadata. For an exact count of the documents in a collection see `countDocuments`.
       * @locus Anywhere
       * @method estimatedDocumentCount
       * @memberof Mongo.Collection
       * @instance
       * @param {Object} [options] All options are listed in [MongoDB documentation](https://mongodb.github.io/node-mongodb-native/4.11/interfaces/EstimatedDocumentCountOptions.html). Please note that not all of them are available on the client.
       * @returns {Promise<number>}
       */
      estimatedDocumentCount() {
        return this._collection.estimatedDocumentCount(...arguments);
      },
      _getFindSelector(args) {
        if (args.length == 0) return {};else return args[0];
      },
      _getFindOptions(args) {
        const [, options] = args || [];
        const newOptions = normalizeProjection(options);
        var self = this;
        if (args.length < 2) {
          return {
            transform: self._transform
          };
        } else {
          check(newOptions, Match.Optional(Match.ObjectIncluding({
            projection: Match.Optional(Match.OneOf(Object, undefined)),
            sort: Match.Optional(Match.OneOf(Object, Array, Function, undefined)),
            limit: Match.Optional(Match.OneOf(Number, undefined)),
            skip: Match.Optional(Match.OneOf(Number, undefined))
          })));
          return _objectSpread({
            transform: self._transform
          }, newOptions);
        }
      },
      /**
       * @summary Find the documents in a collection that match the selector.
       * @locus Anywhere
       * @method find
       * @memberof Mongo.Collection
       * @instance
       * @param {MongoSelector} [selector] A query describing the documents to find
       * @param {Object} [options]
       * @param {MongoSortSpecifier} options.sort Sort order (default: natural order)
       * @param {Number} options.skip Number of results to skip at the beginning
       * @param {Number} options.limit Maximum number of results to return
       * @param {MongoFieldSpecifier} options.fields Dictionary of fields to return or exclude.
       * @param {Boolean} options.reactive (Client only) Default `true`; pass `false` to disable reactivity
       * @param {Function} options.transform Overrides `transform` on the  [`Collection`](#collections) for this cursor.  Pass `null` to disable transformation.
       * @param {Boolean} options.disableOplog (Server only) Pass true to disable oplog-tailing on this query. This affects the way server processes calls to `observe` on this query. Disabling the oplog can be useful when working with data that updates in large batches.
       * @param {Number} options.pollingIntervalMs (Server only) When oplog is disabled (through the use of `disableOplog` or when otherwise not available), the frequency (in milliseconds) of how often to poll this query when observing on the server. Defaults to 10000ms (10 seconds).
       * @param {Number} options.pollingThrottleMs (Server only) When oplog is disabled (through the use of `disableOplog` or when otherwise not available), the minimum time (in milliseconds) to allow between re-polling when observing on the server. Increasing this will save CPU and mongo load at the expense of slower updates to users. Decreasing this is not recommended. Defaults to 50ms.
       * @param {Number} options.maxTimeMs (Server only) If set, instructs MongoDB to set a time limit for this cursor's operations. If the operation reaches the specified time limit (in milliseconds) without the having been completed, an exception will be thrown. Useful to prevent an (accidental or malicious) unoptimized query from causing a full collection scan that would disrupt other database users, at the expense of needing to handle the resulting error.
       * @param {String|Object} options.hint (Server only) Overrides MongoDB's default index selection and query optimization process. Specify an index to force its use, either by its name or index specification. You can also specify `{ $natural : 1 }` to force a forwards collection scan, or `{ $natural : -1 }` for a reverse collection scan. Setting this is only recommended for advanced users.
       * @param {String} options.readPreference (Server only) Specifies a custom MongoDB [`readPreference`](https://docs.mongodb.com/manual/core/read-preference) for this particular cursor. Possible values are `primary`, `primaryPreferred`, `secondary`, `secondaryPreferred` and `nearest`.
       * @returns {Mongo.Cursor}
       */
      find() {
        for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
          args[_key] = arguments[_key];
        }
        // Collection.find() (return all docs) behaves differently
        // from Collection.find(undefined) (return 0 docs).  so be
        // careful about the length of arguments.
        return this._collection.find(this._getFindSelector(args), this._getFindOptions(args));
      },
      /**
       * @summary Finds the first document that matches the selector, as ordered by sort and skip options. Returns `undefined` if no matching document is found.
       * @locus Anywhere
       * @method findOneAsync
       * @memberof Mongo.Collection
       * @instance
       * @param {MongoSelector} [selector] A query describing the documents to find
       * @param {Object} [options]
       * @param {MongoSortSpecifier} options.sort Sort order (default: natural order)
       * @param {Number} options.skip Number of results to skip at the beginning
       * @param {MongoFieldSpecifier} options.fields Dictionary of fields to return or exclude.
       * @param {Boolean} options.reactive (Client only) Default true; pass false to disable reactivity
       * @param {Function} options.transform Overrides `transform` on the [`Collection`](#collections) for this cursor.  Pass `null` to disable transformation.
       * @param {String} options.readPreference (Server only) Specifies a custom MongoDB [`readPreference`](https://docs.mongodb.com/manual/core/read-preference) for fetching the document. Possible values are `primary`, `primaryPreferred`, `secondary`, `secondaryPreferred` and `nearest`.
       * @returns {Object}
       */
      findOneAsync() {
        for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
          args[_key2] = arguments[_key2];
        }
        return this._collection.findOneAsync(this._getFindSelector(args), this._getFindOptions(args));
      },
      /**
       * @summary Finds the first document that matches the selector, as ordered by sort and skip options. Returns `undefined` if no matching document is found.
       * @locus Anywhere
       * @method findOne
       * @memberof Mongo.Collection
       * @instance
       * @param {MongoSelector} [selector] A query describing the documents to find
       * @param {Object} [options]
       * @param {MongoSortSpecifier} options.sort Sort order (default: natural order)
       * @param {Number} options.skip Number of results to skip at the beginning
       * @param {MongoFieldSpecifier} options.fields Dictionary of fields to return or exclude.
       * @param {Boolean} options.reactive (Client only) Default true; pass false to disable reactivity
       * @param {Function} options.transform Overrides `transform` on the [`Collection`](#collections) for this cursor.  Pass `null` to disable transformation.
       * @param {String} options.readPreference (Server only) Specifies a custom MongoDB [`readPreference`](https://docs.mongodb.com/manual/core/read-preference) for fetching the document. Possible values are `primary`, `primaryPreferred`, `secondary`, `secondaryPreferred` and `nearest`.
       * @returns {Object}
       */
      findOne() {
        for (var _len3 = arguments.length, args = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
          args[_key3] = arguments[_key3];
        }
        return this._collection.findOne(this._getFindSelector(args), this._getFindOptions(args));
      }
    });
    Object.assign(Mongo.Collection, {
      async _publishCursor(cursor, sub, collection) {
        var observeHandle = await cursor.observeChanges({
          added: function (id, fields) {
            sub.added(collection, id, fields);
          },
          changed: function (id, fields) {
            sub.changed(collection, id, fields);
          },
          removed: function (id) {
            sub.removed(collection, id);
          }
        },
        // Publications don't mutate the documents
        // This is tested by the `livedata - publish callbacks clone` test
        {
          nonMutatingCallbacks: true
        });

        // We don't call sub.ready() here: it gets called in livedata_server, after
        // possibly calling _publishCursor on multiple returned cursors.

        // register stop callback (expects lambda w/ no args).
        sub.onStop(async function () {
          return await observeHandle.stop();
        });

        // return the observeHandle in case it needs to be stopped early
        return observeHandle;
      },
      // protect against dangerous selectors.  falsey and {_id: falsey} are both
      // likely programmer error, and not what you want, particularly for destructive
      // operations. If a falsey _id is sent in, a new string _id will be
      // generated and returned; if a fallbackId is provided, it will be returned
      // instead.
      _rewriteSelector(selector) {
        let {
          fallbackId
        } = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
        // shorthand -- scalars match _id
        if (LocalCollection._selectorIsId(selector)) selector = {
          _id: selector
        };
        if (Array.isArray(selector)) {
          // This is consistent with the Mongo console itself; if we don't do this
          // check passing an empty array ends up selecting all items
          throw new Error("Mongo selector can't be an array.");
        }
        if (!selector || '_id' in selector && !selector._id) {
          // can't match anything
          return {
            _id: fallbackId || Random.id()
          };
        }
        return selector;
      }
    });
    Object.assign(Mongo.Collection.prototype, {
      // 'insert' immediately returns the inserted document's new _id.
      // The others return values immediately if you are in a stub, an in-memory
      // unmanaged collection, or a mongo-backed collection and you don't pass a
      // callback. 'update' and 'remove' return the number of affected
      // documents. 'upsert' returns an object with keys 'numberAffected' and, if an
      // insert happened, 'insertedId'.
      //
      // Otherwise, the semantics are exactly like other methods: they take
      // a callback as an optional last argument; if no callback is
      // provided, they block until the operation is complete, and throw an
      // exception if it fails; if a callback is provided, then they don't
      // necessarily block, and they call the callback when they finish with error and
      // result arguments.  (The insert method provides the document ID as its result;
      // update and remove provide the number of affected docs as the result; upsert
      // provides an object with numberAffected and maybe insertedId.)
      //
      // On the client, blocking is impossible, so if a callback
      // isn't provided, they just return immediately and any error
      // information is lost.
      //
      // There's one more tweak. On the client, if you don't provide a
      // callback, then if there is an error, a message will be logged with
      // Meteor._debug.
      //
      // The intent (though this is actually determined by the underlying
      // drivers) is that the operations should be done synchronously, not
      // generating their result until the database has acknowledged
      // them. In the future maybe we should provide a flag to turn this
      // off.

      _insert(doc, callback) {
        // Make sure we were passed a document to insert
        if (!doc) {
          throw new Error('insert requires an argument');
        }

        // Make a shallow clone of the document, preserving its prototype.
        doc = Object.create(Object.getPrototypeOf(doc), Object.getOwnPropertyDescriptors(doc));
        if ('_id' in doc) {
          if (!doc._id || !(typeof doc._id === 'string' || doc._id instanceof Mongo.ObjectID)) {
            throw new Error('Meteor requires document _id fields to be non-empty strings or ObjectIDs');
          }
        } else {
          let generateId = true;

          // Don't generate the id if we're the client and the 'outermost' call
          // This optimization saves us passing both the randomSeed and the id
          // Passing both is redundant.
          if (this._isRemoteCollection()) {
            const enclosing = DDP._CurrentMethodInvocation.get();
            if (!enclosing) {
              generateId = false;
            }
          }
          if (generateId) {
            doc._id = this._makeNewID();
          }
        }

        // On inserts, always return the id that we generated; on all other
        // operations, just return the result from the collection.
        var chooseReturnValueFromCollectionResult = function (result) {
          if (Meteor._isPromise(result)) return result;
          if (doc._id) {
            return doc._id;
          }

          // XXX what is this for??
          // It's some iteraction between the callback to _callMutatorMethod and
          // the return value conversion
          doc._id = result;
          return result;
        };
        const wrappedCallback = wrapCallback(callback, chooseReturnValueFromCollectionResult);
        if (this._isRemoteCollection()) {
          const result = this._callMutatorMethod('insert', [doc], wrappedCallback);
          return chooseReturnValueFromCollectionResult(result);
        }

        // it's my collection.  descend into the collection object
        // and propagate any exception.
        try {
          // If the user provided a callback and the collection implements this
          // operation asynchronously, then queryRet will be undefined, and the
          // result will be returned through the callback instead.
          let result;
          if (!!wrappedCallback) {
            this._collection.insert(doc, wrappedCallback);
          } else {
            // If we don't have the callback, we assume the user is using the promise.
            // We can't just pass this._collection.insert to the promisify because it would lose the context.
            result = this._collection.insert(doc);
          }
          return chooseReturnValueFromCollectionResult(result);
        } catch (e) {
          if (callback) {
            callback(e);
            return null;
          }
          throw e;
        }
      },
      /**
       * @summary Insert a document in the collection.  Returns its unique _id.
       * @locus Anywhere
       * @method  insert
       * @memberof Mongo.Collection
       * @instance
       * @param {Object} doc The document to insert. May not yet have an _id attribute, in which case Meteor will generate one for you.
       * @param {Function} [callback] Optional.  If present, called with an error object as the first argument and, if no error, the _id as the second.
       */
      insert(doc, callback) {
        return this._insert(doc, callback);
      },
      _insertAsync(doc) {
        let options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
        // Make sure we were passed a document to insert
        if (!doc) {
          throw new Error('insert requires an argument');
        }

        // Make a shallow clone of the document, preserving its prototype.
        doc = Object.create(Object.getPrototypeOf(doc), Object.getOwnPropertyDescriptors(doc));
        if ('_id' in doc) {
          if (!doc._id || !(typeof doc._id === 'string' || doc._id instanceof Mongo.ObjectID)) {
            throw new Error('Meteor requires document _id fields to be non-empty strings or ObjectIDs');
          }
        } else {
          let generateId = true;

          // Don't generate the id if we're the client and the 'outermost' call
          // This optimization saves us passing both the randomSeed and the id
          // Passing both is redundant.
          if (this._isRemoteCollection()) {
            const enclosing = DDP._CurrentMethodInvocation.get();
            if (!enclosing) {
              generateId = false;
            }
          }
          if (generateId) {
            doc._id = this._makeNewID();
          }
        }

        // On inserts, always return the id that we generated; on all other
        // operations, just return the result from the collection.
        var chooseReturnValueFromCollectionResult = function (result) {
          if (Meteor._isPromise(result)) return result;
          if (doc._id) {
            return doc._id;
          }

          // XXX what is this for??
          // It's some iteraction between the callback to _callMutatorMethod and
          // the return value conversion
          doc._id = result;
          return result;
        };
        if (this._isRemoteCollection()) {
          const promise = this._callMutatorMethodAsync('insertAsync', [doc], options);
          promise.then(chooseReturnValueFromCollectionResult);
          promise.stubPromise = promise.stubPromise.then(chooseReturnValueFromCollectionResult);
          promise.serverPromise = promise.serverPromise.then(chooseReturnValueFromCollectionResult);
          return promise;
        }

        // it's my collection.  descend into the collection object
        // and propagate any exception.
        return this._collection.insertAsync(doc).then(chooseReturnValueFromCollectionResult);
      },
      /**
       * @summary Insert a document in the collection.  Returns a promise that will return the document's unique _id when solved.
       * @locus Anywhere
       * @method  insert
       * @memberof Mongo.Collection
       * @instance
       * @param {Object} doc The document to insert. May not yet have an _id attribute, in which case Meteor will generate one for you.
       */
      insertAsync(doc, options) {
        return this._insertAsync(doc, options);
      },
      /**
       * @summary Modify one or more documents in the collection. Returns the number of matched documents.
       * @locus Anywhere
       * @method update
       * @memberof Mongo.Collection
       * @instance
       * @param {MongoSelector} selector Specifies which documents to modify
       * @param {MongoModifier} modifier Specifies how to modify the documents
       * @param {Object} [options]
       * @param {Boolean} options.multi True to modify all matching documents; false to only modify one of the matching documents (the default).
       * @param {Boolean} options.upsert True to insert a document if no matching documents are found.
       * @param {Array} options.arrayFilters Optional. Used in combination with MongoDB [filtered positional operator](https://docs.mongodb.com/manual/reference/operator/update/positional-filtered/) to specify which elements to modify in an array field.
       */
      updateAsync(selector, modifier) {
        // We've already popped off the callback, so we are left with an array
        // of one or zero items
        const options = _objectSpread({}, (arguments.length <= 2 ? undefined : arguments[2]) || null);
        let insertedId;
        if (options && options.upsert) {
          // set `insertedId` if absent.  `insertedId` is a Meteor extension.
          if (options.insertedId) {
            if (!(typeof options.insertedId === 'string' || options.insertedId instanceof Mongo.ObjectID)) throw new Error('insertedId must be string or ObjectID');
            insertedId = options.insertedId;
          } else if (!selector || !selector._id) {
            insertedId = this._makeNewID();
            options.generatedId = true;
            options.insertedId = insertedId;
          }
        }
        selector = Mongo.Collection._rewriteSelector(selector, {
          fallbackId: insertedId
        });
        if (this._isRemoteCollection()) {
          const args = [selector, modifier, options];
          return this._callMutatorMethodAsync('updateAsync', args, options);
        }

        // it's my collection.  descend into the collection object
        // and propagate any exception.
        // If the user provided a callback and the collection implements this
        // operation asynchronously, then queryRet will be undefined, and the
        // result will be returned through the callback instead.

        return this._collection.updateAsync(selector, modifier, options);
      },
      /**
       * @summary Asynchronously modifies one or more documents in the collection. Returns the number of matched documents.
       * @locus Anywhere
       * @method update
       * @memberof Mongo.Collection
       * @instance
       * @param {MongoSelector} selector Specifies which documents to modify
       * @param {MongoModifier} modifier Specifies how to modify the documents
       * @param {Object} [options]
       * @param {Boolean} options.multi True to modify all matching documents; false to only modify one of the matching documents (the default).
       * @param {Boolean} options.upsert True to insert a document if no matching documents are found.
       * @param {Array} options.arrayFilters Optional. Used in combination with MongoDB [filtered positional operator](https://docs.mongodb.com/manual/reference/operator/update/positional-filtered/) to specify which elements to modify in an array field.
       * @param {Function} [callback] Optional.  If present, called with an error object as the first argument and, if no error, the number of affected documents as the second.
       */
      update(selector, modifier) {
        for (var _len4 = arguments.length, optionsAndCallback = new Array(_len4 > 2 ? _len4 - 2 : 0), _key4 = 2; _key4 < _len4; _key4++) {
          optionsAndCallback[_key4 - 2] = arguments[_key4];
        }
        const callback = popCallbackFromArgs(optionsAndCallback);

        // We've already popped off the callback, so we are left with an array
        // of one or zero items
        const options = _objectSpread({}, optionsAndCallback[0] || null);
        let insertedId;
        if (options && options.upsert) {
          // set `insertedId` if absent.  `insertedId` is a Meteor extension.
          if (options.insertedId) {
            if (!(typeof options.insertedId === 'string' || options.insertedId instanceof Mongo.ObjectID)) throw new Error('insertedId must be string or ObjectID');
            insertedId = options.insertedId;
          } else if (!selector || !selector._id) {
            insertedId = this._makeNewID();
            options.generatedId = true;
            options.insertedId = insertedId;
          }
        }
        selector = Mongo.Collection._rewriteSelector(selector, {
          fallbackId: insertedId
        });
        const wrappedCallback = wrapCallback(callback);
        if (this._isRemoteCollection()) {
          const args = [selector, modifier, options];
          return this._callMutatorMethod('update', args, callback);
        }

        // it's my collection.  descend into the collection object
        // and propagate any exception.
        // If the user provided a callback and the collection implements this
        // operation asynchronously, then queryRet will be undefined, and the
        // result will be returned through the callback instead.
        //console.log({callback, options, selector, modifier, coll: this._collection});
        try {
          // If the user provided a callback and the collection implements this
          // operation asynchronously, then queryRet will be undefined, and the
          // result will be returned through the callback instead.
          return this._collection.update(selector, modifier, options, wrappedCallback);
        } catch (e) {
          if (callback) {
            callback(e);
            return null;
          }
          throw e;
        }
      },
      /**
       * @summary Asynchronously removes documents from the collection.
       * @locus Anywhere
       * @method remove
       * @memberof Mongo.Collection
       * @instance
       * @param {MongoSelector} selector Specifies which documents to remove
       */
      removeAsync(selector) {
        let options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
        selector = Mongo.Collection._rewriteSelector(selector);
        if (this._isRemoteCollection()) {
          return this._callMutatorMethodAsync('removeAsync', [selector], options);
        }

        // it's my collection.  descend into the collection1 object
        // and propagate any exception.
        return this._collection.removeAsync(selector);
      },
      /**
       * @summary Remove documents from the collection
       * @locus Anywhere
       * @method remove
       * @memberof Mongo.Collection
       * @instance
       * @param {MongoSelector} selector Specifies which documents to remove
       * @param {Function} [callback] Optional.  If present, called with an error object as the first argument and, if no error, the number of affected documents as the second.
       */
      remove(selector, callback) {
        selector = Mongo.Collection._rewriteSelector(selector);
        if (this._isRemoteCollection()) {
          return this._callMutatorMethod('remove', [selector], callback);
        }

        // it's my collection.  descend into the collection1 object
        // and propagate any exception.
        return this._collection.remove(selector);
      },
      // Determine if this collection is simply a minimongo representation of a real
      // database on another server
      _isRemoteCollection() {
        // XXX see #MeteorServerNull
        return this._connection && this._connection !== Meteor.server;
      },
      /**
       * @summary Asynchronously modifies one or more documents in the collection, or insert one if no matching documents were found. Returns an object with keys `numberAffected` (the number of documents modified)  and `insertedId` (the unique _id of the document that was inserted, if any).
       * @locus Anywhere
       * @method upsert
       * @memberof Mongo.Collection
       * @instance
       * @param {MongoSelector} selector Specifies which documents to modify
       * @param {MongoModifier} modifier Specifies how to modify the documents
       * @param {Object} [options]
       * @param {Boolean} options.multi True to modify all matching documents; false to only modify one of the matching documents (the default).
       */
      async upsertAsync(selector, modifier, options) {
        return this.updateAsync(selector, modifier, _objectSpread(_objectSpread({}, options), {}, {
          _returnObject: true,
          upsert: true
        }));
      },
      /**
       * @summary Asynchronously modifies one or more documents in the collection, or insert one if no matching documents were found. Returns an object with keys `numberAffected` (the number of documents modified)  and `insertedId` (the unique _id of the document that was inserted, if any).
       * @locus Anywhere
       * @method upsert
       * @memberof Mongo.Collection
       * @instance
       * @param {MongoSelector} selector Specifies which documents to modify
       * @param {MongoModifier} modifier Specifies how to modify the documents
       * @param {Object} [options]
       * @param {Boolean} options.multi True to modify all matching documents; false to only modify one of the matching documents (the default).
       * @param {Function} [callback] Optional.  If present, called with an error object as the first argument and, if no error, the number of affected documents as the second.
       */
      upsert(selector, modifier, options, callback) {
        if (!callback && typeof options === 'function') {
          callback = options;
          options = {};
        }
        return this.update(selector, modifier, _objectSpread(_objectSpread({}, options), {}, {
          _returnObject: true,
          upsert: true
        }));
      },
      // We'll actually design an index API later. For now, we just pass through to
      // Mongo's, but make it synchronous.
      /**
       * @summary Asynchronously creates the specified index on the collection.
       * @locus server
       * @method ensureIndexAsync
       * @deprecated in 3.0
       * @memberof Mongo.Collection
       * @instance
       * @param {Object} index A document that contains the field and value pairs where the field is the index key and the value describes the type of index for that field. For an ascending index on a field, specify a value of `1`; for descending index, specify a value of `-1`. Use `text` for text indexes.
       * @param {Object} [options] All options are listed in [MongoDB documentation](https://docs.mongodb.com/manual/reference/method/db.collection.createIndex/#options)
       * @param {String} options.name Name of the index
       * @param {Boolean} options.unique Define that the index values must be unique, more at [MongoDB documentation](https://docs.mongodb.com/manual/core/index-unique/)
       * @param {Boolean} options.sparse Define that the index is sparse, more at [MongoDB documentation](https://docs.mongodb.com/manual/core/index-sparse/)
       */
      async ensureIndexAsync(index, options) {
        var self = this;
        if (!self._collection.ensureIndexAsync || !self._collection.createIndexAsync) throw new Error('Can only call createIndexAsync on server collections');
        if (self._collection.createIndexAsync) {
          await self._collection.createIndexAsync(index, options);
        } else {
          let Log;
          module1.link("meteor/logging", {
            Log(v) {
              Log = v;
            }
          }, 2);
          Log.debug("ensureIndexAsync has been deprecated, please use the new 'createIndexAsync' instead".concat(options !== null && options !== void 0 && options.name ? ", index name: ".concat(options.name) : ", index: ".concat(JSON.stringify(index))));
          await self._collection.ensureIndexAsync(index, options);
        }
      },
      /**
       * @summary Asynchronously creates the specified index on the collection.
       * @locus server
       * @method createIndexAsync
       * @memberof Mongo.Collection
       * @instance
       * @param {Object} index A document that contains the field and value pairs where the field is the index key and the value describes the type of index for that field. For an ascending index on a field, specify a value of `1`; for descending index, specify a value of `-1`. Use `text` for text indexes.
       * @param {Object} [options] All options are listed in [MongoDB documentation](https://docs.mongodb.com/manual/reference/method/db.collection.createIndex/#options)
       * @param {String} options.name Name of the index
       * @param {Boolean} options.unique Define that the index values must be unique, more at [MongoDB documentation](https://docs.mongodb.com/manual/core/index-unique/)
       * @param {Boolean} options.sparse Define that the index is sparse, more at [MongoDB documentation](https://docs.mongodb.com/manual/core/index-sparse/)
       */
      async createIndexAsync(index, options) {
        var self = this;
        if (!self._collection.createIndexAsync) throw new Error('Can only call createIndexAsync on server collections');
        try {
          await self._collection.createIndexAsync(index, options);
        } catch (e) {
          var _Meteor$settings, _Meteor$settings$pack, _Meteor$settings$pack2;
          if (e.message.includes('An equivalent index already exists with the same name but different options.') && (_Meteor$settings = Meteor.settings) !== null && _Meteor$settings !== void 0 && (_Meteor$settings$pack = _Meteor$settings.packages) !== null && _Meteor$settings$pack !== void 0 && (_Meteor$settings$pack2 = _Meteor$settings$pack.mongo) !== null && _Meteor$settings$pack2 !== void 0 && _Meteor$settings$pack2.reCreateIndexOnOptionMismatch) {
            let Log;
            module1.link("meteor/logging", {
              Log(v) {
                Log = v;
              }
            }, 3);
            Log.info("Re-creating index ".concat(index, " for ").concat(self._name, " due to options mismatch."));
            await self._collection.dropIndexAsync(index);
            await self._collection.createIndexAsync(index, options);
          } else {
            console.error(e);
            throw new Meteor.Error("An error occurred when creating an index for collection \"".concat(self._name, ": ").concat(e.message));
          }
        }
      },
      /**
       * @summary Asynchronously creates the specified index on the collection.
       * @locus server
       * @method createIndex
       * @memberof Mongo.Collection
       * @instance
       * @param {Object} index A document that contains the field and value pairs where the field is the index key and the value describes the type of index for that field. For an ascending index on a field, specify a value of `1`; for descending index, specify a value of `-1`. Use `text` for text indexes.
       * @param {Object} [options] All options are listed in [MongoDB documentation](https://docs.mongodb.com/manual/reference/method/db.collection.createIndex/#options)
       * @param {String} options.name Name of the index
       * @param {Boolean} options.unique Define that the index values must be unique, more at [MongoDB documentation](https://docs.mongodb.com/manual/core/index-unique/)
       * @param {Boolean} options.sparse Define that the index is sparse, more at [MongoDB documentation](https://docs.mongodb.com/manual/core/index-sparse/)
       */
      createIndex(index, options) {
        return this.createIndexAsync(index, options);
      },
      async dropIndexAsync(index) {
        var self = this;
        if (!self._collection.dropIndexAsync) throw new Error('Can only call dropIndexAsync on server collections');
        await self._collection.dropIndexAsync(index);
      },
      async dropCollectionAsync() {
        var self = this;
        if (!self._collection.dropCollectionAsync) throw new Error('Can only call dropCollectionAsync on server collections');
        await self._collection.dropCollectionAsync();
      },
      async createCappedCollectionAsync(byteSize, maxDocuments) {
        var self = this;
        if (!(await self._collection.createCappedCollectionAsync)) throw new Error('Can only call createCappedCollectionAsync on server collections');
        await self._collection.createCappedCollectionAsync(byteSize, maxDocuments);
      },
      /**
       * @summary Returns the [`Collection`](http://mongodb.github.io/node-mongodb-native/3.0/api/Collection.html) object corresponding to this collection from the [npm `mongodb` driver module](https://www.npmjs.com/package/mongodb) which is wrapped by `Mongo.Collection`.
       * @locus Server
       * @memberof Mongo.Collection
       * @instance
       */
      rawCollection() {
        var self = this;
        if (!self._collection.rawCollection) {
          throw new Error('Can only call rawCollection on server collections');
        }
        return self._collection.rawCollection();
      },
      /**
       * @summary Returns the [`Db`](http://mongodb.github.io/node-mongodb-native/3.0/api/Db.html) object corresponding to this collection's database connection from the [npm `mongodb` driver module](https://www.npmjs.com/package/mongodb) which is wrapped by `Mongo.Collection`.
       * @locus Server
       * @memberof Mongo.Collection
       * @instance
       */
      rawDatabase() {
        var self = this;
        if (!(self._driver.mongo && self._driver.mongo.db)) {
          throw new Error('Can only call rawDatabase on server collections');
        }
        return self._driver.mongo.db;
      }
    });

    // Convert the callback to not return a result if there is an error
    function wrapCallback(callback, convertResult) {
      return callback && function (error, result) {
        if (error) {
          callback(error);
        } else if (typeof convertResult === 'function') {
          callback(error, convertResult(result));
        } else {
          callback(error, result);
        }
      };
    }

    /**
     * @summary Create a Mongo-style `ObjectID`.  If you don't specify a `hexString`, the `ObjectID` will be generated randomly (not using MongoDB's ID construction rules).
     * @locus Anywhere
     * @class
     * @param {String} [hexString] Optional.  The 24-character hexadecimal contents of the ObjectID to create
     */
    Mongo.ObjectID = MongoID.ObjectID;

    /**
     * @summary To create a cursor, use find. To access the documents in a cursor, use forEach, map, or fetch.
     * @class
     * @instanceName cursor
     */
    Mongo.Cursor = LocalCollection.Cursor;

    /**
     * @deprecated in 0.9.1
     */
    Mongo.Collection.Cursor = Mongo.Cursor;

    /**
     * @deprecated in 0.9.1
     */
    Mongo.Collection.ObjectID = Mongo.ObjectID;

    /**
     * @deprecated in 0.9.1
     */
    Meteor.Collection = Mongo.Collection;

    // Allow deny stuff is now in the allow-deny package
    Object.assign(Mongo.Collection.prototype, AllowDeny.CollectionPrototype);
    function popCallbackFromArgs(args) {
      // Pull off any callback (or perhaps a 'callback' variable that was passed
      // in undefined, like how 'upsert' does it).
      if (args.length && (args[args.length - 1] === undefined || args[args.length - 1] instanceof Function)) {
        return args.pop();
      }
    }
    __reify_async_result__();
  } catch (_reifyError) {
    return __reify_async_result__(_reifyError);
  }
  __reify_async_result__()
}, {
  self: this,
  async: false
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"connection_options.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/mongo/connection_options.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * @summary Allows for user specified connection options
 * @example http://mongodb.github.io/node-mongodb-native/3.0/reference/connecting/connection-settings/
 * @locus Server
 * @param {Object} options User specified Mongo connection options
 */
Mongo.setConnectionOptions = function setConnectionOptions(options) {
  check(options, Object);
  Mongo._connectionOptions = options;
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mongo_utils.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/mongo/mongo_utils.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
!module.wrapAsync(async function (module, __reifyWaitForDeps__, __reify_async_result__) {
  "use strict";
  try {
    let _objectSpread;
    module.link("@babel/runtime/helpers/objectSpread2", {
      default(v) {
        _objectSpread = v;
      }
    }, 0);
    let _objectWithoutProperties;
    module.link("@babel/runtime/helpers/objectWithoutProperties", {
      default(v) {
        _objectWithoutProperties = v;
      }
    }, 1);
    if (__reifyWaitForDeps__()) (await __reifyWaitForDeps__())();
    const _excluded = ["fields", "projection"];
    module.export({
      normalizeProjection: () => normalizeProjection
    });
    const normalizeProjection = options => {
      // transform fields key in projection
      const _ref = options || {},
        {
          fields,
          projection
        } = _ref,
        otherOptions = _objectWithoutProperties(_ref, _excluded);
      // TODO: enable this comment when deprecating the fields option
      // Log.debug(`fields option has been deprecated, please use the new 'projection' instead`)

      return _objectSpread(_objectSpread({}, otherOptions), projection || fields ? {
        projection: fields || projection
      } : {});
    };
    __reify_async_result__();
  } catch (_reifyError) {
    return __reify_async_result__(_reifyError);
  }
  __reify_async_result__()
}, {
  self: this,
  async: false
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});


/* Exports */
return {
  export: function () { return {
      MongoInternals: MongoInternals,
      Mongo: Mongo,
      ObserveMultiplexer: ObserveMultiplexer
    };},
  require: require,
  eagerModulePaths: [
    "/node_modules/meteor/mongo/mongo_driver.js",
    "/node_modules/meteor/mongo/oplog_tailing.js",
    "/node_modules/meteor/mongo/observe_multiplex.js",
    "/node_modules/meteor/mongo/doc_fetcher.js",
    "/node_modules/meteor/mongo/polling_observe_driver.js",
    "/node_modules/meteor/mongo/oplog_observe_driver.js",
    "/node_modules/meteor/mongo/oplog_v2_converter.js",
    "/node_modules/meteor/mongo/local_collection_driver.js",
    "/node_modules/meteor/mongo/remote_collection_driver.js",
    "/node_modules/meteor/mongo/collection.js",
    "/node_modules/meteor/mongo/connection_options.js"
  ]
}});

//# sourceURL=meteor://💻app/packages/mongo.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvbW9uZ28vbW9uZ29fZHJpdmVyLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9tb25nby9vcGxvZ190YWlsaW5nLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9tb25nby9vYnNlcnZlX211bHRpcGxleC5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvbW9uZ28vZG9jX2ZldGNoZXIuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL21vbmdvL3BvbGxpbmdfb2JzZXJ2ZV9kcml2ZXIuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL21vbmdvL29wbG9nX29ic2VydmVfZHJpdmVyLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9tb25nby9vcGxvZ192Ml9jb252ZXJ0ZXIuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL21vbmdvL2xvY2FsX2NvbGxlY3Rpb25fZHJpdmVyLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9tb25nby9yZW1vdGVfY29sbGVjdGlvbl9kcml2ZXIuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL21vbmdvL2NvbGxlY3Rpb24uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL21vbmdvL2Nvbm5lY3Rpb25fb3B0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvbW9uZ28vbW9uZ29fdXRpbHMuanMiXSwibmFtZXMiOlsiX29iamVjdFNwcmVhZCIsIm1vZHVsZTEiLCJsaW5rIiwiZGVmYXVsdCIsInYiLCJub3JtYWxpemVQcm9qZWN0aW9uIiwiRG9jRmV0Y2hlciIsIkFTWU5DX0NVUlNPUl9NRVRIT0RTIiwiQ0xJRU5UX09OTFlfTUVUSE9EUyIsImdldEFzeW5jTWV0aG9kTmFtZSIsIk1ldGVvciIsIl9fcmVpZnlXYWl0Rm9yRGVwc19fIiwicGF0aCIsInJlcXVpcmUiLCJ1dGlsIiwiTW9uZ29EQiIsIk5wbU1vZHVsZU1vbmdvZGIiLCJNb25nb0ludGVybmFscyIsIl9fcGFja2FnZU5hbWUiLCJOcG1Nb2R1bGVzIiwibW9uZ29kYiIsInZlcnNpb24iLCJOcG1Nb2R1bGVNb25nb2RiVmVyc2lvbiIsIm1vZHVsZSIsIk5wbU1vZHVsZSIsIkZJTEVfQVNTRVRfU1VGRklYIiwiQVNTRVRTX0ZPTERFUiIsIkFQUF9GT0xERVIiLCJyZXBsYWNlTmFtZXMiLCJmaWx0ZXIiLCJ0aGluZyIsIl8iLCJpc0FycmF5IiwibWFwIiwiYmluZCIsInJldCIsImVhY2giLCJ2YWx1ZSIsImtleSIsIlRpbWVzdGFtcCIsInByb3RvdHlwZSIsImNsb25lIiwibWFrZU1vbmdvTGVnYWwiLCJuYW1lIiwidW5tYWtlTW9uZ29MZWdhbCIsInN1YnN0ciIsInJlcGxhY2VNb25nb0F0b21XaXRoTWV0ZW9yIiwiZG9jdW1lbnQiLCJCaW5hcnkiLCJzdWJfdHlwZSIsImJ1ZmZlciIsIlVpbnQ4QXJyYXkiLCJPYmplY3RJRCIsIk1vbmdvIiwidG9IZXhTdHJpbmciLCJEZWNpbWFsMTI4IiwiRGVjaW1hbCIsInRvU3RyaW5nIiwic2l6ZSIsIkVKU09OIiwiZnJvbUpTT05WYWx1ZSIsInVuZGVmaW5lZCIsInJlcGxhY2VNZXRlb3JBdG9tV2l0aE1vbmdvIiwiaXNCaW5hcnkiLCJCdWZmZXIiLCJmcm9tIiwiZnJvbVN0cmluZyIsIl9pc0N1c3RvbVR5cGUiLCJ0b0pTT05WYWx1ZSIsInJlcGxhY2VUeXBlcyIsImF0b21UcmFuc2Zvcm1lciIsInJlcGxhY2VkVG9wTGV2ZWxBdG9tIiwidmFsIiwidmFsUmVwbGFjZWQiLCJNb25nb0Nvbm5lY3Rpb24iLCJ1cmwiLCJvcHRpb25zIiwiX01ldGVvciRzZXR0aW5ncyIsIl9NZXRlb3Ikc2V0dGluZ3MkcGFjayIsIl9NZXRlb3Ikc2V0dGluZ3MkcGFjazIiLCJzZWxmIiwiX29ic2VydmVNdWx0aXBsZXhlcnMiLCJfb25GYWlsb3Zlckhvb2siLCJIb29rIiwidXNlck9wdGlvbnMiLCJfY29ubmVjdGlvbk9wdGlvbnMiLCJzZXR0aW5ncyIsInBhY2thZ2VzIiwibW9uZ28iLCJtb25nb09wdGlvbnMiLCJPYmplY3QiLCJhc3NpZ24iLCJpZ25vcmVVbmRlZmluZWQiLCJoYXMiLCJtYXhQb29sU2l6ZSIsIm1pblBvb2xTaXplIiwiZW50cmllcyIsIl9yZWYiLCJlbmRzV2l0aCIsImZvckVhY2giLCJfcmVmMiIsIm9wdGlvbk5hbWUiLCJyZXBsYWNlIiwiam9pbiIsIkFzc2V0cyIsImdldFNlcnZlckRpciIsImRiIiwiX29wbG9nSGFuZGxlIiwiX2RvY0ZldGNoZXIiLCJjbGllbnQiLCJNb25nb0NsaWVudCIsIm9uIiwiYmluZEVudmlyb25tZW50IiwiZXZlbnQiLCJwcmV2aW91c0Rlc2NyaXB0aW9uIiwidHlwZSIsIm5ld0Rlc2NyaXB0aW9uIiwiY2FsbGJhY2siLCJvcGxvZ1VybCIsIlBhY2thZ2UiLCJPcGxvZ0hhbmRsZSIsImRhdGFiYXNlTmFtZSIsIl9jbG9zZSIsIkVycm9yIiwib3Bsb2dIYW5kbGUiLCJzdG9wIiwiY2xvc2UiLCJfc2V0T3Bsb2dIYW5kbGUiLCJyYXdDb2xsZWN0aW9uIiwiY29sbGVjdGlvbk5hbWUiLCJjb2xsZWN0aW9uIiwiY3JlYXRlQ2FwcGVkQ29sbGVjdGlvbkFzeW5jIiwiYnl0ZVNpemUiLCJtYXhEb2N1bWVudHMiLCJjcmVhdGVDb2xsZWN0aW9uIiwiY2FwcGVkIiwibWF4IiwiX21heWJlQmVnaW5Xcml0ZSIsImZlbmNlIiwiRERQU2VydmVyIiwiX2dldEN1cnJlbnRGZW5jZSIsImJlZ2luV3JpdGUiLCJjb21taXR0ZWQiLCJfb25GYWlsb3ZlciIsInJlZ2lzdGVyIiwid3JpdGVDYWxsYmFjayIsIndyaXRlIiwicmVmcmVzaCIsImVyciIsInJlc3VsdCIsInJlZnJlc2hFcnIiLCJiaW5kRW52aXJvbm1lbnRGb3JXcml0ZSIsImluc2VydEFzeW5jIiwiY29sbGVjdGlvbl9uYW1lIiwiZSIsIl9leHBlY3RlZEJ5VGVzdCIsIkxvY2FsQ29sbGVjdGlvbiIsIl9pc1BsYWluT2JqZWN0IiwiaWQiLCJfaWQiLCJpbnNlcnRPbmUiLCJzYWZlIiwidGhlbiIsIl9yZWYzIiwiaW5zZXJ0ZWRJZCIsImNhdGNoIiwiX3JlZnJlc2giLCJzZWxlY3RvciIsInJlZnJlc2hLZXkiLCJzcGVjaWZpY0lkcyIsIl9pZHNNYXRjaGVkQnlTZWxlY3RvciIsImV4dGVuZCIsInJlbW92ZUFzeW5jIiwiZGVsZXRlTWFueSIsIl9yZWY0IiwiZGVsZXRlZENvdW50IiwidHJhbnNmb3JtUmVzdWx0IiwibW9kaWZpZWRDb3VudCIsIm51bWJlckFmZmVjdGVkIiwiZHJvcENvbGxlY3Rpb25Bc3luYyIsImRyb3BDb2xsZWN0aW9uIiwiZHJvcCIsImRyb3BEYXRhYmFzZUFzeW5jIiwiZHJvcERhdGFiYXNlIiwiX2Ryb3BEYXRhYmFzZSIsInVwZGF0ZUFzeW5jIiwibW9kIiwiZXJyb3IiLCJtb25nb09wdHMiLCJhcnJheUZpbHRlcnMiLCJ1cHNlcnQiLCJtdWx0aSIsImZ1bGxSZXN1bHQiLCJtb25nb1NlbGVjdG9yIiwibW9uZ29Nb2QiLCJpc01vZGlmeSIsIl9pc01vZGlmaWNhdGlvbk1vZCIsIl9mb3JiaWRSZXBsYWNlIiwia25vd25JZCIsIm5ld0RvYyIsIl9jcmVhdGVVcHNlcnREb2N1bWVudCIsImdlbmVyYXRlZElkIiwic2ltdWxhdGVVcHNlcnRXaXRoSW5zZXJ0ZWRJZCIsIl9yZXR1cm5PYmplY3QiLCJoYXNPd25Qcm9wZXJ0eSIsIiRzZXRPbkluc2VydCIsInN0cmluZ3MiLCJrZXlzIiwic3RhcnRzV2l0aCIsInVwZGF0ZU1ldGhvZCIsImxlbmd0aCIsIm1ldGVvclJlc3VsdCIsImRyaXZlclJlc3VsdCIsIm1vbmdvUmVzdWx0IiwidXBzZXJ0ZWRDb3VudCIsInVwc2VydGVkSWQiLCJuIiwibWF0Y2hlZENvdW50IiwiTlVNX09QVElNSVNUSUNfVFJJRVMiLCJfaXNDYW5ub3RDaGFuZ2VJZEVycm9yIiwiZXJybXNnIiwiaW5kZXhPZiIsIm1vbmdvT3B0c0ZvclVwZGF0ZSIsIm1vbmdvT3B0c0Zvckluc2VydCIsInJlcGxhY2VtZW50V2l0aElkIiwidHJpZXMiLCJkb1VwZGF0ZSIsIm1ldGhvZCIsInVwZGF0ZU1hbnkiLCJzb21lIiwicmVwbGFjZU9uZSIsImRvQ29uZGl0aW9uYWxJbnNlcnQiLCJ1cHNlcnRBc3luYyIsImZpbmQiLCJhcmd1bWVudHMiLCJDdXJzb3IiLCJDdXJzb3JEZXNjcmlwdGlvbiIsImZpbmRPbmVBc3luYyIsImxpbWl0IiwicmVzdWx0cyIsImZldGNoIiwiY3JlYXRlSW5kZXhBc3luYyIsImluZGV4IiwiY3JlYXRlSW5kZXgiLCJjb3VudERvY3VtZW50cyIsIl9sZW4iLCJhcmdzIiwiQXJyYXkiLCJfa2V5IiwiYXJnIiwiZXN0aW1hdGVkRG9jdW1lbnRDb3VudCIsIl9sZW4yIiwiX2tleTIiLCJlbnN1cmVJbmRleEFzeW5jIiwiZHJvcEluZGV4QXN5bmMiLCJpbmRleE5hbWUiLCJkcm9wSW5kZXgiLCJtIiwiY29uY2F0IiwiQ29sbGVjdGlvbiIsIl9yZXdyaXRlU2VsZWN0b3IiLCJjdXJzb3JEZXNjcmlwdGlvbiIsIl9tb25nbyIsIl9jdXJzb3JEZXNjcmlwdGlvbiIsIl9zeW5jaHJvbm91c0N1cnNvciIsInNldHVwU3luY2hyb25vdXNDdXJzb3IiLCJjdXJzb3IiLCJ0YWlsYWJsZSIsIl9jcmVhdGVTeW5jaHJvbm91c0N1cnNvciIsInNlbGZGb3JJdGVyYXRpb24iLCJ1c2VUcmFuc2Zvcm0iLCJjb3VudEFzeW5jIiwiY291bnQiLCJTeW1ib2wiLCJpdGVyYXRvciIsImFzeW5jSXRlcmF0b3IiLCJtZXRob2ROYW1lIiwibWV0aG9kTmFtZUFzeW5jIiwiUHJvbWlzZSIsInJlc29sdmUiLCJyZWplY3QiLCJnZXRUcmFuc2Zvcm0iLCJ0cmFuc2Zvcm0iLCJfcHVibGlzaEN1cnNvciIsInN1YiIsIl9nZXRDb2xsZWN0aW9uTmFtZSIsIm9ic2VydmUiLCJjYWxsYmFja3MiLCJfb2JzZXJ2ZUZyb21PYnNlcnZlQ2hhbmdlcyIsIm9ic2VydmVBc3luYyIsIm9ic2VydmVDaGFuZ2VzIiwibWV0aG9kcyIsIm9yZGVyZWQiLCJfb2JzZXJ2ZUNoYW5nZXNDYWxsYmFja3NBcmVPcmRlcmVkIiwiZXhjZXB0aW9uTmFtZSIsIl9mcm9tT2JzZXJ2ZSIsIl9vYnNlcnZlQ2hhbmdlcyIsIm5vbk11dGF0aW5nQ2FsbGJhY2tzIiwib2JzZXJ2ZUNoYW5nZXNBc3luYyIsInBpY2siLCJjdXJzb3JPcHRpb25zIiwic29ydCIsInNraXAiLCJwcm9qZWN0aW9uIiwiZmllbGRzIiwicmVhZFByZWZlcmVuY2UiLCJudW1iZXJPZlJldHJpZXMiLCJkYkN1cnNvciIsImFkZEN1cnNvckZsYWciLCJPUExPR19DT0xMRUNUSU9OIiwidHMiLCJtYXhUaW1lTXMiLCJtYXhUaW1lTVMiLCJoaW50IiwiQXN5bmNocm9ub3VzQ3Vyc29yIiwiY29uc3RydWN0b3IiLCJfZGJDdXJzb3IiLCJfc2VsZkZvckl0ZXJhdGlvbiIsIl90cmFuc2Zvcm0iLCJ3cmFwVHJhbnNmb3JtIiwiX3Zpc2l0ZWRJZHMiLCJfSWRNYXAiLCJuZXh0IiwiX25leHRPYmplY3RQcm9taXNlIiwiZG9uZSIsIl9yYXdOZXh0T2JqZWN0UHJvbWlzZSIsImNvbnNvbGUiLCJkb2MiLCJzZXQiLCJfbmV4dE9iamVjdFByb21pc2VXaXRoVGltZW91dCIsInRpbWVvdXRNUyIsIm5leHRPYmplY3RQcm9taXNlIiwidGltZW91dEVyciIsInRpbWVvdXRQcm9taXNlIiwic2V0VGltZW91dCIsInJhY2UiLCJ0aGlzQXJnIiwiX3Jld2luZCIsImlkeCIsImNhbGwiLCJwdXNoIiwicmV3aW5kIiwiaWRlbnRpdHkiLCJnZXRSYXdPYmplY3RzIiwiU3luY2hyb25vdXNDdXJzb3IiLCJfc3luY2hyb25vdXNDb3VudCIsIkZ1dHVyZSIsIndyYXAiLCJ0aW1lciIsIl9uZXh0T2JqZWN0IiwiYXdhaXQiLCJ3cmFwcGVkRm4iLCJ3cmFwRm4iLCJyZXMiLCJ3YWl0Iiwic3luY1Jlc3VsdCIsInRhaWwiLCJkb2NDYWxsYmFjayIsInN0b3BwZWQiLCJsYXN0VFMiLCJkZWZlciIsImxvb3AiLCJuZXdTZWxlY3RvciIsIiRndCIsIm9wbG9nQ29sbGVjdGlvbldhcm5pbmdzIiwiX3NlbGYkX29wbG9nSGFuZGxlIiwiX29ic2VydmVDaGFuZ2VzVGFpbGFibGUiLCJmaWVsZHNPcHRpb25zIiwib2JzZXJ2ZUtleSIsInN0cmluZ2lmeSIsIm11bHRpcGxleGVyIiwib2JzZXJ2ZURyaXZlciIsImZpcnN0SGFuZGxlIiwiT2JzZXJ2ZU11bHRpcGxleGVyIiwib25TdG9wIiwib2JzZXJ2ZUhhbmRsZSIsIk9ic2VydmVIYW5kbGUiLCJvcGxvZ09wdGlvbnMiLCJfb3Bsb2dPcHRpb25zIiwiaW5jbHVkZUNvbGxlY3Rpb25zIiwiZXhjbHVkZUNvbGxlY3Rpb25zIiwibWF0Y2hlciIsInNvcnRlciIsImNhblVzZU9wbG9nIiwiYWxsIiwiX3Rlc3RPbmx5UG9sbENhbGxiYWNrIiwiaW5jbHVkZXMiLCJ3YXJuIiwiTWluaW1vbmdvIiwiTWF0Y2hlciIsIk9wbG9nT2JzZXJ2ZURyaXZlciIsImN1cnNvclN1cHBvcnRlZCIsIlNvcnRlciIsImYiLCJkcml2ZXJDbGFzcyIsIlBvbGxpbmdPYnNlcnZlRHJpdmVyIiwibW9uZ29IYW5kbGUiLCJfaW5pdCIsIl9vYnNlcnZlRHJpdmVyIiwiYWRkSGFuZGxlQW5kU2VuZEluaXRpYWxBZGRzIiwibGlzdGVuQWxsIiwibGlzdGVuQ2FsbGJhY2siLCJsaXN0ZW5lcnMiLCJmb3JFYWNoVHJpZ2dlciIsInRyaWdnZXIiLCJfSW52YWxpZGF0aW9uQ3Jvc3NiYXIiLCJsaXN0ZW4iLCJsaXN0ZW5lciIsInRyaWdnZXJDYWxsYmFjayIsImFkZGVkQmVmb3JlIiwiYWRkZWQiLCJNb25nb1RpbWVzdGFtcCIsIkNvbm5lY3Rpb24iLCJfX3JlaWZ5X2FzeW5jX3Jlc3VsdF9fIiwiX3JlaWZ5RXJyb3IiLCJhc3luYyIsIkxvbmciLCJUT09fRkFSX0JFSElORCIsInByb2Nlc3MiLCJlbnYiLCJNRVRFT1JfT1BMT0dfVE9PX0ZBUl9CRUhJTkQiLCJUQUlMX1RJTUVPVVQiLCJNRVRFT1JfT1BMT0dfVEFJTF9USU1FT1VUIiwiaWRGb3JPcCIsIm9wIiwibyIsIm8yIiwiZGJOYW1lIiwiX29wbG9nVXJsIiwiX2RiTmFtZSIsIl9vcGxvZ0xhc3RFbnRyeUNvbm5lY3Rpb24iLCJfb3Bsb2dUYWlsQ29ubmVjdGlvbiIsIl9zdG9wcGVkIiwiX3RhaWxIYW5kbGUiLCJfcmVhZHlQcm9taXNlUmVzb2x2ZXIiLCJfcmVhZHlQcm9taXNlIiwiciIsIl9jcm9zc2JhciIsIl9Dcm9zc2JhciIsImZhY3RQYWNrYWdlIiwiZmFjdE5hbWUiLCJfYmFzZU9wbG9nU2VsZWN0b3IiLCJucyIsIlJlZ0V4cCIsIl9lc2NhcGVSZWdFeHAiLCIkb3IiLCIkaW4iLCIkZXhpc3RzIiwiX2NhdGNoaW5nVXBSZXNvbHZlcnMiLCJfbGFzdFByb2Nlc3NlZFRTIiwiX29uU2tpcHBlZEVudHJpZXNIb29rIiwiZGVidWdQcmludEV4Y2VwdGlvbnMiLCJfZW50cnlRdWV1ZSIsIl9Eb3VibGVFbmRlZFF1ZXVlIiwiX3dvcmtlckFjdGl2ZSIsIl9zdGFydFRyYWlsaW5nUHJvbWlzZSIsIl9zdGFydFRhaWxpbmciLCJfb25PcGxvZ0VudHJ5Iiwib3JpZ2luYWxDYWxsYmFjayIsIm5vdGlmaWNhdGlvbiIsIl9kZWJ1ZyIsImxpc3RlbkhhbmRsZSIsIm9uT3Bsb2dFbnRyeSIsIm9uU2tpcHBlZEVudHJpZXMiLCJfd2FpdFVudGlsQ2F1Z2h0VXAiLCJsYXN0RW50cnkiLCIkbmF0dXJhbCIsIl9zbGVlcEZvck1zIiwibGVzc1RoYW5PckVxdWFsIiwiaW5zZXJ0QWZ0ZXIiLCJncmVhdGVyVGhhbiIsInByb21pc2VSZXNvbHZlciIsInByb21pc2VUb0F3YWl0Iiwic3BsaWNlIiwicmVzb2x2ZXIiLCJ3YWl0VW50aWxDYXVnaHRVcCIsIl9NZXRlb3Ikc2V0dGluZ3MyIiwiX01ldGVvciRzZXR0aW5nczIkcGFjIiwiX01ldGVvciRzZXR0aW5nczIkcGFjMiIsIm1vbmdvZGJVcmkiLCJOcG0iLCJwYXJzZSIsImRhdGFiYXNlIiwiaXNNYXN0ZXJEb2MiLCJhZG1pbiIsImNvbW1hbmQiLCJpc21hc3RlciIsInNldE5hbWUiLCJsYXN0T3Bsb2dFbnRyeSIsIm9wbG9nU2VsZWN0b3IiLCJvcGxvZ0luY2x1ZGVDb2xsZWN0aW9ucyIsIm9wbG9nRXhjbHVkZUNvbGxlY3Rpb25zIiwiJHJlZ2V4IiwiJG5pbiIsImNvbGxOYW1lIiwiJGFuZCIsIl9tYXliZVN0YXJ0V29ya2VyIiwiaGFuZGxlRG9jIiwiYXBwbHlPcHMiLCJuZXh0VGltZXN0YW1wIiwiYWRkIiwiT05FIiwic2xpY2UiLCJmaXJlIiwiaXNFbXB0eSIsInBvcCIsImNsZWFyIiwiX3NldExhc3RQcm9jZXNzZWRUUyIsInNoaWZ0Iiwic2VxdWVuY2VyIiwiX2RlZmluZVRvb0ZhckJlaGluZCIsIl9yZXNldFRvb0ZhckJlaGluZCIsIl9vYmplY3RXaXRob3V0UHJvcGVydGllcyIsIl9leGNsdWRlZCIsIm5leHRPYnNlcnZlSGFuZGxlSWQiLCJGYWN0cyIsImluY3JlbWVudFNlcnZlckZhY3QiLCJfb3JkZXJlZCIsIl9vblN0b3AiLCJfcXVldWUiLCJfQXN5bmNocm9ub3VzUXVldWUiLCJfaGFuZGxlcyIsIl9yZXNvbHZlciIsIl9pc1JlYWR5IiwiX2NhY2hlIiwiX0NhY2hpbmdDaGFuZ2VPYnNlcnZlciIsIl9hZGRIYW5kbGVUYXNrc1NjaGVkdWxlZEJ1dE5vdFBlcmZvcm1lZCIsImNhbGxiYWNrTmFtZXMiLCJjYWxsYmFja05hbWUiLCJfYXBwbHlDYWxsYmFjayIsInRvQXJyYXkiLCJoYW5kbGUiLCJfYWRkSGFuZGxlQW5kU2VuZEluaXRpYWxBZGRzIiwicnVuVGFzayIsIl9zZW5kQWRkcyIsInJlbW92ZUhhbmRsZSIsIl9yZWFkeSIsIl9zdG9wIiwiZnJvbVF1ZXJ5RXJyb3IiLCJyZWFkeSIsInF1ZXVlVGFzayIsInF1ZXJ5RXJyb3IiLCJvbkZsdXNoIiwiY2IiLCJhcHBseUNoYW5nZSIsImFwcGx5IiwiaGFuZGxlSWQiLCJfYWRkZWRCZWZvcmUiLCJfYWRkZWQiLCJkb2NzIiwiZm9yRWFjaEFzeW5jIiwiX211bHRpcGxleGVyIiwiYmVmb3JlIiwiZXhwb3J0IiwibW9uZ29Db25uZWN0aW9uIiwiX21vbmdvQ29ubmVjdGlvbiIsIl9jYWxsYmFja3NGb3JPcCIsIk1hcCIsImNoZWNrIiwiU3RyaW5nIiwiZ2V0IiwiZGVsZXRlIiwiUE9MTElOR19USFJPVFRMRV9NUyIsIk1FVEVPUl9QT0xMSU5HX1RIUk9UVExFX01TIiwiUE9MTElOR19JTlRFUlZBTF9NUyIsIk1FVEVPUl9QT0xMSU5HX0lOVEVSVkFMX01TIiwiX29wdGlvbnMiLCJfbW9uZ29IYW5kbGUiLCJfc3RvcENhbGxiYWNrcyIsIl9jdXJzb3IiLCJfcmVzdWx0cyIsIl9wb2xsc1NjaGVkdWxlZEJ1dE5vdFN0YXJ0ZWQiLCJfcGVuZGluZ1dyaXRlcyIsIl9lbnN1cmVQb2xsSXNTY2hlZHVsZWQiLCJ0aHJvdHRsZSIsIl91bnRocm90dGxlZEVuc3VyZVBvbGxJc1NjaGVkdWxlZCIsInBvbGxpbmdUaHJvdHRsZU1zIiwiX3Rhc2tRdWV1ZSIsImxpc3RlbmVyc0hhbmRsZSIsInBvbGxpbmdJbnRlcnZhbCIsInBvbGxpbmdJbnRlcnZhbE1zIiwiX3BvbGxpbmdJbnRlcnZhbCIsImludGVydmFsSGFuZGxlIiwic2V0SW50ZXJ2YWwiLCJjbGVhckludGVydmFsIiwiX3BvbGxNb25nbyIsIl9zdXNwZW5kUG9sbGluZyIsIl9yZXN1bWVQb2xsaW5nIiwiZmlyc3QiLCJuZXdSZXN1bHRzIiwib2xkUmVzdWx0cyIsIndyaXRlc0ZvckN5Y2xlIiwiY29kZSIsIkpTT04iLCJtZXNzYWdlIiwiX2RpZmZRdWVyeUNoYW5nZXMiLCJ3Iiwic3RvcENhbGxiYWNrc0NhbGxlciIsImMiLCJfYXN5bmNJdGVyYXRvciIsIm9wbG9nVjJWMUNvbnZlcnRlciIsIk1hdGNoIiwiUEhBU0UiLCJRVUVSWUlORyIsIkZFVENISU5HIiwiU1RFQURZIiwiU3dpdGNoZWRUb1F1ZXJ5IiwiZmluaXNoSWZOZWVkVG9Qb2xsUXVlcnkiLCJjdXJyZW50SWQiLCJfdXNlc09wbG9nIiwiY29tcGFyYXRvciIsImdldENvbXBhcmF0b3IiLCJoZWFwT3B0aW9ucyIsIklkTWFwIiwiX2xpbWl0IiwiX2NvbXBhcmF0b3IiLCJfc29ydGVyIiwiX3VucHVibGlzaGVkQnVmZmVyIiwiTWluTWF4SGVhcCIsIl9wdWJsaXNoZWQiLCJNYXhIZWFwIiwiX3NhZmVBcHBlbmRUb0J1ZmZlciIsIl9zdG9wSGFuZGxlcyIsIl9hZGRTdG9wSGFuZGxlcyIsIm5ld1N0b3BIYW5kbGVzIiwiZXhwZWN0ZWRQYXR0ZXJuIiwiT2JqZWN0SW5jbHVkaW5nIiwiRnVuY3Rpb24iLCJPbmVPZiIsIl9yZWdpc3RlclBoYXNlQ2hhbmdlIiwiX21hdGNoZXIiLCJfcHJvamVjdGlvbkZuIiwiX2NvbXBpbGVQcm9qZWN0aW9uIiwiX3NoYXJlZFByb2plY3Rpb24iLCJjb21iaW5lSW50b1Byb2plY3Rpb24iLCJfc2hhcmVkUHJvamVjdGlvbkZuIiwiX25lZWRUb0ZldGNoIiwiX2N1cnJlbnRseUZldGNoaW5nIiwiX2ZldGNoR2VuZXJhdGlvbiIsIl9yZXF1ZXJ5V2hlbkRvbmVUaGlzUXVlcnkiLCJfd3JpdGVzVG9Db21taXRXaGVuV2VSZWFjaFN0ZWFkeSIsIl9uZWVkVG9Qb2xsUXVlcnkiLCJfcGhhc2UiLCJfaGFuZGxlT3Bsb2dFbnRyeVF1ZXJ5aW5nIiwiX2hhbmRsZU9wbG9nRW50cnlTdGVhZHlPckZldGNoaW5nIiwiZmlyZWQiLCJfb3Bsb2dPYnNlcnZlRHJpdmVycyIsIm9uQmVmb3JlRmlyZSIsImRyaXZlcnMiLCJkcml2ZXIiLCJ2YWx1ZXMiLCJfcnVuSW5pdGlhbFF1ZXJ5IiwiX2FkZFB1Ymxpc2hlZCIsIl9ub1lpZWxkc0FsbG93ZWQiLCJvdmVyZmxvd2luZ0RvY0lkIiwibWF4RWxlbWVudElkIiwib3ZlcmZsb3dpbmdEb2MiLCJlcXVhbHMiLCJyZW1vdmUiLCJyZW1vdmVkIiwiX2FkZEJ1ZmZlcmVkIiwiX3JlbW92ZVB1Ymxpc2hlZCIsImVtcHR5IiwibmV3RG9jSWQiLCJtaW5FbGVtZW50SWQiLCJfcmVtb3ZlQnVmZmVyZWQiLCJfY2hhbmdlUHVibGlzaGVkIiwib2xkRG9jIiwicHJvamVjdGVkTmV3IiwicHJvamVjdGVkT2xkIiwiY2hhbmdlZCIsIkRpZmZTZXF1ZW5jZSIsIm1ha2VDaGFuZ2VkRmllbGRzIiwibWF4QnVmZmVyZWRJZCIsIl9hZGRNYXRjaGluZyIsIm1heFB1Ymxpc2hlZCIsIm1heEJ1ZmZlcmVkIiwidG9QdWJsaXNoIiwiY2FuQXBwZW5kVG9CdWZmZXIiLCJjYW5JbnNlcnRJbnRvQnVmZmVyIiwidG9CdWZmZXIiLCJfcmVtb3ZlTWF0Y2hpbmciLCJfaGFuZGxlRG9jIiwibWF0Y2hlc05vdyIsImRvY3VtZW50TWF0Y2hlcyIsInB1Ymxpc2hlZEJlZm9yZSIsImJ1ZmZlcmVkQmVmb3JlIiwiY2FjaGVkQmVmb3JlIiwibWluQnVmZmVyZWQiLCJzdGF5c0luUHVibGlzaGVkIiwic3RheXNJbkJ1ZmZlciIsIl9mZXRjaE1vZGlmaWVkRG9jdW1lbnRzIiwidGhpc0dlbmVyYXRpb24iLCJ3YWl0aW5nIiwiYXdhaXRhYmxlUHJvbWlzZSIsIl9iZVN0ZWFkeSIsIndyaXRlcyIsImlzUmVwbGFjZSIsImNhbkRpcmVjdGx5TW9kaWZ5RG9jIiwibW9kaWZpZXJDYW5CZURpcmVjdGx5QXBwbGllZCIsIl9tb2RpZnkiLCJjYW5CZWNvbWVUcnVlQnlNb2RpZmllciIsImFmZmVjdGVkQnlNb2RpZmllciIsIl9ydW5Jbml0aWFsUXVlcnlBc3luYyIsIl9ydW5RdWVyeSIsImluaXRpYWwiLCJfZG9uZVF1ZXJ5aW5nIiwiX3BvbGxRdWVyeSIsIl9ydW5RdWVyeUFzeW5jIiwibmV3QnVmZmVyIiwiX2N1cnNvckZvclF1ZXJ5IiwiaSIsIl9wdWJsaXNoTmV3UmVzdWx0cyIsIm9wdGlvbnNPdmVyd3JpdGUiLCJkZXNjcmlwdGlvbiIsImlkc1RvUmVtb3ZlIiwiX29wbG9nRW50cnlIYW5kbGUiLCJfbGlzdGVuZXJzSGFuZGxlIiwiX2l0ZXJhdG9yQWJydXB0Q29tcGxldGlvbiIsIl9kaWRJdGVyYXRvckVycm9yIiwiX2l0ZXJhdG9yRXJyb3IiLCJfaXRlcmF0b3IiLCJfc3RlcCIsInJldHVybiIsInBoYXNlIiwibm93IiwiRGF0ZSIsInRpbWVEaWZmIiwiX3BoYXNlU3RhcnRUaW1lIiwiZGlzYWJsZU9wbG9nIiwiX2Rpc2FibGVPcGxvZyIsIl9jaGVja1N1cHBvcnRlZFByb2plY3Rpb24iLCJoYXNXaGVyZSIsImhhc0dlb1F1ZXJ5IiwibW9kaWZpZXIiLCJvcGVyYXRpb24iLCJmaWVsZCIsInRlc3QiLCJwcmVmaXgiLCJhcnJheU9wZXJhdG9yS2V5UmVnZXgiLCJpc0FycmF5T3BlcmF0b3JLZXkiLCJpc0FycmF5T3BlcmF0b3IiLCJvcGVyYXRvciIsImEiLCJldmVyeSIsImZsYXR0ZW5PYmplY3RJbnRvIiwidGFyZ2V0Iiwic291cmNlIiwibG9nRGVidWdNZXNzYWdlcyIsIk9QTE9HX0NPTlZFUlRFUl9ERUJVRyIsImNvbnZlcnRPcGxvZ0RpZmYiLCJvcGxvZ0VudHJ5IiwiZGlmZiIsImxvZyIsImRpZmZLZXkiLCJfb3Bsb2dFbnRyeSQkdW5zZXQiLCIkdW5zZXQiLCJfb3Bsb2dFbnRyeSQkc2V0IiwiJHNldCIsIl9vcGxvZ0VudHJ5JCRzZXQyIiwicG9zaXRpb24iLCJwb3NpdGlvbktleSIsIl9vcGxvZ0VudHJ5JCR1bnNldDIiLCJfb3Bsb2dFbnRyeSQkc2V0MyIsIiR2IiwiY29udmVydGVkT3Bsb2dFbnRyeSIsIkxvY2FsQ29sbGVjdGlvbkRyaXZlciIsIm5vQ29ubkNvbGxlY3Rpb25zIiwiY3JlYXRlIiwib3BlbiIsImNvbm4iLCJlbnN1cmVDb2xsZWN0aW9uIiwiX21vbmdvX2xpdmVkYXRhX2NvbGxlY3Rpb25zIiwiY29sbGVjdGlvbnMiLCJBU1lOQ19DT0xMRUNUSU9OX01FVEhPRFMiLCJSZW1vdGVDb2xsZWN0aW9uRHJpdmVyIiwibW9uZ29fdXJsIiwiUkVNT1RFX0NPTExFQ1RJT05fTUVUSE9EUyIsImFzeW5jTWV0aG9kTmFtZSIsImRlZmF1bHRSZW1vdGVDb2xsZWN0aW9uRHJpdmVyIiwib25jZSIsImNvbm5lY3Rpb25PcHRpb25zIiwibW9uZ29VcmwiLCJNT05HT19VUkwiLCJNT05HT19PUExPR19VUkwiLCJzdGFydHVwIiwiY29ubmVjdCIsImNvbm5lY3Rpb24iLCJtYW5hZ2VyIiwiaWRHZW5lcmF0aW9uIiwiX2RyaXZlciIsIl9wcmV2ZW50QXV0b3B1Ymxpc2giLCJfbWFrZU5ld0lEIiwic3JjIiwiRERQIiwicmFuZG9tU3RyZWFtIiwiUmFuZG9tIiwiaW5zZWN1cmUiLCJoZXhTdHJpbmciLCJyZXNvbHZlclR5cGUiLCJfY29ubmVjdGlvbiIsImlzQ2xpZW50Iiwic2VydmVyIiwiX2NvbGxlY3Rpb24iLCJfbmFtZSIsIl9zZXR0aW5nVXBSZXBsaWNhdGlvblByb21pc2UiLCJfbWF5YmVTZXRVcFJlcGxpY2F0aW9uIiwiZGVmaW5lTXV0YXRpb25NZXRob2RzIiwiX2RlZmluZU11dGF0aW9uTWV0aG9kcyIsInVzZUV4aXN0aW5nIiwiX3N1cHByZXNzU2FtZU5hbWVFcnJvciIsImF1dG9wdWJsaXNoIiwicHVibGlzaCIsImlzX2F1dG8iLCJfcmVnaXN0ZXJTdG9yZVJlc3VsdCIsIl9yZWdpc3RlclN0b3JlUmVzdWx0JCIsInJlZ2lzdGVyU3RvcmVDbGllbnQiLCJyZWdpc3RlclN0b3JlU2VydmVyIiwid3JhcHBlZFN0b3JlQ29tbW9uIiwic2F2ZU9yaWdpbmFscyIsInJldHJpZXZlT3JpZ2luYWxzIiwiX2dldENvbGxlY3Rpb24iLCJ3cmFwcGVkU3RvcmVDbGllbnQiLCJiZWdpblVwZGF0ZSIsImJhdGNoU2l6ZSIsInJlc2V0IiwicGF1c2VPYnNlcnZlcnMiLCJ1cGRhdGUiLCJtc2ciLCJtb25nb0lkIiwiTW9uZ29JRCIsImlkUGFyc2UiLCJfZG9jcyIsImluc2VydCIsImVuZFVwZGF0ZSIsInJlc3VtZU9ic2VydmVyc0NsaWVudCIsImdldERvYyIsImZpbmRPbmUiLCJ3cmFwcGVkU3RvcmVTZXJ2ZXIiLCJyZXN1bWVPYnNlcnZlcnNTZXJ2ZXIiLCJyZWdpc3RlclN0b3JlUmVzdWx0IiwibG9nV2FybiIsIm9rIiwiX2dldEZpbmRTZWxlY3RvciIsIl9nZXRGaW5kT3B0aW9ucyIsIm5ld09wdGlvbnMiLCJPcHRpb25hbCIsIk51bWJlciIsIl9sZW4zIiwiX2tleTMiLCJmYWxsYmFja0lkIiwiX3NlbGVjdG9ySXNJZCIsIl9pbnNlcnQiLCJnZXRQcm90b3R5cGVPZiIsImdldE93blByb3BlcnR5RGVzY3JpcHRvcnMiLCJnZW5lcmF0ZUlkIiwiX2lzUmVtb3RlQ29sbGVjdGlvbiIsImVuY2xvc2luZyIsIl9DdXJyZW50TWV0aG9kSW52b2NhdGlvbiIsImNob29zZVJldHVyblZhbHVlRnJvbUNvbGxlY3Rpb25SZXN1bHQiLCJfaXNQcm9taXNlIiwid3JhcHBlZENhbGxiYWNrIiwid3JhcENhbGxiYWNrIiwiX2NhbGxNdXRhdG9yTWV0aG9kIiwiX2luc2VydEFzeW5jIiwicHJvbWlzZSIsIl9jYWxsTXV0YXRvck1ldGhvZEFzeW5jIiwic3R1YlByb21pc2UiLCJzZXJ2ZXJQcm9taXNlIiwiX2xlbjQiLCJvcHRpb25zQW5kQ2FsbGJhY2siLCJfa2V5NCIsInBvcENhbGxiYWNrRnJvbUFyZ3MiLCJMb2ciLCJkZWJ1ZyIsInJlQ3JlYXRlSW5kZXhPbk9wdGlvbk1pc21hdGNoIiwiaW5mbyIsInJhd0RhdGFiYXNlIiwiY29udmVydFJlc3VsdCIsIkFsbG93RGVueSIsIkNvbGxlY3Rpb25Qcm90b3R5cGUiLCJzZXRDb25uZWN0aW9uT3B0aW9ucyIsIm90aGVyT3B0aW9ucyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0lBQUEsSUFBSUEsYUFBYTtJQUFDQyxPQUFPLENBQUNDLElBQUksQ0FBQyxzQ0FBc0MsRUFBQztNQUFDQyxPQUFPQSxDQUFDQyxDQUFDLEVBQUM7UUFBQ0osYUFBYSxHQUFDSSxDQUFDO01BQUE7SUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0lBQXRHLElBQUlDLG1CQUFtQjtJQUFDSixPQUFPLENBQUNDLElBQUksQ0FBQyxlQUFlLEVBQUM7TUFBQ0csbUJBQW1CQSxDQUFDRCxDQUFDLEVBQUM7UUFBQ0MsbUJBQW1CLEdBQUNELENBQUM7TUFBQTtJQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7SUFBQyxJQUFJRSxVQUFVO0lBQUNMLE9BQU8sQ0FBQ0MsSUFBSSxDQUFDLGtCQUFrQixFQUFDO01BQUNJLFVBQVVBLENBQUNGLENBQUMsRUFBQztRQUFDRSxVQUFVLEdBQUNGLENBQUM7TUFBQTtJQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7SUFBQyxJQUFJRyxvQkFBb0IsRUFBQ0MsbUJBQW1CLEVBQUNDLGtCQUFrQjtJQUFDUixPQUFPLENBQUNDLElBQUksQ0FBQyw0QkFBNEIsRUFBQztNQUFDSyxvQkFBb0JBLENBQUNILENBQUMsRUFBQztRQUFDRyxvQkFBb0IsR0FBQ0gsQ0FBQztNQUFBLENBQUM7TUFBQ0ksbUJBQW1CQSxDQUFDSixDQUFDLEVBQUM7UUFBQ0ksbUJBQW1CLEdBQUNKLENBQUM7TUFBQSxDQUFDO01BQUNLLGtCQUFrQkEsQ0FBQ0wsQ0FBQyxFQUFDO1FBQUNLLGtCQUFrQixHQUFDTCxDQUFDO01BQUE7SUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0lBQUMsSUFBSU0sTUFBTTtJQUFDVCxPQUFPLENBQUNDLElBQUksQ0FBQyxlQUFlLEVBQUM7TUFBQ1EsTUFBTUEsQ0FBQ04sQ0FBQyxFQUFDO1FBQUNNLE1BQU0sR0FBQ04sQ0FBQztNQUFBO0lBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztJQUFDLElBQUlPLG9CQUFvQixDQUFDLENBQUMsRUFBRSxDQUFDLE1BQU1BLG9CQUFvQixDQUFDLENBQUMsRUFBRSxDQUFDO0lBRTlpQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztJQUVBLE1BQU1DLElBQUksR0FBR0MsT0FBTyxDQUFDLE1BQU0sQ0FBQztJQUM1QixNQUFNQyxJQUFJLEdBQUdELE9BQU8sQ0FBQyxNQUFNLENBQUM7O0lBRTVCO0lBQ0EsSUFBSUUsT0FBTyxHQUFHQyxnQkFBZ0I7SUFTOUJDLGNBQWMsR0FBRyxDQUFDLENBQUM7SUFFbkJBLGNBQWMsQ0FBQ0MsYUFBYSxHQUFHLE9BQU87SUFFdENELGNBQWMsQ0FBQ0UsVUFBVSxHQUFHO01BQzFCQyxPQUFPLEVBQUU7UUFDUEMsT0FBTyxFQUFFQyx1QkFBdUI7UUFDaENDLE1BQU0sRUFBRVI7TUFDVjtJQUNGLENBQUM7O0lBRUQ7SUFDQTtJQUNBO0lBQ0E7SUFDQUUsY0FBYyxDQUFDTyxTQUFTLEdBQUdULE9BQU87SUFFbEMsTUFBTVUsaUJBQWlCLEdBQUcsT0FBTztJQUNqQyxNQUFNQyxhQUFhLEdBQUcsUUFBUTtJQUM5QixNQUFNQyxVQUFVLEdBQUcsS0FBSzs7SUFFeEI7SUFDQTtJQUNBLElBQUlDLFlBQVksR0FBRyxTQUFBQSxDQUFVQyxNQUFNLEVBQUVDLEtBQUssRUFBRTtNQUMxQyxJQUFJLE9BQU9BLEtBQUssS0FBSyxRQUFRLElBQUlBLEtBQUssS0FBSyxJQUFJLEVBQUU7UUFDL0MsSUFBSUMsQ0FBQyxDQUFDQyxPQUFPLENBQUNGLEtBQUssQ0FBQyxFQUFFO1VBQ3BCLE9BQU9DLENBQUMsQ0FBQ0UsR0FBRyxDQUFDSCxLQUFLLEVBQUVDLENBQUMsQ0FBQ0csSUFBSSxDQUFDTixZQUFZLEVBQUUsSUFBSSxFQUFFQyxNQUFNLENBQUMsQ0FBQztRQUN6RDtRQUNBLElBQUlNLEdBQUcsR0FBRyxDQUFDLENBQUM7UUFDWkosQ0FBQyxDQUFDSyxJQUFJLENBQUNOLEtBQUssRUFBRSxVQUFVTyxLQUFLLEVBQUVDLEdBQUcsRUFBRTtVQUNsQ0gsR0FBRyxDQUFDTixNQUFNLENBQUNTLEdBQUcsQ0FBQyxDQUFDLEdBQUdWLFlBQVksQ0FBQ0MsTUFBTSxFQUFFUSxLQUFLLENBQUM7UUFDaEQsQ0FBQyxDQUFDO1FBQ0YsT0FBT0YsR0FBRztNQUNaO01BQ0EsT0FBT0wsS0FBSztJQUNkLENBQUM7O0lBRUQ7SUFDQTtJQUNBO0lBQ0FmLE9BQU8sQ0FBQ3dCLFNBQVMsQ0FBQ0MsU0FBUyxDQUFDQyxLQUFLLEdBQUcsWUFBWTtNQUM5QztNQUNBLE9BQU8sSUFBSTtJQUNiLENBQUM7SUFFRCxJQUFJQyxjQUFjLEdBQUcsU0FBQUEsQ0FBVUMsSUFBSSxFQUFFO01BQUUsT0FBTyxPQUFPLEdBQUdBLElBQUk7SUFBRSxDQUFDO0lBQy9ELElBQUlDLGdCQUFnQixHQUFHLFNBQUFBLENBQVVELElBQUksRUFBRTtNQUFFLE9BQU9BLElBQUksQ0FBQ0UsTUFBTSxDQUFDLENBQUMsQ0FBQztJQUFFLENBQUM7SUFFakUsSUFBSUMsMEJBQTBCLEdBQUcsU0FBQUEsQ0FBVUMsUUFBUSxFQUFFO01BQ25ELElBQUlBLFFBQVEsWUFBWWhDLE9BQU8sQ0FBQ2lDLE1BQU0sRUFBRTtRQUN0QztRQUNBLElBQUlELFFBQVEsQ0FBQ0UsUUFBUSxLQUFLLENBQUMsRUFBRTtVQUMzQixPQUFPRixRQUFRO1FBQ2pCO1FBQ0EsSUFBSUcsTUFBTSxHQUFHSCxRQUFRLENBQUNWLEtBQUssQ0FBQyxJQUFJLENBQUM7UUFDakMsT0FBTyxJQUFJYyxVQUFVLENBQUNELE1BQU0sQ0FBQztNQUMvQjtNQUNBLElBQUlILFFBQVEsWUFBWWhDLE9BQU8sQ0FBQ3FDLFFBQVEsRUFBRTtRQUN4QyxPQUFPLElBQUlDLEtBQUssQ0FBQ0QsUUFBUSxDQUFDTCxRQUFRLENBQUNPLFdBQVcsQ0FBQyxDQUFDLENBQUM7TUFDbkQ7TUFDQSxJQUFJUCxRQUFRLFlBQVloQyxPQUFPLENBQUN3QyxVQUFVLEVBQUU7UUFDMUMsT0FBT0MsT0FBTyxDQUFDVCxRQUFRLENBQUNVLFFBQVEsQ0FBQyxDQUFDLENBQUM7TUFDckM7TUFDQSxJQUFJVixRQUFRLENBQUMsWUFBWSxDQUFDLElBQUlBLFFBQVEsQ0FBQyxhQUFhLENBQUMsSUFBSWhCLENBQUMsQ0FBQzJCLElBQUksQ0FBQ1gsUUFBUSxDQUFDLEtBQUssQ0FBQyxFQUFFO1FBQy9FLE9BQU9ZLEtBQUssQ0FBQ0MsYUFBYSxDQUFDaEMsWUFBWSxDQUFDZ0IsZ0JBQWdCLEVBQUVHLFFBQVEsQ0FBQyxDQUFDO01BQ3RFO01BQ0EsSUFBSUEsUUFBUSxZQUFZaEMsT0FBTyxDQUFDd0IsU0FBUyxFQUFFO1FBQ3pDO1FBQ0E7UUFDQTtRQUNBO1FBQ0EsT0FBT1EsUUFBUTtNQUNqQjtNQUNBLE9BQU9jLFNBQVM7SUFDbEIsQ0FBQztJQUVELElBQUlDLDBCQUEwQixHQUFHLFNBQUFBLENBQVVmLFFBQVEsRUFBRTtNQUNuRCxJQUFJWSxLQUFLLENBQUNJLFFBQVEsQ0FBQ2hCLFFBQVEsQ0FBQyxFQUFFO1FBQzVCO1FBQ0E7UUFDQTtRQUNBLE9BQU8sSUFBSWhDLE9BQU8sQ0FBQ2lDLE1BQU0sQ0FBQ2dCLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDbEIsUUFBUSxDQUFDLENBQUM7TUFDbEQ7TUFDQSxJQUFJQSxRQUFRLFlBQVloQyxPQUFPLENBQUNpQyxNQUFNLEVBQUU7UUFDckMsT0FBT0QsUUFBUTtNQUNsQjtNQUNBLElBQUlBLFFBQVEsWUFBWU0sS0FBSyxDQUFDRCxRQUFRLEVBQUU7UUFDdEMsT0FBTyxJQUFJckMsT0FBTyxDQUFDcUMsUUFBUSxDQUFDTCxRQUFRLENBQUNPLFdBQVcsQ0FBQyxDQUFDLENBQUM7TUFDckQ7TUFDQSxJQUFJUCxRQUFRLFlBQVloQyxPQUFPLENBQUN3QixTQUFTLEVBQUU7UUFDekM7UUFDQTtRQUNBO1FBQ0E7UUFDQSxPQUFPUSxRQUFRO01BQ2pCO01BQ0EsSUFBSUEsUUFBUSxZQUFZUyxPQUFPLEVBQUU7UUFDL0IsT0FBT3pDLE9BQU8sQ0FBQ3dDLFVBQVUsQ0FBQ1csVUFBVSxDQUFDbkIsUUFBUSxDQUFDVSxRQUFRLENBQUMsQ0FBQyxDQUFDO01BQzNEO01BQ0EsSUFBSUUsS0FBSyxDQUFDUSxhQUFhLENBQUNwQixRQUFRLENBQUMsRUFBRTtRQUNqQyxPQUFPbkIsWUFBWSxDQUFDYyxjQUFjLEVBQUVpQixLQUFLLENBQUNTLFdBQVcsQ0FBQ3JCLFFBQVEsQ0FBQyxDQUFDO01BQ2xFO01BQ0E7TUFDQTtNQUNBLE9BQU9jLFNBQVM7SUFDbEIsQ0FBQztJQUVELElBQUlRLFlBQVksR0FBRyxTQUFBQSxDQUFVdEIsUUFBUSxFQUFFdUIsZUFBZSxFQUFFO01BQ3RELElBQUksT0FBT3ZCLFFBQVEsS0FBSyxRQUFRLElBQUlBLFFBQVEsS0FBSyxJQUFJLEVBQ25ELE9BQU9BLFFBQVE7TUFFakIsSUFBSXdCLG9CQUFvQixHQUFHRCxlQUFlLENBQUN2QixRQUFRLENBQUM7TUFDcEQsSUFBSXdCLG9CQUFvQixLQUFLVixTQUFTLEVBQ3BDLE9BQU9VLG9CQUFvQjtNQUU3QixJQUFJcEMsR0FBRyxHQUFHWSxRQUFRO01BQ2xCaEIsQ0FBQyxDQUFDSyxJQUFJLENBQUNXLFFBQVEsRUFBRSxVQUFVeUIsR0FBRyxFQUFFbEMsR0FBRyxFQUFFO1FBQ25DLElBQUltQyxXQUFXLEdBQUdKLFlBQVksQ0FBQ0csR0FBRyxFQUFFRixlQUFlLENBQUM7UUFDcEQsSUFBSUUsR0FBRyxLQUFLQyxXQUFXLEVBQUU7VUFDdkI7VUFDQSxJQUFJdEMsR0FBRyxLQUFLWSxRQUFRLEVBQ2xCWixHQUFHLEdBQUdKLENBQUMsQ0FBQ1UsS0FBSyxDQUFDTSxRQUFRLENBQUM7VUFDekJaLEdBQUcsQ0FBQ0csR0FBRyxDQUFDLEdBQUdtQyxXQUFXO1FBQ3hCO01BQ0YsQ0FBQyxDQUFDO01BQ0YsT0FBT3RDLEdBQUc7SUFDWixDQUFDO0lBR0R1QyxlQUFlLEdBQUcsU0FBQUEsQ0FBVUMsR0FBRyxFQUFFQyxPQUFPLEVBQUU7TUFBQSxJQUFBQyxnQkFBQSxFQUFBQyxxQkFBQSxFQUFBQyxzQkFBQTtNQUN4QyxJQUFJQyxJQUFJLEdBQUcsSUFBSTtNQUNmSixPQUFPLEdBQUdBLE9BQU8sSUFBSSxDQUFDLENBQUM7TUFDdkJJLElBQUksQ0FBQ0Msb0JBQW9CLEdBQUcsQ0FBQyxDQUFDO01BQzlCRCxJQUFJLENBQUNFLGVBQWUsR0FBRyxJQUFJQyxJQUFJLENBQUQsQ0FBQztNQUUvQixNQUFNQyxXQUFXLEdBQUFwRixhQUFBLENBQUFBLGFBQUEsS0FDWHFELEtBQUssQ0FBQ2dDLGtCQUFrQixJQUFJLENBQUMsQ0FBQyxHQUM5QixFQUFBUixnQkFBQSxHQUFBbkUsTUFBTSxDQUFDNEUsUUFBUSxjQUFBVCxnQkFBQSx3QkFBQUMscUJBQUEsR0FBZkQsZ0JBQUEsQ0FBaUJVLFFBQVEsY0FBQVQscUJBQUEsd0JBQUFDLHNCQUFBLEdBQXpCRCxxQkFBQSxDQUEyQlUsS0FBSyxjQUFBVCxzQkFBQSx1QkFBaENBLHNCQUFBLENBQWtDSCxPQUFPLEtBQUksQ0FBQyxDQUFDLENBQ3BEO01BRUQsSUFBSWEsWUFBWSxHQUFHQyxNQUFNLENBQUNDLE1BQU0sQ0FBQztRQUMvQkMsZUFBZSxFQUFFO01BQ25CLENBQUMsRUFBRVIsV0FBVyxDQUFDOztNQUlmO01BQ0E7TUFDQSxJQUFJckQsQ0FBQyxDQUFDOEQsR0FBRyxDQUFDakIsT0FBTyxFQUFFLGFBQWEsQ0FBQyxFQUFFO1FBQ2pDO1FBQ0E7UUFDQWEsWUFBWSxDQUFDSyxXQUFXLEdBQUdsQixPQUFPLENBQUNrQixXQUFXO01BQ2hEO01BQ0EsSUFBSS9ELENBQUMsQ0FBQzhELEdBQUcsQ0FBQ2pCLE9BQU8sRUFBRSxhQUFhLENBQUMsRUFBRTtRQUNqQ2EsWUFBWSxDQUFDTSxXQUFXLEdBQUduQixPQUFPLENBQUNtQixXQUFXO01BQ2hEOztNQUVBO01BQ0E7TUFDQUwsTUFBTSxDQUFDTSxPQUFPLENBQUNQLFlBQVksSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUMvQjVELE1BQU0sQ0FBQ29FLElBQUE7UUFBQSxJQUFDLENBQUMzRCxHQUFHLENBQUMsR0FBQTJELElBQUE7UUFBQSxPQUFLM0QsR0FBRyxJQUFJQSxHQUFHLENBQUM0RCxRQUFRLENBQUN6RSxpQkFBaUIsQ0FBQztNQUFBLEVBQUMsQ0FDekQwRSxPQUFPLENBQUNDLEtBQUEsSUFBa0I7UUFBQSxJQUFqQixDQUFDOUQsR0FBRyxFQUFFRCxLQUFLLENBQUMsR0FBQStELEtBQUE7UUFDcEIsTUFBTUMsVUFBVSxHQUFHL0QsR0FBRyxDQUFDZ0UsT0FBTyxDQUFDN0UsaUJBQWlCLEVBQUUsRUFBRSxDQUFDO1FBQ3JEZ0UsWUFBWSxDQUFDWSxVQUFVLENBQUMsR0FBR3pGLElBQUksQ0FBQzJGLElBQUksQ0FBQ0MsTUFBTSxDQUFDQyxZQUFZLENBQUMsQ0FBQyxFQUN4RC9FLGFBQWEsRUFBRUMsVUFBVSxFQUFFVSxLQUFLLENBQUM7UUFDbkMsT0FBT29ELFlBQVksQ0FBQ25ELEdBQUcsQ0FBQztNQUMxQixDQUFDLENBQUM7TUFFSjBDLElBQUksQ0FBQzBCLEVBQUUsR0FBRyxJQUFJO01BQ2QxQixJQUFJLENBQUMyQixZQUFZLEdBQUcsSUFBSTtNQUN4QjNCLElBQUksQ0FBQzRCLFdBQVcsR0FBRyxJQUFJO01BRXZCNUIsSUFBSSxDQUFDNkIsTUFBTSxHQUFHLElBQUk5RixPQUFPLENBQUMrRixXQUFXLENBQUNuQyxHQUFHLEVBQUVjLFlBQVksQ0FBQztNQUN4RFQsSUFBSSxDQUFDMEIsRUFBRSxHQUFHMUIsSUFBSSxDQUFDNkIsTUFBTSxDQUFDSCxFQUFFLENBQUMsQ0FBQztNQUUxQjFCLElBQUksQ0FBQzZCLE1BQU0sQ0FBQ0UsRUFBRSxDQUFDLDBCQUEwQixFQUFFckcsTUFBTSxDQUFDc0csZUFBZSxDQUFDQyxLQUFLLElBQUk7UUFDekU7UUFDQTtRQUNBO1FBQ0EsSUFDRUEsS0FBSyxDQUFDQyxtQkFBbUIsQ0FBQ0MsSUFBSSxLQUFLLFdBQVcsSUFDOUNGLEtBQUssQ0FBQ0csY0FBYyxDQUFDRCxJQUFJLEtBQUssV0FBVyxFQUN6QztVQUNBbkMsSUFBSSxDQUFDRSxlQUFlLENBQUM5QyxJQUFJLENBQUNpRixRQUFRLElBQUk7WUFDcENBLFFBQVEsQ0FBQyxDQUFDO1lBQ1YsT0FBTyxJQUFJO1VBQ2IsQ0FBQyxDQUFDO1FBQ0o7TUFDRixDQUFDLENBQUMsQ0FBQztNQUVILElBQUl6QyxPQUFPLENBQUMwQyxRQUFRLElBQUksQ0FBRUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxFQUFFO1FBQ2xEdkMsSUFBSSxDQUFDMkIsWUFBWSxHQUFHLElBQUlhLFdBQVcsQ0FBQzVDLE9BQU8sQ0FBQzBDLFFBQVEsRUFBRXRDLElBQUksQ0FBQzBCLEVBQUUsQ0FBQ2UsWUFBWSxDQUFDO1FBQzNFekMsSUFBSSxDQUFDNEIsV0FBVyxHQUFHLElBQUl0RyxVQUFVLENBQUMwRSxJQUFJLENBQUM7TUFDekM7SUFFRixDQUFDO0lBRUROLGVBQWUsQ0FBQ2xDLFNBQVMsQ0FBQ2tGLE1BQU0sR0FBRyxrQkFBaUI7TUFDbEQsSUFBSTFDLElBQUksR0FBRyxJQUFJO01BRWYsSUFBSSxDQUFFQSxJQUFJLENBQUMwQixFQUFFLEVBQ1gsTUFBTWlCLEtBQUssQ0FBQyx5Q0FBeUMsQ0FBQzs7TUFFeEQ7TUFDQSxJQUFJQyxXQUFXLEdBQUc1QyxJQUFJLENBQUMyQixZQUFZO01BQ25DM0IsSUFBSSxDQUFDMkIsWUFBWSxHQUFHLElBQUk7TUFDeEIsSUFBSWlCLFdBQVcsRUFDYixNQUFNQSxXQUFXLENBQUNDLElBQUksQ0FBQyxDQUFDOztNQUUxQjtNQUNBO01BQ0E7TUFDQSxNQUFNN0MsSUFBSSxDQUFDNkIsTUFBTSxDQUFDaUIsS0FBSyxDQUFDLENBQUM7SUFDM0IsQ0FBQztJQUVEcEQsZUFBZSxDQUFDbEMsU0FBUyxDQUFDc0YsS0FBSyxHQUFHLFlBQVk7TUFDNUMsT0FBTyxJQUFJLENBQUNKLE1BQU0sQ0FBQyxDQUFDO0lBQ3RCLENBQUM7SUFFRGhELGVBQWUsQ0FBQ2xDLFNBQVMsQ0FBQ3VGLGVBQWUsR0FBRyxVQUFTSCxXQUFXLEVBQUU7TUFDaEUsSUFBSSxDQUFDakIsWUFBWSxHQUFHaUIsV0FBVztNQUMvQixPQUFPLElBQUk7SUFDYixDQUFDOztJQUVEO0lBQ0FsRCxlQUFlLENBQUNsQyxTQUFTLENBQUN3RixhQUFhLEdBQUcsVUFBVUMsY0FBYyxFQUFFO01BQ2xFLElBQUlqRCxJQUFJLEdBQUcsSUFBSTtNQUVmLElBQUksQ0FBRUEsSUFBSSxDQUFDMEIsRUFBRSxFQUNYLE1BQU1pQixLQUFLLENBQUMsaURBQWlELENBQUM7TUFFaEUsT0FBTzNDLElBQUksQ0FBQzBCLEVBQUUsQ0FBQ3dCLFVBQVUsQ0FBQ0QsY0FBYyxDQUFDO0lBQzNDLENBQUM7SUFFRHZELGVBQWUsQ0FBQ2xDLFNBQVMsQ0FBQzJGLDJCQUEyQixHQUFHLGdCQUNwREYsY0FBYyxFQUFFRyxRQUFRLEVBQUVDLFlBQVksRUFBRTtNQUMxQyxJQUFJckQsSUFBSSxHQUFHLElBQUk7TUFFZixJQUFJLENBQUVBLElBQUksQ0FBQzBCLEVBQUUsRUFDWCxNQUFNaUIsS0FBSyxDQUFDLCtEQUErRCxDQUFDO01BRzlFLE1BQU0zQyxJQUFJLENBQUMwQixFQUFFLENBQUM0QixnQkFBZ0IsQ0FBQ0wsY0FBYyxFQUMzQztRQUFFTSxNQUFNLEVBQUUsSUFBSTtRQUFFN0UsSUFBSSxFQUFFMEUsUUFBUTtRQUFFSSxHQUFHLEVBQUVIO01BQWEsQ0FBQyxDQUFDO0lBQ3hELENBQUM7O0lBRUQ7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBM0QsZUFBZSxDQUFDbEMsU0FBUyxDQUFDaUcsZ0JBQWdCLEdBQUcsWUFBWTtNQUN2RCxNQUFNQyxLQUFLLEdBQUdDLFNBQVMsQ0FBQ0MsZ0JBQWdCLENBQUMsQ0FBQztNQUMxQyxJQUFJRixLQUFLLEVBQUU7UUFDVCxPQUFPQSxLQUFLLENBQUNHLFVBQVUsQ0FBQyxDQUFDO01BQzNCLENBQUMsTUFBTTtRQUNMLE9BQU87VUFBQ0MsU0FBUyxFQUFFLFNBQUFBLENBQUEsRUFBWSxDQUFDO1FBQUMsQ0FBQztNQUNwQztJQUNGLENBQUM7O0lBRUQ7SUFDQTtJQUNBcEUsZUFBZSxDQUFDbEMsU0FBUyxDQUFDdUcsV0FBVyxHQUFHLFVBQVUxQixRQUFRLEVBQUU7TUFDMUQsT0FBTyxJQUFJLENBQUNuQyxlQUFlLENBQUM4RCxRQUFRLENBQUMzQixRQUFRLENBQUM7SUFDaEQsQ0FBQzs7SUFHRDs7SUFFQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7O0lBRUEsSUFBSTRCLGFBQWEsR0FBRyxTQUFBQSxDQUFVQyxLQUFLLEVBQUVDLE9BQU8sRUFBRTlCLFFBQVEsRUFBRTtNQUN0RCxPQUFPLFVBQVUrQixHQUFHLEVBQUVDLE1BQU0sRUFBRTtRQUM1QixJQUFJLENBQUVELEdBQUcsRUFBRTtVQUNUO1VBQ0EsSUFBSTtZQUNGRCxPQUFPLENBQUMsQ0FBQztVQUNYLENBQUMsQ0FBQyxPQUFPRyxVQUFVLEVBQUU7WUFDbkIsSUFBSWpDLFFBQVEsRUFBRTtjQUNaQSxRQUFRLENBQUNpQyxVQUFVLENBQUM7Y0FDcEI7WUFDRixDQUFDLE1BQU07Y0FDTCxNQUFNQSxVQUFVO1lBQ2xCO1VBQ0Y7UUFDRjtRQUNBSixLQUFLLENBQUNKLFNBQVMsQ0FBQyxDQUFDO1FBQ2pCLElBQUl6QixRQUFRLEVBQUU7VUFDWkEsUUFBUSxDQUFDK0IsR0FBRyxFQUFFQyxNQUFNLENBQUM7UUFDdkIsQ0FBQyxNQUFNLElBQUlELEdBQUcsRUFBRTtVQUNkLE1BQU1BLEdBQUc7UUFDWDtNQUNGLENBQUM7SUFDSCxDQUFDO0lBRUQsSUFBSUcsdUJBQXVCLEdBQUcsU0FBQUEsQ0FBVWxDLFFBQVEsRUFBRTtNQUNoRCxPQUFPM0csTUFBTSxDQUFDc0csZUFBZSxDQUFDSyxRQUFRLEVBQUUsYUFBYSxDQUFDO0lBQ3hELENBQUM7SUFFRDNDLGVBQWUsQ0FBQ2xDLFNBQVMsQ0FBQ2dILFdBQVcsR0FBRyxnQkFBZ0JDLGVBQWUsRUFBRTFHLFFBQVEsRUFBRTtNQUNqRixNQUFNaUMsSUFBSSxHQUFHLElBQUk7TUFFakIsSUFBSXlFLGVBQWUsS0FBSyxtQ0FBbUMsRUFBRTtRQUMzRCxNQUFNQyxDQUFDLEdBQUcsSUFBSS9CLEtBQUssQ0FBQyxjQUFjLENBQUM7UUFDbkMrQixDQUFDLENBQUNDLGVBQWUsR0FBRyxJQUFJO1FBQ3hCLE1BQU1ELENBQUM7TUFDVDtNQUVBLElBQUksRUFBRUUsZUFBZSxDQUFDQyxjQUFjLENBQUM5RyxRQUFRLENBQUMsSUFDeEMsQ0FBQ1ksS0FBSyxDQUFDUSxhQUFhLENBQUNwQixRQUFRLENBQUMsQ0FBQyxFQUFFO1FBQ3JDLE1BQU0sSUFBSTRFLEtBQUssQ0FBQyxpREFBaUQsQ0FBQztNQUNwRTtNQUVBLElBQUl1QixLQUFLLEdBQUdsRSxJQUFJLENBQUN5RCxnQkFBZ0IsQ0FBQyxDQUFDO01BQ25DLElBQUlVLE9BQU8sR0FBRyxlQUFBQSxDQUFBLEVBQWtCO1FBQzlCLE1BQU16SSxNQUFNLENBQUN5SSxPQUFPLENBQUM7VUFBQ2pCLFVBQVUsRUFBRXVCLGVBQWU7VUFBRUssRUFBRSxFQUFFL0csUUFBUSxDQUFDZ0g7UUFBSSxDQUFDLENBQUM7TUFDeEUsQ0FBQztNQUNELE9BQU8vRSxJQUFJLENBQUNnRCxhQUFhLENBQUN5QixlQUFlLENBQUMsQ0FBQ08sU0FBUyxDQUNsRDNGLFlBQVksQ0FBQ3RCLFFBQVEsRUFBRWUsMEJBQTBCLENBQUMsRUFDbEQ7UUFDRW1HLElBQUksRUFBRTtNQUNSLENBQ0YsQ0FBQyxDQUFDQyxJQUFJLENBQUMsTUFBQUMsS0FBQSxJQUF3QjtRQUFBLElBQWpCO1VBQUNDO1FBQVUsQ0FBQyxHQUFBRCxLQUFBO1FBQ3hCLE1BQU1oQixPQUFPLENBQUMsQ0FBQztRQUNmLE1BQU1ELEtBQUssQ0FBQ0osU0FBUyxDQUFDLENBQUM7UUFDdkIsT0FBT3NCLFVBQVU7TUFDbkIsQ0FBQyxDQUFDLENBQUNDLEtBQUssQ0FBQyxNQUFNWCxDQUFDLElBQUk7UUFDbEIsTUFBTVIsS0FBSyxDQUFDSixTQUFTLENBQUMsQ0FBQztRQUN2QixNQUFNWSxDQUFDO01BQ1QsQ0FBQyxDQUFDO0lBQ0osQ0FBQzs7SUFHRDtJQUNBO0lBQ0FoRixlQUFlLENBQUNsQyxTQUFTLENBQUM4SCxRQUFRLEdBQUcsZ0JBQWdCckMsY0FBYyxFQUFFc0MsUUFBUSxFQUFFO01BQzdFLElBQUlDLFVBQVUsR0FBRztRQUFDdEMsVUFBVSxFQUFFRDtNQUFjLENBQUM7TUFDN0M7TUFDQTtNQUNBO01BQ0E7TUFDQSxJQUFJd0MsV0FBVyxHQUFHYixlQUFlLENBQUNjLHFCQUFxQixDQUFDSCxRQUFRLENBQUM7TUFDakUsSUFBSUUsV0FBVyxFQUFFO1FBQ2YsS0FBSyxNQUFNWCxFQUFFLElBQUlXLFdBQVcsRUFBRTtVQUM1QixNQUFNL0osTUFBTSxDQUFDeUksT0FBTyxDQUFDcEgsQ0FBQyxDQUFDNEksTUFBTSxDQUFDO1lBQUNiLEVBQUUsRUFBRUE7VUFBRSxDQUFDLEVBQUVVLFVBQVUsQ0FBQyxDQUFDO1FBQ3REO01BQ0YsQ0FBQyxNQUFNO1FBQ0wsTUFBTTlKLE1BQU0sQ0FBQ3lJLE9BQU8sQ0FBQ3FCLFVBQVUsQ0FBQztNQUNsQztJQUNGLENBQUM7SUFFRDlGLGVBQWUsQ0FBQ2xDLFNBQVMsQ0FBQ29JLFdBQVcsR0FBRyxnQkFBZ0JuQixlQUFlLEVBQUVjLFFBQVEsRUFBRTtNQUNqRixJQUFJdkYsSUFBSSxHQUFHLElBQUk7TUFFZixJQUFJeUUsZUFBZSxLQUFLLG1DQUFtQyxFQUFFO1FBQzNELElBQUlDLENBQUMsR0FBRyxJQUFJL0IsS0FBSyxDQUFDLGNBQWMsQ0FBQztRQUNqQytCLENBQUMsQ0FBQ0MsZUFBZSxHQUFHLElBQUk7UUFDeEIsTUFBTUQsQ0FBQztNQUNUO01BRUEsSUFBSVIsS0FBSyxHQUFHbEUsSUFBSSxDQUFDeUQsZ0JBQWdCLENBQUMsQ0FBQztNQUNuQyxJQUFJVSxPQUFPLEdBQUcsZUFBQUEsQ0FBQSxFQUFrQjtRQUM5QixNQUFNbkUsSUFBSSxDQUFDc0YsUUFBUSxDQUFDYixlQUFlLEVBQUVjLFFBQVEsQ0FBQztNQUNoRCxDQUFDO01BRUQsT0FBT3ZGLElBQUksQ0FBQ2dELGFBQWEsQ0FBQ3lCLGVBQWUsQ0FBQyxDQUN2Q29CLFVBQVUsQ0FBQ3hHLFlBQVksQ0FBQ2tHLFFBQVEsRUFBRXpHLDBCQUEwQixDQUFDLEVBQUU7UUFDOURtRyxJQUFJLEVBQUU7TUFDUixDQUFDLENBQUMsQ0FDREMsSUFBSSxDQUFDLE1BQUFZLEtBQUEsSUFBNEI7UUFBQSxJQUFyQjtVQUFFQztRQUFhLENBQUMsR0FBQUQsS0FBQTtRQUMzQixNQUFNM0IsT0FBTyxDQUFDLENBQUM7UUFDZixNQUFNRCxLQUFLLENBQUNKLFNBQVMsQ0FBQyxDQUFDO1FBQ3ZCLE9BQU9rQyxlQUFlLENBQUM7VUFBRTNCLE1BQU0sRUFBRztZQUFDNEIsYUFBYSxFQUFHRjtVQUFZO1FBQUUsQ0FBQyxDQUFDLENBQUNHLGNBQWM7TUFDcEYsQ0FBQyxDQUFDLENBQUNiLEtBQUssQ0FBQyxNQUFPakIsR0FBRyxJQUFLO1FBQ3BCLE1BQU1GLEtBQUssQ0FBQ0osU0FBUyxDQUFDLENBQUM7UUFDdkIsTUFBTU0sR0FBRztNQUNiLENBQUMsQ0FBQztJQUNOLENBQUM7SUFFRDFFLGVBQWUsQ0FBQ2xDLFNBQVMsQ0FBQzJJLG1CQUFtQixHQUFHLGdCQUFlbEQsY0FBYyxFQUFFO01BQzdFLElBQUlqRCxJQUFJLEdBQUcsSUFBSTtNQUdmLElBQUlrRSxLQUFLLEdBQUdsRSxJQUFJLENBQUN5RCxnQkFBZ0IsQ0FBQyxDQUFDO01BQ25DLElBQUlVLE9BQU8sR0FBRyxTQUFBQSxDQUFBLEVBQVc7UUFDdkIsT0FBT3pJLE1BQU0sQ0FBQ3lJLE9BQU8sQ0FBQztVQUNwQmpCLFVBQVUsRUFBRUQsY0FBYztVQUMxQjZCLEVBQUUsRUFBRSxJQUFJO1VBQ1JzQixjQUFjLEVBQUU7UUFDbEIsQ0FBQyxDQUFDO01BQ0osQ0FBQztNQUVELE9BQU9wRyxJQUFJLENBQ1JnRCxhQUFhLENBQUNDLGNBQWMsQ0FBQyxDQUM3Qm9ELElBQUksQ0FBQyxDQUFDLENBQ05uQixJQUFJLENBQUMsTUFBTWIsTUFBTSxJQUFJO1FBQ3BCLE1BQU1GLE9BQU8sQ0FBQyxDQUFDO1FBQ2YsTUFBTUQsS0FBSyxDQUFDSixTQUFTLENBQUMsQ0FBQztRQUN2QixPQUFPTyxNQUFNO01BQ2YsQ0FBQyxDQUFDLENBQ0RnQixLQUFLLENBQUMsTUFBTVgsQ0FBQyxJQUFJO1FBQ2hCLE1BQU1SLEtBQUssQ0FBQ0osU0FBUyxDQUFDLENBQUM7UUFDdkIsTUFBTVksQ0FBQztNQUNULENBQUMsQ0FBQztJQUNOLENBQUM7O0lBRUQ7SUFDQTtJQUNBaEYsZUFBZSxDQUFDbEMsU0FBUyxDQUFDOEksaUJBQWlCLEdBQUcsa0JBQWtCO01BQzlELElBQUl0RyxJQUFJLEdBQUcsSUFBSTtNQUVmLElBQUlrRSxLQUFLLEdBQUdsRSxJQUFJLENBQUN5RCxnQkFBZ0IsQ0FBQyxDQUFDO01BQ25DLElBQUlVLE9BQU8sR0FBRyxlQUFBQSxDQUFBLEVBQWtCO1FBQzlCLE1BQU16SSxNQUFNLENBQUN5SSxPQUFPLENBQUM7VUFBRW9DLFlBQVksRUFBRTtRQUFLLENBQUMsQ0FBQztNQUM5QyxDQUFDO01BRUQsSUFBSTtRQUNGLE1BQU12RyxJQUFJLENBQUMwQixFQUFFLENBQUM4RSxhQUFhLENBQUMsQ0FBQztRQUM3QixNQUFNckMsT0FBTyxDQUFDLENBQUM7UUFDZixNQUFNRCxLQUFLLENBQUNKLFNBQVMsQ0FBQyxDQUFDO01BQ3pCLENBQUMsQ0FBQyxPQUFPWSxDQUFDLEVBQUU7UUFDVixNQUFNUixLQUFLLENBQUNKLFNBQVMsQ0FBQyxDQUFDO1FBQ3ZCLE1BQU1ZLENBQUM7TUFDVDtJQUNGLENBQUM7SUFFRGhGLGVBQWUsQ0FBQ2xDLFNBQVMsQ0FBQ2lKLFdBQVcsR0FBRyxnQkFBZ0JoQyxlQUFlLEVBQUVjLFFBQVEsRUFBRW1CLEdBQUcsRUFBRTlHLE9BQU8sRUFBRTtNQUMvRixJQUFJSSxJQUFJLEdBQUcsSUFBSTtNQUVmLElBQUl5RSxlQUFlLEtBQUssbUNBQW1DLEVBQUU7UUFDM0QsSUFBSUMsQ0FBQyxHQUFHLElBQUkvQixLQUFLLENBQUMsY0FBYyxDQUFDO1FBQ2pDK0IsQ0FBQyxDQUFDQyxlQUFlLEdBQUcsSUFBSTtRQUN4QixNQUFNRCxDQUFDO01BQ1Q7O01BRUE7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBLElBQUksQ0FBQ2dDLEdBQUcsSUFBSSxPQUFPQSxHQUFHLEtBQUssUUFBUSxFQUFFO1FBQ25DLE1BQU1DLEtBQUssR0FBRyxJQUFJaEUsS0FBSyxDQUFDLCtDQUErQyxDQUFDO1FBRXhFLE1BQU1nRSxLQUFLO01BQ2I7TUFFQSxJQUFJLEVBQUUvQixlQUFlLENBQUNDLGNBQWMsQ0FBQzZCLEdBQUcsQ0FBQyxJQUFJLENBQUMvSCxLQUFLLENBQUNRLGFBQWEsQ0FBQ3VILEdBQUcsQ0FBQyxDQUFDLEVBQUU7UUFDdkUsTUFBTUMsS0FBSyxHQUFHLElBQUloRSxLQUFLLENBQ25CLCtDQUErQyxHQUMvQyx1QkFBdUIsQ0FBQztRQUU1QixNQUFNZ0UsS0FBSztNQUNiO01BRUEsSUFBSSxDQUFDL0csT0FBTyxFQUFFQSxPQUFPLEdBQUcsQ0FBQyxDQUFDO01BRTFCLElBQUlzRSxLQUFLLEdBQUdsRSxJQUFJLENBQUN5RCxnQkFBZ0IsQ0FBQyxDQUFDO01BQ25DLElBQUlVLE9BQU8sR0FBRyxlQUFBQSxDQUFBLEVBQWtCO1FBQzlCLE1BQU1uRSxJQUFJLENBQUNzRixRQUFRLENBQUNiLGVBQWUsRUFBRWMsUUFBUSxDQUFDO01BQ2hELENBQUM7TUFFRCxJQUFJckMsVUFBVSxHQUFHbEQsSUFBSSxDQUFDZ0QsYUFBYSxDQUFDeUIsZUFBZSxDQUFDO01BQ3BELElBQUltQyxTQUFTLEdBQUc7UUFBQzNCLElBQUksRUFBRTtNQUFJLENBQUM7TUFDNUI7TUFDQSxJQUFJckYsT0FBTyxDQUFDaUgsWUFBWSxLQUFLaEksU0FBUyxFQUFFK0gsU0FBUyxDQUFDQyxZQUFZLEdBQUdqSCxPQUFPLENBQUNpSCxZQUFZO01BQ3JGO01BQ0EsSUFBSWpILE9BQU8sQ0FBQ2tILE1BQU0sRUFBRUYsU0FBUyxDQUFDRSxNQUFNLEdBQUcsSUFBSTtNQUMzQyxJQUFJbEgsT0FBTyxDQUFDbUgsS0FBSyxFQUFFSCxTQUFTLENBQUNHLEtBQUssR0FBRyxJQUFJO01BQ3pDO01BQ0E7TUFDQTtNQUNBLElBQUluSCxPQUFPLENBQUNvSCxVQUFVLEVBQUVKLFNBQVMsQ0FBQ0ksVUFBVSxHQUFHLElBQUk7TUFFbkQsSUFBSUMsYUFBYSxHQUFHNUgsWUFBWSxDQUFDa0csUUFBUSxFQUFFekcsMEJBQTBCLENBQUM7TUFDdEUsSUFBSW9JLFFBQVEsR0FBRzdILFlBQVksQ0FBQ3FILEdBQUcsRUFBRTVILDBCQUEwQixDQUFDO01BRTVELElBQUlxSSxRQUFRLEdBQUd2QyxlQUFlLENBQUN3QyxrQkFBa0IsQ0FBQ0YsUUFBUSxDQUFDO01BRTNELElBQUl0SCxPQUFPLENBQUN5SCxjQUFjLElBQUksQ0FBQ0YsUUFBUSxFQUFFO1FBQ3ZDLElBQUkvQyxHQUFHLEdBQUcsSUFBSXpCLEtBQUssQ0FBQywrQ0FBK0MsQ0FBQztRQUNwRSxNQUFNeUIsR0FBRztNQUNYOztNQUVBO01BQ0E7TUFDQTtNQUNBOztNQUVBO01BQ0E7TUFDQSxJQUFJa0QsT0FBTztNQUNYLElBQUkxSCxPQUFPLENBQUNrSCxNQUFNLEVBQUU7UUFDbEIsSUFBSTtVQUNGLElBQUlTLE1BQU0sR0FBRzNDLGVBQWUsQ0FBQzRDLHFCQUFxQixDQUFDakMsUUFBUSxFQUFFbUIsR0FBRyxDQUFDO1VBQ2pFWSxPQUFPLEdBQUdDLE1BQU0sQ0FBQ3hDLEdBQUc7UUFDdEIsQ0FBQyxDQUFDLE9BQU9YLEdBQUcsRUFBRTtVQUNaLE1BQU1BLEdBQUc7UUFDWDtNQUNGO01BQ0EsSUFBSXhFLE9BQU8sQ0FBQ2tILE1BQU0sSUFDZCxDQUFFSyxRQUFRLElBQ1YsQ0FBRUcsT0FBTyxJQUNUMUgsT0FBTyxDQUFDd0YsVUFBVSxJQUNsQixFQUFHeEYsT0FBTyxDQUFDd0YsVUFBVSxZQUFZL0csS0FBSyxDQUFDRCxRQUFRLElBQzVDd0IsT0FBTyxDQUFDNkgsV0FBVyxDQUFDLEVBQUU7UUFDM0I7UUFDQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQSxPQUFPLE1BQU1DLDRCQUE0QixDQUFDeEUsVUFBVSxFQUFFK0QsYUFBYSxFQUFFQyxRQUFRLEVBQUV0SCxPQUFPLENBQUMsQ0FDbEZzRixJQUFJLENBQUMsTUFBTWIsTUFBTSxJQUFJO1VBQ3BCLE1BQU1GLE9BQU8sQ0FBQyxDQUFDO1VBQ2YsTUFBTUQsS0FBSyxDQUFDSixTQUFTLENBQUMsQ0FBQztVQUN2QixJQUFJTyxNQUFNLElBQUksQ0FBRXpFLE9BQU8sQ0FBQytILGFBQWEsRUFBRTtZQUNyQyxPQUFPdEQsTUFBTSxDQUFDNkIsY0FBYztVQUM5QixDQUFDLE1BQU07WUFDTCxPQUFPN0IsTUFBTTtVQUNmO1FBQ0YsQ0FBQyxDQUFDO01BQ1IsQ0FBQyxNQUFNO1FBQ0wsSUFBSXpFLE9BQU8sQ0FBQ2tILE1BQU0sSUFBSSxDQUFDUSxPQUFPLElBQUkxSCxPQUFPLENBQUN3RixVQUFVLElBQUkrQixRQUFRLEVBQUU7VUFDaEUsSUFBSSxDQUFDRCxRQUFRLENBQUNVLGNBQWMsQ0FBQyxjQUFjLENBQUMsRUFBRTtZQUM1Q1YsUUFBUSxDQUFDVyxZQUFZLEdBQUcsQ0FBQyxDQUFDO1VBQzVCO1VBQ0FQLE9BQU8sR0FBRzFILE9BQU8sQ0FBQ3dGLFVBQVU7VUFDNUIxRSxNQUFNLENBQUNDLE1BQU0sQ0FBQ3VHLFFBQVEsQ0FBQ1csWUFBWSxFQUFFeEksWUFBWSxDQUFDO1lBQUMwRixHQUFHLEVBQUVuRixPQUFPLENBQUN3RjtVQUFVLENBQUMsRUFBRXRHLDBCQUEwQixDQUFDLENBQUM7UUFDM0c7UUFFQSxNQUFNZ0osT0FBTyxHQUFHcEgsTUFBTSxDQUFDcUgsSUFBSSxDQUFDYixRQUFRLENBQUMsQ0FBQ3JLLE1BQU0sQ0FBRVMsR0FBRyxJQUFLLENBQUNBLEdBQUcsQ0FBQzBLLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUMzRSxJQUFJQyxZQUFZLEdBQUdILE9BQU8sQ0FBQ0ksTUFBTSxHQUFHLENBQUMsR0FBRyxZQUFZLEdBQUcsWUFBWTtRQUNuRUQsWUFBWSxHQUNSQSxZQUFZLEtBQUssWUFBWSxJQUFJLENBQUNyQixTQUFTLENBQUNHLEtBQUssR0FDM0MsV0FBVyxHQUNYa0IsWUFBWTtRQUN0QixPQUFPL0UsVUFBVSxDQUFDK0UsWUFBWSxDQUFDLENBQzFCL0ssSUFBSSxDQUFDZ0csVUFBVSxDQUFDLENBQUMrRCxhQUFhLEVBQUVDLFFBQVEsRUFBRU4sU0FBUyxDQUFDLENBQ3BEMUIsSUFBSSxDQUFDLE1BQU1iLE1BQU0sSUFBSTtVQUNwQixJQUFJOEQsWUFBWSxHQUFHbkMsZUFBZSxDQUFDO1lBQUMzQjtVQUFNLENBQUMsQ0FBQztVQUM1QyxJQUFJOEQsWUFBWSxJQUFJdkksT0FBTyxDQUFDK0gsYUFBYSxFQUFFO1lBQ3pDO1lBQ0E7WUFDQTtZQUNBLElBQUkvSCxPQUFPLENBQUNrSCxNQUFNLElBQUlxQixZQUFZLENBQUMvQyxVQUFVLEVBQUU7Y0FDN0MsSUFBSWtDLE9BQU8sRUFBRTtnQkFDWGEsWUFBWSxDQUFDL0MsVUFBVSxHQUFHa0MsT0FBTztjQUNuQyxDQUFDLE1BQU0sSUFBSWEsWUFBWSxDQUFDL0MsVUFBVSxZQUFZckosT0FBTyxDQUFDcUMsUUFBUSxFQUFFO2dCQUM5RCtKLFlBQVksQ0FBQy9DLFVBQVUsR0FBRyxJQUFJL0csS0FBSyxDQUFDRCxRQUFRLENBQUMrSixZQUFZLENBQUMvQyxVQUFVLENBQUM5RyxXQUFXLENBQUMsQ0FBQyxDQUFDO2NBQ3JGO1lBQ0Y7WUFDQSxNQUFNNkYsT0FBTyxDQUFDLENBQUM7WUFDZixNQUFNRCxLQUFLLENBQUNKLFNBQVMsQ0FBQyxDQUFDO1lBQ3ZCLE9BQU9xRSxZQUFZO1VBQ3JCLENBQUMsTUFBTTtZQUNMLE1BQU1oRSxPQUFPLENBQUMsQ0FBQztZQUNmLE1BQU1ELEtBQUssQ0FBQ0osU0FBUyxDQUFDLENBQUM7WUFDdkIsT0FBT3FFLFlBQVksQ0FBQ2pDLGNBQWM7VUFDcEM7UUFDRixDQUFDLENBQUMsQ0FBQ2IsS0FBSyxDQUFDLE1BQU9qQixHQUFHLElBQUs7VUFDdEIsTUFBTUYsS0FBSyxDQUFDSixTQUFTLENBQUMsQ0FBQztVQUN2QixNQUFNTSxHQUFHO1FBQ1gsQ0FBQyxDQUFDO01BQ1I7SUFDRixDQUFDO0lBRUQsSUFBSTRCLGVBQWUsR0FBRyxTQUFBQSxDQUFVb0MsWUFBWSxFQUFFO01BQzVDLElBQUlELFlBQVksR0FBRztRQUFFakMsY0FBYyxFQUFFO01BQUUsQ0FBQztNQUN4QyxJQUFJa0MsWUFBWSxFQUFFO1FBQ2hCLElBQUlDLFdBQVcsR0FBR0QsWUFBWSxDQUFDL0QsTUFBTTtRQUNyQztRQUNBO1FBQ0E7UUFDQSxJQUFJZ0UsV0FBVyxDQUFDQyxhQUFhLEVBQUU7VUFDN0JILFlBQVksQ0FBQ2pDLGNBQWMsR0FBR21DLFdBQVcsQ0FBQ0MsYUFBYTtVQUV2RCxJQUFJRCxXQUFXLENBQUNFLFVBQVUsRUFBRTtZQUMxQkosWUFBWSxDQUFDL0MsVUFBVSxHQUFHaUQsV0FBVyxDQUFDRSxVQUFVO1VBQ2xEO1FBQ0YsQ0FBQyxNQUFNO1VBQ0w7VUFDQTtVQUNBSixZQUFZLENBQUNqQyxjQUFjLEdBQUdtQyxXQUFXLENBQUNHLENBQUMsSUFBSUgsV0FBVyxDQUFDSSxZQUFZLElBQUlKLFdBQVcsQ0FBQ3BDLGFBQWE7UUFDdEc7TUFDRjtNQUVBLE9BQU9rQyxZQUFZO0lBQ3JCLENBQUM7SUFHRCxJQUFJTyxvQkFBb0IsR0FBRyxDQUFDOztJQUU1QjtJQUNBaEosZUFBZSxDQUFDaUosc0JBQXNCLEdBQUcsVUFBVXZFLEdBQUcsRUFBRTtNQUV0RDtNQUNBO01BQ0E7TUFDQTtNQUNBLElBQUl1QyxLQUFLLEdBQUd2QyxHQUFHLENBQUN3RSxNQUFNLElBQUl4RSxHQUFHLENBQUNBLEdBQUc7O01BRWpDO01BQ0E7TUFDQTtNQUNBLElBQUl1QyxLQUFLLENBQUNrQyxPQUFPLENBQUMsaUNBQWlDLENBQUMsS0FBSyxDQUFDLElBQ3JEbEMsS0FBSyxDQUFDa0MsT0FBTyxDQUFDLG1FQUFtRSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUU7UUFDOUYsT0FBTyxJQUFJO01BQ2I7TUFFQSxPQUFPLEtBQUs7SUFDZCxDQUFDO0lBRUQsSUFBSW5CLDRCQUE0QixHQUFHLGVBQUFBLENBQWdCeEUsVUFBVSxFQUFFcUMsUUFBUSxFQUFFbUIsR0FBRyxFQUFFOUcsT0FBTyxFQUFFO01BQ3JGO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTs7TUFFQSxJQUFJd0YsVUFBVSxHQUFHeEYsT0FBTyxDQUFDd0YsVUFBVSxDQUFDLENBQUM7TUFDckMsSUFBSTBELGtCQUFrQixHQUFHO1FBQ3ZCN0QsSUFBSSxFQUFFLElBQUk7UUFDVjhCLEtBQUssRUFBRW5ILE9BQU8sQ0FBQ21IO01BQ2pCLENBQUM7TUFDRCxJQUFJZ0Msa0JBQWtCLEdBQUc7UUFDdkI5RCxJQUFJLEVBQUUsSUFBSTtRQUNWNkIsTUFBTSxFQUFFO01BQ1YsQ0FBQztNQUVELElBQUlrQyxpQkFBaUIsR0FBR3RJLE1BQU0sQ0FBQ0MsTUFBTSxDQUNuQ3RCLFlBQVksQ0FBQztRQUFDMEYsR0FBRyxFQUFFSztNQUFVLENBQUMsRUFBRXRHLDBCQUEwQixDQUFDLEVBQzNENEgsR0FBRyxDQUFDO01BRU4sSUFBSXVDLEtBQUssR0FBR1Asb0JBQW9CO01BRWhDLElBQUlRLFFBQVEsR0FBRyxlQUFBQSxDQUFBLEVBQWtCO1FBQy9CRCxLQUFLLEVBQUU7UUFDUCxJQUFJLENBQUVBLEtBQUssRUFBRTtVQUNYLE1BQU0sSUFBSXRHLEtBQUssQ0FBQyxzQkFBc0IsR0FBRytGLG9CQUFvQixHQUFHLFNBQVMsQ0FBQztRQUM1RSxDQUFDLE1BQU07VUFDTCxJQUFJUyxNQUFNLEdBQUdqRyxVQUFVLENBQUNrRyxVQUFVO1VBQ2xDLElBQUcsQ0FBQzFJLE1BQU0sQ0FBQ3FILElBQUksQ0FBQ3JCLEdBQUcsQ0FBQyxDQUFDMkMsSUFBSSxDQUFDL0wsR0FBRyxJQUFJQSxHQUFHLENBQUMwSyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBQztZQUNwRG1CLE1BQU0sR0FBR2pHLFVBQVUsQ0FBQ29HLFVBQVUsQ0FBQ3BNLElBQUksQ0FBQ2dHLFVBQVUsQ0FBQztVQUNqRDtVQUNBLE9BQU9pRyxNQUFNLENBQ1g1RCxRQUFRLEVBQ1JtQixHQUFHLEVBQ0hvQyxrQkFBa0IsQ0FBQyxDQUFDNUQsSUFBSSxDQUFDYixNQUFNLElBQUk7WUFDbkMsSUFBSUEsTUFBTSxLQUFLQSxNQUFNLENBQUM0QixhQUFhLElBQUk1QixNQUFNLENBQUNpRSxhQUFhLENBQUMsRUFBRTtjQUM1RCxPQUFPO2dCQUNMcEMsY0FBYyxFQUFFN0IsTUFBTSxDQUFDNEIsYUFBYSxJQUFJNUIsTUFBTSxDQUFDaUUsYUFBYTtnQkFDNURsRCxVQUFVLEVBQUVmLE1BQU0sQ0FBQ2tFLFVBQVUsSUFBSTFKO2NBQ25DLENBQUM7WUFDSCxDQUFDLE1BQU07Y0FDTCxPQUFPMEssbUJBQW1CLENBQUMsQ0FBQztZQUM5QjtVQUNGLENBQUMsQ0FBQztRQUNKO01BQ0YsQ0FBQztNQUVELElBQUlBLG1CQUFtQixHQUFHLFNBQUFBLENBQUEsRUFBVztRQUNuQyxPQUFPckcsVUFBVSxDQUFDb0csVUFBVSxDQUFDL0QsUUFBUSxFQUFFeUQsaUJBQWlCLEVBQUVELGtCQUFrQixDQUFDLENBQ3hFN0QsSUFBSSxDQUFDYixNQUFNLEtBQUs7VUFDYjZCLGNBQWMsRUFBRTdCLE1BQU0sQ0FBQ2lFLGFBQWE7VUFDcENsRCxVQUFVLEVBQUVmLE1BQU0sQ0FBQ2tFO1FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUNsRCxLQUFLLENBQUNqQixHQUFHLElBQUk7VUFDbkIsSUFBSTFFLGVBQWUsQ0FBQ2lKLHNCQUFzQixDQUFDdkUsR0FBRyxDQUFDLEVBQUU7WUFDL0MsT0FBTzhFLFFBQVEsQ0FBQyxDQUFDO1VBQ25CLENBQUMsTUFBTTtZQUNMLE1BQU05RSxHQUFHO1VBQ1g7UUFDRixDQUFDLENBQUM7TUFFTixDQUFDO01BQ0QsT0FBTzhFLFFBQVEsQ0FBQyxDQUFDO0lBQ25CLENBQUM7O0lBR0Q7SUFDQTtJQUNBO0lBQ0F4SixlQUFlLENBQUNsQyxTQUFTLENBQUNnTSxXQUFXLEdBQUcsZ0JBQWdCdkcsY0FBYyxFQUFFc0MsUUFBUSxFQUFFbUIsR0FBRyxFQUFFOUcsT0FBTyxFQUFFO01BQzlGLElBQUlJLElBQUksR0FBRyxJQUFJO01BSWYsSUFBSSxPQUFPSixPQUFPLEtBQUssVUFBVSxJQUFJLENBQUV5QyxRQUFRLEVBQUU7UUFDL0NBLFFBQVEsR0FBR3pDLE9BQU87UUFDbEJBLE9BQU8sR0FBRyxDQUFDLENBQUM7TUFDZDtNQUVBLE9BQU9JLElBQUksQ0FBQ3lHLFdBQVcsQ0FBQ3hELGNBQWMsRUFBRXNDLFFBQVEsRUFBRW1CLEdBQUcsRUFDbEMzSixDQUFDLENBQUM0SSxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUvRixPQUFPLEVBQUU7UUFDcEJrSCxNQUFNLEVBQUUsSUFBSTtRQUNaYSxhQUFhLEVBQUU7TUFDakIsQ0FBQyxDQUFDLENBQUM7SUFDeEIsQ0FBQztJQUVEakksZUFBZSxDQUFDbEMsU0FBUyxDQUFDaU0sSUFBSSxHQUFHLFVBQVV4RyxjQUFjLEVBQUVzQyxRQUFRLEVBQUUzRixPQUFPLEVBQUU7TUFDNUUsSUFBSUksSUFBSSxHQUFHLElBQUk7TUFFZixJQUFJMEosU0FBUyxDQUFDeEIsTUFBTSxLQUFLLENBQUMsRUFDeEIzQyxRQUFRLEdBQUcsQ0FBQyxDQUFDO01BRWYsT0FBTyxJQUFJb0UsTUFBTSxDQUNmM0osSUFBSSxFQUFFLElBQUk0SixpQkFBaUIsQ0FBQzNHLGNBQWMsRUFBRXNDLFFBQVEsRUFBRTNGLE9BQU8sQ0FBQyxDQUFDO0lBQ25FLENBQUM7SUFFREYsZUFBZSxDQUFDbEMsU0FBUyxDQUFDcU0sWUFBWSxHQUFHLGdCQUFnQnBGLGVBQWUsRUFBRWMsUUFBUSxFQUFFM0YsT0FBTyxFQUFFO01BQzNGLElBQUlJLElBQUksR0FBRyxJQUFJO01BQ2YsSUFBSTBKLFNBQVMsQ0FBQ3hCLE1BQU0sS0FBSyxDQUFDLEVBQUU7UUFDMUIzQyxRQUFRLEdBQUcsQ0FBQyxDQUFDO01BQ2Y7TUFFQTNGLE9BQU8sR0FBR0EsT0FBTyxJQUFJLENBQUMsQ0FBQztNQUN2QkEsT0FBTyxDQUFDa0ssS0FBSyxHQUFHLENBQUM7TUFFakIsTUFBTUMsT0FBTyxHQUFHLE1BQU0vSixJQUFJLENBQUN5SixJQUFJLENBQUNoRixlQUFlLEVBQUVjLFFBQVEsRUFBRTNGLE9BQU8sQ0FBQyxDQUFDb0ssS0FBSyxDQUFDLENBQUM7TUFFM0UsT0FBT0QsT0FBTyxDQUFDLENBQUMsQ0FBQztJQUNuQixDQUFDOztJQUVEO0lBQ0E7SUFDQXJLLGVBQWUsQ0FBQ2xDLFNBQVMsQ0FBQ3lNLGdCQUFnQixHQUFHLGdCQUFnQmhILGNBQWMsRUFBRWlILEtBQUssRUFDL0J0SyxPQUFPLEVBQUU7TUFDMUQsSUFBSUksSUFBSSxHQUFHLElBQUk7O01BRWY7TUFDQTtNQUNBLElBQUlrRCxVQUFVLEdBQUdsRCxJQUFJLENBQUNnRCxhQUFhLENBQUNDLGNBQWMsQ0FBQztNQUNuRCxNQUFNQyxVQUFVLENBQUNpSCxXQUFXLENBQUNELEtBQUssRUFBRXRLLE9BQU8sQ0FBQztJQUM5QyxDQUFDOztJQUVEO0lBQ0FGLGVBQWUsQ0FBQ2xDLFNBQVMsQ0FBQzJNLFdBQVcsR0FDbkN6SyxlQUFlLENBQUNsQyxTQUFTLENBQUN5TSxnQkFBZ0I7SUFFNUN2SyxlQUFlLENBQUNsQyxTQUFTLENBQUM0TSxjQUFjLEdBQUcsVUFBVW5ILGNBQWMsRUFBVztNQUFBLFNBQUFvSCxJQUFBLEdBQUFYLFNBQUEsQ0FBQXhCLE1BQUEsRUFBTm9DLElBQUksT0FBQUMsS0FBQSxDQUFBRixJQUFBLE9BQUFBLElBQUEsV0FBQUcsSUFBQSxNQUFBQSxJQUFBLEdBQUFILElBQUEsRUFBQUcsSUFBQTtRQUFKRixJQUFJLENBQUFFLElBQUEsUUFBQWQsU0FBQSxDQUFBYyxJQUFBO01BQUE7TUFDMUVGLElBQUksR0FBR0EsSUFBSSxDQUFDck4sR0FBRyxDQUFDd04sR0FBRyxJQUFJcEwsWUFBWSxDQUFDb0wsR0FBRyxFQUFFM0wsMEJBQTBCLENBQUMsQ0FBQztNQUNyRSxNQUFNb0UsVUFBVSxHQUFHLElBQUksQ0FBQ0YsYUFBYSxDQUFDQyxjQUFjLENBQUM7TUFDckQsT0FBT0MsVUFBVSxDQUFDa0gsY0FBYyxDQUFDLEdBQUdFLElBQUksQ0FBQztJQUMzQyxDQUFDO0lBRUQ1SyxlQUFlLENBQUNsQyxTQUFTLENBQUNrTixzQkFBc0IsR0FBRyxVQUFVekgsY0FBYyxFQUFXO01BQUEsU0FBQTBILEtBQUEsR0FBQWpCLFNBQUEsQ0FBQXhCLE1BQUEsRUFBTm9DLElBQUksT0FBQUMsS0FBQSxDQUFBSSxLQUFBLE9BQUFBLEtBQUEsV0FBQUMsS0FBQSxNQUFBQSxLQUFBLEdBQUFELEtBQUEsRUFBQUMsS0FBQTtRQUFKTixJQUFJLENBQUFNLEtBQUEsUUFBQWxCLFNBQUEsQ0FBQWtCLEtBQUE7TUFBQTtNQUNsRk4sSUFBSSxHQUFHQSxJQUFJLENBQUNyTixHQUFHLENBQUN3TixHQUFHLElBQUlwTCxZQUFZLENBQUNvTCxHQUFHLEVBQUUzTCwwQkFBMEIsQ0FBQyxDQUFDO01BQ3JFLE1BQU1vRSxVQUFVLEdBQUcsSUFBSSxDQUFDRixhQUFhLENBQUNDLGNBQWMsQ0FBQztNQUNyRCxPQUFPQyxVQUFVLENBQUN3SCxzQkFBc0IsQ0FBQyxHQUFHSixJQUFJLENBQUM7SUFDbkQsQ0FBQztJQUVENUssZUFBZSxDQUFDbEMsU0FBUyxDQUFDcU4sZ0JBQWdCLEdBQUduTCxlQUFlLENBQUNsQyxTQUFTLENBQUN5TSxnQkFBZ0I7SUFFdkZ2SyxlQUFlLENBQUNsQyxTQUFTLENBQUNzTixjQUFjLEdBQUcsZ0JBQWdCN0gsY0FBYyxFQUFFaUgsS0FBSyxFQUFFO01BQ2hGLElBQUlsSyxJQUFJLEdBQUcsSUFBSTs7TUFHZjtNQUNBO01BQ0EsSUFBSWtELFVBQVUsR0FBR2xELElBQUksQ0FBQ2dELGFBQWEsQ0FBQ0MsY0FBYyxDQUFDO01BQ25ELElBQUk4SCxTQUFTLEdBQUksTUFBTTdILFVBQVUsQ0FBQzhILFNBQVMsQ0FBQ2QsS0FBSyxDQUFDO0lBQ3BELENBQUM7SUFHRDFPLG1CQUFtQixDQUFDMkYsT0FBTyxDQUFDLFVBQVU4SixDQUFDLEVBQUU7TUFDdkN2TCxlQUFlLENBQUNsQyxTQUFTLENBQUN5TixDQUFDLENBQUMsR0FBRyxZQUFZO1FBQ3pDLE1BQU0sSUFBSXRJLEtBQUssSUFBQXVJLE1BQUEsQ0FDVkQsQ0FBQyxxREFBQUMsTUFBQSxDQUFrRHpQLGtCQUFrQixDQUN0RXdQLENBQ0YsQ0FBQyxnQkFDSCxDQUFDO01BQ0gsQ0FBQztJQUNILENBQUMsQ0FBQzs7SUFFRjs7SUFFQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7O0lBRUFyQixpQkFBaUIsR0FBRyxTQUFBQSxDQUFVM0csY0FBYyxFQUFFc0MsUUFBUSxFQUFFM0YsT0FBTyxFQUFFO01BQy9ELElBQUlJLElBQUksR0FBRyxJQUFJO01BQ2ZBLElBQUksQ0FBQ2lELGNBQWMsR0FBR0EsY0FBYztNQUNwQ2pELElBQUksQ0FBQ3VGLFFBQVEsR0FBR2xILEtBQUssQ0FBQzhNLFVBQVUsQ0FBQ0MsZ0JBQWdCLENBQUM3RixRQUFRLENBQUM7TUFDM0R2RixJQUFJLENBQUNKLE9BQU8sR0FBR0EsT0FBTyxJQUFJLENBQUMsQ0FBQztJQUM5QixDQUFDO0lBRUQrSixNQUFNLEdBQUcsU0FBQUEsQ0FBVW5KLEtBQUssRUFBRTZLLGlCQUFpQixFQUFFO01BQzNDLElBQUlyTCxJQUFJLEdBQUcsSUFBSTtNQUVmQSxJQUFJLENBQUNzTCxNQUFNLEdBQUc5SyxLQUFLO01BQ25CUixJQUFJLENBQUN1TCxrQkFBa0IsR0FBR0YsaUJBQWlCO01BQzNDckwsSUFBSSxDQUFDd0wsa0JBQWtCLEdBQUcsSUFBSTtJQUNoQyxDQUFDO0lBRUQsU0FBU0Msc0JBQXNCQSxDQUFDQyxNQUFNLEVBQUV2QyxNQUFNLEVBQUU7TUFDOUM7TUFDQSxJQUFJdUMsTUFBTSxDQUFDSCxrQkFBa0IsQ0FBQzNMLE9BQU8sQ0FBQytMLFFBQVEsRUFDNUMsTUFBTSxJQUFJaEosS0FBSyxDQUFDLGNBQWMsR0FBR3dHLE1BQU0sR0FBRyx1QkFBdUIsQ0FBQztNQUVwRSxJQUFJLENBQUN1QyxNQUFNLENBQUNGLGtCQUFrQixFQUFFO1FBQzlCRSxNQUFNLENBQUNGLGtCQUFrQixHQUFHRSxNQUFNLENBQUNKLE1BQU0sQ0FBQ00sd0JBQXdCLENBQ2hFRixNQUFNLENBQUNILGtCQUFrQixFQUN6QjtVQUNFO1VBQ0E7VUFDQU0sZ0JBQWdCLEVBQUVILE1BQU07VUFDeEJJLFlBQVksRUFBRTtRQUNoQixDQUNGLENBQUM7TUFDSDtNQUVBLE9BQU9KLE1BQU0sQ0FBQ0Ysa0JBQWtCO0lBQ2xDO0lBR0E3QixNQUFNLENBQUNuTSxTQUFTLENBQUN1TyxVQUFVLEdBQUcsa0JBQWtCO01BQzlDLE1BQU03SSxVQUFVLEdBQUcsSUFBSSxDQUFDb0ksTUFBTSxDQUFDdEksYUFBYSxDQUFDLElBQUksQ0FBQ3VJLGtCQUFrQixDQUFDdEksY0FBYyxDQUFDO01BQ3BGLE9BQU8sTUFBTUMsVUFBVSxDQUFDa0gsY0FBYyxDQUNwQy9LLFlBQVksQ0FBQyxJQUFJLENBQUNrTSxrQkFBa0IsQ0FBQ2hHLFFBQVEsRUFBRXpHLDBCQUEwQixDQUFDLEVBQzFFTyxZQUFZLENBQUMsSUFBSSxDQUFDa00sa0JBQWtCLENBQUMzTCxPQUFPLEVBQUVkLDBCQUEwQixDQUMxRSxDQUFDO0lBQ0gsQ0FBQztJQUVENkssTUFBTSxDQUFDbk0sU0FBUyxDQUFDd08sS0FBSyxHQUFHLFlBQVk7TUFDbkMsTUFBTSxJQUFJckosS0FBSyxDQUNiLHdFQUNGLENBQUM7SUFDSCxDQUFDO0lBRUQsQ0FBQyxHQUFHcEgsb0JBQW9CLEVBQUUwUSxNQUFNLENBQUNDLFFBQVEsRUFBRUQsTUFBTSxDQUFDRSxhQUFhLENBQUMsQ0FBQ2hMLE9BQU8sQ0FBQ2lMLFVBQVUsSUFBSTtNQUNyRjtNQUNBO01BQ0EsSUFBSUEsVUFBVSxLQUFLLE9BQU8sRUFBRTtRQUMxQjtNQUNGO01BQ0F6QyxNQUFNLENBQUNuTSxTQUFTLENBQUM0TyxVQUFVLENBQUMsR0FBRyxZQUFtQjtRQUNoRCxNQUFNVixNQUFNLEdBQUdELHNCQUFzQixDQUFDLElBQUksRUFBRVcsVUFBVSxDQUFDO1FBQ3ZELE9BQU9WLE1BQU0sQ0FBQ1UsVUFBVSxDQUFDLENBQUMsR0FBQTFDLFNBQU8sQ0FBQztNQUNwQyxDQUFDOztNQUVEO01BQ0EsSUFBSTBDLFVBQVUsS0FBS0gsTUFBTSxDQUFDQyxRQUFRLElBQUlFLFVBQVUsS0FBS0gsTUFBTSxDQUFDRSxhQUFhLEVBQUU7UUFDekU7TUFDRjtNQUVBLE1BQU1FLGVBQWUsR0FBRzVRLGtCQUFrQixDQUFDMlEsVUFBVSxDQUFDO01BQ3REekMsTUFBTSxDQUFDbk0sU0FBUyxDQUFDNk8sZUFBZSxDQUFDLEdBQUcsWUFBbUI7UUFDckQsSUFBSTtVQUNGLE9BQU9DLE9BQU8sQ0FBQ0MsT0FBTyxDQUFDLElBQUksQ0FBQ0gsVUFBVSxDQUFDLENBQUMsR0FBQTFDLFNBQU8sQ0FBQyxDQUFDO1FBQ25ELENBQUMsQ0FBQyxPQUFPL0MsS0FBSyxFQUFFO1VBQ2QsT0FBTzJGLE9BQU8sQ0FBQ0UsTUFBTSxDQUFDN0YsS0FBSyxDQUFDO1FBQzlCO01BQ0YsQ0FBQztJQUNILENBQUMsQ0FBQztJQUVGZ0QsTUFBTSxDQUFDbk0sU0FBUyxDQUFDaVAsWUFBWSxHQUFHLFlBQVk7TUFDMUMsT0FBTyxJQUFJLENBQUNsQixrQkFBa0IsQ0FBQzNMLE9BQU8sQ0FBQzhNLFNBQVM7SUFDbEQsQ0FBQzs7SUFFRDtJQUNBO0lBQ0E7SUFDQS9DLE1BQU0sQ0FBQ25NLFNBQVMsQ0FBQ21QLGNBQWMsR0FBRyxVQUFVQyxHQUFHLEVBQUU7TUFDL0MsSUFBSTVNLElBQUksR0FBRyxJQUFJO01BQ2YsSUFBSWtELFVBQVUsR0FBR2xELElBQUksQ0FBQ3VMLGtCQUFrQixDQUFDdEksY0FBYztNQUN2RCxPQUFPNUUsS0FBSyxDQUFDOE0sVUFBVSxDQUFDd0IsY0FBYyxDQUFDM00sSUFBSSxFQUFFNE0sR0FBRyxFQUFFMUosVUFBVSxDQUFDO0lBQy9ELENBQUM7O0lBRUQ7SUFDQTtJQUNBO0lBQ0F5RyxNQUFNLENBQUNuTSxTQUFTLENBQUNxUCxrQkFBa0IsR0FBRyxZQUFZO01BQ2hELElBQUk3TSxJQUFJLEdBQUcsSUFBSTtNQUNmLE9BQU9BLElBQUksQ0FBQ3VMLGtCQUFrQixDQUFDdEksY0FBYztJQUMvQyxDQUFDO0lBRUQwRyxNQUFNLENBQUNuTSxTQUFTLENBQUNzUCxPQUFPLEdBQUcsVUFBVUMsU0FBUyxFQUFFO01BQzlDLElBQUkvTSxJQUFJLEdBQUcsSUFBSTtNQUNmLE9BQU80RSxlQUFlLENBQUNvSSwwQkFBMEIsQ0FBQ2hOLElBQUksRUFBRStNLFNBQVMsQ0FBQztJQUNwRSxDQUFDO0lBRURwRCxNQUFNLENBQUNuTSxTQUFTLENBQUN5UCxZQUFZLEdBQUcsVUFBVUYsU0FBUyxFQUFFO01BQ25ELE9BQU8sSUFBSVQsT0FBTyxDQUFDQyxPQUFPLElBQUlBLE9BQU8sQ0FBQyxJQUFJLENBQUNPLE9BQU8sQ0FBQ0MsU0FBUyxDQUFDLENBQUMsQ0FBQztJQUNqRSxDQUFDO0lBRURwRCxNQUFNLENBQUNuTSxTQUFTLENBQUMwUCxjQUFjLEdBQUcsVUFBVUgsU0FBUyxFQUFnQjtNQUFBLElBQWRuTixPQUFPLEdBQUE4SixTQUFBLENBQUF4QixNQUFBLFFBQUF3QixTQUFBLFFBQUE3SyxTQUFBLEdBQUE2SyxTQUFBLE1BQUcsQ0FBQyxDQUFDO01BQ2pFLElBQUkxSixJQUFJLEdBQUcsSUFBSTtNQUNmLElBQUltTixPQUFPLEdBQUcsQ0FDWixTQUFTLEVBQ1QsT0FBTyxFQUNQLFdBQVcsRUFDWCxTQUFTLEVBQ1QsV0FBVyxFQUNYLFNBQVMsRUFDVCxTQUFTLENBQ1Y7TUFDRCxJQUFJQyxPQUFPLEdBQUd4SSxlQUFlLENBQUN5SSxrQ0FBa0MsQ0FBQ04sU0FBUyxDQUFDO01BRTNFLElBQUlPLGFBQWEsR0FBR1AsU0FBUyxDQUFDUSxZQUFZLEdBQUcsU0FBUyxHQUFHLGdCQUFnQjtNQUN6RUQsYUFBYSxJQUFJLFdBQVc7TUFDNUJILE9BQU8sQ0FBQ2hNLE9BQU8sQ0FBQyxVQUFVZ0ksTUFBTSxFQUFFO1FBQ2hDLElBQUk0RCxTQUFTLENBQUM1RCxNQUFNLENBQUMsSUFBSSxPQUFPNEQsU0FBUyxDQUFDNUQsTUFBTSxDQUFDLElBQUksVUFBVSxFQUFFO1VBQy9ENEQsU0FBUyxDQUFDNUQsTUFBTSxDQUFDLEdBQUd6TixNQUFNLENBQUNzRyxlQUFlLENBQUMrSyxTQUFTLENBQUM1RCxNQUFNLENBQUMsRUFBRUEsTUFBTSxHQUFHbUUsYUFBYSxDQUFDO1FBQ3ZGO01BQ0YsQ0FBQyxDQUFDO01BRUYsT0FBT3ROLElBQUksQ0FBQ3NMLE1BQU0sQ0FBQ2tDLGVBQWUsQ0FDaEN4TixJQUFJLENBQUN1TCxrQkFBa0IsRUFBRTZCLE9BQU8sRUFBRUwsU0FBUyxFQUFFbk4sT0FBTyxDQUFDNk4sb0JBQW9CLENBQUM7SUFDOUUsQ0FBQztJQUVEOUQsTUFBTSxDQUFDbk0sU0FBUyxDQUFDa1EsbUJBQW1CLEdBQUcsZ0JBQWdCWCxTQUFTLEVBQWdCO01BQUEsSUFBZG5OLE9BQU8sR0FBQThKLFNBQUEsQ0FBQXhCLE1BQUEsUUFBQXdCLFNBQUEsUUFBQTdLLFNBQUEsR0FBQTZLLFNBQUEsTUFBRyxDQUFDLENBQUM7TUFDNUUsT0FBTyxJQUFJLENBQUN3RCxjQUFjLENBQUNILFNBQVMsRUFBRW5OLE9BQU8sQ0FBQztJQUNoRCxDQUFDO0lBRURGLGVBQWUsQ0FBQ2xDLFNBQVMsQ0FBQ29PLHdCQUF3QixHQUFHLFVBQ2pEUCxpQkFBaUIsRUFBRXpMLE9BQU8sRUFBRTtNQUM5QixJQUFJSSxJQUFJLEdBQUcsSUFBSTtNQUNmSixPQUFPLEdBQUc3QyxDQUFDLENBQUM0USxJQUFJLENBQUMvTixPQUFPLElBQUksQ0FBQyxDQUFDLEVBQUUsa0JBQWtCLEVBQUUsY0FBYyxDQUFDO01BRW5FLElBQUlzRCxVQUFVLEdBQUdsRCxJQUFJLENBQUNnRCxhQUFhLENBQUNxSSxpQkFBaUIsQ0FBQ3BJLGNBQWMsQ0FBQztNQUNyRSxJQUFJMkssYUFBYSxHQUFHdkMsaUJBQWlCLENBQUN6TCxPQUFPO01BQzdDLElBQUlhLFlBQVksR0FBRztRQUNqQm9OLElBQUksRUFBRUQsYUFBYSxDQUFDQyxJQUFJO1FBQ3hCL0QsS0FBSyxFQUFFOEQsYUFBYSxDQUFDOUQsS0FBSztRQUMxQmdFLElBQUksRUFBRUYsYUFBYSxDQUFDRSxJQUFJO1FBQ3hCQyxVQUFVLEVBQUVILGFBQWEsQ0FBQ0ksTUFBTSxJQUFJSixhQUFhLENBQUNHLFVBQVU7UUFDNURFLGNBQWMsRUFBRUwsYUFBYSxDQUFDSztNQUNoQyxDQUFDOztNQUVEO01BQ0EsSUFBSUwsYUFBYSxDQUFDakMsUUFBUSxFQUFFO1FBQzFCbEwsWUFBWSxDQUFDeU4sZUFBZSxHQUFHLENBQUMsQ0FBQztNQUNuQztNQUVBLElBQUlDLFFBQVEsR0FBR2pMLFVBQVUsQ0FBQ3VHLElBQUksQ0FDNUJwSyxZQUFZLENBQUNnTSxpQkFBaUIsQ0FBQzlGLFFBQVEsRUFBRXpHLDBCQUEwQixDQUFDLEVBQ3BFMkIsWUFBWSxDQUFDOztNQUVmO01BQ0EsSUFBSW1OLGFBQWEsQ0FBQ2pDLFFBQVEsRUFBRTtRQUMxQjtRQUNBd0MsUUFBUSxDQUFDQyxhQUFhLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQztRQUN4QztRQUNBO1FBQ0FELFFBQVEsQ0FBQ0MsYUFBYSxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUM7O1FBRXpDO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQSxJQUFJL0MsaUJBQWlCLENBQUNwSSxjQUFjLEtBQUtvTCxnQkFBZ0IsSUFDckRoRCxpQkFBaUIsQ0FBQzlGLFFBQVEsQ0FBQytJLEVBQUUsRUFBRTtVQUNqQ0gsUUFBUSxDQUFDQyxhQUFhLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQztRQUM3QztNQUNGO01BRUEsSUFBSSxPQUFPUixhQUFhLENBQUNXLFNBQVMsS0FBSyxXQUFXLEVBQUU7UUFDbERKLFFBQVEsR0FBR0EsUUFBUSxDQUFDSyxTQUFTLENBQUNaLGFBQWEsQ0FBQ1csU0FBUyxDQUFDO01BQ3hEO01BQ0EsSUFBSSxPQUFPWCxhQUFhLENBQUNhLElBQUksS0FBSyxXQUFXLEVBQUU7UUFDN0NOLFFBQVEsR0FBR0EsUUFBUSxDQUFDTSxJQUFJLENBQUNiLGFBQWEsQ0FBQ2EsSUFBSSxDQUFDO01BQzlDO01BRUEsT0FBTyxJQUFJQyxrQkFBa0IsQ0FBQ1AsUUFBUSxFQUFFOUMsaUJBQWlCLEVBQUV6TCxPQUFPLEVBQUVzRCxVQUFVLENBQUM7SUFDakYsQ0FBQzs7SUFFRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7SUFDQSxNQUFNd0wsa0JBQWtCLENBQUM7TUFDdkJDLFdBQVdBLENBQUNSLFFBQVEsRUFBRTlDLGlCQUFpQixFQUFFekwsT0FBTyxFQUFFO1FBQ2hELElBQUksQ0FBQ2dQLFNBQVMsR0FBR1QsUUFBUTtRQUN6QixJQUFJLENBQUM1QyxrQkFBa0IsR0FBR0YsaUJBQWlCO1FBRTNDLElBQUksQ0FBQ3dELGlCQUFpQixHQUFHalAsT0FBTyxDQUFDaU0sZ0JBQWdCLElBQUksSUFBSTtRQUN6RCxJQUFJak0sT0FBTyxDQUFDa00sWUFBWSxJQUFJVCxpQkFBaUIsQ0FBQ3pMLE9BQU8sQ0FBQzhNLFNBQVMsRUFBRTtVQUMvRCxJQUFJLENBQUNvQyxVQUFVLEdBQUdsSyxlQUFlLENBQUNtSyxhQUFhLENBQzNDMUQsaUJBQWlCLENBQUN6TCxPQUFPLENBQUM4TSxTQUFTLENBQUM7UUFDMUMsQ0FBQyxNQUFNO1VBQ0wsSUFBSSxDQUFDb0MsVUFBVSxHQUFHLElBQUk7UUFDeEI7UUFFQSxJQUFJLENBQUNFLFdBQVcsR0FBRyxJQUFJcEssZUFBZSxDQUFDcUssTUFBTSxDQUFELENBQUM7TUFDL0M7TUFFQSxDQUFDaEQsTUFBTSxDQUFDRSxhQUFhLElBQUk7UUFDdkIsSUFBSVQsTUFBTSxHQUFHLElBQUk7UUFDakIsT0FBTztVQUNMLE1BQU13RCxJQUFJQSxDQUFBLEVBQUc7WUFDWCxNQUFNN1IsS0FBSyxHQUFHLE1BQU1xTyxNQUFNLENBQUN5RCxrQkFBa0IsQ0FBQyxDQUFDO1lBQy9DLE9BQU87Y0FBRUMsSUFBSSxFQUFFLENBQUMvUixLQUFLO2NBQUVBO1lBQU0sQ0FBQztVQUNoQztRQUNGLENBQUM7TUFDSDs7TUFFQTtNQUNBO01BQ0EsTUFBTWdTLHFCQUFxQkEsQ0FBQSxFQUFHO1FBQzVCLElBQUk7VUFDRixPQUFPLElBQUksQ0FBQ1QsU0FBUyxDQUFDTSxJQUFJLENBQUMsQ0FBQztRQUM5QixDQUFDLENBQUMsT0FBT3hLLENBQUMsRUFBRTtVQUNWNEssT0FBTyxDQUFDM0ksS0FBSyxDQUFDakMsQ0FBQyxDQUFDO1FBQ2xCO01BQ0Y7O01BRUE7TUFDQTtNQUNBLE1BQU15SyxrQkFBa0JBLENBQUEsRUFBSTtRQUMxQixPQUFPLElBQUksRUFBRTtVQUNYLElBQUlJLEdBQUcsR0FBRyxNQUFNLElBQUksQ0FBQ0YscUJBQXFCLENBQUMsQ0FBQztVQUU1QyxJQUFJLENBQUNFLEdBQUcsRUFBRSxPQUFPLElBQUk7VUFDckJBLEdBQUcsR0FBR2xRLFlBQVksQ0FBQ2tRLEdBQUcsRUFBRXpSLDBCQUEwQixDQUFDO1VBRW5ELElBQUksQ0FBQyxJQUFJLENBQUN5TixrQkFBa0IsQ0FBQzNMLE9BQU8sQ0FBQytMLFFBQVEsSUFBSTVPLENBQUMsQ0FBQzhELEdBQUcsQ0FBQzBPLEdBQUcsRUFBRSxLQUFLLENBQUMsRUFBRTtZQUNsRTtZQUNBO1lBQ0E7WUFDQTtZQUNBO1lBQ0E7WUFDQSxJQUFJLElBQUksQ0FBQ1AsV0FBVyxDQUFDbk8sR0FBRyxDQUFDME8sR0FBRyxDQUFDeEssR0FBRyxDQUFDLEVBQUU7WUFDbkMsSUFBSSxDQUFDaUssV0FBVyxDQUFDUSxHQUFHLENBQUNELEdBQUcsQ0FBQ3hLLEdBQUcsRUFBRSxJQUFJLENBQUM7VUFDckM7VUFFQSxJQUFJLElBQUksQ0FBQytKLFVBQVUsRUFDakJTLEdBQUcsR0FBRyxJQUFJLENBQUNULFVBQVUsQ0FBQ1MsR0FBRyxDQUFDO1VBRTVCLE9BQU9BLEdBQUc7UUFDWjtNQUNGOztNQUVBO01BQ0E7TUFDQTtNQUNBRSw2QkFBNkJBLENBQUNDLFNBQVMsRUFBRTtRQUN2QyxJQUFJLENBQUNBLFNBQVMsRUFBRTtVQUNkLE9BQU8sSUFBSSxDQUFDUCxrQkFBa0IsQ0FBQyxDQUFDO1FBQ2xDO1FBQ0EsTUFBTVEsaUJBQWlCLEdBQUcsSUFBSSxDQUFDUixrQkFBa0IsQ0FBQyxDQUFDO1FBQ25ELE1BQU1TLFVBQVUsR0FBRyxJQUFJak4sS0FBSyxDQUFDLDZDQUE2QyxDQUFDO1FBQzNFLE1BQU1rTixjQUFjLEdBQUcsSUFBSXZELE9BQU8sQ0FBQyxDQUFDQyxPQUFPLEVBQUVDLE1BQU0sS0FBSztVQUN0RHNELFVBQVUsQ0FBQyxNQUFNO1lBQ2Z0RCxNQUFNLENBQUNvRCxVQUFVLENBQUM7VUFDcEIsQ0FBQyxFQUFFRixTQUFTLENBQUM7UUFDZixDQUFDLENBQUM7UUFDRixPQUFPcEQsT0FBTyxDQUFDeUQsSUFBSSxDQUFDLENBQUNKLGlCQUFpQixFQUFFRSxjQUFjLENBQUMsQ0FBQyxDQUNuRHhLLEtBQUssQ0FBRWpCLEdBQUcsSUFBSztVQUNkLElBQUlBLEdBQUcsS0FBS3dMLFVBQVUsRUFBRTtZQUN0QixJQUFJLENBQUM5TSxLQUFLLENBQUMsQ0FBQztVQUNkO1VBQ0EsTUFBTXNCLEdBQUc7UUFDWCxDQUFDLENBQUM7TUFDUjtNQUVBLE1BQU1qRCxPQUFPQSxDQUFDa0IsUUFBUSxFQUFFMk4sT0FBTyxFQUFFO1FBQy9CO1FBQ0EsSUFBSSxDQUFDQyxPQUFPLENBQUMsQ0FBQztRQUVkLElBQUlDLEdBQUcsR0FBRyxDQUFDO1FBQ1gsT0FBTyxJQUFJLEVBQUU7VUFDWCxNQUFNWCxHQUFHLEdBQUcsTUFBTSxJQUFJLENBQUNKLGtCQUFrQixDQUFDLENBQUM7VUFDM0MsSUFBSSxDQUFDSSxHQUFHLEVBQUU7VUFDVixNQUFNbE4sUUFBUSxDQUFDOE4sSUFBSSxDQUFDSCxPQUFPLEVBQUVULEdBQUcsRUFBRVcsR0FBRyxFQUFFLEVBQUUsSUFBSSxDQUFDckIsaUJBQWlCLENBQUM7UUFDbEU7TUFDRjtNQUVBLE1BQU01UixHQUFHQSxDQUFDb0YsUUFBUSxFQUFFMk4sT0FBTyxFQUFFO1FBQzNCLE1BQU1qRyxPQUFPLEdBQUcsRUFBRTtRQUNsQixNQUFNLElBQUksQ0FBQzVJLE9BQU8sQ0FBQyxPQUFPb08sR0FBRyxFQUFFckYsS0FBSyxLQUFLO1VBQ3ZDSCxPQUFPLENBQUNxRyxJQUFJLENBQUMsTUFBTS9OLFFBQVEsQ0FBQzhOLElBQUksQ0FBQ0gsT0FBTyxFQUFFVCxHQUFHLEVBQUVyRixLQUFLLEVBQUUsSUFBSSxDQUFDMkUsaUJBQWlCLENBQUMsQ0FBQztRQUNoRixDQUFDLENBQUM7UUFFRixPQUFPOUUsT0FBTztNQUNoQjtNQUVBa0csT0FBT0EsQ0FBQSxFQUFHO1FBQ1I7UUFDQSxJQUFJLENBQUNyQixTQUFTLENBQUN5QixNQUFNLENBQUMsQ0FBQztRQUV2QixJQUFJLENBQUNyQixXQUFXLEdBQUcsSUFBSXBLLGVBQWUsQ0FBQ3FLLE1BQU0sQ0FBRCxDQUFDO01BQy9DOztNQUVBO01BQ0FuTSxLQUFLQSxDQUFBLEVBQUc7UUFDTixJQUFJLENBQUM4TCxTQUFTLENBQUM5TCxLQUFLLENBQUMsQ0FBQztNQUN4QjtNQUVBa0gsS0FBS0EsQ0FBQSxFQUFHO1FBQ04sT0FBTyxJQUFJLENBQUMvTSxHQUFHLENBQUNGLENBQUMsQ0FBQ3VULFFBQVEsQ0FBQztNQUM3Qjs7TUFFQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO01BQ0V0RSxLQUFLQSxDQUFBLEVBQUc7UUFDTixPQUFPLElBQUksQ0FBQzRDLFNBQVMsQ0FBQzVDLEtBQUssQ0FBQyxDQUFDO01BQy9COztNQUVBO01BQ0EsTUFBTXVFLGFBQWFBLENBQUNuRCxPQUFPLEVBQUU7UUFDM0IsSUFBSXBOLElBQUksR0FBRyxJQUFJO1FBQ2YsSUFBSW9OLE9BQU8sRUFBRTtVQUNYLE9BQU9wTixJQUFJLENBQUNnSyxLQUFLLENBQUMsQ0FBQztRQUNyQixDQUFDLE1BQU07VUFDTCxJQUFJRCxPQUFPLEdBQUcsSUFBSW5GLGVBQWUsQ0FBQ3FLLE1BQU0sQ0FBRCxDQUFDO1VBQ3hDLE1BQU1qUCxJQUFJLENBQUNtQixPQUFPLENBQUMsVUFBVW9PLEdBQUcsRUFBRTtZQUNoQ3hGLE9BQU8sQ0FBQ3lGLEdBQUcsQ0FBQ0QsR0FBRyxDQUFDeEssR0FBRyxFQUFFd0ssR0FBRyxDQUFDO1VBQzNCLENBQUMsQ0FBQztVQUNGLE9BQU94RixPQUFPO1FBQ2hCO01BQ0Y7SUFDRjtJQUVBLElBQUl5RyxpQkFBaUIsR0FBRyxTQUFBQSxDQUFVckMsUUFBUSxFQUFFOUMsaUJBQWlCLEVBQUV6TCxPQUFPLEVBQUVzRCxVQUFVLEVBQUU7TUFDbEYsSUFBSWxELElBQUksR0FBRyxJQUFJO01BQ2ZKLE9BQU8sR0FBRzdDLENBQUMsQ0FBQzRRLElBQUksQ0FBQy9OLE9BQU8sSUFBSSxDQUFDLENBQUMsRUFBRSxrQkFBa0IsRUFBRSxjQUFjLENBQUM7TUFFbkVJLElBQUksQ0FBQzRPLFNBQVMsR0FBR1QsUUFBUTtNQUN6Qm5PLElBQUksQ0FBQ3VMLGtCQUFrQixHQUFHRixpQkFBaUI7TUFDM0M7TUFDQTtNQUNBckwsSUFBSSxDQUFDNk8saUJBQWlCLEdBQUdqUCxPQUFPLENBQUNpTSxnQkFBZ0IsSUFBSTdMLElBQUk7TUFDekQsSUFBSUosT0FBTyxDQUFDa00sWUFBWSxJQUFJVCxpQkFBaUIsQ0FBQ3pMLE9BQU8sQ0FBQzhNLFNBQVMsRUFBRTtRQUMvRDFNLElBQUksQ0FBQzhPLFVBQVUsR0FBR2xLLGVBQWUsQ0FBQ21LLGFBQWEsQ0FDN0MxRCxpQkFBaUIsQ0FBQ3pMLE9BQU8sQ0FBQzhNLFNBQVMsQ0FBQztNQUN4QyxDQUFDLE1BQU07UUFDTDFNLElBQUksQ0FBQzhPLFVBQVUsR0FBRyxJQUFJO01BQ3hCO01BRUE5TyxJQUFJLENBQUN5USxpQkFBaUIsR0FBR0MsTUFBTSxDQUFDQyxJQUFJLENBQ2xDek4sVUFBVSxDQUFDa0gsY0FBYyxDQUFDbE4sSUFBSSxDQUM1QmdHLFVBQVUsRUFDVjdELFlBQVksQ0FBQ2dNLGlCQUFpQixDQUFDOUYsUUFBUSxFQUFFekcsMEJBQTBCLENBQUMsRUFDcEVPLFlBQVksQ0FBQ2dNLGlCQUFpQixDQUFDekwsT0FBTyxFQUFFZCwwQkFBMEIsQ0FDcEUsQ0FDRixDQUFDO01BQ0RrQixJQUFJLENBQUNnUCxXQUFXLEdBQUcsSUFBSXBLLGVBQWUsQ0FBQ3FLLE1BQU0sQ0FBRCxDQUFDO0lBQy9DLENBQUM7SUFFRGxTLENBQUMsQ0FBQzRJLE1BQU0sQ0FBQzZLLGlCQUFpQixDQUFDaFQsU0FBUyxFQUFFO01BQ3BDO01BQ0E7TUFDQTZSLHFCQUFxQixFQUFFLFNBQUFBLENBQUEsRUFBWTtRQUNqQyxNQUFNclAsSUFBSSxHQUFHLElBQUk7UUFDakIsT0FBTyxJQUFJc00sT0FBTyxDQUFDLENBQUNDLE9BQU8sRUFBRUMsTUFBTSxLQUFLO1VBQ3RDeE0sSUFBSSxDQUFDNE8sU0FBUyxDQUFDTSxJQUFJLENBQUMsQ0FBQzlLLEdBQUcsRUFBRW1MLEdBQUcsS0FBSztZQUNoQyxJQUFJbkwsR0FBRyxFQUFFO2NBQ1BvSSxNQUFNLENBQUNwSSxHQUFHLENBQUM7WUFDYixDQUFDLE1BQU07Y0FDTG1JLE9BQU8sQ0FBQ2dELEdBQUcsQ0FBQztZQUNkO1VBQ0YsQ0FBQyxDQUFDO1FBQ0osQ0FBQyxDQUFDO01BQ0osQ0FBQztNQUVEO01BQ0E7TUFDQUosa0JBQWtCLEVBQUUsZUFBQUEsQ0FBQSxFQUFrQjtRQUNwQyxJQUFJblAsSUFBSSxHQUFHLElBQUk7UUFFZixPQUFPLElBQUksRUFBRTtVQUNYLElBQUl1UCxHQUFHLEdBQUcsTUFBTXZQLElBQUksQ0FBQ3FQLHFCQUFxQixDQUFDLENBQUM7VUFFNUMsSUFBSSxDQUFDRSxHQUFHLEVBQUUsT0FBTyxJQUFJO1VBQ3JCQSxHQUFHLEdBQUdsUSxZQUFZLENBQUNrUSxHQUFHLEVBQUV6UiwwQkFBMEIsQ0FBQztVQUVuRCxJQUFJLENBQUNrQyxJQUFJLENBQUN1TCxrQkFBa0IsQ0FBQzNMLE9BQU8sQ0FBQytMLFFBQVEsSUFBSTVPLENBQUMsQ0FBQzhELEdBQUcsQ0FBQzBPLEdBQUcsRUFBRSxLQUFLLENBQUMsRUFBRTtZQUNsRTtZQUNBO1lBQ0E7WUFDQTtZQUNBO1lBQ0E7WUFDQSxJQUFJdlAsSUFBSSxDQUFDZ1AsV0FBVyxDQUFDbk8sR0FBRyxDQUFDME8sR0FBRyxDQUFDeEssR0FBRyxDQUFDLEVBQUU7WUFDbkMvRSxJQUFJLENBQUNnUCxXQUFXLENBQUNRLEdBQUcsQ0FBQ0QsR0FBRyxDQUFDeEssR0FBRyxFQUFFLElBQUksQ0FBQztVQUNyQztVQUVBLElBQUkvRSxJQUFJLENBQUM4TyxVQUFVLEVBQ2pCUyxHQUFHLEdBQUd2UCxJQUFJLENBQUM4TyxVQUFVLENBQUNTLEdBQUcsQ0FBQztVQUU1QixPQUFPQSxHQUFHO1FBQ1o7TUFDRixDQUFDO01BRUQ7TUFDQTtNQUNBO01BQ0FFLDZCQUE2QixFQUFFLFNBQUFBLENBQVVDLFNBQVMsRUFBRTtRQUNsRCxNQUFNMVAsSUFBSSxHQUFHLElBQUk7UUFDakIsSUFBSSxDQUFDMFAsU0FBUyxFQUFFO1VBQ2QsT0FBTzFQLElBQUksQ0FBQ21QLGtCQUFrQixDQUFDLENBQUM7UUFDbEM7UUFDQSxNQUFNUSxpQkFBaUIsR0FBRzNQLElBQUksQ0FBQ21QLGtCQUFrQixDQUFDLENBQUM7UUFDbkQsTUFBTVMsVUFBVSxHQUFHLElBQUlqTixLQUFLLENBQUMsNkNBQTZDLENBQUM7UUFDM0UsTUFBTWtOLGNBQWMsR0FBRyxJQUFJdkQsT0FBTyxDQUFDLENBQUNDLE9BQU8sRUFBRUMsTUFBTSxLQUFLO1VBQ3RELE1BQU1vRSxLQUFLLEdBQUdkLFVBQVUsQ0FBQyxNQUFNO1lBQzdCdEQsTUFBTSxDQUFDb0QsVUFBVSxDQUFDO1VBQ3BCLENBQUMsRUFBRUYsU0FBUyxDQUFDO1FBQ2YsQ0FBQyxDQUFDO1FBQ0YsT0FBT3BELE9BQU8sQ0FBQ3lELElBQUksQ0FBQyxDQUFDSixpQkFBaUIsRUFBRUUsY0FBYyxDQUFDLENBQUMsQ0FDckR4SyxLQUFLLENBQUVqQixHQUFHLElBQUs7VUFDZCxJQUFJQSxHQUFHLEtBQUt3TCxVQUFVLEVBQUU7WUFDdEI1UCxJQUFJLENBQUM4QyxLQUFLLENBQUMsQ0FBQztVQUNkO1VBQ0EsTUFBTXNCLEdBQUc7UUFDWCxDQUFDLENBQUM7TUFDTixDQUFDO01BRUR5TSxXQUFXLEVBQUUsU0FBQUEsQ0FBQSxFQUFZO1FBQ3ZCLElBQUk3USxJQUFJLEdBQUcsSUFBSTtRQUNmLE9BQU9BLElBQUksQ0FBQ21QLGtCQUFrQixDQUFDLENBQUMsQ0FBQzJCLEtBQUssQ0FBQyxDQUFDO01BQzFDLENBQUM7TUFFRDNQLE9BQU8sRUFBRSxTQUFBQSxDQUFVa0IsUUFBUSxFQUFFMk4sT0FBTyxFQUFFO1FBQ3BDLElBQUloUSxJQUFJLEdBQUcsSUFBSTtRQUNmLE1BQU0rUSxTQUFTLEdBQUdyVixNQUFNLENBQUNzVixNQUFNLENBQUMzTyxRQUFRLENBQUM7O1FBRXpDO1FBQ0FyQyxJQUFJLENBQUNpUSxPQUFPLENBQUMsQ0FBQzs7UUFFZDtRQUNBO1FBQ0E7UUFDQSxJQUFJL0YsS0FBSyxHQUFHLENBQUM7UUFDYixPQUFPLElBQUksRUFBRTtVQUNYLElBQUlxRixHQUFHLEdBQUd2UCxJQUFJLENBQUM2USxXQUFXLENBQUMsQ0FBQztVQUM1QixJQUFJLENBQUN0QixHQUFHLEVBQUU7VUFDVndCLFNBQVMsQ0FBQ1osSUFBSSxDQUFDSCxPQUFPLEVBQUVULEdBQUcsRUFBRXJGLEtBQUssRUFBRSxFQUFFbEssSUFBSSxDQUFDNk8saUJBQWlCLENBQUM7UUFDL0Q7TUFDRixDQUFDO01BRUQ7TUFDQTVSLEdBQUcsRUFBRSxTQUFBQSxDQUFVb0YsUUFBUSxFQUFFMk4sT0FBTyxFQUFFO1FBQ2hDLElBQUloUSxJQUFJLEdBQUcsSUFBSTtRQUNmLE1BQU0rUSxTQUFTLEdBQUdyVixNQUFNLENBQUNzVixNQUFNLENBQUMzTyxRQUFRLENBQUM7UUFDekMsSUFBSTRPLEdBQUcsR0FBRyxFQUFFO1FBQ1pqUixJQUFJLENBQUNtQixPQUFPLENBQUMsVUFBVW9PLEdBQUcsRUFBRXJGLEtBQUssRUFBRTtVQUNqQytHLEdBQUcsQ0FBQ2IsSUFBSSxDQUFDVyxTQUFTLENBQUNaLElBQUksQ0FBQ0gsT0FBTyxFQUFFVCxHQUFHLEVBQUVyRixLQUFLLEVBQUVsSyxJQUFJLENBQUM2TyxpQkFBaUIsQ0FBQyxDQUFDO1FBQ3ZFLENBQUMsQ0FBQztRQUNGLE9BQU9vQyxHQUFHO01BQ1osQ0FBQztNQUVEaEIsT0FBTyxFQUFFLFNBQUFBLENBQUEsRUFBWTtRQUNuQixJQUFJalEsSUFBSSxHQUFHLElBQUk7O1FBRWY7UUFDQUEsSUFBSSxDQUFDNE8sU0FBUyxDQUFDeUIsTUFBTSxDQUFDLENBQUM7UUFFdkJyUSxJQUFJLENBQUNnUCxXQUFXLEdBQUcsSUFBSXBLLGVBQWUsQ0FBQ3FLLE1BQU0sQ0FBRCxDQUFDO01BQy9DLENBQUM7TUFFRDtNQUNBbk0sS0FBSyxFQUFFLFNBQUFBLENBQUEsRUFBWTtRQUNqQixJQUFJOUMsSUFBSSxHQUFHLElBQUk7UUFFZkEsSUFBSSxDQUFDNE8sU0FBUyxDQUFDOUwsS0FBSyxDQUFDLENBQUM7TUFDeEIsQ0FBQztNQUVEa0gsS0FBSyxFQUFFLFNBQUFBLENBQUEsRUFBWTtRQUNqQixJQUFJaEssSUFBSSxHQUFHLElBQUk7UUFDZixPQUFPQSxJQUFJLENBQUMvQyxHQUFHLENBQUNGLENBQUMsQ0FBQ3VULFFBQVEsQ0FBQztNQUM3QixDQUFDO01BRUR0RSxLQUFLLEVBQUUsU0FBQUEsQ0FBQSxFQUFZO1FBQ2pCLElBQUloTSxJQUFJLEdBQUcsSUFBSTtRQUNmLE9BQU9BLElBQUksQ0FBQ3lRLGlCQUFpQixDQUFDLENBQUMsQ0FBQ1MsSUFBSSxDQUFDLENBQUM7TUFDeEMsQ0FBQztNQUVEO01BQ0FYLGFBQWEsRUFBRSxTQUFBQSxDQUFVbkQsT0FBTyxFQUFFO1FBQ2hDLElBQUlwTixJQUFJLEdBQUcsSUFBSTtRQUNmLElBQUlvTixPQUFPLEVBQUU7VUFDWCxPQUFPcE4sSUFBSSxDQUFDZ0ssS0FBSyxDQUFDLENBQUM7UUFDckIsQ0FBQyxNQUFNO1VBQ0wsSUFBSUQsT0FBTyxHQUFHLElBQUluRixlQUFlLENBQUNxSyxNQUFNLENBQUQsQ0FBQztVQUN4Q2pQLElBQUksQ0FBQ21CLE9BQU8sQ0FBQyxVQUFVb08sR0FBRyxFQUFFO1lBQzFCeEYsT0FBTyxDQUFDeUYsR0FBRyxDQUFDRCxHQUFHLENBQUN4SyxHQUFHLEVBQUV3SyxHQUFHLENBQUM7VUFDM0IsQ0FBQyxDQUFDO1VBQ0YsT0FBT3hGLE9BQU87UUFDaEI7TUFDRjtJQUNGLENBQUMsQ0FBQztJQUVGeUcsaUJBQWlCLENBQUNoVCxTQUFTLENBQUN5TyxNQUFNLENBQUNDLFFBQVEsQ0FBQyxHQUFHLFlBQVk7TUFDekQsSUFBSWxNLElBQUksR0FBRyxJQUFJOztNQUVmO01BQ0FBLElBQUksQ0FBQ2lRLE9BQU8sQ0FBQyxDQUFDO01BRWQsT0FBTztRQUNMZixJQUFJQSxDQUFBLEVBQUc7VUFDTCxNQUFNSyxHQUFHLEdBQUd2UCxJQUFJLENBQUM2USxXQUFXLENBQUMsQ0FBQztVQUM5QixPQUFPdEIsR0FBRyxHQUFHO1lBQ1hsUyxLQUFLLEVBQUVrUztVQUNULENBQUMsR0FBRztZQUNGSCxJQUFJLEVBQUU7VUFDUixDQUFDO1FBQ0g7TUFDRixDQUFDO0lBQ0gsQ0FBQztJQUVEb0IsaUJBQWlCLENBQUNoVCxTQUFTLENBQUN5TyxNQUFNLENBQUNFLGFBQWEsQ0FBQyxHQUFHLFlBQVk7TUFDOUQsTUFBTWdGLFVBQVUsR0FBRyxJQUFJLENBQUNsRixNQUFNLENBQUNDLFFBQVEsQ0FBQyxDQUFDLENBQUM7TUFDMUMsT0FBTztRQUNMLE1BQU1nRCxJQUFJQSxDQUFBLEVBQUc7VUFDWCxPQUFPNUMsT0FBTyxDQUFDQyxPQUFPLENBQUM0RSxVQUFVLENBQUNqQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBQzNDO01BQ0YsQ0FBQztJQUNILENBQUM7O0lBRUQ7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0F4UCxlQUFlLENBQUNsQyxTQUFTLENBQUM0VCxJQUFJLEdBQUcsVUFBVS9GLGlCQUFpQixFQUFFZ0csV0FBVyxFQUFFM0IsU0FBUyxFQUFFO01BQ3BGLElBQUkxUCxJQUFJLEdBQUcsSUFBSTtNQUNmLElBQUksQ0FBQ3FMLGlCQUFpQixDQUFDekwsT0FBTyxDQUFDK0wsUUFBUSxFQUNyQyxNQUFNLElBQUloSixLQUFLLENBQUMsaUNBQWlDLENBQUM7TUFFcEQsSUFBSStJLE1BQU0sR0FBRzFMLElBQUksQ0FBQzRMLHdCQUF3QixDQUFDUCxpQkFBaUIsQ0FBQztNQUU3RCxJQUFJaUcsT0FBTyxHQUFHLEtBQUs7TUFDbkIsSUFBSUMsTUFBTTtNQUVWN1YsTUFBTSxDQUFDOFYsS0FBSyxDQUFDLGVBQWVDLElBQUlBLENBQUEsRUFBRztRQUNqQyxJQUFJbEMsR0FBRyxHQUFHLElBQUk7UUFDZCxPQUFPLElBQUksRUFBRTtVQUNYLElBQUkrQixPQUFPLEVBQ1Q7VUFDRixJQUFJO1lBQ0YvQixHQUFHLEdBQUcsTUFBTTdELE1BQU0sQ0FBQytELDZCQUE2QixDQUFDQyxTQUFTLENBQUM7VUFDN0QsQ0FBQyxDQUFDLE9BQU90TCxHQUFHLEVBQUU7WUFDWjtZQUNBO1lBQ0E7WUFDQTtZQUNBbUwsR0FBRyxHQUFHLElBQUk7VUFDWjtVQUNBO1VBQ0E7VUFDQSxJQUFJK0IsT0FBTyxFQUNUO1VBQ0YsSUFBSS9CLEdBQUcsRUFBRTtZQUNQO1lBQ0E7WUFDQTtZQUNBO1lBQ0FnQyxNQUFNLEdBQUdoQyxHQUFHLENBQUNqQixFQUFFO1lBQ2YrQyxXQUFXLENBQUM5QixHQUFHLENBQUM7VUFDbEIsQ0FBQyxNQUFNO1lBQ0wsSUFBSW1DLFdBQVcsR0FBRzNVLENBQUMsQ0FBQ1UsS0FBSyxDQUFDNE4saUJBQWlCLENBQUM5RixRQUFRLENBQUM7WUFDckQsSUFBSWdNLE1BQU0sRUFBRTtjQUNWRyxXQUFXLENBQUNwRCxFQUFFLEdBQUc7Z0JBQUNxRCxHQUFHLEVBQUVKO2NBQU0sQ0FBQztZQUNoQztZQUNBN0YsTUFBTSxHQUFHMUwsSUFBSSxDQUFDNEwsd0JBQXdCLENBQUMsSUFBSWhDLGlCQUFpQixDQUMxRHlCLGlCQUFpQixDQUFDcEksY0FBYyxFQUNoQ3lPLFdBQVcsRUFDWHJHLGlCQUFpQixDQUFDekwsT0FBTyxDQUFDLENBQUM7WUFDN0I7WUFDQTtZQUNBO1lBQ0FrUSxVQUFVLENBQUMyQixJQUFJLEVBQUUsR0FBRyxDQUFDO1lBQ3JCO1VBQ0Y7UUFDRjtNQUNGLENBQUMsQ0FBQztNQUVGLE9BQU87UUFDTDVPLElBQUksRUFBRSxTQUFBQSxDQUFBLEVBQVk7VUFDaEJ5TyxPQUFPLEdBQUcsSUFBSTtVQUNkNUYsTUFBTSxDQUFDNUksS0FBSyxDQUFDLENBQUM7UUFDaEI7TUFDRixDQUFDO0lBQ0gsQ0FBQztJQUVELE1BQU04Tyx1QkFBdUIsR0FBRyxFQUFFO0lBRWxDbFIsTUFBTSxDQUFDQyxNQUFNLENBQUNqQixlQUFlLENBQUNsQyxTQUFTLEVBQUU7TUFDdkNnUSxlQUFlLEVBQUUsZUFBQUEsQ0FDYm5DLGlCQUFpQixFQUFFK0IsT0FBTyxFQUFFTCxTQUFTLEVBQUVVLG9CQUFvQixFQUFFO1FBQUEsSUFBQW9FLGtCQUFBO1FBQy9ELElBQUk3UixJQUFJLEdBQUcsSUFBSTtRQUNmLE1BQU1pRCxjQUFjLEdBQUdvSSxpQkFBaUIsQ0FBQ3BJLGNBQWM7UUFFdkQsSUFBSW9JLGlCQUFpQixDQUFDekwsT0FBTyxDQUFDK0wsUUFBUSxFQUFFO1VBQ3RDLE9BQU8zTCxJQUFJLENBQUM4Uix1QkFBdUIsQ0FBQ3pHLGlCQUFpQixFQUFFK0IsT0FBTyxFQUFFTCxTQUFTLENBQUM7UUFDNUU7O1FBRUE7UUFDQTtRQUNBLE1BQU1nRixhQUFhLEdBQUcxRyxpQkFBaUIsQ0FBQ3pMLE9BQU8sQ0FBQ21PLFVBQVUsSUFBSTFDLGlCQUFpQixDQUFDekwsT0FBTyxDQUFDb08sTUFBTTtRQUM5RixJQUFJK0QsYUFBYSxLQUNaQSxhQUFhLENBQUNoTixHQUFHLEtBQUssQ0FBQyxJQUNwQmdOLGFBQWEsQ0FBQ2hOLEdBQUcsS0FBSyxLQUFLLENBQUMsRUFBRTtVQUNwQyxNQUFNcEMsS0FBSyxDQUFDLHNEQUFzRCxDQUFDO1FBQ3JFO1FBRUEsSUFBSXFQLFVBQVUsR0FBR3JULEtBQUssQ0FBQ3NULFNBQVMsQ0FDNUJsVixDQUFDLENBQUM0SSxNQUFNLENBQUM7VUFBQ3lILE9BQU8sRUFBRUE7UUFBTyxDQUFDLEVBQUUvQixpQkFBaUIsQ0FBQyxDQUFDO1FBRXBELElBQUk2RyxXQUFXLEVBQUVDLGFBQWE7UUFDOUIsSUFBSUMsV0FBVyxHQUFHLEtBQUs7O1FBRXZCO1FBQ0E7UUFDQTtRQUNBLElBQUlyVixDQUFDLENBQUM4RCxHQUFHLENBQUNiLElBQUksQ0FBQ0Msb0JBQW9CLEVBQUUrUixVQUFVLENBQUMsRUFBRTtVQUNoREUsV0FBVyxHQUFHbFMsSUFBSSxDQUFDQyxvQkFBb0IsQ0FBQytSLFVBQVUsQ0FBQztRQUNyRCxDQUFDLE1BQU07VUFDTEksV0FBVyxHQUFHLElBQUk7VUFDbEI7VUFDQUYsV0FBVyxHQUFHLElBQUlHLGtCQUFrQixDQUFDO1lBQ25DakYsT0FBTyxFQUFFQSxPQUFPO1lBQ2hCa0YsTUFBTSxFQUFFLFNBQUFBLENBQUEsRUFBWTtjQUNsQixPQUFPdFMsSUFBSSxDQUFDQyxvQkFBb0IsQ0FBQytSLFVBQVUsQ0FBQztjQUM1QyxPQUFPRyxhQUFhLENBQUN0UCxJQUFJLENBQUMsQ0FBQztZQUM3QjtVQUNGLENBQUMsQ0FBQztRQUNKO1FBRUEsSUFBSTBQLGFBQWEsR0FBRyxJQUFJQyxhQUFhLENBQUNOLFdBQVcsRUFDN0NuRixTQUFTLEVBQ1RVLG9CQUNKLENBQUM7UUFFRCxNQUFNZ0YsWUFBWSxHQUFHLENBQUF6UyxJQUFJLGFBQUpBLElBQUksd0JBQUE2UixrQkFBQSxHQUFKN1IsSUFBSSxDQUFFMkIsWUFBWSxjQUFBa1Esa0JBQUEsdUJBQWxCQSxrQkFBQSxDQUFvQmEsYUFBYSxLQUFJLENBQUMsQ0FBQztRQUM5RCxNQUFNO1VBQUVDLGtCQUFrQjtVQUFFQztRQUFtQixDQUFDLEdBQUdILFlBQVk7UUFBQyxJQUFJTCxXQUFXLEVBQUU7VUFDN0UsSUFBSVMsT0FBTyxFQUFFQyxNQUFNO1VBQ25CLElBQUlDLFdBQVcsR0FBR2hXLENBQUMsQ0FBQ2lXLEdBQUcsQ0FBQyxDQUN0QixZQUFZO1lBQ1Y7WUFDQTtZQUNBO1lBQ0EsT0FBT2hULElBQUksQ0FBQzJCLFlBQVksSUFBSSxDQUFDeUwsT0FBTyxJQUNoQyxDQUFDTCxTQUFTLENBQUNrRyxxQkFBcUI7VUFBQyxDQUFDLEVBQUUsWUFBWTtZQUN0RDtZQUNBO1lBQ0EsSUFBSUwsa0JBQWtCLGFBQWxCQSxrQkFBa0IsZUFBbEJBLGtCQUFrQixDQUFFMUssTUFBTSxJQUFJMEssa0JBQWtCLENBQUNNLFFBQVEsQ0FBQ2pRLGNBQWMsQ0FBQyxFQUFFO2NBQzdFLElBQUksQ0FBQzJPLHVCQUF1QixDQUFDc0IsUUFBUSxDQUFDalEsY0FBYyxDQUFDLEVBQUU7Z0JBQ3JEcU0sT0FBTyxDQUFDNkQsSUFBSSxtRkFBQWpJLE1BQUEsQ0FBbUZqSSxjQUFjLHNEQUFtRCxDQUFDO2dCQUNqSzJPLHVCQUF1QixDQUFDeEIsSUFBSSxDQUFDbk4sY0FBYyxDQUFDLENBQUMsQ0FBQztjQUNoRDtjQUNBLE9BQU8sS0FBSztZQUNkO1lBQ0EsSUFBSTBQLGtCQUFrQixhQUFsQkEsa0JBQWtCLGVBQWxCQSxrQkFBa0IsQ0FBRXpLLE1BQU0sSUFBSSxDQUFDeUssa0JBQWtCLENBQUNPLFFBQVEsQ0FBQ2pRLGNBQWMsQ0FBQyxFQUFFO2NBQzlFLElBQUksQ0FBQzJPLHVCQUF1QixDQUFDc0IsUUFBUSxDQUFDalEsY0FBYyxDQUFDLEVBQUU7Z0JBQ3JEcU0sT0FBTyxDQUFDNkQsSUFBSSwyRkFBQWpJLE1BQUEsQ0FBMkZqSSxjQUFjLHNEQUFtRCxDQUFDO2dCQUN6SzJPLHVCQUF1QixDQUFDeEIsSUFBSSxDQUFDbk4sY0FBYyxDQUFDLENBQUMsQ0FBQztjQUNoRDtjQUNBLE9BQU8sS0FBSztZQUNkO1lBQ0EsT0FBTyxJQUFJO1VBQ1gsQ0FBQyxFQUFFLFlBQVk7WUFDYjtZQUNBO1lBQ0EsSUFBSTtjQUNGNFAsT0FBTyxHQUFHLElBQUlPLFNBQVMsQ0FBQ0MsT0FBTyxDQUFDaEksaUJBQWlCLENBQUM5RixRQUFRLENBQUM7Y0FDM0QsT0FBTyxJQUFJO1lBQ2IsQ0FBQyxDQUFDLE9BQU9iLENBQUMsRUFBRTtjQUNWO2NBQ0E7Y0FDQSxPQUFPLEtBQUs7WUFDZDtVQUNGLENBQUMsRUFBRSxZQUFZO1lBQ2I7WUFDQSxPQUFPNE8sa0JBQWtCLENBQUNDLGVBQWUsQ0FBQ2xJLGlCQUFpQixFQUFFd0gsT0FBTyxDQUFDO1VBQ3ZFLENBQUMsRUFBRSxZQUFZO1lBQ2I7WUFDQTtZQUNBLElBQUksQ0FBQ3hILGlCQUFpQixDQUFDekwsT0FBTyxDQUFDaU8sSUFBSSxFQUNqQyxPQUFPLElBQUk7WUFDYixJQUFJO2NBQ0ZpRixNQUFNLEdBQUcsSUFBSU0sU0FBUyxDQUFDSSxNQUFNLENBQUNuSSxpQkFBaUIsQ0FBQ3pMLE9BQU8sQ0FBQ2lPLElBQUksQ0FBQztjQUM3RCxPQUFPLElBQUk7WUFDYixDQUFDLENBQUMsT0FBT25KLENBQUMsRUFBRTtjQUNWO2NBQ0E7Y0FDQSxPQUFPLEtBQUs7WUFDZDtVQUNGLENBQUMsQ0FBQyxFQUFFLFVBQVUrTyxDQUFDLEVBQUU7WUFBRSxPQUFPQSxDQUFDLENBQUMsQ0FBQztVQUFFLENBQUMsQ0FBQyxDQUFDLENBQUU7O1VBRXRDLElBQUlDLFdBQVcsR0FBR1gsV0FBVyxHQUFHTyxrQkFBa0IsR0FBR0ssb0JBQW9CO1VBQ3pFeEIsYUFBYSxHQUFHLElBQUl1QixXQUFXLENBQUM7WUFDOUJySSxpQkFBaUIsRUFBRUEsaUJBQWlCO1lBQ3BDdUksV0FBVyxFQUFFNVQsSUFBSTtZQUNqQmtTLFdBQVcsRUFBRUEsV0FBVztZQUN4QjlFLE9BQU8sRUFBRUEsT0FBTztZQUNoQnlGLE9BQU8sRUFBRUEsT0FBTztZQUFHO1lBQ25CQyxNQUFNLEVBQUVBLE1BQU07WUFBRztZQUNqQkcscUJBQXFCLEVBQUVsRyxTQUFTLENBQUNrRztVQUNuQyxDQUFDLENBQUM7VUFFRixJQUFJZCxhQUFhLENBQUMwQixLQUFLLEVBQUU7WUFDdkIsTUFBTTFCLGFBQWEsQ0FBQzBCLEtBQUssQ0FBQyxDQUFDO1VBQzdCOztVQUVBO1VBQ0EzQixXQUFXLENBQUM0QixjQUFjLEdBQUczQixhQUFhO1FBQzVDO1FBQ0FuUyxJQUFJLENBQUNDLG9CQUFvQixDQUFDK1IsVUFBVSxDQUFDLEdBQUdFLFdBQVc7UUFDbkQ7UUFDQSxNQUFNQSxXQUFXLENBQUM2QiwyQkFBMkIsQ0FBQ3hCLGFBQWEsQ0FBQztRQUU1RCxPQUFPQSxhQUFhO01BQ3RCO0lBRUYsQ0FBQyxDQUFDOztJQUdGO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7O0lBRUF5QixTQUFTLEdBQUcsZUFBQUEsQ0FBZ0IzSSxpQkFBaUIsRUFBRTRJLGNBQWMsRUFBRTtNQUM3RCxNQUFNQyxTQUFTLEdBQUcsRUFBRTtNQUNwQixNQUFNQyxjQUFjLENBQUM5SSxpQkFBaUIsRUFBRSxVQUFVK0ksT0FBTyxFQUFFO1FBQ3pERixTQUFTLENBQUM5RCxJQUFJLENBQUN6TSxTQUFTLENBQUMwUSxxQkFBcUIsQ0FBQ0MsTUFBTSxDQUNuREYsT0FBTyxFQUFFSCxjQUFjLENBQUMsQ0FBQztNQUM3QixDQUFDLENBQUM7TUFFRixPQUFPO1FBQ0xwUixJQUFJLEVBQUUsU0FBQUEsQ0FBQSxFQUFZO1VBQ2hCOUYsQ0FBQyxDQUFDSyxJQUFJLENBQUM4VyxTQUFTLEVBQUUsVUFBVUssUUFBUSxFQUFFO1lBQ3BDQSxRQUFRLENBQUMxUixJQUFJLENBQUMsQ0FBQztVQUNqQixDQUFDLENBQUM7UUFDSjtNQUNGLENBQUM7SUFDSCxDQUFDO0lBRURzUixjQUFjLEdBQUcsZUFBQUEsQ0FBZ0I5SSxpQkFBaUIsRUFBRW1KLGVBQWUsRUFBRTtNQUNuRSxNQUFNbFgsR0FBRyxHQUFHO1FBQUM0RixVQUFVLEVBQUVtSSxpQkFBaUIsQ0FBQ3BJO01BQWMsQ0FBQztNQUMxRCxNQUFNd0MsV0FBVyxHQUFHYixlQUFlLENBQUNjLHFCQUFxQixDQUN2RDJGLGlCQUFpQixDQUFDOUYsUUFBUSxDQUFDO01BQzdCLElBQUlFLFdBQVcsRUFBRTtRQUNmLEtBQUssTUFBTVgsRUFBRSxJQUFJVyxXQUFXLEVBQUU7VUFDNUIsTUFBTStPLGVBQWUsQ0FBQ3pYLENBQUMsQ0FBQzRJLE1BQU0sQ0FBQztZQUFDYixFQUFFLEVBQUVBO1VBQUUsQ0FBQyxFQUFFeEgsR0FBRyxDQUFDLENBQUM7UUFDaEQ7UUFDQSxNQUFNa1gsZUFBZSxDQUFDelgsQ0FBQyxDQUFDNEksTUFBTSxDQUFDO1VBQUNTLGNBQWMsRUFBRSxJQUFJO1VBQUV0QixFQUFFLEVBQUU7UUFBSSxDQUFDLEVBQUV4SCxHQUFHLENBQUMsQ0FBQztNQUN4RSxDQUFDLE1BQU07UUFDTCxNQUFNa1gsZUFBZSxDQUFDbFgsR0FBRyxDQUFDO01BQzVCO01BQ0E7TUFDQSxNQUFNa1gsZUFBZSxDQUFDO1FBQUVqTyxZQUFZLEVBQUU7TUFBSyxDQUFDLENBQUM7SUFDL0MsQ0FBQzs7SUFFRDtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBN0csZUFBZSxDQUFDbEMsU0FBUyxDQUFDc1UsdUJBQXVCLEdBQUcsVUFDaER6RyxpQkFBaUIsRUFBRStCLE9BQU8sRUFBRUwsU0FBUyxFQUFFO01BQ3pDLElBQUkvTSxJQUFJLEdBQUcsSUFBSTs7TUFFZjtNQUNBO01BQ0EsSUFBS29OLE9BQU8sSUFBSSxDQUFDTCxTQUFTLENBQUMwSCxXQUFXLElBQ2pDLENBQUNySCxPQUFPLElBQUksQ0FBQ0wsU0FBUyxDQUFDMkgsS0FBTSxFQUFFO1FBQ2xDLE1BQU0sSUFBSS9SLEtBQUssQ0FBQyxtQkFBbUIsSUFBSXlLLE9BQU8sR0FBRyxTQUFTLEdBQUcsV0FBVyxDQUFDLEdBQ3ZELDZCQUE2QixJQUM1QkEsT0FBTyxHQUFHLGFBQWEsR0FBRyxPQUFPLENBQUMsR0FBRyxXQUFXLENBQUM7TUFDdEU7TUFFQSxPQUFPcE4sSUFBSSxDQUFDb1IsSUFBSSxDQUFDL0YsaUJBQWlCLEVBQUUsVUFBVWtFLEdBQUcsRUFBRTtRQUNqRCxJQUFJekssRUFBRSxHQUFHeUssR0FBRyxDQUFDeEssR0FBRztRQUNoQixPQUFPd0ssR0FBRyxDQUFDeEssR0FBRztRQUNkO1FBQ0EsT0FBT3dLLEdBQUcsQ0FBQ2pCLEVBQUU7UUFDYixJQUFJbEIsT0FBTyxFQUFFO1VBQ1hMLFNBQVMsQ0FBQzBILFdBQVcsQ0FBQzNQLEVBQUUsRUFBRXlLLEdBQUcsRUFBRSxJQUFJLENBQUM7UUFDdEMsQ0FBQyxNQUFNO1VBQ0x4QyxTQUFTLENBQUMySCxLQUFLLENBQUM1UCxFQUFFLEVBQUV5SyxHQUFHLENBQUM7UUFDMUI7TUFDRixDQUFDLENBQUM7SUFDSixDQUFDOztJQUVEO0lBQ0E7SUFDQTtJQUNBdFQsY0FBYyxDQUFDMFksY0FBYyxHQUFHNVksT0FBTyxDQUFDd0IsU0FBUztJQUVqRHRCLGNBQWMsQ0FBQzJZLFVBQVUsR0FBR2xWLGVBQWU7SUFBQ21WLHNCQUFBO0VBQUEsU0FBQUMsV0FBQTtJQUFBLE9BQUFELHNCQUFBLENBQUFDLFdBQUE7RUFBQTtFQUFBRCxzQkFBQTtBQUFBO0VBQUE3VSxJQUFBO0VBQUErVSxLQUFBO0FBQUEsRzs7Ozs7Ozs7Ozs7Ozs7SUN6cEQ1QyxJQUFJL1ksZ0JBQWdCO0lBQUNPLE1BQU0sQ0FBQ3JCLElBQUksQ0FBQyxrQkFBa0IsRUFBQztNQUFDYyxnQkFBZ0JBLENBQUNaLENBQUMsRUFBQztRQUFDWSxnQkFBZ0IsR0FBQ1osQ0FBQztNQUFBO0lBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztJQUFDLElBQUlPLG9CQUFvQixDQUFDLENBQUMsRUFBRSxDQUFDLE1BQU1BLG9CQUFvQixDQUFDLENBQUMsRUFBRSxDQUFDO0lBQzdKLE1BQU07TUFBRXFaO0lBQUssQ0FBQyxHQUFHaFosZ0JBQWdCO0lBRWpDcVMsZ0JBQWdCLEdBQUcsVUFBVTtJQUU3QixJQUFJNEcsY0FBYyxHQUFHQyxPQUFPLENBQUNDLEdBQUcsQ0FBQ0MsMkJBQTJCLElBQUksSUFBSTtJQUNwRSxJQUFJQyxZQUFZLEdBQUcsQ0FBQ0gsT0FBTyxDQUFDQyxHQUFHLENBQUNHLHlCQUF5QixJQUFJLEtBQUs7SUFFbEVDLE9BQU8sR0FBRyxTQUFBQSxDQUFVQyxFQUFFLEVBQUU7TUFDdEIsSUFBSUEsRUFBRSxDQUFDQSxFQUFFLEtBQUssR0FBRyxFQUNmLE9BQU9BLEVBQUUsQ0FBQ0MsQ0FBQyxDQUFDMVEsR0FBRyxDQUFDLEtBQ2IsSUFBSXlRLEVBQUUsQ0FBQ0EsRUFBRSxLQUFLLEdBQUcsRUFDcEIsT0FBT0EsRUFBRSxDQUFDQyxDQUFDLENBQUMxUSxHQUFHLENBQUMsS0FDYixJQUFJeVEsRUFBRSxDQUFDQSxFQUFFLEtBQUssR0FBRyxFQUNwQixPQUFPQSxFQUFFLENBQUNFLEVBQUUsQ0FBQzNRLEdBQUcsQ0FBQyxLQUNkLElBQUl5USxFQUFFLENBQUNBLEVBQUUsS0FBSyxHQUFHLEVBQ3BCLE1BQU03UyxLQUFLLENBQUMsaURBQWlELEdBQ2pEaEUsS0FBSyxDQUFDc1QsU0FBUyxDQUFDdUQsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUVqQyxNQUFNN1MsS0FBSyxDQUFDLGNBQWMsR0FBR2hFLEtBQUssQ0FBQ3NULFNBQVMsQ0FBQ3VELEVBQUUsQ0FBQyxDQUFDO0lBQ3JELENBQUM7SUFFRGhULFdBQVcsR0FBRyxTQUFBQSxDQUFVRixRQUFRLEVBQUVxVCxNQUFNLEVBQUU7TUFDeEMsSUFBSTNWLElBQUksR0FBRyxJQUFJO01BQ2ZBLElBQUksQ0FBQzRWLFNBQVMsR0FBR3RULFFBQVE7TUFDekJ0QyxJQUFJLENBQUM2VixPQUFPLEdBQUdGLE1BQU07TUFFckIzVixJQUFJLENBQUM4Vix5QkFBeUIsR0FBRyxJQUFJO01BQ3JDOVYsSUFBSSxDQUFDK1Ysb0JBQW9CLEdBQUcsSUFBSTtNQUNoQy9WLElBQUksQ0FBQzBTLGFBQWEsR0FBRyxJQUFJO01BQ3pCMVMsSUFBSSxDQUFDZ1csUUFBUSxHQUFHLEtBQUs7TUFDckJoVyxJQUFJLENBQUNpVyxXQUFXLEdBQUcsSUFBSTtNQUN2QmpXLElBQUksQ0FBQ2tXLHFCQUFxQixHQUFHLElBQUk7TUFDakNsVyxJQUFJLENBQUNtVyxhQUFhLEdBQUcsSUFBSTdKLE9BQU8sQ0FBQzhKLENBQUMsSUFBSXBXLElBQUksQ0FBQ2tXLHFCQUFxQixHQUFHRSxDQUFDLENBQUM7TUFDckVwVyxJQUFJLENBQUNxVyxTQUFTLEdBQUcsSUFBSTFTLFNBQVMsQ0FBQzJTLFNBQVMsQ0FBQztRQUN2Q0MsV0FBVyxFQUFFLGdCQUFnQjtRQUFFQyxRQUFRLEVBQUU7TUFDM0MsQ0FBQyxDQUFDO01BQ0Z4VyxJQUFJLENBQUN5VyxrQkFBa0IsR0FBRztRQUN4QkMsRUFBRSxFQUFFLElBQUlDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FDdEJqYixNQUFNLENBQUNrYixhQUFhLENBQUM1VyxJQUFJLENBQUM2VixPQUFPLEdBQUcsR0FBRyxDQUFDLEVBQ3hDbmEsTUFBTSxDQUFDa2IsYUFBYSxDQUFDLFlBQVksQ0FBQyxDQUNuQyxDQUFDclYsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBQztRQUVsQnNWLEdBQUcsRUFBRSxDQUNIO1VBQUVyQixFQUFFLEVBQUU7WUFBRXNCLEdBQUcsRUFBRSxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRztVQUFFO1FBQUUsQ0FBQztRQUNoQztRQUNBO1VBQUV0QixFQUFFLEVBQUUsR0FBRztVQUFFLFFBQVEsRUFBRTtZQUFFdUIsT0FBTyxFQUFFO1VBQUs7UUFBRSxDQUFDLEVBQ3hDO1VBQUV2QixFQUFFLEVBQUUsR0FBRztVQUFFLGdCQUFnQixFQUFFO1FBQUUsQ0FBQyxFQUNoQztVQUFFQSxFQUFFLEVBQUUsR0FBRztVQUFFLFlBQVksRUFBRTtZQUFFdUIsT0FBTyxFQUFFO1VBQUs7UUFBRSxDQUFDO01BRWhELENBQUM7O01BRUQ7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0EvVyxJQUFJLENBQUNnWCxvQkFBb0IsR0FBRyxFQUFFO01BQzlCaFgsSUFBSSxDQUFDaVgsZ0JBQWdCLEdBQUcsSUFBSTtNQUU1QmpYLElBQUksQ0FBQ2tYLHFCQUFxQixHQUFHLElBQUkvVyxJQUFJLENBQUM7UUFDcENnWCxvQkFBb0IsRUFBRTtNQUN4QixDQUFDLENBQUM7TUFFRm5YLElBQUksQ0FBQ29YLFdBQVcsR0FBRyxJQUFJMWIsTUFBTSxDQUFDMmIsaUJBQWlCLENBQUMsQ0FBQztNQUNqRHJYLElBQUksQ0FBQ3NYLGFBQWEsR0FBRyxLQUFLO01BRTFCdFgsSUFBSSxDQUFDdVgscUJBQXFCLEdBQUd2WCxJQUFJLENBQUN3WCxhQUFhLENBQUMsQ0FBQztNQUNqRDtJQUNGLENBQUM7SUFFRHZiLGNBQWMsQ0FBQ3VHLFdBQVcsR0FBR0EsV0FBVztJQUV4QzlCLE1BQU0sQ0FBQ0MsTUFBTSxDQUFDNkIsV0FBVyxDQUFDaEYsU0FBUyxFQUFFO01BQ25DcUYsSUFBSSxFQUFFLGVBQUFBLENBQUEsRUFBa0I7UUFDdEIsSUFBSTdDLElBQUksR0FBRyxJQUFJO1FBQ2YsSUFBSUEsSUFBSSxDQUFDZ1csUUFBUSxFQUNmO1FBQ0ZoVyxJQUFJLENBQUNnVyxRQUFRLEdBQUcsSUFBSTtRQUNwQixJQUFJaFcsSUFBSSxDQUFDaVcsV0FBVyxFQUNsQixNQUFNalcsSUFBSSxDQUFDaVcsV0FBVyxDQUFDcFQsSUFBSSxDQUFDLENBQUM7UUFDL0I7TUFDRixDQUFDO01BQ0Q0VSxhQUFhLEVBQUUsZUFBQUEsQ0FBZXJELE9BQU8sRUFBRS9SLFFBQVEsRUFBRTtRQUMvQyxJQUFJckMsSUFBSSxHQUFHLElBQUk7UUFDZixJQUFJQSxJQUFJLENBQUNnVyxRQUFRLEVBQ2YsTUFBTSxJQUFJclQsS0FBSyxDQUFDLHdDQUF3QyxDQUFDOztRQUUzRDtRQUNBLE1BQU0zQyxJQUFJLENBQUNtVyxhQUFhO1FBRXhCLElBQUl1QixnQkFBZ0IsR0FBR3JWLFFBQVE7UUFDL0JBLFFBQVEsR0FBRzNHLE1BQU0sQ0FBQ3NHLGVBQWUsQ0FBQyxVQUFVMlYsWUFBWSxFQUFFO1VBQ3hERCxnQkFBZ0IsQ0FBQ0MsWUFBWSxDQUFDO1FBQ2hDLENBQUMsRUFBRSxVQUFVdlQsR0FBRyxFQUFFO1VBQ2hCMUksTUFBTSxDQUFDa2MsTUFBTSxDQUFDLHlCQUF5QixFQUFFeFQsR0FBRyxDQUFDO1FBQy9DLENBQUMsQ0FBQztRQUNGLElBQUl5VCxZQUFZLEdBQUc3WCxJQUFJLENBQUNxVyxTQUFTLENBQUMvQixNQUFNLENBQUNGLE9BQU8sRUFBRS9SLFFBQVEsQ0FBQztRQUMzRCxPQUFPO1VBQ0xRLElBQUksRUFBRSxlQUFBQSxDQUFBLEVBQWtCO1lBQ3RCLE1BQU1nVixZQUFZLENBQUNoVixJQUFJLENBQUMsQ0FBQztVQUMzQjtRQUNGLENBQUM7TUFDSCxDQUFDO01BQ0RpVixZQUFZLEVBQUUsU0FBQUEsQ0FBVTFELE9BQU8sRUFBRS9SLFFBQVEsRUFBRTtRQUN6QyxPQUFPLElBQUksQ0FBQ29WLGFBQWEsQ0FBQ3JELE9BQU8sRUFBRS9SLFFBQVEsQ0FBQztNQUM5QyxDQUFDO01BQ0Q7TUFDQTtNQUNBMFYsZ0JBQWdCLEVBQUUsU0FBQUEsQ0FBVTFWLFFBQVEsRUFBRTtRQUNwQyxJQUFJckMsSUFBSSxHQUFHLElBQUk7UUFDZixJQUFJQSxJQUFJLENBQUNnVyxRQUFRLEVBQ2YsTUFBTSxJQUFJclQsS0FBSyxDQUFDLDRDQUE0QyxDQUFDO1FBQy9ELE9BQU8zQyxJQUFJLENBQUNrWCxxQkFBcUIsQ0FBQ2xULFFBQVEsQ0FBQzNCLFFBQVEsQ0FBQztNQUN0RCxDQUFDO01BRUQsTUFBTTJWLGtCQUFrQkEsQ0FBQSxFQUFHO1FBQ3pCLElBQUloWSxJQUFJLEdBQUcsSUFBSTtRQUNmLElBQUlBLElBQUksQ0FBQ2dXLFFBQVEsRUFDZixNQUFNLElBQUlyVCxLQUFLLENBQUMsNkNBQTZDLENBQUM7O1FBRWhFO1FBQ0E7UUFDQSxNQUFNM0MsSUFBSSxDQUFDbVcsYUFBYTtRQUN4QixJQUFJOEIsU0FBUztRQUViLE9BQU8sQ0FBQ2pZLElBQUksQ0FBQ2dXLFFBQVEsRUFBRTtVQUNyQjtVQUNBO1VBQ0E7VUFDQSxJQUFJO1lBQ0ZpQyxTQUFTLEdBQUcsTUFBTWpZLElBQUksQ0FBQzhWLHlCQUF5QixDQUFDak0sWUFBWSxDQUMzRHdFLGdCQUFnQixFQUNoQnJPLElBQUksQ0FBQ3lXLGtCQUFrQixFQUN2QjtjQUFFMUksVUFBVSxFQUFFO2dCQUFFTyxFQUFFLEVBQUU7Y0FBRSxDQUFDO2NBQUVULElBQUksRUFBRTtnQkFBRXFLLFFBQVEsRUFBRSxDQUFDO2NBQUU7WUFBRSxDQUNsRCxDQUFDO1lBQ0Q7VUFDRixDQUFDLENBQUMsT0FBT3hULENBQUMsRUFBRTtZQUNWO1lBQ0E7WUFDQWhKLE1BQU0sQ0FBQ2tjLE1BQU0sQ0FBQyx3Q0FBd0MsRUFBRWxULENBQUMsQ0FBQztZQUMxRCxNQUFNaEosTUFBTSxDQUFDeWMsV0FBVyxDQUFDLEdBQUcsQ0FBQztVQUMvQjtRQUNGO1FBRUEsSUFBSW5ZLElBQUksQ0FBQ2dXLFFBQVEsRUFDZjtRQUVGLElBQUksQ0FBQ2lDLFNBQVMsRUFBRTtVQUNkO1VBQ0E7UUFDRjtRQUVBLElBQUkzSixFQUFFLEdBQUcySixTQUFTLENBQUMzSixFQUFFO1FBQ3JCLElBQUksQ0FBQ0EsRUFBRSxFQUNMLE1BQU0zTCxLQUFLLENBQUMsMEJBQTBCLEdBQUdoRSxLQUFLLENBQUNzVCxTQUFTLENBQUNnRyxTQUFTLENBQUMsQ0FBQztRQUV0RSxJQUFJalksSUFBSSxDQUFDaVgsZ0JBQWdCLElBQUkzSSxFQUFFLENBQUM4SixlQUFlLENBQUNwWSxJQUFJLENBQUNpWCxnQkFBZ0IsQ0FBQyxFQUFFO1VBQ3RFO1VBQ0E7UUFDRjs7UUFHQTtRQUNBO1FBQ0E7UUFDQSxJQUFJb0IsV0FBVyxHQUFHclksSUFBSSxDQUFDZ1gsb0JBQW9CLENBQUM5TyxNQUFNO1FBQ2xELE9BQU9tUSxXQUFXLEdBQUcsQ0FBQyxHQUFHLENBQUMsSUFBSXJZLElBQUksQ0FBQ2dYLG9CQUFvQixDQUFDcUIsV0FBVyxHQUFHLENBQUMsQ0FBQyxDQUFDL0osRUFBRSxDQUFDZ0ssV0FBVyxDQUFDaEssRUFBRSxDQUFDLEVBQUU7VUFDM0YrSixXQUFXLEVBQUU7UUFDZjtRQUNBLElBQUlFLGVBQWUsR0FBRyxJQUFJO1FBQzFCLE1BQU1DLGNBQWMsR0FBRyxJQUFJbE0sT0FBTyxDQUFDOEosQ0FBQyxJQUFJbUMsZUFBZSxHQUFHbkMsQ0FBQyxDQUFDO1FBQzVEcFcsSUFBSSxDQUFDZ1gsb0JBQW9CLENBQUN5QixNQUFNLENBQUNKLFdBQVcsRUFBRSxDQUFDLEVBQUU7VUFBQy9KLEVBQUUsRUFBRUEsRUFBRTtVQUFFb0ssUUFBUSxFQUFFSDtRQUFlLENBQUMsQ0FBQztRQUNyRixNQUFNQyxjQUFjO01BQ3RCLENBQUM7TUFFRDtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0FHLGlCQUFpQixFQUFFLGVBQUFBLENBQUEsRUFBa0I7UUFDbkMsT0FBTyxJQUFJLENBQUNYLGtCQUFrQixDQUFDLENBQUM7TUFDbEMsQ0FBQztNQUVEUixhQUFhLEVBQUUsZUFBQUEsQ0FBQSxFQUFrQjtRQUFBLElBQUEzWCxnQkFBQSxFQUFBQyxxQkFBQSxFQUFBQyxzQkFBQSxFQUFBNlksaUJBQUEsRUFBQUMscUJBQUEsRUFBQUMsc0JBQUE7UUFDL0IsSUFBSTlZLElBQUksR0FBRyxJQUFJO1FBQ2Y7UUFDQSxJQUFJK1ksVUFBVSxHQUFHQyxHQUFHLENBQUNuZCxPQUFPLENBQUMsYUFBYSxDQUFDO1FBQzNDLElBQUlrZCxVQUFVLENBQUNFLEtBQUssQ0FBQ2paLElBQUksQ0FBQzRWLFNBQVMsQ0FBQyxDQUFDc0QsUUFBUSxLQUFLLE9BQU8sRUFBRTtVQUN6RCxNQUFNdlcsS0FBSyxDQUFDLDBEQUEwRCxHQUNsRSxxQkFBcUIsQ0FBQztRQUM1Qjs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0EzQyxJQUFJLENBQUMrVixvQkFBb0IsR0FBRyxJQUFJclcsZUFBZSxDQUMzQ00sSUFBSSxDQUFDNFYsU0FBUyxFQUFFO1VBQUM5VSxXQUFXLEVBQUUsQ0FBQztVQUFFQyxXQUFXLEVBQUU7UUFBQyxDQUFDLENBQUM7UUFDckQ7UUFDQTtRQUNBO1FBQ0FmLElBQUksQ0FBQzhWLHlCQUF5QixHQUFHLElBQUlwVyxlQUFlLENBQ2hETSxJQUFJLENBQUM0VixTQUFTLEVBQUU7VUFBQzlVLFdBQVcsRUFBRSxDQUFDO1VBQUVDLFdBQVcsRUFBRTtRQUFDLENBQUMsQ0FBQzs7UUFHckQ7UUFDQTtRQUNBO1FBQ0E7UUFDQSxNQUFNb1ksV0FBVyxHQUFHLE1BQU0sSUFBSTdNLE9BQU8sQ0FBQyxVQUFVQyxPQUFPLEVBQUVDLE1BQU0sRUFBRTtVQUMvRHhNLElBQUksQ0FBQzhWLHlCQUF5QixDQUFDcFUsRUFBRSxDQUM5QjBYLEtBQUssQ0FBQyxDQUFDLENBQ1BDLE9BQU8sQ0FBQztZQUFFQyxRQUFRLEVBQUU7VUFBRSxDQUFDLEVBQUUsVUFBVWxWLEdBQUcsRUFBRUMsTUFBTSxFQUFFO1lBQy9DLElBQUlELEdBQUcsRUFBRW9JLE1BQU0sQ0FBQ3BJLEdBQUcsQ0FBQyxDQUFDLEtBQ2hCbUksT0FBTyxDQUFDbEksTUFBTSxDQUFDO1VBQ3RCLENBQUMsQ0FBQztRQUNOLENBQUMsQ0FBQztRQUVGLElBQUksRUFBRThVLFdBQVcsSUFBSUEsV0FBVyxDQUFDSSxPQUFPLENBQUMsRUFBRTtVQUN6QyxNQUFNNVcsS0FBSyxDQUFDLDBEQUEwRCxHQUNsRSxxQkFBcUIsQ0FBQztRQUM1Qjs7UUFFQTtRQUNBLElBQUk2VyxjQUFjLEdBQUcsTUFBTXhaLElBQUksQ0FBQzhWLHlCQUF5QixDQUFDak0sWUFBWSxDQUNwRXdFLGdCQUFnQixFQUNoQixDQUFDLENBQUMsRUFDRjtVQUFFUixJQUFJLEVBQUU7WUFBRXFLLFFBQVEsRUFBRSxDQUFDO1VBQUUsQ0FBQztVQUFFbkssVUFBVSxFQUFFO1lBQUVPLEVBQUUsRUFBRTtVQUFFO1FBQUUsQ0FDbEQsQ0FBQztRQUVELElBQUltTCxhQUFhLEdBQUcvWSxNQUFNLENBQUNDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRVgsSUFBSSxDQUFDeVcsa0JBQWtCLENBQUM7UUFDOUQsSUFBSStDLGNBQWMsRUFBRTtVQUNsQjtVQUNBQyxhQUFhLENBQUNuTCxFQUFFLEdBQUc7WUFBQ3FELEdBQUcsRUFBRTZILGNBQWMsQ0FBQ2xMO1VBQUUsQ0FBQztVQUMzQztVQUNBO1VBQ0E7VUFDQXRPLElBQUksQ0FBQ2lYLGdCQUFnQixHQUFHdUMsY0FBYyxDQUFDbEwsRUFBRTtRQUMzQzs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBLE1BQU1xRSxrQkFBa0IsSUFBQTlTLGdCQUFBLEdBQUduRSxNQUFNLENBQUM0RSxRQUFRLGNBQUFULGdCQUFBLHdCQUFBQyxxQkFBQSxHQUFmRCxnQkFBQSxDQUFpQlUsUUFBUSxjQUFBVCxxQkFBQSx3QkFBQUMsc0JBQUEsR0FBekJELHFCQUFBLENBQTJCVSxLQUFLLGNBQUFULHNCQUFBLHVCQUFoQ0Esc0JBQUEsQ0FBa0MyWix1QkFBdUI7UUFDcEYsTUFBTTlHLGtCQUFrQixJQUFBZ0csaUJBQUEsR0FBR2xkLE1BQU0sQ0FBQzRFLFFBQVEsY0FBQXNZLGlCQUFBLHdCQUFBQyxxQkFBQSxHQUFmRCxpQkFBQSxDQUFpQnJZLFFBQVEsY0FBQXNZLHFCQUFBLHdCQUFBQyxzQkFBQSxHQUF6QkQscUJBQUEsQ0FBMkJyWSxLQUFLLGNBQUFzWSxzQkFBQSx1QkFBaENBLHNCQUFBLENBQWtDYSx1QkFBdUI7UUFDcEYsSUFBSWhILGtCQUFrQixhQUFsQkEsa0JBQWtCLGVBQWxCQSxrQkFBa0IsQ0FBRXpLLE1BQU0sSUFBSTBLLGtCQUFrQixhQUFsQkEsa0JBQWtCLGVBQWxCQSxrQkFBa0IsQ0FBRTFLLE1BQU0sRUFBRTtVQUM1RCxNQUFNLElBQUl2RixLQUFLLENBQUMsMkdBQTJHLENBQUM7UUFDOUg7UUFDQSxJQUFJaVEsa0JBQWtCLGFBQWxCQSxrQkFBa0IsZUFBbEJBLGtCQUFrQixDQUFFMUssTUFBTSxFQUFFO1VBQzlCdVIsYUFBYSxDQUFDL0MsRUFBRSxHQUFHO1lBQ2pCa0QsTUFBTSxFQUFFSCxhQUFhLENBQUMvQyxFQUFFO1lBQ3hCbUQsSUFBSSxFQUFFakgsa0JBQWtCLENBQUMzVixHQUFHLENBQUU2YyxRQUFRLE9BQUE1TyxNQUFBLENBQVFsTCxJQUFJLENBQUM2VixPQUFPLE9BQUEzSyxNQUFBLENBQUk0TyxRQUFRLENBQUU7VUFDMUUsQ0FBQztVQUNEOVosSUFBSSxDQUFDMFMsYUFBYSxHQUFHO1lBQUVFO1VBQW1CLENBQUM7UUFDN0MsQ0FBQyxNQUNJLElBQUlELGtCQUFrQixhQUFsQkEsa0JBQWtCLGVBQWxCQSxrQkFBa0IsQ0FBRXpLLE1BQU0sRUFBRTtVQUNuQ3VSLGFBQWEsR0FBRztZQUFFTSxJQUFJLEVBQUUsQ0FDdEI7Y0FBRWxELEdBQUcsRUFBRSxDQUNMO2dCQUFFSCxFQUFFLEVBQUU7Y0FBZ0IsQ0FBQyxFQUN2QjtnQkFBRUEsRUFBRSxFQUFFO2tCQUFFSSxHQUFHLEVBQUVuRSxrQkFBa0IsQ0FBQzFWLEdBQUcsQ0FBRTZjLFFBQVEsT0FBQTVPLE1BQUEsQ0FBUWxMLElBQUksQ0FBQzZWLE9BQU8sT0FBQTNLLE1BQUEsQ0FBSTRPLFFBQVEsQ0FBRTtnQkFBRTtjQUFFLENBQUM7WUFDcEYsQ0FBQyxFQUNIO2NBQUVqRCxHQUFHLEVBQUU0QyxhQUFhLENBQUM1QztZQUFJLENBQUM7WUFBRTtZQUM1QjtjQUFFdkksRUFBRSxFQUFFbUwsYUFBYSxDQUFDbkw7WUFBRyxDQUFDO1VBQ3hCLENBQUM7VUFDSHRPLElBQUksQ0FBQzBTLGFBQWEsR0FBRztZQUFFQztVQUFtQixDQUFDO1FBQzdDO1FBRUEsSUFBSXRILGlCQUFpQixHQUFHLElBQUl6QixpQkFBaUIsQ0FDekN5RSxnQkFBZ0IsRUFBRW9MLGFBQWEsRUFBRTtVQUFDOU4sUUFBUSxFQUFFO1FBQUksQ0FBQyxDQUFDOztRQUV0RDtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTNMLElBQUksQ0FBQ2lXLFdBQVcsR0FBR2pXLElBQUksQ0FBQytWLG9CQUFvQixDQUFDM0UsSUFBSSxDQUM3Qy9GLGlCQUFpQixFQUNqQixVQUFVa0UsR0FBRyxFQUFFO1VBQ2J2UCxJQUFJLENBQUNvWCxXQUFXLENBQUNoSCxJQUFJLENBQUNiLEdBQUcsQ0FBQztVQUMxQnZQLElBQUksQ0FBQ2dhLGlCQUFpQixDQUFDLENBQUM7UUFDMUIsQ0FBQyxFQUNEM0UsWUFDSixDQUFDO1FBRURyVixJQUFJLENBQUNrVyxxQkFBcUIsQ0FBQyxDQUFDO01BQzlCLENBQUM7TUFFRDhELGlCQUFpQixFQUFFLFNBQUFBLENBQUEsRUFBWTtRQUM3QixJQUFJaGEsSUFBSSxHQUFHLElBQUk7UUFDZixJQUFJQSxJQUFJLENBQUNzWCxhQUFhLEVBQUU7UUFDeEJ0WCxJQUFJLENBQUNzWCxhQUFhLEdBQUcsSUFBSTtRQUV6QjViLE1BQU0sQ0FBQzhWLEtBQUssQ0FBQyxrQkFBa0I7VUFDN0I7VUFDQSxlQUFleUksU0FBU0EsQ0FBQzFLLEdBQUcsRUFBRTtZQUM1QixJQUFJQSxHQUFHLENBQUNtSCxFQUFFLEtBQUssWUFBWSxFQUFFO2NBQzNCLElBQUluSCxHQUFHLENBQUNrRyxDQUFDLENBQUN5RSxRQUFRLEVBQUU7Z0JBQ2xCO2dCQUNBO2dCQUNBLElBQUlDLGFBQWEsR0FBRzVLLEdBQUcsQ0FBQ2pCLEVBQUU7Z0JBQzFCLEtBQUssTUFBTWtILEVBQUUsSUFBSWpHLEdBQUcsQ0FBQ2tHLENBQUMsQ0FBQ3lFLFFBQVEsRUFBRTtrQkFDL0I7a0JBQ0EsSUFBSSxDQUFDMUUsRUFBRSxDQUFDbEgsRUFBRSxFQUFFO29CQUNWa0gsRUFBRSxDQUFDbEgsRUFBRSxHQUFHNkwsYUFBYTtvQkFDckJBLGFBQWEsR0FBR0EsYUFBYSxDQUFDQyxHQUFHLENBQUNwRixJQUFJLENBQUNxRixHQUFHLENBQUM7a0JBQzdDO2tCQUNBLE1BQU1KLFNBQVMsQ0FBQ3pFLEVBQUUsQ0FBQztnQkFDckI7Z0JBQ0E7Y0FDRjtjQUNBLE1BQU0sSUFBSTdTLEtBQUssQ0FBQyxrQkFBa0IsR0FBR2hFLEtBQUssQ0FBQ3NULFNBQVMsQ0FBQzFDLEdBQUcsQ0FBQyxDQUFDO1lBQzVEO1lBRUEsTUFBTTZFLE9BQU8sR0FBRztjQUNkaE8sY0FBYyxFQUFFLEtBQUs7Y0FDckJHLFlBQVksRUFBRSxLQUFLO2NBQ25CaVAsRUFBRSxFQUFFakc7WUFDTixDQUFDO1lBRUQsSUFBSSxPQUFPQSxHQUFHLENBQUNtSCxFQUFFLEtBQUssUUFBUSxJQUMxQm5ILEdBQUcsQ0FBQ21ILEVBQUUsQ0FBQzFPLFVBQVUsQ0FBQ2hJLElBQUksQ0FBQzZWLE9BQU8sR0FBRyxHQUFHLENBQUMsRUFBRTtjQUN6Q3pCLE9BQU8sQ0FBQ2xSLFVBQVUsR0FBR3FNLEdBQUcsQ0FBQ21ILEVBQUUsQ0FBQzRELEtBQUssQ0FBQ3RhLElBQUksQ0FBQzZWLE9BQU8sQ0FBQzNOLE1BQU0sR0FBRyxDQUFDLENBQUM7WUFDNUQ7O1lBRUE7WUFDQTtZQUNBLElBQUlrTSxPQUFPLENBQUNsUixVQUFVLEtBQUssTUFBTSxFQUFFO2NBQ2pDLElBQUlxTSxHQUFHLENBQUNrRyxDQUFDLENBQUNsUCxZQUFZLEVBQUU7Z0JBQ3RCLE9BQU82TixPQUFPLENBQUNsUixVQUFVO2dCQUN6QmtSLE9BQU8sQ0FBQzdOLFlBQVksR0FBRyxJQUFJO2NBQzdCLENBQUMsTUFBTSxJQUFJeEosQ0FBQyxDQUFDOEQsR0FBRyxDQUFDME8sR0FBRyxDQUFDa0csQ0FBQyxFQUFFLE1BQU0sQ0FBQyxFQUFFO2dCQUMvQnJCLE9BQU8sQ0FBQ2xSLFVBQVUsR0FBR3FNLEdBQUcsQ0FBQ2tHLENBQUMsQ0FBQ3BQLElBQUk7Z0JBQy9CK04sT0FBTyxDQUFDaE8sY0FBYyxHQUFHLElBQUk7Z0JBQzdCZ08sT0FBTyxDQUFDdFAsRUFBRSxHQUFHLElBQUk7Y0FDbkIsQ0FBQyxNQUFNLElBQUksUUFBUSxJQUFJeUssR0FBRyxDQUFDa0csQ0FBQyxJQUFJLFNBQVMsSUFBSWxHLEdBQUcsQ0FBQ2tHLENBQUMsRUFBRTtnQkFDbEQ7Z0JBQ0E7Y0FBQSxDQUNELE1BQU07Z0JBQ0wsTUFBTTlTLEtBQUssQ0FBQyxrQkFBa0IsR0FBR2hFLEtBQUssQ0FBQ3NULFNBQVMsQ0FBQzFDLEdBQUcsQ0FBQyxDQUFDO2NBQ3hEO1lBRUYsQ0FBQyxNQUFNO2NBQ0w7Y0FDQTZFLE9BQU8sQ0FBQ3RQLEVBQUUsR0FBR3lRLE9BQU8sQ0FBQ2hHLEdBQUcsQ0FBQztZQUMzQjtZQUVBLE1BQU12UCxJQUFJLENBQUNxVyxTQUFTLENBQUNrRSxJQUFJLENBQUNuRyxPQUFPLENBQUM7VUFDcEM7VUFFQSxJQUFJO1lBQ0YsT0FBTyxDQUFFcFUsSUFBSSxDQUFDZ1csUUFBUSxJQUNmLENBQUVoVyxJQUFJLENBQUNvWCxXQUFXLENBQUNvRCxPQUFPLENBQUMsQ0FBQyxFQUFFO2NBQ25DO2NBQ0E7Y0FDQSxJQUFJeGEsSUFBSSxDQUFDb1gsV0FBVyxDQUFDbFAsTUFBTSxHQUFHK00sY0FBYyxFQUFFO2dCQUM1QyxJQUFJZ0QsU0FBUyxHQUFHalksSUFBSSxDQUFDb1gsV0FBVyxDQUFDcUQsR0FBRyxDQUFDLENBQUM7Z0JBQ3RDemEsSUFBSSxDQUFDb1gsV0FBVyxDQUFDc0QsS0FBSyxDQUFDLENBQUM7Z0JBRXhCMWEsSUFBSSxDQUFDa1gscUJBQXFCLENBQUM5WixJQUFJLENBQUMsVUFBVWlGLFFBQVEsRUFBRTtrQkFDbERBLFFBQVEsQ0FBQyxDQUFDO2tCQUNWLE9BQU8sSUFBSTtnQkFDYixDQUFDLENBQUM7O2dCQUVGO2dCQUNBO2dCQUNBckMsSUFBSSxDQUFDMmEsbUJBQW1CLENBQUMxQyxTQUFTLENBQUMzSixFQUFFLENBQUM7Z0JBQ3RDO2NBQ0Y7Y0FFQSxNQUFNaUIsR0FBRyxHQUFHdlAsSUFBSSxDQUFDb1gsV0FBVyxDQUFDd0QsS0FBSyxDQUFDLENBQUM7O2NBRXBDO2NBQ0EsTUFBTVgsU0FBUyxDQUFDMUssR0FBRyxDQUFDOztjQUVwQjtjQUNBO2NBQ0EsSUFBSUEsR0FBRyxDQUFDakIsRUFBRSxFQUFFO2dCQUNWdE8sSUFBSSxDQUFDMmEsbUJBQW1CLENBQUNwTCxHQUFHLENBQUNqQixFQUFFLENBQUM7Y0FDbEMsQ0FBQyxNQUFNO2dCQUNMLE1BQU0zTCxLQUFLLENBQUMsMEJBQTBCLEdBQUdoRSxLQUFLLENBQUNzVCxTQUFTLENBQUMxQyxHQUFHLENBQUMsQ0FBQztjQUNoRTtZQUNGO1VBQ0YsQ0FBQyxTQUFTO1lBQ1J2UCxJQUFJLENBQUNzWCxhQUFhLEdBQUcsS0FBSztVQUM1QjtRQUNGLENBQUMsQ0FBQztNQUNKLENBQUM7TUFFRHFELG1CQUFtQixFQUFFLFNBQUFBLENBQVVyTSxFQUFFLEVBQUU7UUFDakMsSUFBSXRPLElBQUksR0FBRyxJQUFJO1FBQ2ZBLElBQUksQ0FBQ2lYLGdCQUFnQixHQUFHM0ksRUFBRTtRQUMxQixPQUFPLENBQUN2UixDQUFDLENBQUN5ZCxPQUFPLENBQUN4YSxJQUFJLENBQUNnWCxvQkFBb0IsQ0FBQyxJQUFJaFgsSUFBSSxDQUFDZ1gsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLENBQUMxSSxFQUFFLENBQUM4SixlQUFlLENBQUNwWSxJQUFJLENBQUNpWCxnQkFBZ0IsQ0FBQyxFQUFFO1VBQ3RILElBQUk0RCxTQUFTLEdBQUc3YSxJQUFJLENBQUNnWCxvQkFBb0IsQ0FBQzRELEtBQUssQ0FBQyxDQUFDO1VBQ2pEQyxTQUFTLENBQUNuQyxRQUFRLENBQUMsQ0FBQztRQUN0QjtNQUNGLENBQUM7TUFFRDtNQUNBb0MsbUJBQW1CLEVBQUUsU0FBQUEsQ0FBU3pkLEtBQUssRUFBRTtRQUNuQzRYLGNBQWMsR0FBRzVYLEtBQUs7TUFDeEIsQ0FBQztNQUNEMGQsa0JBQWtCLEVBQUUsU0FBQUEsQ0FBQSxFQUFXO1FBQzdCOUYsY0FBYyxHQUFHQyxPQUFPLENBQUNDLEdBQUcsQ0FBQ0MsMkJBQTJCLElBQUksSUFBSTtNQUNsRTtJQUNGLENBQUMsQ0FBQztJQUFDUCxzQkFBQTtFQUFBLFNBQUFDLFdBQUE7SUFBQSxPQUFBRCxzQkFBQSxDQUFBQyxXQUFBO0VBQUE7RUFBQUQsc0JBQUE7QUFBQTtFQUFBN1UsSUFBQTtFQUFBK1UsS0FBQTtBQUFBLEc7Ozs7Ozs7Ozs7Ozs7O0lDbGJILElBQUlpRyx3QkFBd0I7SUFBQ3plLE1BQU0sQ0FBQ3JCLElBQUksQ0FBQyxnREFBZ0QsRUFBQztNQUFDQyxPQUFPQSxDQUFDQyxDQUFDLEVBQUM7UUFBQzRmLHdCQUF3QixHQUFDNWYsQ0FBQztNQUFBO0lBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztJQUFDLElBQUlPLG9CQUFvQixDQUFDLENBQUMsRUFBRSxDQUFDLE1BQU1BLG9CQUFvQixDQUFDLENBQUMsRUFBRSxDQUFDO0lBQUMsTUFBQXNmLFNBQUE7SUFBbk0sSUFBSUMsbUJBQW1CLEdBQUcsQ0FBQztJQUUzQjdJLGtCQUFrQixHQUFHLE1BQU07TUFDekIxRCxXQUFXQSxDQUFBLEVBQXNDO1FBQUEsSUFBckM7VUFBRXZCLE9BQU87VUFBRWtGLE1BQU0sR0FBR0EsQ0FBQSxLQUFNLENBQUM7UUFBRSxDQUFDLEdBQUE1SSxTQUFBLENBQUF4QixNQUFBLFFBQUF3QixTQUFBLFFBQUE3SyxTQUFBLEdBQUE2SyxTQUFBLE1BQUcsQ0FBQyxDQUFDO1FBQzdDLElBQUkwRCxPQUFPLEtBQUt2TyxTQUFTLEVBQUUsTUFBTThELEtBQUssQ0FBQyxzQkFBc0IsQ0FBQztRQUU5REosT0FBTyxDQUFDLFlBQVksQ0FBQyxJQUFJQSxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM0WSxLQUFLLENBQUNDLG1CQUFtQixDQUNwRSxnQkFBZ0IsRUFBRSxzQkFBc0IsRUFBRSxDQUFDLENBQUM7UUFFaEQsSUFBSSxDQUFDQyxRQUFRLEdBQUdqTyxPQUFPO1FBQ3ZCLElBQUksQ0FBQ2tPLE9BQU8sR0FBR2hKLE1BQU07UUFDckIsSUFBSSxDQUFDaUosTUFBTSxHQUFHLElBQUk3ZixNQUFNLENBQUM4ZixrQkFBa0IsQ0FBQyxDQUFDO1FBQzdDLElBQUksQ0FBQ0MsUUFBUSxHQUFHLENBQUMsQ0FBQztRQUNsQixJQUFJLENBQUNDLFNBQVMsR0FBRyxJQUFJO1FBQ3JCLElBQUksQ0FBQ3ZGLGFBQWEsR0FBRyxJQUFJN0osT0FBTyxDQUFDOEosQ0FBQyxJQUFJLElBQUksQ0FBQ3NGLFNBQVMsR0FBR3RGLENBQUMsQ0FBQyxDQUFDbFIsSUFBSSxDQUFDLE1BQU0sSUFBSSxDQUFDeVcsUUFBUSxHQUFHLElBQUksQ0FBQztRQUMxRixJQUFJLENBQUNDLE1BQU0sR0FBRyxJQUFJaFgsZUFBZSxDQUFDaVgsc0JBQXNCLENBQUM7VUFDdkR6TztRQUFPLENBQUMsQ0FBQztRQUNYO1FBQ0E7UUFDQTtRQUNBLElBQUksQ0FBQzBPLHVDQUF1QyxHQUFHLENBQUM7UUFFaEQsTUFBTTliLElBQUksR0FBRyxJQUFJO1FBQ2pCLElBQUksQ0FBQytiLGFBQWEsQ0FBQyxDQUFDLENBQUM1YSxPQUFPLENBQUM2YSxZQUFZLElBQUk7VUFDM0MsSUFBSSxDQUFDQSxZQUFZLENBQUMsR0FBRyxTQUFTO1VBQUEsR0FBVztZQUN2Q2hjLElBQUksQ0FBQ2ljLGNBQWMsQ0FBQ0QsWUFBWSxFQUFFamYsQ0FBQyxDQUFDbWYsT0FBTyxDQUFDeFMsU0FBUyxDQUFDLENBQUM7VUFDekQsQ0FBQztRQUNILENBQUMsQ0FBQztNQUNKO01BRUFxSywyQkFBMkJBLENBQUNvSSxNQUFNLEVBQUU7UUFDbEMsT0FBTyxJQUFJLENBQUNDLDRCQUE0QixDQUFDRCxNQUFNLENBQUM7TUFDbEQ7TUFFQSxNQUFNQyw0QkFBNEJBLENBQUNELE1BQU0sRUFBRTtRQUN6QyxFQUFFLElBQUksQ0FBQ0wsdUNBQXVDO1FBRTlDdlosT0FBTyxDQUFDLFlBQVksQ0FBQyxJQUFJQSxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM0WSxLQUFLLENBQUNDLG1CQUFtQixDQUNwRSxnQkFBZ0IsRUFBRSxpQkFBaUIsRUFBRSxDQUFDLENBQUM7UUFFM0MsTUFBTXBiLElBQUksR0FBRyxJQUFJO1FBQ2pCLE1BQU0sSUFBSSxDQUFDdWIsTUFBTSxDQUFDYyxPQUFPLENBQUMsa0JBQWtCO1VBQzFDcmMsSUFBSSxDQUFDeWIsUUFBUSxDQUFDVSxNQUFNLENBQUNwWCxHQUFHLENBQUMsR0FBR29YLE1BQU07VUFDbEM7VUFDQTtVQUNBLE1BQU1uYyxJQUFJLENBQUNzYyxTQUFTLENBQUNILE1BQU0sQ0FBQztVQUM1QixFQUFFbmMsSUFBSSxDQUFDOGIsdUNBQXVDO1FBQ2hELENBQUMsQ0FBQztRQUNGLE1BQU0sSUFBSSxDQUFDM0YsYUFBYTtNQUMxQjs7TUFFQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQSxNQUFNb0csWUFBWUEsQ0FBQ3pYLEVBQUUsRUFBRTtRQUNyQjtRQUNBO1FBQ0E7UUFDQSxJQUFJLENBQUMsSUFBSSxDQUFDMFgsTUFBTSxDQUFDLENBQUMsRUFDaEIsTUFBTSxJQUFJN1osS0FBSyxDQUFDLG1EQUFtRCxDQUFDO1FBRXRFLE9BQU8sSUFBSSxDQUFDOFksUUFBUSxDQUFDM1csRUFBRSxDQUFDO1FBRXhCdkMsT0FBTyxDQUFDLFlBQVksQ0FBQyxJQUFJQSxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM0WSxLQUFLLENBQUNDLG1CQUFtQixDQUNwRSxnQkFBZ0IsRUFBRSxpQkFBaUIsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUU1QyxJQUFJcmUsQ0FBQyxDQUFDeWQsT0FBTyxDQUFDLElBQUksQ0FBQ2lCLFFBQVEsQ0FBQyxJQUN4QixJQUFJLENBQUNLLHVDQUF1QyxLQUFLLENBQUMsRUFBRTtVQUN0RCxNQUFNLElBQUksQ0FBQ1csS0FBSyxDQUFDLENBQUM7UUFDcEI7TUFDRjtNQUNBLE1BQU1BLEtBQUtBLENBQUM3YyxPQUFPLEVBQUU7UUFDbkJBLE9BQU8sR0FBR0EsT0FBTyxJQUFJLENBQUMsQ0FBQzs7UUFFdkI7UUFDQTtRQUNBLElBQUksQ0FBRSxJQUFJLENBQUM0YyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUU1YyxPQUFPLENBQUM4YyxjQUFjLEVBQzdDLE1BQU0vWixLQUFLLENBQUMsNkJBQTZCLENBQUM7O1FBRTVDO1FBQ0E7UUFDQSxNQUFNLElBQUksQ0FBQzJZLE9BQU8sQ0FBQyxDQUFDO1FBQ3BCL1ksT0FBTyxDQUFDLFlBQVksQ0FBQyxJQUFJQSxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM0WSxLQUFLLENBQUNDLG1CQUFtQixDQUNwRSxnQkFBZ0IsRUFBRSxzQkFBc0IsRUFBRSxDQUFDLENBQUMsQ0FBQzs7UUFFakQ7UUFDQTtRQUNBLElBQUksQ0FBQ0ssUUFBUSxHQUFHLElBQUk7TUFDdEI7O01BRUE7TUFDQTtNQUNBLE1BQU1rQixLQUFLQSxDQUFBLEVBQUc7UUFDWixNQUFNM2MsSUFBSSxHQUFHLElBQUk7UUFDakIsSUFBSSxDQUFDdWIsTUFBTSxDQUFDcUIsU0FBUyxDQUFDLFlBQVk7VUFDaEMsSUFBSTVjLElBQUksQ0FBQ3djLE1BQU0sQ0FBQyxDQUFDLEVBQ2YsTUFBTTdaLEtBQUssQ0FBQywwQ0FBMEMsQ0FBQztVQUV6RCxJQUFJLENBQUMzQyxJQUFJLENBQUMwYixTQUFTLEVBQUU7WUFDbkIsTUFBTSxJQUFJL1ksS0FBSyxDQUFDLGtCQUFrQixDQUFDO1VBQ3JDO1VBRUEzQyxJQUFJLENBQUMwYixTQUFTLENBQUMsQ0FBQztVQUNoQjFiLElBQUksQ0FBQzJiLFFBQVEsR0FBRyxJQUFJO1FBQ3RCLENBQUMsQ0FBQztNQUNKOztNQUVBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBLE1BQU1rQixVQUFVQSxDQUFDelksR0FBRyxFQUFFO1FBQ3BCLElBQUlwRSxJQUFJLEdBQUcsSUFBSTtRQUNmLE1BQU0sSUFBSSxDQUFDdWIsTUFBTSxDQUFDYyxPQUFPLENBQUMsWUFBWTtVQUNwQyxJQUFJcmMsSUFBSSxDQUFDd2MsTUFBTSxDQUFDLENBQUMsRUFDZixNQUFNN1osS0FBSyxDQUFDLGlEQUFpRCxDQUFDO1VBQ2hFM0MsSUFBSSxDQUFDeWMsS0FBSyxDQUFDO1lBQUNDLGNBQWMsRUFBRTtVQUFJLENBQUMsQ0FBQztVQUNsQyxNQUFNdFksR0FBRztRQUNYLENBQUMsQ0FBQztNQUNKOztNQUVBO01BQ0E7TUFDQTtNQUNBLE1BQU0wWSxPQUFPQSxDQUFDQyxFQUFFLEVBQUU7UUFDaEIsSUFBSS9jLElBQUksR0FBRyxJQUFJO1FBQ2YsTUFBTSxJQUFJLENBQUN1YixNQUFNLENBQUNxQixTQUFTLENBQUMsa0JBQWtCO1VBQzVDLElBQUksQ0FBQzVjLElBQUksQ0FBQ3djLE1BQU0sQ0FBQyxDQUFDLEVBQ2hCLE1BQU03WixLQUFLLENBQUMsdURBQXVELENBQUM7VUFDdEUsTUFBTW9hLEVBQUUsQ0FBQyxDQUFDO1FBQ1osQ0FBQyxDQUFDO01BQ0o7TUFDQWhCLGFBQWFBLENBQUEsRUFBRztRQUNkLElBQUksSUFBSSxDQUFDVixRQUFRLEVBQ2YsT0FBTyxDQUFDLGFBQWEsRUFBRSxTQUFTLEVBQUUsYUFBYSxFQUFFLFNBQVMsQ0FBQyxDQUFDLEtBRTVELE9BQU8sQ0FBQyxPQUFPLEVBQUUsU0FBUyxFQUFFLFNBQVMsQ0FBQztNQUMxQztNQUNBbUIsTUFBTUEsQ0FBQSxFQUFHO1FBQ1AsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDYixRQUFRO01BQ3hCO01BQ0FNLGNBQWNBLENBQUNELFlBQVksRUFBRTFSLElBQUksRUFBRTtRQUNqQyxNQUFNdEssSUFBSSxHQUFHLElBQUk7UUFDakIsSUFBSSxDQUFDdWIsTUFBTSxDQUFDcUIsU0FBUyxDQUFDLGtCQUFrQjtVQUN0QztVQUNBLElBQUksQ0FBQzVjLElBQUksQ0FBQ3liLFFBQVEsRUFDaEI7O1VBRUY7VUFDQSxNQUFNemIsSUFBSSxDQUFDNGIsTUFBTSxDQUFDb0IsV0FBVyxDQUFDaEIsWUFBWSxDQUFDLENBQUNpQixLQUFLLENBQUMsSUFBSSxFQUFFM1MsSUFBSSxDQUFDO1VBQzdEO1VBQ0E7VUFDQSxJQUFJLENBQUN0SyxJQUFJLENBQUN3YyxNQUFNLENBQUMsQ0FBQyxJQUNiUixZQUFZLEtBQUssT0FBTyxJQUFJQSxZQUFZLEtBQUssYUFBYyxFQUFFO1lBQ2hFLE1BQU0sSUFBSXJaLEtBQUssQ0FBQyxNQUFNLEdBQUdxWixZQUFZLEdBQUcsc0JBQXNCLENBQUM7VUFDakU7O1VBRUE7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBLEtBQUssTUFBTWtCLFFBQVEsSUFBSXhjLE1BQU0sQ0FBQ3FILElBQUksQ0FBQy9ILElBQUksQ0FBQ3liLFFBQVEsQ0FBQyxFQUFFO1lBQ2pELElBQUlVLE1BQU0sR0FBR25jLElBQUksQ0FBQ3liLFFBQVEsSUFBSXpiLElBQUksQ0FBQ3liLFFBQVEsQ0FBQ3lCLFFBQVEsQ0FBQztZQUNyRCxJQUFJLENBQUNmLE1BQU0sRUFBRTtZQUNiLElBQUk5WixRQUFRLEdBQUc4WixNQUFNLENBQUMsR0FBRyxHQUFHSCxZQUFZLENBQUM7WUFDekM7O1lBRUEzWixRQUFRLEtBQ0wsTUFBTUEsUUFBUSxDQUFDNGEsS0FBSyxDQUNuQixJQUFJLEVBQ0pkLE1BQU0sQ0FBQzFPLG9CQUFvQixHQUFHbkQsSUFBSSxHQUFHM0wsS0FBSyxDQUFDbEIsS0FBSyxDQUFDNk0sSUFBSSxDQUN2RCxDQUFDLENBQUM7VUFDTjtRQUNGLENBQUMsQ0FBQztNQUNKOztNQUVBO01BQ0E7TUFDQTtNQUNBO01BQ0EsTUFBTWdTLFNBQVNBLENBQUNILE1BQU0sRUFBRTtRQUN0QixJQUFJL0IsR0FBRyxHQUFHLElBQUksQ0FBQ2lCLFFBQVEsR0FBR2MsTUFBTSxDQUFDZ0IsWUFBWSxHQUFHaEIsTUFBTSxDQUFDaUIsTUFBTTtRQUM3RCxJQUFJLENBQUNoRCxHQUFHLEVBQ047UUFDRjtRQUNBLE1BQU0sSUFBSSxDQUFDd0IsTUFBTSxDQUFDeUIsSUFBSSxDQUFDQyxZQUFZLENBQUMsT0FBTy9OLEdBQUcsRUFBRXpLLEVBQUUsS0FBSztVQUNyRCxJQUFJLENBQUMvSCxDQUFDLENBQUM4RCxHQUFHLENBQUMsSUFBSSxDQUFDNGEsUUFBUSxFQUFFVSxNQUFNLENBQUNwWCxHQUFHLENBQUMsRUFDbkMsTUFBTXBDLEtBQUssQ0FBQyxpREFBaUQsQ0FBQztVQUNoRSxNQUFBMUIsSUFBQSxHQUEyQmtiLE1BQU0sQ0FBQzFPLG9CQUFvQixHQUFHOEIsR0FBRyxHQUN0RDVRLEtBQUssQ0FBQ2xCLEtBQUssQ0FBQzhSLEdBQUcsQ0FBQztZQURoQjtjQUFFeEs7WUFBZSxDQUFDLEdBQUE5RCxJQUFBO1lBQVIrTSxNQUFNLEdBQUFnTix3QkFBQSxDQUFBL1osSUFBQSxFQUFBZ2EsU0FBQTtVQUV0QixJQUFJLElBQUksQ0FBQ0ksUUFBUSxFQUNmLE1BQU1qQixHQUFHLENBQUN0VixFQUFFLEVBQUVrSixNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQztVQUFBLEtBRTdCLE1BQU1vTSxHQUFHLENBQUN0VixFQUFFLEVBQUVrSixNQUFNLENBQUM7UUFDekIsQ0FBQyxDQUFDO01BQ0o7SUFDRixDQUFDOztJQUVEO0lBQ0F3RSxhQUFhLEdBQUcsTUFBTTtNQUNwQjdELFdBQVdBLENBQUN1RCxXQUFXLEVBQUVuRixTQUFTLEVBQWdDO1FBQUEsSUFBOUJVLG9CQUFvQixHQUFBL0QsU0FBQSxDQUFBeEIsTUFBQSxRQUFBd0IsU0FBQSxRQUFBN0ssU0FBQSxHQUFBNkssU0FBQSxNQUFHLEtBQUs7UUFDOUQsSUFBSSxDQUFDNlQsWUFBWSxHQUFHckwsV0FBVztRQUMvQkEsV0FBVyxDQUFDNkosYUFBYSxDQUFDLENBQUMsQ0FBQzVhLE9BQU8sQ0FBRXhELElBQUksSUFBSztVQUM1QyxJQUFJb1AsU0FBUyxDQUFDcFAsSUFBSSxDQUFDLEVBQUU7WUFDbkIsSUFBSSxDQUFDLEdBQUcsR0FBR0EsSUFBSSxDQUFDLEdBQUdvUCxTQUFTLENBQUNwUCxJQUFJLENBQUM7VUFDcEMsQ0FBQyxNQUFNLElBQUlBLElBQUksS0FBSyxhQUFhLElBQUlvUCxTQUFTLENBQUMySCxLQUFLLEVBQUU7WUFDcEQ7WUFDQTtZQUNBO1lBQ0E7WUFDQSxJQUFJLENBQUN5SSxZQUFZLEdBQUcsZ0JBQWdCclksRUFBRSxFQUFFa0osTUFBTSxFQUFFd1AsTUFBTSxFQUFFO2NBQ3RELE1BQU16USxTQUFTLENBQUMySCxLQUFLLENBQUM1UCxFQUFFLEVBQUVrSixNQUFNLENBQUM7WUFDbkMsQ0FBQztVQUNIO1FBQ0YsQ0FBQyxDQUFDO1FBQ0YsSUFBSSxDQUFDZ0ksUUFBUSxHQUFHLEtBQUs7UUFDckIsSUFBSSxDQUFDalIsR0FBRyxHQUFHbVcsbUJBQW1CLEVBQUU7UUFDaEMsSUFBSSxDQUFDek4sb0JBQW9CLEdBQUdBLG9CQUFvQjtNQUNsRDtNQUVBLE1BQU01SyxJQUFJQSxDQUFBLEVBQUc7UUFDWCxJQUFJLElBQUksQ0FBQ21ULFFBQVEsRUFBRTtRQUNuQixJQUFJLENBQUNBLFFBQVEsR0FBRyxJQUFJO1FBQ3BCLE1BQU0sSUFBSSxDQUFDdUgsWUFBWSxDQUFDaEIsWUFBWSxDQUFDLElBQUksQ0FBQ3hYLEdBQUcsQ0FBQztNQUNoRDtJQUNGLENBQUM7SUFBQzhQLHNCQUFBO0VBQUEsU0FBQUMsV0FBQTtJQUFBLE9BQUFELHNCQUFBLENBQUFDLFdBQUE7RUFBQTtFQUFBRCxzQkFBQTtBQUFBO0VBQUE3VSxJQUFBO0VBQUErVSxLQUFBO0FBQUEsRzs7Ozs7Ozs7Ozs7QUN2T0Z4WSxNQUFNLENBQUNraEIsTUFBTSxDQUFDO0VBQUNuaUIsVUFBVSxFQUFDQSxDQUFBLEtBQUlBO0FBQVUsQ0FBQyxDQUFDO0FBQW5DLE1BQU1BLFVBQVUsQ0FBQztFQUN0QnFULFdBQVdBLENBQUMrTyxlQUFlLEVBQUU7SUFDM0IsSUFBSSxDQUFDQyxnQkFBZ0IsR0FBR0QsZUFBZTtJQUN2QztJQUNBLElBQUksQ0FBQ0UsZUFBZSxHQUFHLElBQUlDLEdBQUcsQ0FBQyxDQUFDO0VBQ2xDOztFQUVBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU03VCxLQUFLQSxDQUFDL0csY0FBYyxFQUFFNkIsRUFBRSxFQUFFMFEsRUFBRSxFQUFFblQsUUFBUSxFQUFFO0lBQzVDLE1BQU1yQyxJQUFJLEdBQUcsSUFBSTtJQUdqQjhkLEtBQUssQ0FBQzdhLGNBQWMsRUFBRThhLE1BQU0sQ0FBQztJQUM3QkQsS0FBSyxDQUFDdEksRUFBRSxFQUFFOVUsTUFBTSxDQUFDOztJQUdqQjtJQUNBO0lBQ0EsSUFBSVYsSUFBSSxDQUFDNGQsZUFBZSxDQUFDL2MsR0FBRyxDQUFDMlUsRUFBRSxDQUFDLEVBQUU7TUFDaEN4VixJQUFJLENBQUM0ZCxlQUFlLENBQUNJLEdBQUcsQ0FBQ3hJLEVBQUUsQ0FBQyxDQUFDcEYsSUFBSSxDQUFDL04sUUFBUSxDQUFDO01BQzNDO0lBQ0Y7SUFFQSxNQUFNMEssU0FBUyxHQUFHLENBQUMxSyxRQUFRLENBQUM7SUFDNUJyQyxJQUFJLENBQUM0ZCxlQUFlLENBQUNwTyxHQUFHLENBQUNnRyxFQUFFLEVBQUV6SSxTQUFTLENBQUM7SUFFdkMsSUFBSTtNQUNGLElBQUl3QyxHQUFHLEdBQ0wsQ0FBQyxNQUFNdlAsSUFBSSxDQUFDMmQsZ0JBQWdCLENBQUM5VCxZQUFZLENBQUM1RyxjQUFjLEVBQUU7UUFDeEQ4QixHQUFHLEVBQUVEO01BQ1AsQ0FBQyxDQUFDLEtBQUssSUFBSTtNQUNiO01BQ0E7TUFDQSxPQUFPaUksU0FBUyxDQUFDN0UsTUFBTSxHQUFHLENBQUMsRUFBRTtRQUMzQjtRQUNBO1FBQ0E7UUFDQTtRQUNBNkUsU0FBUyxDQUFDME4sR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUU5YixLQUFLLENBQUNsQixLQUFLLENBQUM4UixHQUFHLENBQUMsQ0FBQztNQUN6QztJQUNGLENBQUMsQ0FBQyxPQUFPN0ssQ0FBQyxFQUFFO01BQ1YsT0FBT3FJLFNBQVMsQ0FBQzdFLE1BQU0sR0FBRyxDQUFDLEVBQUU7UUFDM0I2RSxTQUFTLENBQUMwTixHQUFHLENBQUMsQ0FBQyxDQUFDL1YsQ0FBQyxDQUFDO01BQ3BCO0lBQ0YsQ0FBQyxTQUFTO01BQ1I7TUFDQTtNQUNBMUUsSUFBSSxDQUFDNGQsZUFBZSxDQUFDSyxNQUFNLENBQUN6SSxFQUFFLENBQUM7SUFDakM7RUFDRjtBQUNGLEM7Ozs7Ozs7Ozs7O0FDMURBLElBQUkwSSxtQkFBbUIsR0FBRyxDQUFDaEosT0FBTyxDQUFDQyxHQUFHLENBQUNnSiwwQkFBMEIsSUFBSSxFQUFFO0FBQ3ZFLElBQUlDLG1CQUFtQixHQUFHLENBQUNsSixPQUFPLENBQUNDLEdBQUcsQ0FBQ2tKLDBCQUEwQixJQUFJLEVBQUUsR0FBRyxJQUFJO0FBRTlFMUssb0JBQW9CLEdBQUcsU0FBQUEsQ0FBVS9ULE9BQU8sRUFBRTtFQUN4QyxNQUFNSSxJQUFJLEdBQUcsSUFBSTtFQUNqQkEsSUFBSSxDQUFDc2UsUUFBUSxHQUFHMWUsT0FBTztFQUV2QkksSUFBSSxDQUFDdUwsa0JBQWtCLEdBQUczTCxPQUFPLENBQUN5TCxpQkFBaUI7RUFDbkRyTCxJQUFJLENBQUN1ZSxZQUFZLEdBQUczZSxPQUFPLENBQUNnVSxXQUFXO0VBQ3ZDNVQsSUFBSSxDQUFDcWIsUUFBUSxHQUFHemIsT0FBTyxDQUFDd04sT0FBTztFQUMvQnBOLElBQUksQ0FBQ3VkLFlBQVksR0FBRzNkLE9BQU8sQ0FBQ3NTLFdBQVc7RUFDdkNsUyxJQUFJLENBQUN3ZSxjQUFjLEdBQUcsRUFBRTtFQUN4QnhlLElBQUksQ0FBQ2dXLFFBQVEsR0FBRyxLQUFLO0VBRXJCaFcsSUFBSSxDQUFDeWUsT0FBTyxHQUFHemUsSUFBSSxDQUFDdWUsWUFBWSxDQUFDM1Msd0JBQXdCLENBQ3ZENUwsSUFBSSxDQUFDdUwsa0JBQWtCLENBQUM7O0VBRTFCO0VBQ0E7RUFDQXZMLElBQUksQ0FBQzBlLFFBQVEsR0FBRyxJQUFJOztFQUVwQjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBMWUsSUFBSSxDQUFDMmUsNEJBQTRCLEdBQUcsQ0FBQztFQUNyQzNlLElBQUksQ0FBQzRlLGNBQWMsR0FBRyxFQUFFLENBQUMsQ0FBQzs7RUFFMUI7RUFDQTtFQUNBNWUsSUFBSSxDQUFDNmUsc0JBQXNCLEdBQUc5aEIsQ0FBQyxDQUFDK2hCLFFBQVEsQ0FDdEM5ZSxJQUFJLENBQUMrZSxpQ0FBaUMsRUFDdEMvZSxJQUFJLENBQUN1TCxrQkFBa0IsQ0FBQzNMLE9BQU8sQ0FBQ29mLGlCQUFpQixJQUFJZCxtQkFBbUIsQ0FBQyxRQUFRLENBQUM7O0VBRXBGO0VBQ0FsZSxJQUFJLENBQUNpZixVQUFVLEdBQUcsSUFBSXZqQixNQUFNLENBQUM4ZixrQkFBa0IsQ0FBQyxDQUFDO0FBR25ELENBQUM7QUFFRHplLENBQUMsQ0FBQzRJLE1BQU0sQ0FBQ2dPLG9CQUFvQixDQUFDblcsU0FBUyxFQUFFO0VBQ3ZDcVcsS0FBSyxFQUFFLGVBQUFBLENBQUEsRUFBa0I7SUFDdkIsTUFBTTdULElBQUksR0FBRyxJQUFJO0lBQ2pCLE1BQU1KLE9BQU8sR0FBR0ksSUFBSSxDQUFDc2UsUUFBUTtJQUM3QixNQUFNWSxlQUFlLEdBQUcsTUFBTWxMLFNBQVMsQ0FDckNoVSxJQUFJLENBQUN1TCxrQkFBa0IsRUFBRSxVQUFVb00sWUFBWSxFQUFFO01BQy9DO01BQ0E7TUFDQTtNQUNBLE1BQU1qVSxLQUFLLEdBQUdDLFNBQVMsQ0FBQ0MsZ0JBQWdCLENBQUMsQ0FBQztNQUMxQyxJQUFJRixLQUFLLEVBQ1AxRCxJQUFJLENBQUM0ZSxjQUFjLENBQUN4TyxJQUFJLENBQUMxTSxLQUFLLENBQUNHLFVBQVUsQ0FBQyxDQUFDLENBQUM7TUFDOUM7TUFDQTtNQUNBO01BQ0EsSUFBSTdELElBQUksQ0FBQzJlLDRCQUE0QixLQUFLLENBQUMsRUFDekMzZSxJQUFJLENBQUM2ZSxzQkFBc0IsQ0FBQyxDQUFDO0lBQ2pDLENBQ0YsQ0FBQztJQUNEN2UsSUFBSSxDQUFDd2UsY0FBYyxDQUFDcE8sSUFBSSxDQUFDLGtCQUFrQjtNQUFFLE1BQU04TyxlQUFlLENBQUNyYyxJQUFJLENBQUMsQ0FBQztJQUFFLENBQUMsQ0FBQzs7SUFFN0U7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQSxJQUFJakQsT0FBTyxDQUFDcVQscUJBQXFCLEVBQUU7TUFDakNqVCxJQUFJLENBQUNpVCxxQkFBcUIsR0FBR3JULE9BQU8sQ0FBQ3FULHFCQUFxQjtJQUM1RCxDQUFDLE1BQU07TUFDTCxNQUFNa00sZUFBZSxHQUNmbmYsSUFBSSxDQUFDdUwsa0JBQWtCLENBQUMzTCxPQUFPLENBQUN3ZixpQkFBaUIsSUFDakRwZixJQUFJLENBQUN1TCxrQkFBa0IsQ0FBQzNMLE9BQU8sQ0FBQ3lmLGdCQUFnQjtNQUFJO01BQ3BEakIsbUJBQW1CO01BQ3pCLE1BQU1rQixjQUFjLEdBQUc1akIsTUFBTSxDQUFDNmpCLFdBQVcsQ0FDdkN4aUIsQ0FBQyxDQUFDRyxJQUFJLENBQUM4QyxJQUFJLENBQUM2ZSxzQkFBc0IsRUFBRTdlLElBQUksQ0FBQyxFQUFFbWYsZUFBZSxDQUFDO01BQzdEbmYsSUFBSSxDQUFDd2UsY0FBYyxDQUFDcE8sSUFBSSxDQUFDLFlBQVk7UUFDbkMxVSxNQUFNLENBQUM4akIsYUFBYSxDQUFDRixjQUFjLENBQUM7TUFDdEMsQ0FBQyxDQUFDO0lBQ0o7O0lBRUE7SUFDQSxNQUFNLElBQUksQ0FBQ1AsaUNBQWlDLENBQUMsQ0FBQztJQUU5Q3hjLE9BQU8sQ0FBQyxZQUFZLENBQUMsSUFBSUEsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDNFksS0FBSyxDQUFDQyxtQkFBbUIsQ0FDcEUsZ0JBQWdCLEVBQUUseUJBQXlCLEVBQUUsQ0FBQyxDQUFDO0VBQ3JELENBQUM7RUFDRDtFQUNBMkQsaUNBQWlDLEVBQUUsZUFBQUEsQ0FBQSxFQUFrQjtJQUNuRCxJQUFJL2UsSUFBSSxHQUFHLElBQUk7SUFDZixJQUFJQSxJQUFJLENBQUMyZSw0QkFBNEIsR0FBRyxDQUFDLEVBQ3ZDO0lBQ0YsRUFBRTNlLElBQUksQ0FBQzJlLDRCQUE0QjtJQUNuQyxNQUFNM2UsSUFBSSxDQUFDaWYsVUFBVSxDQUFDNUMsT0FBTyxDQUFDLGtCQUFrQjtNQUM5QyxNQUFNcmMsSUFBSSxDQUFDeWYsVUFBVSxDQUFDLENBQUM7SUFDekIsQ0FBQyxDQUFDO0VBQ0osQ0FBQztFQUVEO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQUMsZUFBZSxFQUFFLFNBQUFBLENBQUEsRUFBVztJQUMxQixJQUFJMWYsSUFBSSxHQUFHLElBQUk7SUFDZjtJQUNBO0lBQ0EsRUFBRUEsSUFBSSxDQUFDMmUsNEJBQTRCO0lBQ25DO0lBQ0EzZSxJQUFJLENBQUNpZixVQUFVLENBQUM1QyxPQUFPLENBQUMsWUFBVyxDQUFDLENBQUMsQ0FBQzs7SUFFdEM7SUFDQTtJQUNBLElBQUlyYyxJQUFJLENBQUMyZSw0QkFBNEIsS0FBSyxDQUFDLEVBQ3pDLE1BQU0sSUFBSWhjLEtBQUssQ0FBQyxrQ0FBa0MsR0FDbEMzQyxJQUFJLENBQUMyZSw0QkFBNEIsQ0FBQztFQUN0RCxDQUFDO0VBQ0RnQixjQUFjLEVBQUUsZUFBQUEsQ0FBQSxFQUFpQjtJQUMvQixJQUFJM2YsSUFBSSxHQUFHLElBQUk7SUFDZjtJQUNBLElBQUlBLElBQUksQ0FBQzJlLDRCQUE0QixLQUFLLENBQUMsRUFDekMsTUFBTSxJQUFJaGMsS0FBSyxDQUFDLGtDQUFrQyxHQUNsQzNDLElBQUksQ0FBQzJlLDRCQUE0QixDQUFDO0lBQ3BEO0lBQ0E7SUFDQSxNQUFNM2UsSUFBSSxDQUFDaWYsVUFBVSxDQUFDNUMsT0FBTyxDQUFDLGtCQUFrQjtNQUM5QyxNQUFNcmMsSUFBSSxDQUFDeWYsVUFBVSxDQUFDLENBQUM7SUFDekIsQ0FBQyxDQUFDO0VBQ0osQ0FBQztFQUVELE1BQU1BLFVBQVVBLENBQUEsRUFBRztJQUNqQixJQUFJemYsSUFBSSxHQUFHLElBQUk7SUFDZixFQUFFQSxJQUFJLENBQUMyZSw0QkFBNEI7SUFFbkMsSUFBSTNlLElBQUksQ0FBQ2dXLFFBQVEsRUFDZjtJQUVGLElBQUk0SixLQUFLLEdBQUcsS0FBSztJQUNqQixJQUFJQyxVQUFVO0lBQ2QsSUFBSUMsVUFBVSxHQUFHOWYsSUFBSSxDQUFDMGUsUUFBUTtJQUM5QixJQUFJLENBQUNvQixVQUFVLEVBQUU7TUFDZkYsS0FBSyxHQUFHLElBQUk7TUFDWjtNQUNBRSxVQUFVLEdBQUc5ZixJQUFJLENBQUNxYixRQUFRLEdBQUcsRUFBRSxHQUFHLElBQUl6VyxlQUFlLENBQUNxSyxNQUFNLENBQUQsQ0FBQztJQUM5RDtJQUVBalAsSUFBSSxDQUFDaVQscUJBQXFCLElBQUlqVCxJQUFJLENBQUNpVCxxQkFBcUIsQ0FBQyxDQUFDOztJQUUxRDtJQUNBLElBQUk4TSxjQUFjLEdBQUcvZixJQUFJLENBQUM0ZSxjQUFjO0lBQ3hDNWUsSUFBSSxDQUFDNGUsY0FBYyxHQUFHLEVBQUU7O0lBRXhCO0lBQ0EsSUFBSTtNQUNGaUIsVUFBVSxHQUFHLE1BQU03ZixJQUFJLENBQUN5ZSxPQUFPLENBQUNsTyxhQUFhLENBQUN2USxJQUFJLENBQUNxYixRQUFRLENBQUM7SUFDOUQsQ0FBQyxDQUFDLE9BQU8zVyxDQUFDLEVBQUU7TUFDVixJQUFJa2IsS0FBSyxJQUFJLE9BQU9sYixDQUFDLENBQUNzYixJQUFLLEtBQUssUUFBUSxFQUFFO1FBQ3hDO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQSxNQUFNaGdCLElBQUksQ0FBQ3VkLFlBQVksQ0FBQ1YsVUFBVSxDQUM5QixJQUFJbGEsS0FBSyxDQUNMLGdDQUFnQyxHQUNoQ3NkLElBQUksQ0FBQ2hPLFNBQVMsQ0FBQ2pTLElBQUksQ0FBQ3VMLGtCQUFrQixDQUFDLEdBQUcsSUFBSSxHQUFHN0csQ0FBQyxDQUFDd2IsT0FBTyxDQUFDLENBQUM7TUFDdEU7O01BRUE7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0EzVixLQUFLLENBQUMvTSxTQUFTLENBQUM0UyxJQUFJLENBQUM2TSxLQUFLLENBQUNqZCxJQUFJLENBQUM0ZSxjQUFjLEVBQUVtQixjQUFjLENBQUM7TUFDL0Rya0IsTUFBTSxDQUFDa2MsTUFBTSxDQUFDLGdDQUFnQyxHQUMxQ3FJLElBQUksQ0FBQ2hPLFNBQVMsQ0FBQ2pTLElBQUksQ0FBQ3VMLGtCQUFrQixDQUFDLEVBQUU3RyxDQUFDLENBQUM7TUFDL0M7SUFDRjs7SUFFQTtJQUNBLElBQUksQ0FBQzFFLElBQUksQ0FBQ2dXLFFBQVEsRUFBRTtNQUNsQnBSLGVBQWUsQ0FBQ3ViLGlCQUFpQixDQUM3Qm5nQixJQUFJLENBQUNxYixRQUFRLEVBQUV5RSxVQUFVLEVBQUVELFVBQVUsRUFBRTdmLElBQUksQ0FBQ3VkLFlBQVksQ0FBQztJQUMvRDs7SUFFQTtJQUNBO0lBQ0E7SUFDQSxJQUFJcUMsS0FBSyxFQUNQNWYsSUFBSSxDQUFDdWQsWUFBWSxDQUFDWixLQUFLLENBQUMsQ0FBQzs7SUFFM0I7SUFDQTtJQUNBO0lBQ0EzYyxJQUFJLENBQUMwZSxRQUFRLEdBQUdtQixVQUFVOztJQUUxQjtJQUNBO0lBQ0E7SUFDQTtJQUNBLE1BQU03ZixJQUFJLENBQUN1ZCxZQUFZLENBQUNULE9BQU8sQ0FBQyxrQkFBa0I7TUFDaEQsS0FBSyxNQUFNc0QsQ0FBQyxJQUFJTCxjQUFjLEVBQUU7UUFDOUIsTUFBTUssQ0FBQyxDQUFDdGMsU0FBUyxDQUFDLENBQUM7TUFDckI7SUFDRixDQUFDLENBQUM7RUFDSixDQUFDO0VBRURqQixJQUFJLEVBQUUsU0FBQUEsQ0FBQSxFQUFZO0lBQ2hCLElBQUk3QyxJQUFJLEdBQUcsSUFBSTtJQUNmQSxJQUFJLENBQUNnVyxRQUFRLEdBQUcsSUFBSTtJQUNwQixNQUFNcUssbUJBQW1CLEdBQUcsZUFBQUEsQ0FBZUMsQ0FBQyxFQUFFO01BQzVDLE1BQU1BLENBQUMsQ0FBQyxDQUFDO0lBQ1gsQ0FBQztJQUVEdmpCLENBQUMsQ0FBQ0ssSUFBSSxDQUFDNEMsSUFBSSxDQUFDd2UsY0FBYyxFQUFFNkIsbUJBQW1CLENBQUM7SUFDaEQ7SUFDQXRqQixDQUFDLENBQUNLLElBQUksQ0FBQzRDLElBQUksQ0FBQzRlLGNBQWMsRUFBRSxnQkFBZ0J3QixDQUFDLEVBQUU7TUFDN0MsTUFBTUEsQ0FBQyxDQUFDdGMsU0FBUyxDQUFDLENBQUM7SUFDckIsQ0FBQyxDQUFDO0lBQ0Z2QixPQUFPLENBQUMsWUFBWSxDQUFDLElBQUlBLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQzRZLEtBQUssQ0FBQ0MsbUJBQW1CLENBQ3RFLGdCQUFnQixFQUFFLHlCQUF5QixFQUFFLENBQUMsQ0FBQyxDQUFDO0VBQ3BEO0FBQ0YsQ0FBQyxDQUFDLEM7Ozs7Ozs7Ozs7Ozs7O0lDdE9GLElBQUltRixjQUFjO0lBQUNoa0IsTUFBTSxDQUFDckIsSUFBSSxDQUFDLHNDQUFzQyxFQUFDO01BQUNDLE9BQU9BLENBQUNDLENBQUMsRUFBQztRQUFDbWxCLGNBQWMsR0FBQ25sQixDQUFDO01BQUE7SUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0lBQXZHLElBQUlvbEIsa0JBQWtCO0lBQUNqa0IsTUFBTSxDQUFDckIsSUFBSSxDQUFDLHNCQUFzQixFQUFDO01BQUNzbEIsa0JBQWtCQSxDQUFDcGxCLENBQUMsRUFBQztRQUFDb2xCLGtCQUFrQixHQUFDcGxCLENBQUM7TUFBQTtJQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7SUFBQyxJQUFJMGlCLEtBQUssRUFBQzJDLEtBQUs7SUFBQ2xrQixNQUFNLENBQUNyQixJQUFJLENBQUMsY0FBYyxFQUFDO01BQUM0aUIsS0FBS0EsQ0FBQzFpQixDQUFDLEVBQUM7UUFBQzBpQixLQUFLLEdBQUMxaUIsQ0FBQztNQUFBLENBQUM7TUFBQ3FsQixLQUFLQSxDQUFDcmxCLENBQUMsRUFBQztRQUFDcWxCLEtBQUssR0FBQ3JsQixDQUFDO01BQUE7SUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0lBQUMsSUFBSU8sb0JBQW9CLENBQUMsQ0FBQyxFQUFFLENBQUMsTUFBTUEsb0JBQW9CLENBQUMsQ0FBQyxFQUFFLENBQUM7SUFHM1AsSUFBSStrQixLQUFLLEdBQUc7TUFDVkMsUUFBUSxFQUFFLFVBQVU7TUFDcEJDLFFBQVEsRUFBRSxVQUFVO01BQ3BCQyxNQUFNLEVBQUU7SUFDVixDQUFDOztJQUVEO0lBQ0E7SUFDQSxJQUFJQyxlQUFlLEdBQUcsU0FBQUEsQ0FBQSxFQUFZLENBQUMsQ0FBQztJQUNwQyxJQUFJQyx1QkFBdUIsR0FBRyxTQUFBQSxDQUFVdE4sQ0FBQyxFQUFFO01BQ3pDLE9BQU8sWUFBWTtRQUNqQixJQUFJO1VBQ0ZBLENBQUMsQ0FBQ3dKLEtBQUssQ0FBQyxJQUFJLEVBQUV2VCxTQUFTLENBQUM7UUFDMUIsQ0FBQyxDQUFDLE9BQU9oRixDQUFDLEVBQUU7VUFDVixJQUFJLEVBQUVBLENBQUMsWUFBWW9jLGVBQWUsQ0FBQyxFQUNqQyxNQUFNcGMsQ0FBQztRQUNYO01BQ0YsQ0FBQztJQUNILENBQUM7SUFFRCxJQUFJc2MsU0FBUyxHQUFHLENBQUM7O0lBRWpCO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTFOLGtCQUFrQixHQUFHLFNBQUFBLENBQVUxVCxPQUFPLEVBQUU7TUFDdEMsTUFBTUksSUFBSSxHQUFHLElBQUk7TUFDakJBLElBQUksQ0FBQ2loQixVQUFVLEdBQUcsSUFBSSxDQUFDLENBQUU7O01BRXpCamhCLElBQUksQ0FBQytFLEdBQUcsR0FBR2ljLFNBQVM7TUFDcEJBLFNBQVMsRUFBRTtNQUVYaGhCLElBQUksQ0FBQ3VMLGtCQUFrQixHQUFHM0wsT0FBTyxDQUFDeUwsaUJBQWlCO01BQ25EckwsSUFBSSxDQUFDdWUsWUFBWSxHQUFHM2UsT0FBTyxDQUFDZ1UsV0FBVztNQUN2QzVULElBQUksQ0FBQ3VkLFlBQVksR0FBRzNkLE9BQU8sQ0FBQ3NTLFdBQVc7TUFFdkMsSUFBSXRTLE9BQU8sQ0FBQ3dOLE9BQU8sRUFBRTtRQUNuQixNQUFNekssS0FBSyxDQUFDLDJEQUEyRCxDQUFDO01BQzFFO01BRUEsTUFBTW1RLE1BQU0sR0FBR2xULE9BQU8sQ0FBQ2tULE1BQU07TUFDN0I7TUFDQTtNQUNBLE1BQU1vTyxVQUFVLEdBQUdwTyxNQUFNLElBQUlBLE1BQU0sQ0FBQ3FPLGFBQWEsQ0FBQyxDQUFDO01BRW5ELElBQUl2aEIsT0FBTyxDQUFDeUwsaUJBQWlCLENBQUN6TCxPQUFPLENBQUNrSyxLQUFLLEVBQUU7UUFDM0M7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTs7UUFFQSxNQUFNc1gsV0FBVyxHQUFHO1VBQUVDLEtBQUssRUFBRXpjLGVBQWUsQ0FBQ3FLO1FBQU8sQ0FBQztRQUNyRGpQLElBQUksQ0FBQ3NoQixNQUFNLEdBQUd0aEIsSUFBSSxDQUFDdUwsa0JBQWtCLENBQUMzTCxPQUFPLENBQUNrSyxLQUFLO1FBQ25EOUosSUFBSSxDQUFDdWhCLFdBQVcsR0FBR0wsVUFBVTtRQUM3QmxoQixJQUFJLENBQUN3aEIsT0FBTyxHQUFHMU8sTUFBTTtRQUNyQjlTLElBQUksQ0FBQ3loQixrQkFBa0IsR0FBRyxJQUFJQyxVQUFVLENBQUNSLFVBQVUsRUFBRUUsV0FBVyxDQUFDO1FBQ2pFO1FBQ0FwaEIsSUFBSSxDQUFDMmhCLFVBQVUsR0FBRyxJQUFJQyxPQUFPLENBQUNWLFVBQVUsRUFBRUUsV0FBVyxDQUFDO01BQ3hELENBQUMsTUFBTTtRQUNMcGhCLElBQUksQ0FBQ3NoQixNQUFNLEdBQUcsQ0FBQztRQUNmdGhCLElBQUksQ0FBQ3VoQixXQUFXLEdBQUcsSUFBSTtRQUN2QnZoQixJQUFJLENBQUN3aEIsT0FBTyxHQUFHLElBQUk7UUFDbkJ4aEIsSUFBSSxDQUFDeWhCLGtCQUFrQixHQUFHLElBQUk7UUFDOUJ6aEIsSUFBSSxDQUFDMmhCLFVBQVUsR0FBRyxJQUFJL2MsZUFBZSxDQUFDcUssTUFBTSxDQUFELENBQUM7TUFDOUM7O01BRUE7TUFDQTtNQUNBO01BQ0FqUCxJQUFJLENBQUM2aEIsbUJBQW1CLEdBQUcsS0FBSztNQUVoQzdoQixJQUFJLENBQUNnVyxRQUFRLEdBQUcsS0FBSztNQUNyQmhXLElBQUksQ0FBQzhoQixZQUFZLEdBQUcsRUFBRTtNQUN0QjloQixJQUFJLENBQUMraEIsZUFBZSxHQUFHLFVBQVVDLGNBQWMsRUFBRTtRQUMvQyxNQUFNQyxlQUFlLEdBQUd4QixLQUFLLENBQUN5QixlQUFlLENBQUM7VUFBRXJmLElBQUksRUFBRXNmO1FBQVMsQ0FBQyxDQUFDO1FBQ2pFO1FBQ0FyRSxLQUFLLENBQUNrRSxjQUFjLEVBQUV2QixLQUFLLENBQUMyQixLQUFLLENBQUMsQ0FBQ0gsZUFBZSxDQUFDLEVBQUVBLGVBQWUsQ0FBQyxDQUFDO1FBQ3RFamlCLElBQUksQ0FBQzhoQixZQUFZLENBQUMxUixJQUFJLENBQUM0UixjQUFjLENBQUM7TUFDeEMsQ0FBQztNQUVEemYsT0FBTyxDQUFDLFlBQVksQ0FBQyxJQUFJQSxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM0WSxLQUFLLENBQUNDLG1CQUFtQixDQUN0RSxnQkFBZ0IsRUFBRSx1QkFBdUIsRUFBRSxDQUFDLENBQUM7TUFFL0NwYixJQUFJLENBQUNxaUIsb0JBQW9CLENBQUMzQixLQUFLLENBQUNDLFFBQVEsQ0FBQztNQUV6QzNnQixJQUFJLENBQUNzaUIsUUFBUSxHQUFHMWlCLE9BQU8sQ0FBQ2lULE9BQU87TUFDL0I7TUFDQTtNQUNBLE1BQU05RSxVQUFVLEdBQUcvTixJQUFJLENBQUN1TCxrQkFBa0IsQ0FBQzNMLE9BQU8sQ0FBQ29PLE1BQU0sSUFBSWhPLElBQUksQ0FBQ3VMLGtCQUFrQixDQUFDM0wsT0FBTyxDQUFDbU8sVUFBVSxJQUFJLENBQUMsQ0FBQztNQUM3Ry9OLElBQUksQ0FBQ3VpQixhQUFhLEdBQUczZCxlQUFlLENBQUM0ZCxrQkFBa0IsQ0FBQ3pVLFVBQVUsQ0FBQztNQUNuRTtNQUNBO01BQ0EvTixJQUFJLENBQUN5aUIsaUJBQWlCLEdBQUd6aUIsSUFBSSxDQUFDc2lCLFFBQVEsQ0FBQ0kscUJBQXFCLENBQUMzVSxVQUFVLENBQUM7TUFDeEUsSUFBSStFLE1BQU0sRUFDUjlTLElBQUksQ0FBQ3lpQixpQkFBaUIsR0FBRzNQLE1BQU0sQ0FBQzRQLHFCQUFxQixDQUFDMWlCLElBQUksQ0FBQ3lpQixpQkFBaUIsQ0FBQztNQUMvRXppQixJQUFJLENBQUMyaUIsbUJBQW1CLEdBQUcvZCxlQUFlLENBQUM0ZCxrQkFBa0IsQ0FDM0R4aUIsSUFBSSxDQUFDeWlCLGlCQUFpQixDQUFDO01BRXpCemlCLElBQUksQ0FBQzRpQixZQUFZLEdBQUcsSUFBSWhlLGVBQWUsQ0FBQ3FLLE1BQU0sQ0FBRCxDQUFDO01BQzlDalAsSUFBSSxDQUFDNmlCLGtCQUFrQixHQUFHLElBQUk7TUFDOUI3aUIsSUFBSSxDQUFDOGlCLGdCQUFnQixHQUFHLENBQUM7TUFFekI5aUIsSUFBSSxDQUFDK2lCLHlCQUF5QixHQUFHLEtBQUs7TUFDdEMvaUIsSUFBSSxDQUFDZ2pCLGdDQUFnQyxHQUFHLEVBQUU7SUFJM0MsQ0FBQztJQUVGam1CLENBQUMsQ0FBQzRJLE1BQU0sQ0FBQzJOLGtCQUFrQixDQUFDOVYsU0FBUyxFQUFFO01BQ3JDcVcsS0FBSyxFQUFFLGVBQUFBLENBQUEsRUFBaUI7UUFDdEIsTUFBTTdULElBQUksR0FBRyxJQUFJOztRQUVqQjtRQUNBO1FBQ0FBLElBQUksQ0FBQytoQixlQUFlLENBQUMvaEIsSUFBSSxDQUFDdWUsWUFBWSxDQUFDNWMsWUFBWSxDQUFDb1csZ0JBQWdCLENBQ2xFZ0osdUJBQXVCLENBQUMsWUFBWTtVQUNsQyxPQUFPL2dCLElBQUksQ0FBQ2lqQixnQkFBZ0IsQ0FBQyxDQUFDO1FBQ2hDLENBQUMsQ0FDSCxDQUFDLENBQUM7UUFFRixNQUFNOU8sY0FBYyxDQUFDblUsSUFBSSxDQUFDdUwsa0JBQWtCLEVBQUUsZ0JBQWdCNkksT0FBTyxFQUFFO1VBQ3JFcFUsSUFBSSxDQUFDK2hCLGVBQWUsQ0FBQyxNQUFNL2hCLElBQUksQ0FBQ3VlLFlBQVksQ0FBQzVjLFlBQVksQ0FBQ21XLFlBQVksQ0FDcEUxRCxPQUFPLEVBQUUsVUFBVXVELFlBQVksRUFBRTtZQUMvQm9KLHVCQUF1QixDQUFDLFlBQVk7Y0FDbEMsTUFBTXZMLEVBQUUsR0FBR21DLFlBQVksQ0FBQ25DLEVBQUU7Y0FDMUIsSUFBSW1DLFlBQVksQ0FBQ3ZSLGNBQWMsSUFBSXVSLFlBQVksQ0FBQ3BSLFlBQVksRUFBRTtnQkFDNUQ7Z0JBQ0E7Z0JBQ0E7Z0JBQ0EsT0FBT3ZHLElBQUksQ0FBQ2lqQixnQkFBZ0IsQ0FBQyxDQUFDO2NBQ2hDLENBQUMsTUFBTTtnQkFDTDtnQkFDQSxJQUFJampCLElBQUksQ0FBQ2tqQixNQUFNLEtBQUt4QyxLQUFLLENBQUNDLFFBQVEsRUFBRTtrQkFDbEMsT0FBTzNnQixJQUFJLENBQUNtakIseUJBQXlCLENBQUMzTixFQUFFLENBQUM7Z0JBQzNDLENBQUMsTUFBTTtrQkFDTCxPQUFPeFYsSUFBSSxDQUFDb2pCLGlDQUFpQyxDQUFDNU4sRUFBRSxDQUFDO2dCQUNuRDtjQUNGO1lBQ0YsQ0FBQyxDQUFDLENBQUMsQ0FBQztVQUNOLENBQ0YsQ0FBQyxDQUFDO1FBQ0osQ0FBQyxDQUFDOztRQUVGO1FBQ0F4VixJQUFJLENBQUMraEIsZUFBZSxDQUFDLE1BQU0vTixTQUFTLENBQ2xDaFUsSUFBSSxDQUFDdUwsa0JBQWtCLEVBQUUsWUFBWTtVQUNuQztVQUNBLE1BQU03SCxLQUFLLEdBQUdDLFNBQVMsQ0FBQ0MsZ0JBQWdCLENBQUMsQ0FBQztVQUMxQyxJQUFJLENBQUNGLEtBQUssSUFBSUEsS0FBSyxDQUFDMmYsS0FBSyxFQUN2QjtVQUVGLElBQUkzZixLQUFLLENBQUM0ZixvQkFBb0IsRUFBRTtZQUM5QjVmLEtBQUssQ0FBQzRmLG9CQUFvQixDQUFDdGpCLElBQUksQ0FBQytFLEdBQUcsQ0FBQyxHQUFHL0UsSUFBSTtZQUMzQztVQUNGO1VBRUEwRCxLQUFLLENBQUM0ZixvQkFBb0IsR0FBRyxDQUFDLENBQUM7VUFDL0I1ZixLQUFLLENBQUM0ZixvQkFBb0IsQ0FBQ3RqQixJQUFJLENBQUMrRSxHQUFHLENBQUMsR0FBRy9FLElBQUk7VUFFM0MwRCxLQUFLLENBQUM2ZixZQUFZLENBQUMsa0JBQWtCO1lBQ25DLE1BQU1DLE9BQU8sR0FBRzlmLEtBQUssQ0FBQzRmLG9CQUFvQjtZQUMxQyxPQUFPNWYsS0FBSyxDQUFDNGYsb0JBQW9COztZQUVqQztZQUNBO1lBQ0EsTUFBTXRqQixJQUFJLENBQUN1ZSxZQUFZLENBQUM1YyxZQUFZLENBQUNnWCxpQkFBaUIsQ0FBQyxDQUFDO1lBRXhELEtBQUssTUFBTThLLE1BQU0sSUFBSS9pQixNQUFNLENBQUNnakIsTUFBTSxDQUFDRixPQUFPLENBQUMsRUFBRTtjQUMzQyxJQUFJQyxNQUFNLENBQUN6TixRQUFRLEVBQ2pCO2NBRUYsTUFBTTlSLEtBQUssR0FBRyxNQUFNUixLQUFLLENBQUNHLFVBQVUsQ0FBQyxDQUFDO2NBQ3RDLElBQUk0ZixNQUFNLENBQUNQLE1BQU0sS0FBS3hDLEtBQUssQ0FBQ0csTUFBTSxFQUFFO2dCQUNsQztnQkFDQTtnQkFDQTtnQkFDQSxNQUFNNEMsTUFBTSxDQUFDbEcsWUFBWSxDQUFDVCxPQUFPLENBQUM1WSxLQUFLLENBQUNKLFNBQVMsQ0FBQztjQUNwRCxDQUFDLE1BQU07Z0JBQ0wyZixNQUFNLENBQUNULGdDQUFnQyxDQUFDNVMsSUFBSSxDQUFDbE0sS0FBSyxDQUFDO2NBQ3JEO1lBQ0Y7VUFDRixDQUFDLENBQUM7UUFDSixDQUNGLENBQUMsQ0FBQzs7UUFFRjtRQUNBO1FBQ0FsRSxJQUFJLENBQUMraEIsZUFBZSxDQUFDL2hCLElBQUksQ0FBQ3VlLFlBQVksQ0FBQ3hhLFdBQVcsQ0FBQ2dkLHVCQUF1QixDQUN4RSxZQUFZO1VBQ1YsT0FBTy9nQixJQUFJLENBQUNpakIsZ0JBQWdCLENBQUMsQ0FBQztRQUNoQyxDQUFDLENBQUMsQ0FBQyxDQUFDOztRQUVOO1FBQ0E7UUFDQSxPQUFPampCLElBQUksQ0FBQzJqQixnQkFBZ0IsQ0FBQyxDQUFDO01BQ2hDLENBQUM7TUFDREMsYUFBYSxFQUFFLFNBQUFBLENBQVU5ZSxFQUFFLEVBQUV5SyxHQUFHLEVBQUU7UUFDaEMsSUFBSXZQLElBQUksR0FBRyxJQUFJO1FBQ2Z0RSxNQUFNLENBQUNtb0IsZ0JBQWdCLENBQUMsWUFBWTtVQUNsQyxJQUFJN1YsTUFBTSxHQUFHalIsQ0FBQyxDQUFDVSxLQUFLLENBQUM4UixHQUFHLENBQUM7VUFDekIsT0FBT3ZCLE1BQU0sQ0FBQ2pKLEdBQUc7VUFDakIvRSxJQUFJLENBQUMyaEIsVUFBVSxDQUFDblMsR0FBRyxDQUFDMUssRUFBRSxFQUFFOUUsSUFBSSxDQUFDMmlCLG1CQUFtQixDQUFDcFQsR0FBRyxDQUFDLENBQUM7VUFDdER2UCxJQUFJLENBQUN1ZCxZQUFZLENBQUM3SSxLQUFLLENBQUM1UCxFQUFFLEVBQUU5RSxJQUFJLENBQUN1aUIsYUFBYSxDQUFDdlUsTUFBTSxDQUFDLENBQUM7O1VBRXZEO1VBQ0E7VUFDQTtVQUNBO1VBQ0EsSUFBSWhPLElBQUksQ0FBQ3NoQixNQUFNLElBQUl0aEIsSUFBSSxDQUFDMmhCLFVBQVUsQ0FBQ2pqQixJQUFJLENBQUMsQ0FBQyxHQUFHc0IsSUFBSSxDQUFDc2hCLE1BQU0sRUFBRTtZQUN2RDtZQUNBLElBQUl0aEIsSUFBSSxDQUFDMmhCLFVBQVUsQ0FBQ2pqQixJQUFJLENBQUMsQ0FBQyxLQUFLc0IsSUFBSSxDQUFDc2hCLE1BQU0sR0FBRyxDQUFDLEVBQUU7Y0FDOUMsTUFBTSxJQUFJM2UsS0FBSyxDQUFDLDZCQUE2QixJQUM1QjNDLElBQUksQ0FBQzJoQixVQUFVLENBQUNqakIsSUFBSSxDQUFDLENBQUMsR0FBR3NCLElBQUksQ0FBQ3NoQixNQUFNLENBQUMsR0FDdEMsb0NBQW9DLENBQUM7WUFDdkQ7WUFFQSxJQUFJd0MsZ0JBQWdCLEdBQUc5akIsSUFBSSxDQUFDMmhCLFVBQVUsQ0FBQ29DLFlBQVksQ0FBQyxDQUFDO1lBQ3JELElBQUlDLGNBQWMsR0FBR2hrQixJQUFJLENBQUMyaEIsVUFBVSxDQUFDM0QsR0FBRyxDQUFDOEYsZ0JBQWdCLENBQUM7WUFFMUQsSUFBSW5sQixLQUFLLENBQUNzbEIsTUFBTSxDQUFDSCxnQkFBZ0IsRUFBRWhmLEVBQUUsQ0FBQyxFQUFFO2NBQ3RDLE1BQU0sSUFBSW5DLEtBQUssQ0FBQywwREFBMEQsQ0FBQztZQUM3RTtZQUVBM0MsSUFBSSxDQUFDMmhCLFVBQVUsQ0FBQ3VDLE1BQU0sQ0FBQ0osZ0JBQWdCLENBQUM7WUFDeEM5akIsSUFBSSxDQUFDdWQsWUFBWSxDQUFDNEcsT0FBTyxDQUFDTCxnQkFBZ0IsQ0FBQztZQUMzQzlqQixJQUFJLENBQUNva0IsWUFBWSxDQUFDTixnQkFBZ0IsRUFBRUUsY0FBYyxDQUFDO1VBQ3JEO1FBQ0YsQ0FBQyxDQUFDO01BQ0osQ0FBQztNQUNESyxnQkFBZ0IsRUFBRSxTQUFBQSxDQUFVdmYsRUFBRSxFQUFFO1FBQzlCLElBQUk5RSxJQUFJLEdBQUcsSUFBSTtRQUNmdEUsTUFBTSxDQUFDbW9CLGdCQUFnQixDQUFDLFlBQVk7VUFDbEM3akIsSUFBSSxDQUFDMmhCLFVBQVUsQ0FBQ3VDLE1BQU0sQ0FBQ3BmLEVBQUUsQ0FBQztVQUMxQjlFLElBQUksQ0FBQ3VkLFlBQVksQ0FBQzRHLE9BQU8sQ0FBQ3JmLEVBQUUsQ0FBQztVQUM3QixJQUFJLENBQUU5RSxJQUFJLENBQUNzaEIsTUFBTSxJQUFJdGhCLElBQUksQ0FBQzJoQixVQUFVLENBQUNqakIsSUFBSSxDQUFDLENBQUMsS0FBS3NCLElBQUksQ0FBQ3NoQixNQUFNLEVBQ3pEO1VBRUYsSUFBSXRoQixJQUFJLENBQUMyaEIsVUFBVSxDQUFDampCLElBQUksQ0FBQyxDQUFDLEdBQUdzQixJQUFJLENBQUNzaEIsTUFBTSxFQUN0QyxNQUFNM2UsS0FBSyxDQUFDLDZCQUE2QixDQUFDOztVQUU1QztVQUNBOztVQUVBLElBQUksQ0FBQzNDLElBQUksQ0FBQ3loQixrQkFBa0IsQ0FBQzZDLEtBQUssQ0FBQyxDQUFDLEVBQUU7WUFDcEM7WUFDQTtZQUNBLElBQUlDLFFBQVEsR0FBR3ZrQixJQUFJLENBQUN5aEIsa0JBQWtCLENBQUMrQyxZQUFZLENBQUMsQ0FBQztZQUNyRCxJQUFJamQsTUFBTSxHQUFHdkgsSUFBSSxDQUFDeWhCLGtCQUFrQixDQUFDekQsR0FBRyxDQUFDdUcsUUFBUSxDQUFDO1lBQ2xEdmtCLElBQUksQ0FBQ3lrQixlQUFlLENBQUNGLFFBQVEsQ0FBQztZQUM5QnZrQixJQUFJLENBQUM0akIsYUFBYSxDQUFDVyxRQUFRLEVBQUVoZCxNQUFNLENBQUM7WUFDcEM7VUFDRjs7VUFFQTs7VUFFQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0EsSUFBSXZILElBQUksQ0FBQ2tqQixNQUFNLEtBQUt4QyxLQUFLLENBQUNDLFFBQVEsRUFDaEM7O1VBRUY7VUFDQTtVQUNBO1VBQ0E7VUFDQSxJQUFJM2dCLElBQUksQ0FBQzZoQixtQkFBbUIsRUFDMUI7O1VBRUY7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBOztVQUVBLE1BQU0sSUFBSWxmLEtBQUssQ0FBQywyQkFBMkIsQ0FBQztRQUM5QyxDQUFDLENBQUM7TUFDSixDQUFDO01BQ0QraEIsZ0JBQWdCLEVBQUUsU0FBQUEsQ0FBVTVmLEVBQUUsRUFBRTZmLE1BQU0sRUFBRXBkLE1BQU0sRUFBRTtRQUM5QyxJQUFJdkgsSUFBSSxHQUFHLElBQUk7UUFDZnRFLE1BQU0sQ0FBQ21vQixnQkFBZ0IsQ0FBQyxZQUFZO1VBQ2xDN2pCLElBQUksQ0FBQzJoQixVQUFVLENBQUNuUyxHQUFHLENBQUMxSyxFQUFFLEVBQUU5RSxJQUFJLENBQUMyaUIsbUJBQW1CLENBQUNwYixNQUFNLENBQUMsQ0FBQztVQUN6RCxJQUFJcWQsWUFBWSxHQUFHNWtCLElBQUksQ0FBQ3VpQixhQUFhLENBQUNoYixNQUFNLENBQUM7VUFDN0MsSUFBSXNkLFlBQVksR0FBRzdrQixJQUFJLENBQUN1aUIsYUFBYSxDQUFDb0MsTUFBTSxDQUFDO1VBQzdDLElBQUlHLE9BQU8sR0FBR0MsWUFBWSxDQUFDQyxpQkFBaUIsQ0FDMUNKLFlBQVksRUFBRUMsWUFBWSxDQUFDO1VBQzdCLElBQUksQ0FBQzluQixDQUFDLENBQUN5ZCxPQUFPLENBQUNzSyxPQUFPLENBQUMsRUFDckI5a0IsSUFBSSxDQUFDdWQsWUFBWSxDQUFDdUgsT0FBTyxDQUFDaGdCLEVBQUUsRUFBRWdnQixPQUFPLENBQUM7UUFDMUMsQ0FBQyxDQUFDO01BQ0osQ0FBQztNQUNEVixZQUFZLEVBQUUsU0FBQUEsQ0FBVXRmLEVBQUUsRUFBRXlLLEdBQUcsRUFBRTtRQUMvQixJQUFJdlAsSUFBSSxHQUFHLElBQUk7UUFDZnRFLE1BQU0sQ0FBQ21vQixnQkFBZ0IsQ0FBQyxZQUFZO1VBQ2xDN2pCLElBQUksQ0FBQ3loQixrQkFBa0IsQ0FBQ2pTLEdBQUcsQ0FBQzFLLEVBQUUsRUFBRTlFLElBQUksQ0FBQzJpQixtQkFBbUIsQ0FBQ3BULEdBQUcsQ0FBQyxDQUFDOztVQUU5RDtVQUNBLElBQUl2UCxJQUFJLENBQUN5aEIsa0JBQWtCLENBQUMvaUIsSUFBSSxDQUFDLENBQUMsR0FBR3NCLElBQUksQ0FBQ3NoQixNQUFNLEVBQUU7WUFDaEQsSUFBSTJELGFBQWEsR0FBR2psQixJQUFJLENBQUN5aEIsa0JBQWtCLENBQUNzQyxZQUFZLENBQUMsQ0FBQztZQUUxRC9qQixJQUFJLENBQUN5aEIsa0JBQWtCLENBQUN5QyxNQUFNLENBQUNlLGFBQWEsQ0FBQzs7WUFFN0M7WUFDQTtZQUNBamxCLElBQUksQ0FBQzZoQixtQkFBbUIsR0FBRyxLQUFLO1VBQ2xDO1FBQ0YsQ0FBQyxDQUFDO01BQ0osQ0FBQztNQUNEO01BQ0E7TUFDQTRDLGVBQWUsRUFBRSxTQUFBQSxDQUFVM2YsRUFBRSxFQUFFO1FBQzdCLElBQUk5RSxJQUFJLEdBQUcsSUFBSTtRQUNmdEUsTUFBTSxDQUFDbW9CLGdCQUFnQixDQUFDLFlBQVk7VUFDbEM3akIsSUFBSSxDQUFDeWhCLGtCQUFrQixDQUFDeUMsTUFBTSxDQUFDcGYsRUFBRSxDQUFDO1VBQ2xDO1VBQ0E7VUFDQTtVQUNBLElBQUksQ0FBRTlFLElBQUksQ0FBQ3loQixrQkFBa0IsQ0FBQy9pQixJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUVzQixJQUFJLENBQUM2aEIsbUJBQW1CLEVBQ2hFN2hCLElBQUksQ0FBQ2lqQixnQkFBZ0IsQ0FBQyxDQUFDO1FBQzNCLENBQUMsQ0FBQztNQUNKLENBQUM7TUFDRDtNQUNBO01BQ0E7TUFDQWlDLFlBQVksRUFBRSxTQUFBQSxDQUFVM1YsR0FBRyxFQUFFO1FBQzNCLElBQUl2UCxJQUFJLEdBQUcsSUFBSTtRQUNmdEUsTUFBTSxDQUFDbW9CLGdCQUFnQixDQUFDLFlBQVk7VUFDbEMsSUFBSS9lLEVBQUUsR0FBR3lLLEdBQUcsQ0FBQ3hLLEdBQUc7VUFDaEIsSUFBSS9FLElBQUksQ0FBQzJoQixVQUFVLENBQUM5Z0IsR0FBRyxDQUFDaUUsRUFBRSxDQUFDLEVBQ3pCLE1BQU1uQyxLQUFLLENBQUMsMkNBQTJDLEdBQUdtQyxFQUFFLENBQUM7VUFDL0QsSUFBSTlFLElBQUksQ0FBQ3NoQixNQUFNLElBQUl0aEIsSUFBSSxDQUFDeWhCLGtCQUFrQixDQUFDNWdCLEdBQUcsQ0FBQ2lFLEVBQUUsQ0FBQyxFQUNoRCxNQUFNbkMsS0FBSyxDQUFDLG1EQUFtRCxHQUFHbUMsRUFBRSxDQUFDO1VBRXZFLElBQUlnRixLQUFLLEdBQUc5SixJQUFJLENBQUNzaEIsTUFBTTtVQUN2QixJQUFJSixVQUFVLEdBQUdsaEIsSUFBSSxDQUFDdWhCLFdBQVc7VUFDakMsSUFBSTRELFlBQVksR0FBSXJiLEtBQUssSUFBSTlKLElBQUksQ0FBQzJoQixVQUFVLENBQUNqakIsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQ3JEc0IsSUFBSSxDQUFDMmhCLFVBQVUsQ0FBQzNELEdBQUcsQ0FBQ2hlLElBQUksQ0FBQzJoQixVQUFVLENBQUNvQyxZQUFZLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSTtVQUM1RCxJQUFJcUIsV0FBVyxHQUFJdGIsS0FBSyxJQUFJOUosSUFBSSxDQUFDeWhCLGtCQUFrQixDQUFDL2lCLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUMxRHNCLElBQUksQ0FBQ3loQixrQkFBa0IsQ0FBQ3pELEdBQUcsQ0FBQ2hlLElBQUksQ0FBQ3loQixrQkFBa0IsQ0FBQ3NDLFlBQVksQ0FBQyxDQUFDLENBQUMsR0FDbkUsSUFBSTtVQUNSO1VBQ0E7VUFDQTtVQUNBLElBQUlzQixTQUFTLEdBQUcsQ0FBRXZiLEtBQUssSUFBSTlKLElBQUksQ0FBQzJoQixVQUFVLENBQUNqakIsSUFBSSxDQUFDLENBQUMsR0FBR29MLEtBQUssSUFDdkRvWCxVQUFVLENBQUMzUixHQUFHLEVBQUU0VixZQUFZLENBQUMsR0FBRyxDQUFDOztVQUVuQztVQUNBO1VBQ0E7VUFDQSxJQUFJRyxpQkFBaUIsR0FBRyxDQUFDRCxTQUFTLElBQUlybEIsSUFBSSxDQUFDNmhCLG1CQUFtQixJQUM1RDdoQixJQUFJLENBQUN5aEIsa0JBQWtCLENBQUMvaUIsSUFBSSxDQUFDLENBQUMsR0FBR29MLEtBQUs7O1VBRXhDO1VBQ0E7VUFDQSxJQUFJeWIsbUJBQW1CLEdBQUcsQ0FBQ0YsU0FBUyxJQUFJRCxXQUFXLElBQ2pEbEUsVUFBVSxDQUFDM1IsR0FBRyxFQUFFNlYsV0FBVyxDQUFDLElBQUksQ0FBQztVQUVuQyxJQUFJSSxRQUFRLEdBQUdGLGlCQUFpQixJQUFJQyxtQkFBbUI7VUFFdkQsSUFBSUYsU0FBUyxFQUFFO1lBQ2JybEIsSUFBSSxDQUFDNGpCLGFBQWEsQ0FBQzllLEVBQUUsRUFBRXlLLEdBQUcsQ0FBQztVQUM3QixDQUFDLE1BQU0sSUFBSWlXLFFBQVEsRUFBRTtZQUNuQnhsQixJQUFJLENBQUNva0IsWUFBWSxDQUFDdGYsRUFBRSxFQUFFeUssR0FBRyxDQUFDO1VBQzVCLENBQUMsTUFBTTtZQUNMO1lBQ0F2UCxJQUFJLENBQUM2aEIsbUJBQW1CLEdBQUcsS0FBSztVQUNsQztRQUNGLENBQUMsQ0FBQztNQUNKLENBQUM7TUFDRDtNQUNBO01BQ0E7TUFDQTRELGVBQWUsRUFBRSxTQUFBQSxDQUFVM2dCLEVBQUUsRUFBRTtRQUM3QixJQUFJOUUsSUFBSSxHQUFHLElBQUk7UUFDZnRFLE1BQU0sQ0FBQ21vQixnQkFBZ0IsQ0FBQyxZQUFZO1VBQ2xDLElBQUksQ0FBRTdqQixJQUFJLENBQUMyaEIsVUFBVSxDQUFDOWdCLEdBQUcsQ0FBQ2lFLEVBQUUsQ0FBQyxJQUFJLENBQUU5RSxJQUFJLENBQUNzaEIsTUFBTSxFQUM1QyxNQUFNM2UsS0FBSyxDQUFDLG9EQUFvRCxHQUFHbUMsRUFBRSxDQUFDO1VBRXhFLElBQUk5RSxJQUFJLENBQUMyaEIsVUFBVSxDQUFDOWdCLEdBQUcsQ0FBQ2lFLEVBQUUsQ0FBQyxFQUFFO1lBQzNCOUUsSUFBSSxDQUFDcWtCLGdCQUFnQixDQUFDdmYsRUFBRSxDQUFDO1VBQzNCLENBQUMsTUFBTSxJQUFJOUUsSUFBSSxDQUFDeWhCLGtCQUFrQixDQUFDNWdCLEdBQUcsQ0FBQ2lFLEVBQUUsQ0FBQyxFQUFFO1lBQzFDOUUsSUFBSSxDQUFDeWtCLGVBQWUsQ0FBQzNmLEVBQUUsQ0FBQztVQUMxQjtRQUNGLENBQUMsQ0FBQztNQUNKLENBQUM7TUFDRDRnQixVQUFVLEVBQUUsU0FBQUEsQ0FBVTVnQixFQUFFLEVBQUV5QyxNQUFNLEVBQUU7UUFDaEMsSUFBSXZILElBQUksR0FBRyxJQUFJO1FBQ2Z0RSxNQUFNLENBQUNtb0IsZ0JBQWdCLENBQUMsWUFBWTtVQUNsQyxJQUFJOEIsVUFBVSxHQUFHcGUsTUFBTSxJQUFJdkgsSUFBSSxDQUFDc2lCLFFBQVEsQ0FBQ3NELGVBQWUsQ0FBQ3JlLE1BQU0sQ0FBQyxDQUFDbEQsTUFBTTtVQUV2RSxJQUFJd2hCLGVBQWUsR0FBRzdsQixJQUFJLENBQUMyaEIsVUFBVSxDQUFDOWdCLEdBQUcsQ0FBQ2lFLEVBQUUsQ0FBQztVQUM3QyxJQUFJZ2hCLGNBQWMsR0FBRzlsQixJQUFJLENBQUNzaEIsTUFBTSxJQUFJdGhCLElBQUksQ0FBQ3loQixrQkFBa0IsQ0FBQzVnQixHQUFHLENBQUNpRSxFQUFFLENBQUM7VUFDbkUsSUFBSWloQixZQUFZLEdBQUdGLGVBQWUsSUFBSUMsY0FBYztVQUVwRCxJQUFJSCxVQUFVLElBQUksQ0FBQ0ksWUFBWSxFQUFFO1lBQy9CL2xCLElBQUksQ0FBQ2tsQixZQUFZLENBQUMzZCxNQUFNLENBQUM7VUFDM0IsQ0FBQyxNQUFNLElBQUl3ZSxZQUFZLElBQUksQ0FBQ0osVUFBVSxFQUFFO1lBQ3RDM2xCLElBQUksQ0FBQ3lsQixlQUFlLENBQUMzZ0IsRUFBRSxDQUFDO1VBQzFCLENBQUMsTUFBTSxJQUFJaWhCLFlBQVksSUFBSUosVUFBVSxFQUFFO1lBQ3JDLElBQUloQixNQUFNLEdBQUcza0IsSUFBSSxDQUFDMmhCLFVBQVUsQ0FBQzNELEdBQUcsQ0FBQ2xaLEVBQUUsQ0FBQztZQUNwQyxJQUFJb2MsVUFBVSxHQUFHbGhCLElBQUksQ0FBQ3VoQixXQUFXO1lBQ2pDLElBQUl5RSxXQUFXLEdBQUdobUIsSUFBSSxDQUFDc2hCLE1BQU0sSUFBSXRoQixJQUFJLENBQUN5aEIsa0JBQWtCLENBQUMvaUIsSUFBSSxDQUFDLENBQUMsSUFDN0RzQixJQUFJLENBQUN5aEIsa0JBQWtCLENBQUN6RCxHQUFHLENBQUNoZSxJQUFJLENBQUN5aEIsa0JBQWtCLENBQUMrQyxZQUFZLENBQUMsQ0FBQyxDQUFDO1lBQ3JFLElBQUlZLFdBQVc7WUFFZixJQUFJUyxlQUFlLEVBQUU7Y0FDbkI7Y0FDQTtjQUNBO2NBQ0E7Y0FDQTtjQUNBO2NBQ0E7Y0FDQTtjQUNBO2NBQ0EsSUFBSUksZ0JBQWdCLEdBQUcsQ0FBRWptQixJQUFJLENBQUNzaEIsTUFBTSxJQUNsQ3RoQixJQUFJLENBQUN5aEIsa0JBQWtCLENBQUMvaUIsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLElBQ3BDd2lCLFVBQVUsQ0FBQzNaLE1BQU0sRUFBRXllLFdBQVcsQ0FBQyxJQUFJLENBQUM7Y0FFdEMsSUFBSUMsZ0JBQWdCLEVBQUU7Z0JBQ3BCam1CLElBQUksQ0FBQzBrQixnQkFBZ0IsQ0FBQzVmLEVBQUUsRUFBRTZmLE1BQU0sRUFBRXBkLE1BQU0sQ0FBQztjQUMzQyxDQUFDLE1BQU07Z0JBQ0w7Z0JBQ0F2SCxJQUFJLENBQUNxa0IsZ0JBQWdCLENBQUN2ZixFQUFFLENBQUM7Z0JBQ3pCO2dCQUNBc2dCLFdBQVcsR0FBR3BsQixJQUFJLENBQUN5aEIsa0JBQWtCLENBQUN6RCxHQUFHLENBQ3ZDaGUsSUFBSSxDQUFDeWhCLGtCQUFrQixDQUFDc0MsWUFBWSxDQUFDLENBQUMsQ0FBQztnQkFFekMsSUFBSXlCLFFBQVEsR0FBR3hsQixJQUFJLENBQUM2aEIsbUJBQW1CLElBQ2hDdUQsV0FBVyxJQUFJbEUsVUFBVSxDQUFDM1osTUFBTSxFQUFFNmQsV0FBVyxDQUFDLElBQUksQ0FBRTtnQkFFM0QsSUFBSUksUUFBUSxFQUFFO2tCQUNaeGxCLElBQUksQ0FBQ29rQixZQUFZLENBQUN0ZixFQUFFLEVBQUV5QyxNQUFNLENBQUM7Z0JBQy9CLENBQUMsTUFBTTtrQkFDTDtrQkFDQXZILElBQUksQ0FBQzZoQixtQkFBbUIsR0FBRyxLQUFLO2dCQUNsQztjQUNGO1lBQ0YsQ0FBQyxNQUFNLElBQUlpRSxjQUFjLEVBQUU7Y0FDekJuQixNQUFNLEdBQUcza0IsSUFBSSxDQUFDeWhCLGtCQUFrQixDQUFDekQsR0FBRyxDQUFDbFosRUFBRSxDQUFDO2NBQ3hDO2NBQ0E7Y0FDQTtjQUNBO2NBQ0E5RSxJQUFJLENBQUN5aEIsa0JBQWtCLENBQUN5QyxNQUFNLENBQUNwZixFQUFFLENBQUM7Y0FFbEMsSUFBSXFnQixZQUFZLEdBQUdubEIsSUFBSSxDQUFDMmhCLFVBQVUsQ0FBQzNELEdBQUcsQ0FDcENoZSxJQUFJLENBQUMyaEIsVUFBVSxDQUFDb0MsWUFBWSxDQUFDLENBQUMsQ0FBQztjQUNqQ3FCLFdBQVcsR0FBR3BsQixJQUFJLENBQUN5aEIsa0JBQWtCLENBQUMvaUIsSUFBSSxDQUFDLENBQUMsSUFDdENzQixJQUFJLENBQUN5aEIsa0JBQWtCLENBQUN6RCxHQUFHLENBQ3pCaGUsSUFBSSxDQUFDeWhCLGtCQUFrQixDQUFDc0MsWUFBWSxDQUFDLENBQUMsQ0FBQzs7Y0FFL0M7Y0FDQSxJQUFJc0IsU0FBUyxHQUFHbkUsVUFBVSxDQUFDM1osTUFBTSxFQUFFNGQsWUFBWSxDQUFDLEdBQUcsQ0FBQzs7Y0FFcEQ7Y0FDQSxJQUFJZSxhQUFhLEdBQUksQ0FBRWIsU0FBUyxJQUFJcmxCLElBQUksQ0FBQzZoQixtQkFBbUIsSUFDckQsQ0FBQ3dELFNBQVMsSUFBSUQsV0FBVyxJQUN6QmxFLFVBQVUsQ0FBQzNaLE1BQU0sRUFBRTZkLFdBQVcsQ0FBQyxJQUFJLENBQUU7Y0FFNUMsSUFBSUMsU0FBUyxFQUFFO2dCQUNicmxCLElBQUksQ0FBQzRqQixhQUFhLENBQUM5ZSxFQUFFLEVBQUV5QyxNQUFNLENBQUM7Y0FDaEMsQ0FBQyxNQUFNLElBQUkyZSxhQUFhLEVBQUU7Z0JBQ3hCO2dCQUNBbG1CLElBQUksQ0FBQ3loQixrQkFBa0IsQ0FBQ2pTLEdBQUcsQ0FBQzFLLEVBQUUsRUFBRXlDLE1BQU0sQ0FBQztjQUN6QyxDQUFDLE1BQU07Z0JBQ0w7Z0JBQ0F2SCxJQUFJLENBQUM2aEIsbUJBQW1CLEdBQUcsS0FBSztnQkFDaEM7Z0JBQ0E7Z0JBQ0EsSUFBSSxDQUFFN2hCLElBQUksQ0FBQ3loQixrQkFBa0IsQ0FBQy9pQixJQUFJLENBQUMsQ0FBQyxFQUFFO2tCQUNwQ3NCLElBQUksQ0FBQ2lqQixnQkFBZ0IsQ0FBQyxDQUFDO2dCQUN6QjtjQUNGO1lBQ0YsQ0FBQyxNQUFNO2NBQ0wsTUFBTSxJQUFJdGdCLEtBQUssQ0FBQywyRUFBMkUsQ0FBQztZQUM5RjtVQUNGO1FBQ0YsQ0FBQyxDQUFDO01BQ0osQ0FBQztNQUNEd2pCLHVCQUF1QixFQUFFLFNBQUFBLENBQUEsRUFBWTtRQUNuQyxJQUFJbm1CLElBQUksR0FBRyxJQUFJO1FBQ2ZBLElBQUksQ0FBQ3FpQixvQkFBb0IsQ0FBQzNCLEtBQUssQ0FBQ0UsUUFBUSxDQUFDO1FBQ3pDO1FBQ0E7UUFDQWxsQixNQUFNLENBQUM4VixLQUFLLENBQUN1UCx1QkFBdUIsQ0FBQyxrQkFBa0I7VUFDckQsT0FBTyxDQUFDL2dCLElBQUksQ0FBQ2dXLFFBQVEsSUFBSSxDQUFDaFcsSUFBSSxDQUFDNGlCLFlBQVksQ0FBQzBCLEtBQUssQ0FBQyxDQUFDLEVBQUU7WUFDbkQsSUFBSXRrQixJQUFJLENBQUNrakIsTUFBTSxLQUFLeEMsS0FBSyxDQUFDQyxRQUFRLEVBQUU7Y0FDbEM7Y0FDQTtjQUNBO2NBQ0E7WUFDRjs7WUFFQTtZQUNBLElBQUkzZ0IsSUFBSSxDQUFDa2pCLE1BQU0sS0FBS3hDLEtBQUssQ0FBQ0UsUUFBUSxFQUNoQyxNQUFNLElBQUlqZSxLQUFLLENBQUMsbUNBQW1DLEdBQUczQyxJQUFJLENBQUNrakIsTUFBTSxDQUFDO1lBRXBFbGpCLElBQUksQ0FBQzZpQixrQkFBa0IsR0FBRzdpQixJQUFJLENBQUM0aUIsWUFBWTtZQUMzQyxJQUFJd0QsY0FBYyxHQUFHLEVBQUVwbUIsSUFBSSxDQUFDOGlCLGdCQUFnQjtZQUM1QzlpQixJQUFJLENBQUM0aUIsWUFBWSxHQUFHLElBQUloZSxlQUFlLENBQUNxSyxNQUFNLENBQUQsQ0FBQztZQUM5QyxJQUFJb1gsT0FBTyxHQUFHLENBQUM7WUFFZixJQUFJOU4sZUFBZSxHQUFHLElBQUk7WUFDMUIsTUFBTStOLGdCQUFnQixHQUFHLElBQUloYSxPQUFPLENBQUM4SixDQUFDLElBQUltQyxlQUFlLEdBQUduQyxDQUFDLENBQUM7WUFDOUQ7WUFDQTtZQUNBLE1BQU1wVyxJQUFJLENBQUM2aUIsa0JBQWtCLENBQUN2RixZQUFZLENBQUMsZ0JBQWdCOUgsRUFBRSxFQUFFMVEsRUFBRSxFQUFFO2NBQ2pFdWhCLE9BQU8sRUFBRTtjQUNULE1BQU1ybUIsSUFBSSxDQUFDdWUsWUFBWSxDQUFDM2MsV0FBVyxDQUFDb0ksS0FBSyxDQUN2Q2hLLElBQUksQ0FBQ3VMLGtCQUFrQixDQUFDdEksY0FBYyxFQUN0QzZCLEVBQUUsRUFDRjBRLEVBQUUsRUFDRnVMLHVCQUF1QixDQUFDLFVBQVMzYyxHQUFHLEVBQUVtTCxHQUFHLEVBQUU7Z0JBQ3pDLElBQUluTCxHQUFHLEVBQUU7a0JBQ1AxSSxNQUFNLENBQUNrYyxNQUFNLENBQUMsd0NBQXdDLEVBQUV4VCxHQUFHLENBQUM7a0JBQzVEO2tCQUNBO2tCQUNBO2tCQUNBO2tCQUNBLElBQUlwRSxJQUFJLENBQUNrakIsTUFBTSxLQUFLeEMsS0FBSyxDQUFDQyxRQUFRLEVBQUU7b0JBQ2xDM2dCLElBQUksQ0FBQ2lqQixnQkFBZ0IsQ0FBQyxDQUFDO2tCQUN6QjtrQkFDQW9ELE9BQU8sRUFBRTtrQkFDVDtrQkFDQTtrQkFDQTtrQkFDQSxJQUFJQSxPQUFPLEtBQUssQ0FBQyxFQUFFOU4sZUFBZSxDQUFDLENBQUM7a0JBQ3BDO2dCQUNGO2dCQUVBLElBQUk7a0JBQ0YsSUFDRSxDQUFDdlksSUFBSSxDQUFDZ1csUUFBUSxJQUNkaFcsSUFBSSxDQUFDa2pCLE1BQU0sS0FBS3hDLEtBQUssQ0FBQ0UsUUFBUSxJQUM5QjVnQixJQUFJLENBQUM4aUIsZ0JBQWdCLEtBQUtzRCxjQUFjLEVBQ3hDO29CQUNBO29CQUNBO29CQUNBO29CQUNBOztvQkFFQXBtQixJQUFJLENBQUMwbEIsVUFBVSxDQUFDNWdCLEVBQUUsRUFBRXlLLEdBQUcsQ0FBQztrQkFDMUI7Z0JBQ0YsQ0FBQyxTQUFTO2tCQUNSOFcsT0FBTyxFQUFFO2tCQUNUO2tCQUNBO2tCQUNBO2tCQUNBLElBQUlBLE9BQU8sS0FBSyxDQUFDLEVBQUU5TixlQUFlLENBQUMsQ0FBQztnQkFDdEM7Y0FDRixDQUFDLENBQ0gsQ0FBQztZQUNILENBQUMsQ0FBQztZQUNGLE1BQU0rTixnQkFBZ0I7WUFDdEI7WUFDQSxJQUFJdG1CLElBQUksQ0FBQ2tqQixNQUFNLEtBQUt4QyxLQUFLLENBQUNDLFFBQVEsRUFDaEM7WUFDRjNnQixJQUFJLENBQUM2aUIsa0JBQWtCLEdBQUcsSUFBSTtVQUNoQztVQUNBO1VBQ0E7VUFDQSxJQUFJN2lCLElBQUksQ0FBQ2tqQixNQUFNLEtBQUt4QyxLQUFLLENBQUNDLFFBQVEsRUFDaEMsTUFBTTNnQixJQUFJLENBQUN1bUIsU0FBUyxDQUFDLENBQUM7UUFDMUIsQ0FBQyxDQUFDLENBQUM7TUFDTCxDQUFDO01BQ0RBLFNBQVMsRUFBRSxlQUFBQSxDQUFBLEVBQWtCO1FBQzNCLElBQUl2bUIsSUFBSSxHQUFHLElBQUk7UUFDZkEsSUFBSSxDQUFDcWlCLG9CQUFvQixDQUFDM0IsS0FBSyxDQUFDRyxNQUFNLENBQUM7UUFDdkMsSUFBSTJGLE1BQU0sR0FBR3htQixJQUFJLENBQUNnakIsZ0NBQWdDLElBQUksRUFBRTtRQUN4RGhqQixJQUFJLENBQUNnakIsZ0NBQWdDLEdBQUcsRUFBRTtRQUMxQyxNQUFNaGpCLElBQUksQ0FBQ3VkLFlBQVksQ0FBQ1QsT0FBTyxDQUFDLGtCQUFrQjtVQUNoRCxJQUFJO1lBQ0YsS0FBSyxNQUFNc0QsQ0FBQyxJQUFJb0csTUFBTSxFQUFFO2NBQ3RCLE1BQU1wRyxDQUFDLENBQUN0YyxTQUFTLENBQUMsQ0FBQztZQUNyQjtVQUNGLENBQUMsQ0FBQyxPQUFPWSxDQUFDLEVBQUU7WUFDVjRLLE9BQU8sQ0FBQzNJLEtBQUssQ0FBQyxpQkFBaUIsRUFBRTtjQUFDNmY7WUFBTSxDQUFDLEVBQUU5aEIsQ0FBQyxDQUFDO1VBQy9DO1FBQ0YsQ0FBQyxDQUFDO01BQ0osQ0FBQztNQUNEeWUseUJBQXlCLEVBQUUsU0FBQUEsQ0FBVTNOLEVBQUUsRUFBRTtRQUN2QyxJQUFJeFYsSUFBSSxHQUFHLElBQUk7UUFDZnRFLE1BQU0sQ0FBQ21vQixnQkFBZ0IsQ0FBQyxZQUFZO1VBQ2xDN2pCLElBQUksQ0FBQzRpQixZQUFZLENBQUNwVCxHQUFHLENBQUMrRixPQUFPLENBQUNDLEVBQUUsQ0FBQyxFQUFFQSxFQUFFLENBQUM7UUFDeEMsQ0FBQyxDQUFDO01BQ0osQ0FBQztNQUNENE4saUNBQWlDLEVBQUUsU0FBQUEsQ0FBVTVOLEVBQUUsRUFBRTtRQUMvQyxJQUFJeFYsSUFBSSxHQUFHLElBQUk7UUFDZnRFLE1BQU0sQ0FBQ21vQixnQkFBZ0IsQ0FBQyxZQUFZO1VBQ2xDLElBQUkvZSxFQUFFLEdBQUd5USxPQUFPLENBQUNDLEVBQUUsQ0FBQztVQUNwQjtVQUNBOztVQUVBLElBQUl4VixJQUFJLENBQUNrakIsTUFBTSxLQUFLeEMsS0FBSyxDQUFDRSxRQUFRLEtBQzVCNWdCLElBQUksQ0FBQzZpQixrQkFBa0IsSUFBSTdpQixJQUFJLENBQUM2aUIsa0JBQWtCLENBQUNoaUIsR0FBRyxDQUFDaUUsRUFBRSxDQUFDLElBQzNEOUUsSUFBSSxDQUFDNGlCLFlBQVksQ0FBQy9oQixHQUFHLENBQUNpRSxFQUFFLENBQUMsQ0FBQyxFQUFFO1lBQy9COUUsSUFBSSxDQUFDNGlCLFlBQVksQ0FBQ3BULEdBQUcsQ0FBQzFLLEVBQUUsRUFBRTBRLEVBQUUsQ0FBQztZQUM3QjtVQUNGO1VBRUEsSUFBSUEsRUFBRSxDQUFDQSxFQUFFLEtBQUssR0FBRyxFQUFFO1lBQ2pCLElBQUl4VixJQUFJLENBQUMyaEIsVUFBVSxDQUFDOWdCLEdBQUcsQ0FBQ2lFLEVBQUUsQ0FBQyxJQUN0QjlFLElBQUksQ0FBQ3NoQixNQUFNLElBQUl0aEIsSUFBSSxDQUFDeWhCLGtCQUFrQixDQUFDNWdCLEdBQUcsQ0FBQ2lFLEVBQUUsQ0FBRSxFQUNsRDlFLElBQUksQ0FBQ3lsQixlQUFlLENBQUMzZ0IsRUFBRSxDQUFDO1VBQzVCLENBQUMsTUFBTSxJQUFJMFEsRUFBRSxDQUFDQSxFQUFFLEtBQUssR0FBRyxFQUFFO1lBQ3hCLElBQUl4VixJQUFJLENBQUMyaEIsVUFBVSxDQUFDOWdCLEdBQUcsQ0FBQ2lFLEVBQUUsQ0FBQyxFQUN6QixNQUFNLElBQUluQyxLQUFLLENBQUMsbURBQW1ELENBQUM7WUFDdEUsSUFBSTNDLElBQUksQ0FBQ3loQixrQkFBa0IsSUFBSXpoQixJQUFJLENBQUN5aEIsa0JBQWtCLENBQUM1Z0IsR0FBRyxDQUFDaUUsRUFBRSxDQUFDLEVBQzVELE1BQU0sSUFBSW5DLEtBQUssQ0FBQyxnREFBZ0QsQ0FBQzs7WUFFbkU7WUFDQTtZQUNBLElBQUkzQyxJQUFJLENBQUNzaUIsUUFBUSxDQUFDc0QsZUFBZSxDQUFDcFEsRUFBRSxDQUFDQyxDQUFDLENBQUMsQ0FBQ3BSLE1BQU0sRUFDNUNyRSxJQUFJLENBQUNrbEIsWUFBWSxDQUFDMVAsRUFBRSxDQUFDQyxDQUFDLENBQUM7VUFDM0IsQ0FBQyxNQUFNLElBQUlELEVBQUUsQ0FBQ0EsRUFBRSxLQUFLLEdBQUcsRUFBRTtZQUN4QjtZQUNBO1lBQ0FBLEVBQUUsQ0FBQ0MsQ0FBQyxHQUFHK0ssa0JBQWtCLENBQUNoTCxFQUFFLENBQUNDLENBQUMsQ0FBQztZQUMvQjtZQUNBO1lBQ0E7WUFDQTtZQUNBO1lBQ0E7WUFDQSxJQUFJZ1IsU0FBUyxHQUFHLENBQUMxcEIsQ0FBQyxDQUFDOEQsR0FBRyxDQUFDMlUsRUFBRSxDQUFDQyxDQUFDLEVBQUUsTUFBTSxDQUFDLElBQUksQ0FBQzFZLENBQUMsQ0FBQzhELEdBQUcsQ0FBQzJVLEVBQUUsQ0FBQ0MsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMxWSxDQUFDLENBQUM4RCxHQUFHLENBQUMyVSxFQUFFLENBQUNDLENBQUMsRUFBRSxRQUFRLENBQUM7WUFDdEY7WUFDQTtZQUNBO1lBQ0E7WUFDQSxJQUFJaVIsb0JBQW9CLEdBQ3RCLENBQUNELFNBQVMsSUFBSUUsNEJBQTRCLENBQUNuUixFQUFFLENBQUNDLENBQUMsQ0FBQztZQUVsRCxJQUFJb1EsZUFBZSxHQUFHN2xCLElBQUksQ0FBQzJoQixVQUFVLENBQUM5Z0IsR0FBRyxDQUFDaUUsRUFBRSxDQUFDO1lBQzdDLElBQUlnaEIsY0FBYyxHQUFHOWxCLElBQUksQ0FBQ3NoQixNQUFNLElBQUl0aEIsSUFBSSxDQUFDeWhCLGtCQUFrQixDQUFDNWdCLEdBQUcsQ0FBQ2lFLEVBQUUsQ0FBQztZQUVuRSxJQUFJMmhCLFNBQVMsRUFBRTtjQUNiem1CLElBQUksQ0FBQzBsQixVQUFVLENBQUM1Z0IsRUFBRSxFQUFFL0gsQ0FBQyxDQUFDNEksTUFBTSxDQUFDO2dCQUFDWixHQUFHLEVBQUVEO2NBQUUsQ0FBQyxFQUFFMFEsRUFBRSxDQUFDQyxDQUFDLENBQUMsQ0FBQztZQUNoRCxDQUFDLE1BQU0sSUFBSSxDQUFDb1EsZUFBZSxJQUFJQyxjQUFjLEtBQ2xDWSxvQkFBb0IsRUFBRTtjQUMvQjtjQUNBO2NBQ0EsSUFBSW5mLE1BQU0sR0FBR3ZILElBQUksQ0FBQzJoQixVQUFVLENBQUM5Z0IsR0FBRyxDQUFDaUUsRUFBRSxDQUFDLEdBQ2hDOUUsSUFBSSxDQUFDMmhCLFVBQVUsQ0FBQzNELEdBQUcsQ0FBQ2xaLEVBQUUsQ0FBQyxHQUFHOUUsSUFBSSxDQUFDeWhCLGtCQUFrQixDQUFDekQsR0FBRyxDQUFDbFosRUFBRSxDQUFDO2NBQzdEeUMsTUFBTSxHQUFHNUksS0FBSyxDQUFDbEIsS0FBSyxDQUFDOEosTUFBTSxDQUFDO2NBRTVCQSxNQUFNLENBQUN4QyxHQUFHLEdBQUdELEVBQUU7Y0FDZixJQUFJO2dCQUNGRixlQUFlLENBQUNnaUIsT0FBTyxDQUFDcmYsTUFBTSxFQUFFaU8sRUFBRSxDQUFDQyxDQUFDLENBQUM7Y0FDdkMsQ0FBQyxDQUFDLE9BQU8vUSxDQUFDLEVBQUU7Z0JBQ1YsSUFBSUEsQ0FBQyxDQUFDL0csSUFBSSxLQUFLLGdCQUFnQixFQUM3QixNQUFNK0csQ0FBQztnQkFDVDtnQkFDQTFFLElBQUksQ0FBQzRpQixZQUFZLENBQUNwVCxHQUFHLENBQUMxSyxFQUFFLEVBQUUwUSxFQUFFLENBQUM7Z0JBQzdCLElBQUl4VixJQUFJLENBQUNrakIsTUFBTSxLQUFLeEMsS0FBSyxDQUFDRyxNQUFNLEVBQUU7a0JBQ2hDN2dCLElBQUksQ0FBQ21tQix1QkFBdUIsQ0FBQyxDQUFDO2dCQUNoQztnQkFDQTtjQUNGO2NBQ0FubUIsSUFBSSxDQUFDMGxCLFVBQVUsQ0FBQzVnQixFQUFFLEVBQUU5RSxJQUFJLENBQUMyaUIsbUJBQW1CLENBQUNwYixNQUFNLENBQUMsQ0FBQztZQUN2RCxDQUFDLE1BQU0sSUFBSSxDQUFDbWYsb0JBQW9CLElBQ3JCMW1CLElBQUksQ0FBQ3NpQixRQUFRLENBQUN1RSx1QkFBdUIsQ0FBQ3JSLEVBQUUsQ0FBQ0MsQ0FBQyxDQUFDLElBQzFDelYsSUFBSSxDQUFDd2hCLE9BQU8sSUFBSXhoQixJQUFJLENBQUN3aEIsT0FBTyxDQUFDc0Ysa0JBQWtCLENBQUN0UixFQUFFLENBQUNDLENBQUMsQ0FBRSxFQUFFO2NBQ2xFelYsSUFBSSxDQUFDNGlCLFlBQVksQ0FBQ3BULEdBQUcsQ0FBQzFLLEVBQUUsRUFBRTBRLEVBQUUsQ0FBQztjQUM3QixJQUFJeFYsSUFBSSxDQUFDa2pCLE1BQU0sS0FBS3hDLEtBQUssQ0FBQ0csTUFBTSxFQUM5QjdnQixJQUFJLENBQUNtbUIsdUJBQXVCLENBQUMsQ0FBQztZQUNsQztVQUNGLENBQUMsTUFBTTtZQUNMLE1BQU14akIsS0FBSyxDQUFDLDRCQUE0QixHQUFHNlMsRUFBRSxDQUFDO1VBQ2hEO1FBQ0YsQ0FBQyxDQUFDO01BQ0osQ0FBQztNQUVELE1BQU11UixxQkFBcUJBLENBQUEsRUFBRztRQUM1QixJQUFJL21CLElBQUksR0FBRyxJQUFJO1FBQ2YsSUFBSUEsSUFBSSxDQUFDZ1csUUFBUSxFQUNmLE1BQU0sSUFBSXJULEtBQUssQ0FBQyxrQ0FBa0MsQ0FBQztRQUVyRCxNQUFNM0MsSUFBSSxDQUFDZ25CLFNBQVMsQ0FBQztVQUFDQyxPQUFPLEVBQUU7UUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFFOztRQUV4QyxJQUFJam5CLElBQUksQ0FBQ2dXLFFBQVEsRUFDZixPQUFPLENBQUU7O1FBRVg7UUFDQTtRQUNBLE1BQU1oVyxJQUFJLENBQUN1ZCxZQUFZLENBQUNaLEtBQUssQ0FBQyxDQUFDO1FBRS9CLE1BQU0zYyxJQUFJLENBQUNrbkIsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFFO01BQy9CLENBQUM7TUFFRDtNQUNBdkQsZ0JBQWdCLEVBQUUsU0FBQUEsQ0FBQSxFQUFZO1FBQzVCLE9BQU8sSUFBSSxDQUFDb0QscUJBQXFCLENBQUMsQ0FBQztNQUNyQyxDQUFDO01BRUQ7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBSSxVQUFVLEVBQUUsU0FBQUEsQ0FBQSxFQUFZO1FBQ3RCLElBQUlubkIsSUFBSSxHQUFHLElBQUk7UUFDZnRFLE1BQU0sQ0FBQ21vQixnQkFBZ0IsQ0FBQyxZQUFZO1VBQ2xDLElBQUk3akIsSUFBSSxDQUFDZ1csUUFBUSxFQUNmOztVQUVGO1VBQ0FoVyxJQUFJLENBQUM0aUIsWUFBWSxHQUFHLElBQUloZSxlQUFlLENBQUNxSyxNQUFNLENBQUQsQ0FBQztVQUM5Q2pQLElBQUksQ0FBQzZpQixrQkFBa0IsR0FBRyxJQUFJO1VBQzlCLEVBQUU3aUIsSUFBSSxDQUFDOGlCLGdCQUFnQixDQUFDLENBQUU7VUFDMUI5aUIsSUFBSSxDQUFDcWlCLG9CQUFvQixDQUFDM0IsS0FBSyxDQUFDQyxRQUFRLENBQUM7O1VBRXpDO1VBQ0E7VUFDQWpsQixNQUFNLENBQUM4VixLQUFLLENBQUMsa0JBQWtCO1lBQzdCLE1BQU14UixJQUFJLENBQUNnbkIsU0FBUyxDQUFDLENBQUM7WUFDdEIsTUFBTWhuQixJQUFJLENBQUNrbkIsYUFBYSxDQUFDLENBQUM7VUFDNUIsQ0FBQyxDQUFDO1FBQ0osQ0FBQyxDQUFDO01BQ0osQ0FBQztNQUVEO01BQ0EsTUFBTUUsY0FBY0EsQ0FBQ3huQixPQUFPLEVBQUU7UUFDNUIsSUFBSUksSUFBSSxHQUFHLElBQUk7UUFDZkosT0FBTyxHQUFHQSxPQUFPLElBQUksQ0FBQyxDQUFDO1FBQ3ZCLElBQUlpZ0IsVUFBVSxFQUFFd0gsU0FBUzs7UUFFekI7UUFDQSxPQUFPLElBQUksRUFBRTtVQUNYO1VBQ0EsSUFBSXJuQixJQUFJLENBQUNnVyxRQUFRLEVBQ2Y7VUFFRjZKLFVBQVUsR0FBRyxJQUFJamIsZUFBZSxDQUFDcUssTUFBTSxDQUFELENBQUM7VUFDdkNvWSxTQUFTLEdBQUcsSUFBSXppQixlQUFlLENBQUNxSyxNQUFNLENBQUQsQ0FBQzs7VUFFdEM7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQSxJQUFJdkQsTUFBTSxHQUFHMUwsSUFBSSxDQUFDc25CLGVBQWUsQ0FBQztZQUFFeGQsS0FBSyxFQUFFOUosSUFBSSxDQUFDc2hCLE1BQU0sR0FBRztVQUFFLENBQUMsQ0FBQztVQUM3RCxJQUFJO1lBQ0YsTUFBTTVWLE1BQU0sQ0FBQ3ZLLE9BQU8sQ0FBQyxVQUFVb08sR0FBRyxFQUFFZ1ksQ0FBQyxFQUFFO2NBQUc7Y0FDeEMsSUFBSSxDQUFDdm5CLElBQUksQ0FBQ3NoQixNQUFNLElBQUlpRyxDQUFDLEdBQUd2bkIsSUFBSSxDQUFDc2hCLE1BQU0sRUFBRTtnQkFDbkN6QixVQUFVLENBQUNyUSxHQUFHLENBQUNELEdBQUcsQ0FBQ3hLLEdBQUcsRUFBRXdLLEdBQUcsQ0FBQztjQUM5QixDQUFDLE1BQU07Z0JBQ0w4WCxTQUFTLENBQUM3WCxHQUFHLENBQUNELEdBQUcsQ0FBQ3hLLEdBQUcsRUFBRXdLLEdBQUcsQ0FBQztjQUM3QjtZQUNGLENBQUMsQ0FBQztZQUNGO1VBQ0YsQ0FBQyxDQUFDLE9BQU83SyxDQUFDLEVBQUU7WUFDVixJQUFJOUUsT0FBTyxDQUFDcW5CLE9BQU8sSUFBSSxPQUFPdmlCLENBQUMsQ0FBQ3NiLElBQUssS0FBSyxRQUFRLEVBQUU7Y0FDbEQ7Y0FDQTtjQUNBO2NBQ0E7Y0FDQTtjQUNBLE1BQU1oZ0IsSUFBSSxDQUFDdWQsWUFBWSxDQUFDVixVQUFVLENBQUNuWSxDQUFDLENBQUM7Y0FDckM7WUFDRjs7WUFFQTtZQUNBO1lBQ0FoSixNQUFNLENBQUNrYyxNQUFNLENBQUMsbUNBQW1DLEVBQUVsVCxDQUFDLENBQUM7WUFDckQsTUFBTWhKLE1BQU0sQ0FBQ3ljLFdBQVcsQ0FBQyxHQUFHLENBQUM7VUFDL0I7UUFDRjtRQUVBLElBQUluWSxJQUFJLENBQUNnVyxRQUFRLEVBQ2Y7UUFFRmhXLElBQUksQ0FBQ3duQixrQkFBa0IsQ0FBQzNILFVBQVUsRUFBRXdILFNBQVMsQ0FBQztNQUNoRCxDQUFDO01BRUQ7TUFDQUwsU0FBUyxFQUFFLFNBQUFBLENBQVVwbkIsT0FBTyxFQUFFO1FBQzVCLE9BQU8sSUFBSSxDQUFDd25CLGNBQWMsQ0FBQ3huQixPQUFPLENBQUM7TUFDckMsQ0FBQztNQUVEO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBcWpCLGdCQUFnQixFQUFFLFNBQUFBLENBQUEsRUFBWTtRQUM1QixJQUFJampCLElBQUksR0FBRyxJQUFJO1FBQ2Z0RSxNQUFNLENBQUNtb0IsZ0JBQWdCLENBQUMsWUFBWTtVQUNsQyxJQUFJN2pCLElBQUksQ0FBQ2dXLFFBQVEsRUFDZjs7VUFFRjtVQUNBO1VBQ0EsSUFBSWhXLElBQUksQ0FBQ2tqQixNQUFNLEtBQUt4QyxLQUFLLENBQUNDLFFBQVEsRUFBRTtZQUNsQzNnQixJQUFJLENBQUNtbkIsVUFBVSxDQUFDLENBQUM7WUFDakIsTUFBTSxJQUFJckcsZUFBZSxDQUFELENBQUM7VUFDM0I7O1VBRUE7VUFDQTtVQUNBOWdCLElBQUksQ0FBQytpQix5QkFBeUIsR0FBRyxJQUFJO1FBQ3ZDLENBQUMsQ0FBQztNQUNKLENBQUM7TUFFRDtNQUNBbUUsYUFBYSxFQUFFLGVBQUFBLENBQUEsRUFBa0I7UUFDL0IsSUFBSWxuQixJQUFJLEdBQUcsSUFBSTtRQUVmLElBQUlBLElBQUksQ0FBQ2dXLFFBQVEsRUFDZjtRQUVGLE1BQU1oVyxJQUFJLENBQUN1ZSxZQUFZLENBQUM1YyxZQUFZLENBQUNnWCxpQkFBaUIsQ0FBQyxDQUFDO1FBRXhELElBQUkzWSxJQUFJLENBQUNnVyxRQUFRLEVBQ2Y7UUFFRixJQUFJaFcsSUFBSSxDQUFDa2pCLE1BQU0sS0FBS3hDLEtBQUssQ0FBQ0MsUUFBUSxFQUNoQyxNQUFNaGUsS0FBSyxDQUFDLHFCQUFxQixHQUFHM0MsSUFBSSxDQUFDa2pCLE1BQU0sQ0FBQztRQUVsRCxJQUFJbGpCLElBQUksQ0FBQytpQix5QkFBeUIsRUFBRTtVQUNsQy9pQixJQUFJLENBQUMraUIseUJBQXlCLEdBQUcsS0FBSztVQUN0Qy9pQixJQUFJLENBQUNtbkIsVUFBVSxDQUFDLENBQUM7UUFDbkIsQ0FBQyxNQUFNLElBQUlubkIsSUFBSSxDQUFDNGlCLFlBQVksQ0FBQzBCLEtBQUssQ0FBQyxDQUFDLEVBQUU7VUFDcEMsTUFBTXRrQixJQUFJLENBQUN1bUIsU0FBUyxDQUFDLENBQUM7UUFDeEIsQ0FBQyxNQUFNO1VBQ0x2bUIsSUFBSSxDQUFDbW1CLHVCQUF1QixDQUFDLENBQUM7UUFDaEM7TUFDRixDQUFDO01BRURtQixlQUFlLEVBQUUsU0FBQUEsQ0FBVUcsZ0JBQWdCLEVBQUU7UUFDM0MsSUFBSXpuQixJQUFJLEdBQUcsSUFBSTtRQUNmLE9BQU90RSxNQUFNLENBQUNtb0IsZ0JBQWdCLENBQUMsWUFBWTtVQUN6QztVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0EsSUFBSWprQixPQUFPLEdBQUc3QyxDQUFDLENBQUNVLEtBQUssQ0FBQ3VDLElBQUksQ0FBQ3VMLGtCQUFrQixDQUFDM0wsT0FBTyxDQUFDOztVQUV0RDtVQUNBO1VBQ0E3QyxDQUFDLENBQUM0SSxNQUFNLENBQUMvRixPQUFPLEVBQUU2bkIsZ0JBQWdCLENBQUM7VUFFbkM3bkIsT0FBTyxDQUFDb08sTUFBTSxHQUFHaE8sSUFBSSxDQUFDeWlCLGlCQUFpQjtVQUN2QyxPQUFPN2lCLE9BQU8sQ0FBQzhNLFNBQVM7VUFDeEI7VUFDQSxJQUFJZ2IsV0FBVyxHQUFHLElBQUk5ZCxpQkFBaUIsQ0FDckM1SixJQUFJLENBQUN1TCxrQkFBa0IsQ0FBQ3RJLGNBQWMsRUFDdENqRCxJQUFJLENBQUN1TCxrQkFBa0IsQ0FBQ2hHLFFBQVEsRUFDaEMzRixPQUFPLENBQUM7VUFDVixPQUFPLElBQUkrSixNQUFNLENBQUMzSixJQUFJLENBQUN1ZSxZQUFZLEVBQUVtSixXQUFXLENBQUM7UUFDbkQsQ0FBQyxDQUFDO01BQ0osQ0FBQztNQUdEO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0FGLGtCQUFrQixFQUFFLFNBQUFBLENBQVUzSCxVQUFVLEVBQUV3SCxTQUFTLEVBQUU7UUFDbkQsSUFBSXJuQixJQUFJLEdBQUcsSUFBSTtRQUNmdEUsTUFBTSxDQUFDbW9CLGdCQUFnQixDQUFDLFlBQVk7VUFFbEM7VUFDQTtVQUNBLElBQUk3akIsSUFBSSxDQUFDc2hCLE1BQU0sRUFBRTtZQUNmdGhCLElBQUksQ0FBQ3loQixrQkFBa0IsQ0FBQy9HLEtBQUssQ0FBQyxDQUFDO1VBQ2pDOztVQUVBO1VBQ0E7VUFDQSxJQUFJaU4sV0FBVyxHQUFHLEVBQUU7VUFDcEIzbkIsSUFBSSxDQUFDMmhCLFVBQVUsQ0FBQ3hnQixPQUFPLENBQUMsVUFBVW9PLEdBQUcsRUFBRXpLLEVBQUUsRUFBRTtZQUN6QyxJQUFJLENBQUMrYSxVQUFVLENBQUNoZixHQUFHLENBQUNpRSxFQUFFLENBQUMsRUFDckI2aUIsV0FBVyxDQUFDdlgsSUFBSSxDQUFDdEwsRUFBRSxDQUFDO1VBQ3hCLENBQUMsQ0FBQztVQUNGL0gsQ0FBQyxDQUFDSyxJQUFJLENBQUN1cUIsV0FBVyxFQUFFLFVBQVU3aUIsRUFBRSxFQUFFO1lBQ2hDOUUsSUFBSSxDQUFDcWtCLGdCQUFnQixDQUFDdmYsRUFBRSxDQUFDO1VBQzNCLENBQUMsQ0FBQzs7VUFFRjtVQUNBO1VBQ0E7VUFDQSthLFVBQVUsQ0FBQzFlLE9BQU8sQ0FBQyxVQUFVb08sR0FBRyxFQUFFekssRUFBRSxFQUFFO1lBQ3BDOUUsSUFBSSxDQUFDMGxCLFVBQVUsQ0FBQzVnQixFQUFFLEVBQUV5SyxHQUFHLENBQUM7VUFDMUIsQ0FBQyxDQUFDOztVQUVGO1VBQ0E7VUFDQTtVQUNBLElBQUl2UCxJQUFJLENBQUMyaEIsVUFBVSxDQUFDampCLElBQUksQ0FBQyxDQUFDLEtBQUttaEIsVUFBVSxDQUFDbmhCLElBQUksQ0FBQyxDQUFDLEVBQUU7WUFDaERoRCxNQUFNLENBQUNrYyxNQUFNLENBQUMsd0RBQXdELEdBQ3BFLHVEQUF1RCxFQUN2RDVYLElBQUksQ0FBQ3VMLGtCQUFrQixDQUFDO1VBQzVCO1VBRUF2TCxJQUFJLENBQUMyaEIsVUFBVSxDQUFDeGdCLE9BQU8sQ0FBQyxVQUFVb08sR0FBRyxFQUFFekssRUFBRSxFQUFFO1lBQ3pDLElBQUksQ0FBQythLFVBQVUsQ0FBQ2hmLEdBQUcsQ0FBQ2lFLEVBQUUsQ0FBQyxFQUNyQixNQUFNbkMsS0FBSyxDQUFDLGdEQUFnRCxHQUFHbUMsRUFBRSxDQUFDO1VBQ3RFLENBQUMsQ0FBQzs7VUFFRjtVQUNBdWlCLFNBQVMsQ0FBQ2xtQixPQUFPLENBQUMsVUFBVW9PLEdBQUcsRUFBRXpLLEVBQUUsRUFBRTtZQUNuQzlFLElBQUksQ0FBQ29rQixZQUFZLENBQUN0ZixFQUFFLEVBQUV5SyxHQUFHLENBQUM7VUFDNUIsQ0FBQyxDQUFDO1VBRUZ2UCxJQUFJLENBQUM2aEIsbUJBQW1CLEdBQUd3RixTQUFTLENBQUMzb0IsSUFBSSxDQUFDLENBQUMsR0FBR3NCLElBQUksQ0FBQ3NoQixNQUFNO1FBQzNELENBQUMsQ0FBQztNQUNKLENBQUM7TUFFRDtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTdFLEtBQUssRUFBRSxlQUFBQSxDQUFBLEVBQWlCO1FBQ3RCLElBQUl6YyxJQUFJLEdBQUcsSUFBSTtRQUNmLElBQUlBLElBQUksQ0FBQ2dXLFFBQVEsRUFDZjtRQUNGaFcsSUFBSSxDQUFDZ1csUUFBUSxHQUFHLElBQUk7O1FBRXBCO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQSxLQUFLLE1BQU1vSyxDQUFDLElBQUlwZ0IsSUFBSSxDQUFDZ2pCLGdDQUFnQyxFQUFFO1VBQ3JELE1BQU01QyxDQUFDLENBQUN0YyxTQUFTLENBQUMsQ0FBQztRQUNyQjtRQUNBOUQsSUFBSSxDQUFDZ2pCLGdDQUFnQyxHQUFHLElBQUk7O1FBRTVDO1FBQ0FoakIsSUFBSSxDQUFDMmhCLFVBQVUsR0FBRyxJQUFJO1FBQ3RCM2hCLElBQUksQ0FBQ3loQixrQkFBa0IsR0FBRyxJQUFJO1FBQzlCemhCLElBQUksQ0FBQzRpQixZQUFZLEdBQUcsSUFBSTtRQUN4QjVpQixJQUFJLENBQUM2aUIsa0JBQWtCLEdBQUcsSUFBSTtRQUM5QjdpQixJQUFJLENBQUM0bkIsaUJBQWlCLEdBQUcsSUFBSTtRQUM3QjVuQixJQUFJLENBQUM2bkIsZ0JBQWdCLEdBQUcsSUFBSTtRQUU1QnRsQixPQUFPLENBQUMsWUFBWSxDQUFDLElBQUlBLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQzRZLEtBQUssQ0FBQ0MsbUJBQW1CLENBQ3BFLGdCQUFnQixFQUFFLHVCQUF1QixFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQUMsSUFBQTBNLHlCQUFBO1FBQUEsSUFBQUMsaUJBQUE7UUFBQSxJQUFBQyxjQUFBO1FBQUE7VUFFbkQsU0FBQUMsU0FBQSxHQUFBMUgsY0FBQSxDQUEyQnZnQixJQUFJLENBQUM4aEIsWUFBWSxHQUFBb0csS0FBQSxFQUFBSix5QkFBQSxLQUFBSSxLQUFBLFNBQUFELFNBQUEsQ0FBQS9ZLElBQUEsSUFBQUUsSUFBQSxFQUFBMFkseUJBQUEsVUFBRTtZQUFBLE1BQTdCM0wsTUFBTSxHQUFBK0wsS0FBQSxDQUFBN3FCLEtBQUE7WUFBQTtjQUNyQixNQUFNOGUsTUFBTSxDQUFDdFosSUFBSSxDQUFDLENBQUM7WUFBQztVQUN0QjtRQUFDLFNBQUF1QixHQUFBO1VBQUEyakIsaUJBQUE7VUFBQUMsY0FBQSxHQUFBNWpCLEdBQUE7UUFBQTtVQUFBO1lBQUEsSUFBQTBqQix5QkFBQSxJQUFBRyxTQUFBLENBQUFFLE1BQUE7Y0FBQSxNQUFBRixTQUFBLENBQUFFLE1BQUE7WUFBQTtVQUFBO1lBQUEsSUFBQUosaUJBQUE7Y0FBQSxNQUFBQyxjQUFBO1lBQUE7VUFBQTtRQUFBO01BQ0gsQ0FBQztNQUNEbmxCLElBQUksRUFBRSxlQUFBQSxDQUFBLEVBQWlCO1FBQ3JCLE1BQU03QyxJQUFJLEdBQUcsSUFBSTtRQUNqQixPQUFPLE1BQU1BLElBQUksQ0FBQ3ljLEtBQUssQ0FBQyxDQUFDO01BQzNCLENBQUM7TUFFRDRGLG9CQUFvQixFQUFFLFNBQUFBLENBQVUrRixLQUFLLEVBQUU7UUFDckMsSUFBSXBvQixJQUFJLEdBQUcsSUFBSTtRQUNmdEUsTUFBTSxDQUFDbW9CLGdCQUFnQixDQUFDLFlBQVk7VUFDbEMsSUFBSXdFLEdBQUcsR0FBRyxJQUFJQyxJQUFJLENBQUQsQ0FBQztVQUVsQixJQUFJdG9CLElBQUksQ0FBQ2tqQixNQUFNLEVBQUU7WUFDZixJQUFJcUYsUUFBUSxHQUFHRixHQUFHLEdBQUdyb0IsSUFBSSxDQUFDd29CLGVBQWU7WUFDekNqbUIsT0FBTyxDQUFDLFlBQVksQ0FBQyxJQUFJQSxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUM0WSxLQUFLLENBQUNDLG1CQUFtQixDQUN0RSxnQkFBZ0IsRUFBRSxnQkFBZ0IsR0FBR3BiLElBQUksQ0FBQ2tqQixNQUFNLEdBQUcsUUFBUSxFQUFFcUYsUUFBUSxDQUFDO1VBQzFFO1VBRUF2b0IsSUFBSSxDQUFDa2pCLE1BQU0sR0FBR2tGLEtBQUs7VUFDbkJwb0IsSUFBSSxDQUFDd29CLGVBQWUsR0FBR0gsR0FBRztRQUM1QixDQUFDLENBQUM7TUFDSjtJQUNGLENBQUMsQ0FBQzs7SUFFRjtJQUNBO0lBQ0E7SUFDQS9VLGtCQUFrQixDQUFDQyxlQUFlLEdBQUcsVUFBVWxJLGlCQUFpQixFQUFFd0gsT0FBTyxFQUFFO01BQ3pFO01BQ0EsSUFBSWpULE9BQU8sR0FBR3lMLGlCQUFpQixDQUFDekwsT0FBTzs7TUFFdkM7TUFDQTtNQUNBLElBQUlBLE9BQU8sQ0FBQzZvQixZQUFZLElBQUk3b0IsT0FBTyxDQUFDOG9CLGFBQWEsRUFDL0MsT0FBTyxLQUFLOztNQUVkO01BQ0E7TUFDQTtNQUNBO01BQ0EsSUFBSTlvQixPQUFPLENBQUNrTyxJQUFJLElBQUtsTyxPQUFPLENBQUNrSyxLQUFLLElBQUksQ0FBQ2xLLE9BQU8sQ0FBQ2lPLElBQUssRUFBRSxPQUFPLEtBQUs7O01BRWxFO01BQ0E7TUFDQSxNQUFNRyxNQUFNLEdBQUdwTyxPQUFPLENBQUNvTyxNQUFNLElBQUlwTyxPQUFPLENBQUNtTyxVQUFVO01BQ25ELElBQUlDLE1BQU0sRUFBRTtRQUNWLElBQUk7VUFDRnBKLGVBQWUsQ0FBQytqQix5QkFBeUIsQ0FBQzNhLE1BQU0sQ0FBQztRQUNuRCxDQUFDLENBQUMsT0FBT3RKLENBQUMsRUFBRTtVQUNWLElBQUlBLENBQUMsQ0FBQy9HLElBQUksS0FBSyxnQkFBZ0IsRUFBRTtZQUMvQixPQUFPLEtBQUs7VUFDZCxDQUFDLE1BQU07WUFDTCxNQUFNK0csQ0FBQztVQUNUO1FBQ0Y7TUFDRjs7TUFFQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0EsT0FBTyxDQUFDbU8sT0FBTyxDQUFDK1YsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDL1YsT0FBTyxDQUFDZ1csV0FBVyxDQUFDLENBQUM7SUFDdEQsQ0FBQztJQUVELElBQUlsQyw0QkFBNEIsR0FBRyxTQUFBQSxDQUFVbUMsUUFBUSxFQUFFO01BQ3JELE9BQU8vckIsQ0FBQyxDQUFDaVcsR0FBRyxDQUFDOFYsUUFBUSxFQUFFLFVBQVU5YSxNQUFNLEVBQUUrYSxTQUFTLEVBQUU7UUFDbEQsT0FBT2hzQixDQUFDLENBQUNpVyxHQUFHLENBQUNoRixNQUFNLEVBQUUsVUFBVTNRLEtBQUssRUFBRTJyQixLQUFLLEVBQUU7VUFDM0MsT0FBTyxDQUFDLFNBQVMsQ0FBQ0MsSUFBSSxDQUFDRCxLQUFLLENBQUM7UUFDL0IsQ0FBQyxDQUFDO01BQ0osQ0FBQyxDQUFDO0lBQ0osQ0FBQztJQUVEL3NCLGNBQWMsQ0FBQ3FYLGtCQUFrQixHQUFHQSxrQkFBa0I7SUFBQ3VCLHNCQUFBO0VBQUEsU0FBQUMsV0FBQTtJQUFBLE9BQUFELHNCQUFBLENBQUFDLFdBQUE7RUFBQTtFQUFBRCxzQkFBQTtBQUFBO0VBQUE3VSxJQUFBO0VBQUErVSxLQUFBO0FBQUEsRzs7Ozs7Ozs7Ozs7QUM3aEN2RHhZLE1BQU0sQ0FBQ2toQixNQUFNLENBQUM7RUFBQytDLGtCQUFrQixFQUFDQSxDQUFBLEtBQUlBO0FBQWtCLENBQUMsQ0FBQztBQUExRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsU0FBU2pmLElBQUlBLENBQUMybkIsTUFBTSxFQUFFNXJCLEdBQUcsRUFBRTtFQUN6QixPQUFPNHJCLE1BQU0sTUFBQWhlLE1BQUEsQ0FBTWdlLE1BQU0sT0FBQWhlLE1BQUEsQ0FBSTVOLEdBQUcsSUFBS0EsR0FBRztBQUMxQztBQUVBLE1BQU02ckIscUJBQXFCLEdBQUcsZUFBZTtBQUU3QyxTQUFTQyxrQkFBa0JBLENBQUNKLEtBQUssRUFBRTtFQUNqQyxPQUFPRyxxQkFBcUIsQ0FBQ0YsSUFBSSxDQUFDRCxLQUFLLENBQUM7QUFDMUM7QUFFQSxTQUFTSyxlQUFlQSxDQUFDQyxRQUFRLEVBQUU7RUFDakMsT0FBT0EsUUFBUSxDQUFDQyxDQUFDLEtBQUssSUFBSSxJQUFJN29CLE1BQU0sQ0FBQ3FILElBQUksQ0FBQ3VoQixRQUFRLENBQUMsQ0FBQ0UsS0FBSyxDQUFDSixrQkFBa0IsQ0FBQztBQUMvRTtBQUVBLFNBQVNLLGlCQUFpQkEsQ0FBQ0MsTUFBTSxFQUFFQyxNQUFNLEVBQUVULE1BQU0sRUFBRTtFQUNqRCxJQUFJM2UsS0FBSyxDQUFDdk4sT0FBTyxDQUFDMnNCLE1BQU0sQ0FBQyxJQUFJLE9BQU9BLE1BQU0sS0FBSyxRQUFRLElBQUlBLE1BQU0sS0FBSyxJQUFJLElBQ3RFQSxNQUFNLFlBQVl0ckIsS0FBSyxDQUFDRCxRQUFRLEVBQUU7SUFDcENzckIsTUFBTSxDQUFDUixNQUFNLENBQUMsR0FBR1MsTUFBTTtFQUN6QixDQUFDLE1BQU07SUFDTCxNQUFNM29CLE9BQU8sR0FBR04sTUFBTSxDQUFDTSxPQUFPLENBQUMyb0IsTUFBTSxDQUFDO0lBQ3RDLElBQUkzb0IsT0FBTyxDQUFDa0gsTUFBTSxFQUFFO01BQ2xCbEgsT0FBTyxDQUFDRyxPQUFPLENBQUNGLElBQUEsSUFBa0I7UUFBQSxJQUFqQixDQUFDM0QsR0FBRyxFQUFFRCxLQUFLLENBQUMsR0FBQTRELElBQUE7UUFDM0J3b0IsaUJBQWlCLENBQUNDLE1BQU0sRUFBRXJzQixLQUFLLEVBQUVrRSxJQUFJLENBQUMybkIsTUFBTSxFQUFFNXJCLEdBQUcsQ0FBQyxDQUFDO01BQ3JELENBQUMsQ0FBQztJQUNKLENBQUMsTUFBTTtNQUNMb3NCLE1BQU0sQ0FBQ1IsTUFBTSxDQUFDLEdBQUdTLE1BQU07SUFDekI7RUFDRjtBQUNGO0FBRUEsTUFBTUMsZ0JBQWdCLEdBQUcsQ0FBQyxDQUFDMVUsT0FBTyxDQUFDQyxHQUFHLENBQUMwVSxxQkFBcUI7QUFFNUQsU0FBU0MsZ0JBQWdCQSxDQUFDQyxVQUFVLEVBQUVDLElBQUksRUFBRWQsTUFBTSxFQUFFO0VBQ2xELElBQUlVLGdCQUFnQixFQUFFO0lBQ3BCdGEsT0FBTyxDQUFDMmEsR0FBRyxxQkFBQS9lLE1BQUEsQ0FBcUIrVSxJQUFJLENBQUNoTyxTQUFTLENBQUM4WCxVQUFVLENBQUMsUUFBQTdlLE1BQUEsQ0FBSytVLElBQUksQ0FBQ2hPLFNBQVMsQ0FBQytYLElBQUksQ0FBQyxRQUFBOWUsTUFBQSxDQUFLK1UsSUFBSSxDQUFDaE8sU0FBUyxDQUFDaVgsTUFBTSxDQUFDLE1BQUcsQ0FBQztFQUNwSDtFQUVBeG9CLE1BQU0sQ0FBQ00sT0FBTyxDQUFDZ3BCLElBQUksQ0FBQyxDQUFDN29CLE9BQU8sQ0FBQ0MsS0FBQSxJQUFzQjtJQUFBLElBQXJCLENBQUM4b0IsT0FBTyxFQUFFN3NCLEtBQUssQ0FBQyxHQUFBK0QsS0FBQTtJQUM1QyxJQUFJOG9CLE9BQU8sS0FBSyxHQUFHLEVBQUU7TUFBQSxJQUFBQyxrQkFBQTtNQUNuQjtNQUNBLENBQUFBLGtCQUFBLEdBQUFKLFVBQVUsQ0FBQ0ssTUFBTSxjQUFBRCxrQkFBQSxjQUFBQSxrQkFBQSxHQUFqQkosVUFBVSxDQUFDSyxNQUFNLEdBQUssQ0FBQyxDQUFDO01BQ3hCMXBCLE1BQU0sQ0FBQ3FILElBQUksQ0FBQzFLLEtBQUssQ0FBQyxDQUFDOEQsT0FBTyxDQUFDN0QsR0FBRyxJQUFJO1FBQ2hDeXNCLFVBQVUsQ0FBQ0ssTUFBTSxDQUFDN29CLElBQUksQ0FBQzJuQixNQUFNLEVBQUU1ckIsR0FBRyxDQUFDLENBQUMsR0FBRyxJQUFJO01BQzdDLENBQUMsQ0FBQztJQUNKLENBQUMsTUFBTSxJQUFJNHNCLE9BQU8sS0FBSyxHQUFHLEVBQUU7TUFBQSxJQUFBRyxnQkFBQTtNQUMxQjtNQUNBLENBQUFBLGdCQUFBLEdBQUFOLFVBQVUsQ0FBQ08sSUFBSSxjQUFBRCxnQkFBQSxjQUFBQSxnQkFBQSxHQUFmTixVQUFVLENBQUNPLElBQUksR0FBSyxDQUFDLENBQUM7TUFDdEJiLGlCQUFpQixDQUFDTSxVQUFVLENBQUNPLElBQUksRUFBRWp0QixLQUFLLEVBQUU2ckIsTUFBTSxDQUFDO0lBQ25ELENBQUMsTUFBTSxJQUFJZ0IsT0FBTyxLQUFLLEdBQUcsRUFBRTtNQUFBLElBQUFLLGlCQUFBO01BQzFCO01BQ0EsQ0FBQUEsaUJBQUEsR0FBQVIsVUFBVSxDQUFDTyxJQUFJLGNBQUFDLGlCQUFBLGNBQUFBLGlCQUFBLEdBQWZSLFVBQVUsQ0FBQ08sSUFBSSxHQUFLLENBQUMsQ0FBQztNQUN0QjVwQixNQUFNLENBQUNNLE9BQU8sQ0FBQzNELEtBQUssQ0FBQyxDQUFDOEQsT0FBTyxDQUFDZ0UsS0FBQSxJQUFrQjtRQUFBLElBQWpCLENBQUM3SCxHQUFHLEVBQUVELEtBQUssQ0FBQyxHQUFBOEgsS0FBQTtRQUN6QzRrQixVQUFVLENBQUNPLElBQUksQ0FBQy9vQixJQUFJLENBQUMybkIsTUFBTSxFQUFFNXJCLEdBQUcsQ0FBQyxDQUFDLEdBQUdELEtBQUs7TUFDNUMsQ0FBQyxDQUFDO0lBQ0osQ0FBQyxNQUFNO01BQ0w7TUFDQSxNQUFNQyxHQUFHLEdBQUc0c0IsT0FBTyxDQUFDNVAsS0FBSyxDQUFDLENBQUMsQ0FBQztNQUM1QixJQUFJK08sZUFBZSxDQUFDaHNCLEtBQUssQ0FBQyxFQUFFO1FBQzFCO1FBQ0FxRCxNQUFNLENBQUNNLE9BQU8sQ0FBQzNELEtBQUssQ0FBQyxDQUFDOEQsT0FBTyxDQUFDMkUsS0FBQSxJQUF1QjtVQUFBLElBQXRCLENBQUMwa0IsUUFBUSxFQUFFbnRCLEtBQUssQ0FBQyxHQUFBeUksS0FBQTtVQUM5QyxJQUFJMGtCLFFBQVEsS0FBSyxHQUFHLEVBQUU7WUFDcEI7VUFDRjtVQUVBLE1BQU1DLFdBQVcsR0FBR2xwQixJQUFJLENBQUNBLElBQUksQ0FBQzJuQixNQUFNLEVBQUU1ckIsR0FBRyxDQUFDLEVBQUVrdEIsUUFBUSxDQUFDbFEsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1VBQzlELElBQUlrUSxRQUFRLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxFQUFFO1lBQ3ZCVixnQkFBZ0IsQ0FBQ0MsVUFBVSxFQUFFMXNCLEtBQUssRUFBRW90QixXQUFXLENBQUM7VUFDbEQsQ0FBQyxNQUFNLElBQUlwdEIsS0FBSyxLQUFLLElBQUksRUFBRTtZQUFBLElBQUFxdEIsbUJBQUE7WUFDekIsQ0FBQUEsbUJBQUEsR0FBQVgsVUFBVSxDQUFDSyxNQUFNLGNBQUFNLG1CQUFBLGNBQUFBLG1CQUFBLEdBQWpCWCxVQUFVLENBQUNLLE1BQU0sR0FBSyxDQUFDLENBQUM7WUFDeEJMLFVBQVUsQ0FBQ0ssTUFBTSxDQUFDSyxXQUFXLENBQUMsR0FBRyxJQUFJO1VBQ3ZDLENBQUMsTUFBTTtZQUFBLElBQUFFLGlCQUFBO1lBQ0wsQ0FBQUEsaUJBQUEsR0FBQVosVUFBVSxDQUFDTyxJQUFJLGNBQUFLLGlCQUFBLGNBQUFBLGlCQUFBLEdBQWZaLFVBQVUsQ0FBQ08sSUFBSSxHQUFLLENBQUMsQ0FBQztZQUN0QlAsVUFBVSxDQUFDTyxJQUFJLENBQUNHLFdBQVcsQ0FBQyxHQUFHcHRCLEtBQUs7VUFDdEM7UUFDRixDQUFDLENBQUM7TUFDSixDQUFDLE1BQU0sSUFBSUMsR0FBRyxFQUFFO1FBQ2Q7UUFDQXdzQixnQkFBZ0IsQ0FBQ0MsVUFBVSxFQUFFMXNCLEtBQUssRUFBRWtFLElBQUksQ0FBQzJuQixNQUFNLEVBQUU1ckIsR0FBRyxDQUFDLENBQUM7TUFDeEQ7SUFDRjtFQUNGLENBQUMsQ0FBQztBQUNKO0FBRU8sU0FBU2tqQixrQkFBa0JBLENBQUN1SixVQUFVLEVBQUU7RUFDN0M7RUFDQSxJQUFJQSxVQUFVLENBQUNhLEVBQUUsS0FBSyxDQUFDLElBQUksQ0FBQ2IsVUFBVSxDQUFDQyxJQUFJLEVBQUU7SUFDM0MsT0FBT0QsVUFBVTtFQUNuQjtFQUVBLE1BQU1jLG1CQUFtQixHQUFHO0lBQUVELEVBQUUsRUFBRTtFQUFFLENBQUM7RUFDckNkLGdCQUFnQixDQUFDZSxtQkFBbUIsRUFBRWQsVUFBVSxDQUFDQyxJQUFJLEVBQUUsRUFBRSxDQUFDO0VBQzFELE9BQU9hLG1CQUFtQjtBQUM1QixDOzs7Ozs7Ozs7OztBQzlIQXR1QixNQUFNLENBQUNraEIsTUFBTSxDQUFDO0VBQUNxTixxQkFBcUIsRUFBQ0EsQ0FBQSxLQUFJQTtBQUFxQixDQUFDLENBQUM7QUFDekQsTUFBTUEscUJBQXFCLEdBQUcsSUFBSyxNQUFNQSxxQkFBcUIsQ0FBQztFQUNwRW5jLFdBQVdBLENBQUEsRUFBRztJQUNaLElBQUksQ0FBQ29jLGlCQUFpQixHQUFHcnFCLE1BQU0sQ0FBQ3NxQixNQUFNLENBQUMsSUFBSSxDQUFDO0VBQzlDO0VBRUFDLElBQUlBLENBQUN0dEIsSUFBSSxFQUFFdXRCLElBQUksRUFBRTtJQUNmLElBQUksQ0FBRXZ0QixJQUFJLEVBQUU7TUFDVixPQUFPLElBQUlpSCxlQUFlLENBQUQsQ0FBQztJQUM1QjtJQUVBLElBQUksQ0FBRXNtQixJQUFJLEVBQUU7TUFDVixPQUFPQyxnQkFBZ0IsQ0FBQ3h0QixJQUFJLEVBQUUsSUFBSSxDQUFDb3RCLGlCQUFpQixDQUFDO0lBQ3ZEO0lBRUEsSUFBSSxDQUFFRyxJQUFJLENBQUNFLDJCQUEyQixFQUFFO01BQ3RDRixJQUFJLENBQUNFLDJCQUEyQixHQUFHMXFCLE1BQU0sQ0FBQ3NxQixNQUFNLENBQUMsSUFBSSxDQUFDO0lBQ3hEOztJQUVBO0lBQ0E7SUFDQSxPQUFPRyxnQkFBZ0IsQ0FBQ3h0QixJQUFJLEVBQUV1dEIsSUFBSSxDQUFDRSwyQkFBMkIsQ0FBQztFQUNqRTtBQUNGLENBQUMsRUFBQztBQUVGLFNBQVNELGdCQUFnQkEsQ0FBQ3h0QixJQUFJLEVBQUUwdEIsV0FBVyxFQUFFO0VBQzNDLE9BQVExdEIsSUFBSSxJQUFJMHRCLFdBQVcsR0FDdkJBLFdBQVcsQ0FBQzF0QixJQUFJLENBQUMsR0FDakIwdEIsV0FBVyxDQUFDMXRCLElBQUksQ0FBQyxHQUFHLElBQUlpSCxlQUFlLENBQUNqSCxJQUFJLENBQUM7QUFDbkQsQzs7Ozs7Ozs7Ozs7Ozs7SUM3QkEsSUFBSTJ0Qix3QkFBd0IsRUFBQzd2QixrQkFBa0IsRUFBQ0QsbUJBQW1CO0lBQUNlLE1BQU0sQ0FBQ3JCLElBQUksQ0FBQyw0QkFBNEIsRUFBQztNQUFDb3dCLHdCQUF3QkEsQ0FBQ2x3QixDQUFDLEVBQUM7UUFBQ2t3Qix3QkFBd0IsR0FBQ2x3QixDQUFDO01BQUEsQ0FBQztNQUFDSyxrQkFBa0JBLENBQUNMLENBQUMsRUFBQztRQUFDSyxrQkFBa0IsR0FBQ0wsQ0FBQztNQUFBLENBQUM7TUFBQ0ksbUJBQW1CQSxDQUFDSixDQUFDLEVBQUM7UUFBQ0ksbUJBQW1CLEdBQUNKLENBQUM7TUFBQTtJQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7SUFBQyxJQUFJTyxvQkFBb0IsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxNQUFNQSxvQkFBb0IsQ0FBQyxDQUFDLEVBQUUsQ0FBQztJQU1oVU0sY0FBYyxDQUFDc3ZCLHNCQUFzQixHQUFHLFVBQ3RDQyxTQUFTLEVBQUU1ckIsT0FBTyxFQUFFO01BQ3BCLElBQUlJLElBQUksR0FBRyxJQUFJO01BQ2ZBLElBQUksQ0FBQ1EsS0FBSyxHQUFHLElBQUlkLGVBQWUsQ0FBQzhyQixTQUFTLEVBQUU1ckIsT0FBTyxDQUFDO0lBQ3RELENBQUM7SUFFRCxNQUFNNnJCLHlCQUF5QixHQUFHLENBQ2hDLDZCQUE2QixFQUM3QixnQkFBZ0IsRUFDaEIsa0JBQWtCLEVBQ2xCLGtCQUFrQixFQUNsQixnQkFBZ0IsRUFDaEIscUJBQXFCLEVBQ3JCLHdCQUF3QixFQUN4QixNQUFNLEVBQ04sY0FBYyxFQUNkLGFBQWEsRUFDYixlQUFlLEVBQ2YsYUFBYSxFQUNiLGFBQWEsRUFDYixhQUFhLENBQ2Q7SUFFRC9xQixNQUFNLENBQUNDLE1BQU0sQ0FBQzFFLGNBQWMsQ0FBQ3N2QixzQkFBc0IsQ0FBQy90QixTQUFTLEVBQUU7TUFDN0R5dEIsSUFBSSxFQUFFLFNBQUFBLENBQVV0dEIsSUFBSSxFQUFFO1FBQ3BCLElBQUlxQyxJQUFJLEdBQUcsSUFBSTtRQUNmLElBQUk3QyxHQUFHLEdBQUcsQ0FBQyxDQUFDO1FBQ1pzdUIseUJBQXlCLENBQUN0cUIsT0FBTyxDQUFDLFVBQVU4SixDQUFDLEVBQUU7VUFDN0M5TixHQUFHLENBQUM4TixDQUFDLENBQUMsR0FBR2xPLENBQUMsQ0FBQ0csSUFBSSxDQUFDOEMsSUFBSSxDQUFDUSxLQUFLLENBQUN5SyxDQUFDLENBQUMsRUFBRWpMLElBQUksQ0FBQ1EsS0FBSyxFQUFFN0MsSUFBSSxDQUFDO1VBRWhELElBQUksQ0FBQzJ0Qix3QkFBd0IsQ0FBQ3BZLFFBQVEsQ0FBQ2pJLENBQUMsQ0FBQyxFQUFFO1VBQzNDLE1BQU15Z0IsZUFBZSxHQUFHandCLGtCQUFrQixDQUFDd1AsQ0FBQyxDQUFDO1VBQzdDOU4sR0FBRyxDQUFDdXVCLGVBQWUsQ0FBQyxHQUFHLFlBQW1CO1lBQ3hDLElBQUk7Y0FDRixPQUFPcGYsT0FBTyxDQUFDQyxPQUFPLENBQUNwUCxHQUFHLENBQUM4TixDQUFDLENBQUMsQ0FBQyxHQUFBdkIsU0FBTyxDQUFDLENBQUM7WUFDekMsQ0FBQyxDQUFDLE9BQU8vQyxLQUFLLEVBQUU7Y0FDZCxPQUFPMkYsT0FBTyxDQUFDRSxNQUFNLENBQUM3RixLQUFLLENBQUM7WUFDOUI7VUFDRixDQUFDO1FBQ0gsQ0FBQyxDQUFDO1FBRUZuTCxtQkFBbUIsQ0FBQzJGLE9BQU8sQ0FBQyxVQUFVOEosQ0FBQyxFQUFFO1VBQ3ZDOU4sR0FBRyxDQUFDOE4sQ0FBQyxDQUFDLEdBQUdsTyxDQUFDLENBQUNHLElBQUksQ0FBQzhDLElBQUksQ0FBQ1EsS0FBSyxDQUFDeUssQ0FBQyxDQUFDLEVBQUVqTCxJQUFJLENBQUNRLEtBQUssRUFBRTdDLElBQUksQ0FBQztVQUVoRFIsR0FBRyxDQUFDOE4sQ0FBQyxDQUFDLEdBQUcsWUFBbUI7WUFDMUIsTUFBTSxJQUFJdEksS0FBSyxJQUFBdUksTUFBQSxDQUNWRCxDQUFDLHFEQUFBQyxNQUFBLENBQWtEelAsa0JBQWtCLENBQ3RFd1AsQ0FDRixDQUFDLGdCQUNILENBQUM7VUFDSCxDQUFDO1FBQ0gsQ0FBQyxDQUFDO1FBQ0YsT0FBTzlOLEdBQUc7TUFDWjtJQUNGLENBQUMsQ0FBQzs7SUFFRjtJQUNBO0lBQ0E7SUFDQWxCLGNBQWMsQ0FBQzB2Qiw2QkFBNkIsR0FBRzV1QixDQUFDLENBQUM2dUIsSUFBSSxDQUFDLFlBQVk7TUFDaEUsSUFBSUMsaUJBQWlCLEdBQUcsQ0FBQyxDQUFDO01BRTFCLElBQUlDLFFBQVEsR0FBRzVXLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDNFcsU0FBUztNQUVwQyxJQUFJN1csT0FBTyxDQUFDQyxHQUFHLENBQUM2VyxlQUFlLEVBQUU7UUFDL0JILGlCQUFpQixDQUFDdnBCLFFBQVEsR0FBRzRTLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDNlcsZUFBZTtNQUMxRDtNQUVBLElBQUksQ0FBRUYsUUFBUSxFQUNaLE1BQU0sSUFBSW5wQixLQUFLLENBQUMsc0NBQXNDLENBQUM7TUFFekQsTUFBTThnQixNQUFNLEdBQUcsSUFBSXhuQixjQUFjLENBQUNzdkIsc0JBQXNCLENBQUNPLFFBQVEsRUFBRUQsaUJBQWlCLENBQUM7O01BRXJGO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQW53QixNQUFNLENBQUN1d0IsT0FBTyxDQUFDLFlBQVk7UUFDekIsTUFBTXhJLE1BQU0sQ0FBQ2pqQixLQUFLLENBQUNxQixNQUFNLENBQUNxcUIsT0FBTyxDQUFDLENBQUM7TUFDckMsQ0FBQyxDQUFDO01BRUYsT0FBT3pJLE1BQU07SUFDZixDQUFDLENBQUM7SUFBQzVPLHNCQUFBO0VBQUEsU0FBQUMsV0FBQTtJQUFBLE9BQUFELHNCQUFBLENBQUFDLFdBQUE7RUFBQTtFQUFBRCxzQkFBQTtBQUFBO0VBQUE3VSxJQUFBO0VBQUErVSxLQUFBO0FBQUEsRzs7Ozs7Ozs7Ozs7Ozs7SUN6RkgsSUFBSS9aLGFBQWE7SUFBQ0MsT0FBTyxDQUFDQyxJQUFJLENBQUMsc0NBQXNDLEVBQUM7TUFBQ0MsT0FBT0EsQ0FBQ0MsQ0FBQyxFQUFDO1FBQUNKLGFBQWEsR0FBQ0ksQ0FBQztNQUFBO0lBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztJQUF0RyxJQUFJa3dCLHdCQUF3QixFQUFDN3ZCLGtCQUFrQjtJQUFDUixPQUFPLENBQUNDLElBQUksQ0FBQyw0QkFBNEIsRUFBQztNQUFDb3dCLHdCQUF3QkEsQ0FBQ2x3QixDQUFDLEVBQUM7UUFBQ2t3Qix3QkFBd0IsR0FBQ2x3QixDQUFDO01BQUEsQ0FBQztNQUFDSyxrQkFBa0JBLENBQUNMLENBQUMsRUFBQztRQUFDSyxrQkFBa0IsR0FBQ0wsQ0FBQztNQUFBO0lBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztJQUFDLElBQUlDLG1CQUFtQjtJQUFDSixPQUFPLENBQUNDLElBQUksQ0FBQyxlQUFlLEVBQUM7TUFBQ0csbUJBQW1CQSxDQUFDRCxDQUFDLEVBQUM7UUFBQ0MsbUJBQW1CLEdBQUNELENBQUM7TUFBQTtJQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7SUFBQyxJQUFJTyxvQkFBb0IsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxNQUFNQSxvQkFBb0IsQ0FBQyxDQUFDLEVBQUUsQ0FBQztJQVN2VztBQUNBO0FBQ0E7QUFDQTtJQUNBMEMsS0FBSyxHQUFHLENBQUMsQ0FBQzs7SUFFVjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0lBQ0FBLEtBQUssQ0FBQzhNLFVBQVUsR0FBRyxTQUFTQSxVQUFVQSxDQUFDeE4sSUFBSSxFQUFFaUMsT0FBTyxFQUFFO01BQ3BELElBQUksQ0FBQ2pDLElBQUksSUFBSUEsSUFBSSxLQUFLLElBQUksRUFBRTtRQUMxQmpDLE1BQU0sQ0FBQ2tjLE1BQU0sQ0FDWCx5REFBeUQsR0FDdkQseURBQXlELEdBQ3pELGdEQUNKLENBQUM7UUFDRGphLElBQUksR0FBRyxJQUFJO01BQ2I7TUFFQSxJQUFJQSxJQUFJLEtBQUssSUFBSSxJQUFJLE9BQU9BLElBQUksS0FBSyxRQUFRLEVBQUU7UUFDN0MsTUFBTSxJQUFJZ0YsS0FBSyxDQUNiLGlFQUNGLENBQUM7TUFDSDtNQUVBLElBQUkvQyxPQUFPLElBQUlBLE9BQU8sQ0FBQ3VOLE9BQU8sRUFBRTtRQUM5QjtRQUNBO1FBQ0E7UUFDQTtRQUNBdk4sT0FBTyxHQUFHO1VBQUV1c0IsVUFBVSxFQUFFdnNCO1FBQVEsQ0FBQztNQUNuQztNQUNBO01BQ0EsSUFBSUEsT0FBTyxJQUFJQSxPQUFPLENBQUN3c0IsT0FBTyxJQUFJLENBQUN4c0IsT0FBTyxDQUFDdXNCLFVBQVUsRUFBRTtRQUNyRHZzQixPQUFPLENBQUN1c0IsVUFBVSxHQUFHdnNCLE9BQU8sQ0FBQ3dzQixPQUFPO01BQ3RDO01BRUF4c0IsT0FBTyxHQUFBNUUsYUFBQTtRQUNMbXhCLFVBQVUsRUFBRXR0QixTQUFTO1FBQ3JCd3RCLFlBQVksRUFBRSxRQUFRO1FBQ3RCM2YsU0FBUyxFQUFFLElBQUk7UUFDZjRmLE9BQU8sRUFBRXp0QixTQUFTO1FBQ2xCMHRCLG1CQUFtQixFQUFFO01BQUssR0FDdkIzc0IsT0FBTyxDQUNYO01BRUQsUUFBUUEsT0FBTyxDQUFDeXNCLFlBQVk7UUFDMUIsS0FBSyxPQUFPO1VBQ1YsSUFBSSxDQUFDRyxVQUFVLEdBQUcsWUFBVztZQUMzQixJQUFJQyxHQUFHLEdBQUc5dUIsSUFBSSxHQUNWK3VCLEdBQUcsQ0FBQ0MsWUFBWSxDQUFDLGNBQWMsR0FBR2h2QixJQUFJLENBQUMsR0FDdkNpdkIsTUFBTSxDQUFDQyxRQUFRO1lBQ25CLE9BQU8sSUFBSXh1QixLQUFLLENBQUNELFFBQVEsQ0FBQ3F1QixHQUFHLENBQUNLLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQztVQUM5QyxDQUFDO1VBQ0Q7UUFDRixLQUFLLFFBQVE7UUFDYjtVQUNFLElBQUksQ0FBQ04sVUFBVSxHQUFHLFlBQVc7WUFDM0IsSUFBSUMsR0FBRyxHQUFHOXVCLElBQUksR0FDVit1QixHQUFHLENBQUNDLFlBQVksQ0FBQyxjQUFjLEdBQUdodkIsSUFBSSxDQUFDLEdBQ3ZDaXZCLE1BQU0sQ0FBQ0MsUUFBUTtZQUNuQixPQUFPSixHQUFHLENBQUMzbkIsRUFBRSxDQUFDLENBQUM7VUFDakIsQ0FBQztVQUNEO01BQ0o7TUFFQSxJQUFJLENBQUNnSyxVQUFVLEdBQUdsSyxlQUFlLENBQUNtSyxhQUFhLENBQUNuUCxPQUFPLENBQUM4TSxTQUFTLENBQUM7TUFFbEUsSUFBSSxDQUFDcWdCLFlBQVksR0FBR250QixPQUFPLENBQUNtdEIsWUFBWTtNQUV4QyxJQUFJLENBQUNwdkIsSUFBSSxJQUFJaUMsT0FBTyxDQUFDdXNCLFVBQVUsS0FBSyxJQUFJO1FBQ3RDO1FBQ0EsSUFBSSxDQUFDYSxXQUFXLEdBQUcsSUFBSSxDQUFDLEtBQ3JCLElBQUlwdEIsT0FBTyxDQUFDdXNCLFVBQVUsRUFBRSxJQUFJLENBQUNhLFdBQVcsR0FBR3B0QixPQUFPLENBQUN1c0IsVUFBVSxDQUFDLEtBQzlELElBQUl6d0IsTUFBTSxDQUFDdXhCLFFBQVEsRUFBRSxJQUFJLENBQUNELFdBQVcsR0FBR3R4QixNQUFNLENBQUN5d0IsVUFBVSxDQUFDLEtBQzFELElBQUksQ0FBQ2EsV0FBVyxHQUFHdHhCLE1BQU0sQ0FBQ3d4QixNQUFNO01BRXJDLElBQUksQ0FBQ3R0QixPQUFPLENBQUMwc0IsT0FBTyxFQUFFO1FBQ3BCO1FBQ0E7UUFDQTtRQUNBO1FBQ0EsSUFDRTN1QixJQUFJLElBQ0osSUFBSSxDQUFDcXZCLFdBQVcsS0FBS3R4QixNQUFNLENBQUN3eEIsTUFBTSxJQUNsQyxPQUFPanhCLGNBQWMsS0FBSyxXQUFXLElBQ3JDQSxjQUFjLENBQUMwdkIsNkJBQTZCLEVBQzVDO1VBQ0EvckIsT0FBTyxDQUFDMHNCLE9BQU8sR0FBR3J3QixjQUFjLENBQUMwdkIsNkJBQTZCLENBQUMsQ0FBQztRQUNsRSxDQUFDLE1BQU07VUFDTCxNQUFNO1lBQUViO1VBQXNCLENBQUMsR0FBR2p2QixPQUFPLENBQUMsOEJBQThCLENBQUM7VUFDekUrRCxPQUFPLENBQUMwc0IsT0FBTyxHQUFHeEIscUJBQXFCO1FBQ3pDO01BQ0Y7TUFFQSxJQUFJLENBQUNxQyxXQUFXLEdBQUd2dEIsT0FBTyxDQUFDMHNCLE9BQU8sQ0FBQ3JCLElBQUksQ0FBQ3R0QixJQUFJLEVBQUUsSUFBSSxDQUFDcXZCLFdBQVcsQ0FBQztNQUMvRCxJQUFJLENBQUNJLEtBQUssR0FBR3p2QixJQUFJO01BQ2pCLElBQUksQ0FBQzJ1QixPQUFPLEdBQUcxc0IsT0FBTyxDQUFDMHNCLE9BQU87O01BRTlCO01BQ0U7TUFDRixJQUFJLENBQUNlLDRCQUE0QixHQUFHLElBQUksQ0FBQ0Msc0JBQXNCLENBQUMzdkIsSUFBSSxFQUFFaUMsT0FBTyxDQUFDOztNQUU5RTtNQUNBO01BQ0E7TUFDQSxJQUFJQSxPQUFPLENBQUMydEIscUJBQXFCLEtBQUssS0FBSyxFQUFFO1FBQzNDLElBQUk7VUFDRixJQUFJLENBQUNDLHNCQUFzQixDQUFDO1lBQzFCQyxXQUFXLEVBQUU3dEIsT0FBTyxDQUFDOHRCLHNCQUFzQixLQUFLO1VBQ2xELENBQUMsQ0FBQztRQUNKLENBQUMsQ0FBQyxPQUFPL21CLEtBQUssRUFBRTtVQUNkO1VBQ0EsSUFDRUEsS0FBSyxDQUFDdVosT0FBTyx5QkFBQWhWLE1BQUEsQ0FBeUJ2TixJQUFJLHFDQUFrQyxFQUU1RSxNQUFNLElBQUlnRixLQUFLLDBDQUFBdUksTUFBQSxDQUF5Q3ZOLElBQUksT0FBRyxDQUFDO1VBQ2xFLE1BQU1nSixLQUFLO1FBQ2I7TUFDRjs7TUFFQTtNQUNBLElBQ0VwRSxPQUFPLENBQUNvckIsV0FBVyxJQUNuQixDQUFDL3RCLE9BQU8sQ0FBQzJzQixtQkFBbUIsSUFDNUIsSUFBSSxDQUFDUyxXQUFXLElBQ2hCLElBQUksQ0FBQ0EsV0FBVyxDQUFDWSxPQUFPLEVBQ3hCO1FBQ0EsSUFBSSxDQUFDWixXQUFXLENBQUNZLE9BQU8sQ0FBQyxJQUFJLEVBQUUsTUFBTSxJQUFJLENBQUNua0IsSUFBSSxDQUFDLENBQUMsRUFBRTtVQUNoRG9rQixPQUFPLEVBQUU7UUFDWCxDQUFDLENBQUM7TUFDSjtJQUNGLENBQUM7SUFFRG50QixNQUFNLENBQUNDLE1BQU0sQ0FBQ3RDLEtBQUssQ0FBQzhNLFVBQVUsQ0FBQzNOLFNBQVMsRUFBRTtNQUN4QyxNQUFNOHZCLHNCQUFzQkEsQ0FBQzN2QixJQUFJLEVBQUU7UUFBQSxJQUFBbXdCLG9CQUFBLEVBQUFDLHFCQUFBO1FBQ2pDLE1BQU0vdEIsSUFBSSxHQUFHLElBQUk7UUFDakIsSUFDRSxFQUNFQSxJQUFJLENBQUNndEIsV0FBVyxJQUNoQmh0QixJQUFJLENBQUNndEIsV0FBVyxDQUFDZ0IsbUJBQW1CLElBQ3BDaHVCLElBQUksQ0FBQ2d0QixXQUFXLENBQUNpQixtQkFBbUIsQ0FDckMsRUFDRDtVQUNBO1FBQ0Y7UUFHQSxNQUFNQyxrQkFBa0IsR0FBRztVQUN6QjtVQUNBO1VBQ0FDLGFBQWFBLENBQUEsRUFBRztZQUNkbnVCLElBQUksQ0FBQ210QixXQUFXLENBQUNnQixhQUFhLENBQUMsQ0FBQztVQUNsQyxDQUFDO1VBQ0RDLGlCQUFpQkEsQ0FBQSxFQUFHO1lBQ2xCLE9BQU9wdUIsSUFBSSxDQUFDbXRCLFdBQVcsQ0FBQ2lCLGlCQUFpQixDQUFDLENBQUM7VUFDN0MsQ0FBQztVQUNEO1VBQ0FDLGNBQWNBLENBQUEsRUFBRztZQUNmLE9BQU9ydUIsSUFBSTtVQUNiO1FBQ0YsQ0FBQztRQUNELE1BQU1zdUIsa0JBQWtCLEdBQUF0ekIsYUFBQTtVQUN0QjtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBLE1BQU11ekIsV0FBV0EsQ0FBQ0MsU0FBUyxFQUFFQyxLQUFLLEVBQUU7WUFDbEM7WUFDQTtZQUNBO1lBQ0E7WUFDQTtZQUNBLElBQUlELFNBQVMsR0FBRyxDQUFDLElBQUlDLEtBQUssRUFBRXp1QixJQUFJLENBQUNtdEIsV0FBVyxDQUFDdUIsY0FBYyxDQUFDLENBQUM7WUFFN0QsSUFBSUQsS0FBSyxFQUFFLE1BQU16dUIsSUFBSSxDQUFDbXRCLFdBQVcsQ0FBQ2pKLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztVQUM5QyxDQUFDO1VBRUQ7VUFDQTtVQUNBeUssTUFBTUEsQ0FBQ0MsR0FBRyxFQUFFO1lBQ1YsSUFBSUMsT0FBTyxHQUFHQyxPQUFPLENBQUNDLE9BQU8sQ0FBQ0gsR0FBRyxDQUFDOXBCLEVBQUUsQ0FBQztZQUNyQyxJQUFJeUssR0FBRyxHQUFHdlAsSUFBSSxDQUFDbXRCLFdBQVcsQ0FBQzZCLEtBQUssQ0FBQ2hSLEdBQUcsQ0FBQzZRLE9BQU8sQ0FBQzs7WUFFN0M7WUFDQTtZQUNBO1lBQ0E7O1lBRUE7WUFDQTs7WUFFQTtZQUNBO1lBQ0EsSUFBSW56QixNQUFNLENBQUN1eEIsUUFBUSxFQUFFO2NBQ25CLElBQUkyQixHQUFHLENBQUNBLEdBQUcsS0FBSyxPQUFPLElBQUlyZixHQUFHLEVBQUU7Z0JBQzlCcWYsR0FBRyxDQUFDQSxHQUFHLEdBQUcsU0FBUztjQUNyQixDQUFDLE1BQU0sSUFBSUEsR0FBRyxDQUFDQSxHQUFHLEtBQUssU0FBUyxJQUFJLENBQUNyZixHQUFHLEVBQUU7Z0JBQ3hDO2NBQ0YsQ0FBQyxNQUFNLElBQUlxZixHQUFHLENBQUNBLEdBQUcsS0FBSyxTQUFTLElBQUksQ0FBQ3JmLEdBQUcsRUFBRTtnQkFDeENxZixHQUFHLENBQUNBLEdBQUcsR0FBRyxPQUFPO2dCQUNqQixNQUFNM3RCLElBQUksR0FBRzJ0QixHQUFHLENBQUM1Z0IsTUFBTTtnQkFDdkIsS0FBSyxJQUFJZ2IsS0FBSyxJQUFJL25CLElBQUksRUFBRTtrQkFDdEIsTUFBTTVELEtBQUssR0FBRzRELElBQUksQ0FBQytuQixLQUFLLENBQUM7a0JBQ3pCLElBQUkzckIsS0FBSyxLQUFLLEtBQUssQ0FBQyxFQUFFO29CQUNwQixPQUFPdXhCLEdBQUcsQ0FBQzVnQixNQUFNLENBQUNnYixLQUFLLENBQUM7a0JBQzFCO2dCQUNGO2NBQ0Y7WUFDRjtZQUNBO1lBQ0E7WUFDQTtZQUNBLElBQUk0RixHQUFHLENBQUNBLEdBQUcsS0FBSyxTQUFTLEVBQUU7Y0FDekIsSUFBSXR0QixPQUFPLEdBQUdzdEIsR0FBRyxDQUFDdHRCLE9BQU87Y0FDekIsSUFBSSxDQUFDQSxPQUFPLEVBQUU7Z0JBQ1osSUFBSWlPLEdBQUcsRUFBRXZQLElBQUksQ0FBQ210QixXQUFXLENBQUNqSixNQUFNLENBQUMySyxPQUFPLENBQUM7Y0FDM0MsQ0FBQyxNQUFNLElBQUksQ0FBQ3RmLEdBQUcsRUFBRTtnQkFDZnZQLElBQUksQ0FBQ210QixXQUFXLENBQUM4QixNQUFNLENBQUMzdEIsT0FBTyxDQUFDO2NBQ2xDLENBQUMsTUFBTTtnQkFDTDtnQkFDQXRCLElBQUksQ0FBQ210QixXQUFXLENBQUN3QixNQUFNLENBQUNFLE9BQU8sRUFBRXZ0QixPQUFPLENBQUM7Y0FDM0M7Y0FDQTtZQUNGLENBQUMsTUFBTSxJQUFJc3RCLEdBQUcsQ0FBQ0EsR0FBRyxLQUFLLE9BQU8sRUFBRTtjQUM5QixJQUFJcmYsR0FBRyxFQUFFO2dCQUNQLE1BQU0sSUFBSTVNLEtBQUssQ0FDYiw0REFDRixDQUFDO2NBQ0g7Y0FDQTNDLElBQUksQ0FBQ210QixXQUFXLENBQUM4QixNQUFNLENBQUFqMEIsYUFBQTtnQkFBRytKLEdBQUcsRUFBRThwQjtjQUFPLEdBQUtELEdBQUcsQ0FBQzVnQixNQUFNLENBQUUsQ0FBQztZQUMxRCxDQUFDLE1BQU0sSUFBSTRnQixHQUFHLENBQUNBLEdBQUcsS0FBSyxTQUFTLEVBQUU7Y0FDaEMsSUFBSSxDQUFDcmYsR0FBRyxFQUNOLE1BQU0sSUFBSTVNLEtBQUssQ0FDYix5REFDRixDQUFDO2NBQ0gzQyxJQUFJLENBQUNtdEIsV0FBVyxDQUFDakosTUFBTSxDQUFDMkssT0FBTyxDQUFDO1lBQ2xDLENBQUMsTUFBTSxJQUFJRCxHQUFHLENBQUNBLEdBQUcsS0FBSyxTQUFTLEVBQUU7Y0FDaEMsSUFBSSxDQUFDcmYsR0FBRyxFQUFFLE1BQU0sSUFBSTVNLEtBQUssQ0FBQyx1Q0FBdUMsQ0FBQztjQUNsRSxNQUFNb0YsSUFBSSxHQUFHckgsTUFBTSxDQUFDcUgsSUFBSSxDQUFDNm1CLEdBQUcsQ0FBQzVnQixNQUFNLENBQUM7Y0FDcEMsSUFBSWpHLElBQUksQ0FBQ0csTUFBTSxHQUFHLENBQUMsRUFBRTtnQkFDbkIsSUFBSTRnQixRQUFRLEdBQUcsQ0FBQyxDQUFDO2dCQUNqQi9nQixJQUFJLENBQUM1RyxPQUFPLENBQUM3RCxHQUFHLElBQUk7a0JBQ2xCLE1BQU1ELEtBQUssR0FBR3V4QixHQUFHLENBQUM1Z0IsTUFBTSxDQUFDMVEsR0FBRyxDQUFDO2tCQUM3QixJQUFJcUIsS0FBSyxDQUFDc2xCLE1BQU0sQ0FBQzFVLEdBQUcsQ0FBQ2pTLEdBQUcsQ0FBQyxFQUFFRCxLQUFLLENBQUMsRUFBRTtvQkFDakM7a0JBQ0Y7a0JBQ0EsSUFBSSxPQUFPQSxLQUFLLEtBQUssV0FBVyxFQUFFO29CQUNoQyxJQUFJLENBQUN5ckIsUUFBUSxDQUFDc0IsTUFBTSxFQUFFO3NCQUNwQnRCLFFBQVEsQ0FBQ3NCLE1BQU0sR0FBRyxDQUFDLENBQUM7b0JBQ3RCO29CQUNBdEIsUUFBUSxDQUFDc0IsTUFBTSxDQUFDOXNCLEdBQUcsQ0FBQyxHQUFHLENBQUM7a0JBQzFCLENBQUMsTUFBTTtvQkFDTCxJQUFJLENBQUN3ckIsUUFBUSxDQUFDd0IsSUFBSSxFQUFFO3NCQUNsQnhCLFFBQVEsQ0FBQ3dCLElBQUksR0FBRyxDQUFDLENBQUM7b0JBQ3BCO29CQUNBeEIsUUFBUSxDQUFDd0IsSUFBSSxDQUFDaHRCLEdBQUcsQ0FBQyxHQUFHRCxLQUFLO2tCQUM1QjtnQkFDRixDQUFDLENBQUM7Z0JBQ0YsSUFBSXFELE1BQU0sQ0FBQ3FILElBQUksQ0FBQytnQixRQUFRLENBQUMsQ0FBQzVnQixNQUFNLEdBQUcsQ0FBQyxFQUFFO2tCQUNwQ2xJLElBQUksQ0FBQ210QixXQUFXLENBQUN3QixNQUFNLENBQUNFLE9BQU8sRUFBRS9GLFFBQVEsQ0FBQztnQkFDNUM7Y0FDRjtZQUNGLENBQUMsTUFBTTtjQUNMLE1BQU0sSUFBSW5tQixLQUFLLENBQUMsNENBQTRDLENBQUM7WUFDL0Q7VUFDRixDQUFDO1VBRUQ7VUFDQXVzQixTQUFTQSxDQUFBLEVBQUc7WUFDVmx2QixJQUFJLENBQUNtdEIsV0FBVyxDQUFDZ0MscUJBQXFCLENBQUMsQ0FBQztVQUMxQyxDQUFDO1VBRUQ7VUFDQUMsTUFBTUEsQ0FBQ3RxQixFQUFFLEVBQUU7WUFDVCxPQUFPOUUsSUFBSSxDQUFDcXZCLE9BQU8sQ0FBQ3ZxQixFQUFFLENBQUM7VUFDekI7UUFBQyxHQUVFb3BCLGtCQUFrQixDQUN0QjtRQUNELE1BQU1vQixrQkFBa0IsR0FBQXQwQixhQUFBO1VBQ3RCLE1BQU11ekIsV0FBV0EsQ0FBQ0MsU0FBUyxFQUFFQyxLQUFLLEVBQUU7WUFDbEMsSUFBSUQsU0FBUyxHQUFHLENBQUMsSUFBSUMsS0FBSyxFQUFFenVCLElBQUksQ0FBQ210QixXQUFXLENBQUN1QixjQUFjLENBQUMsQ0FBQztZQUU3RCxJQUFJRCxLQUFLLEVBQUUsTUFBTXp1QixJQUFJLENBQUNtdEIsV0FBVyxDQUFDdm5CLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQztVQUNuRCxDQUFDO1VBRUQsTUFBTStvQixNQUFNQSxDQUFDQyxHQUFHLEVBQUU7WUFDaEIsSUFBSUMsT0FBTyxHQUFHQyxPQUFPLENBQUNDLE9BQU8sQ0FBQ0gsR0FBRyxDQUFDOXBCLEVBQUUsQ0FBQztZQUNyQyxJQUFJeUssR0FBRyxHQUFHdlAsSUFBSSxDQUFDbXRCLFdBQVcsQ0FBQzZCLEtBQUssQ0FBQ2hSLEdBQUcsQ0FBQzZRLE9BQU8sQ0FBQzs7WUFFN0M7WUFDQTtZQUNBO1lBQ0EsSUFBSUQsR0FBRyxDQUFDQSxHQUFHLEtBQUssU0FBUyxFQUFFO2NBQ3pCLElBQUl0dEIsT0FBTyxHQUFHc3RCLEdBQUcsQ0FBQ3R0QixPQUFPO2NBQ3pCLElBQUksQ0FBQ0EsT0FBTyxFQUFFO2dCQUNaLElBQUlpTyxHQUFHLEVBQUUsTUFBTXZQLElBQUksQ0FBQ210QixXQUFXLENBQUN2bkIsV0FBVyxDQUFDaXBCLE9BQU8sQ0FBQztjQUN0RCxDQUFDLE1BQU0sSUFBSSxDQUFDdGYsR0FBRyxFQUFFO2dCQUNmLE1BQU12UCxJQUFJLENBQUNtdEIsV0FBVyxDQUFDM29CLFdBQVcsQ0FBQ2xELE9BQU8sQ0FBQztjQUM3QyxDQUFDLE1BQU07Z0JBQ0w7Z0JBQ0EsTUFBTXRCLElBQUksQ0FBQ210QixXQUFXLENBQUMxbUIsV0FBVyxDQUFDb29CLE9BQU8sRUFBRXZ0QixPQUFPLENBQUM7Y0FDdEQ7Y0FDQTtZQUNGLENBQUMsTUFBTSxJQUFJc3RCLEdBQUcsQ0FBQ0EsR0FBRyxLQUFLLE9BQU8sRUFBRTtjQUM5QixJQUFJcmYsR0FBRyxFQUFFO2dCQUNQLE1BQU0sSUFBSTVNLEtBQUssQ0FDYiw0REFDRixDQUFDO2NBQ0g7Y0FDQSxNQUFNM0MsSUFBSSxDQUFDbXRCLFdBQVcsQ0FBQzNvQixXQUFXLENBQUF4SixhQUFBO2dCQUFHK0osR0FBRyxFQUFFOHBCO2NBQU8sR0FBS0QsR0FBRyxDQUFDNWdCLE1BQU0sQ0FBRSxDQUFDO1lBQ3JFLENBQUMsTUFBTSxJQUFJNGdCLEdBQUcsQ0FBQ0EsR0FBRyxLQUFLLFNBQVMsRUFBRTtjQUNoQyxJQUFJLENBQUNyZixHQUFHLEVBQ04sTUFBTSxJQUFJNU0sS0FBSyxDQUNiLHlEQUNGLENBQUM7Y0FDSCxNQUFNM0MsSUFBSSxDQUFDbXRCLFdBQVcsQ0FBQ3ZuQixXQUFXLENBQUNpcEIsT0FBTyxDQUFDO1lBQzdDLENBQUMsTUFBTSxJQUFJRCxHQUFHLENBQUNBLEdBQUcsS0FBSyxTQUFTLEVBQUU7Y0FDaEMsSUFBSSxDQUFDcmYsR0FBRyxFQUFFLE1BQU0sSUFBSTVNLEtBQUssQ0FBQyx1Q0FBdUMsQ0FBQztjQUNsRSxNQUFNb0YsSUFBSSxHQUFHckgsTUFBTSxDQUFDcUgsSUFBSSxDQUFDNm1CLEdBQUcsQ0FBQzVnQixNQUFNLENBQUM7Y0FDcEMsSUFBSWpHLElBQUksQ0FBQ0csTUFBTSxHQUFHLENBQUMsRUFBRTtnQkFDbkIsSUFBSTRnQixRQUFRLEdBQUcsQ0FBQyxDQUFDO2dCQUNqQi9nQixJQUFJLENBQUM1RyxPQUFPLENBQUM3RCxHQUFHLElBQUk7a0JBQ2xCLE1BQU1ELEtBQUssR0FBR3V4QixHQUFHLENBQUM1Z0IsTUFBTSxDQUFDMVEsR0FBRyxDQUFDO2tCQUM3QixJQUFJcUIsS0FBSyxDQUFDc2xCLE1BQU0sQ0FBQzFVLEdBQUcsQ0FBQ2pTLEdBQUcsQ0FBQyxFQUFFRCxLQUFLLENBQUMsRUFBRTtvQkFDakM7a0JBQ0Y7a0JBQ0EsSUFBSSxPQUFPQSxLQUFLLEtBQUssV0FBVyxFQUFFO29CQUNoQyxJQUFJLENBQUN5ckIsUUFBUSxDQUFDc0IsTUFBTSxFQUFFO3NCQUNwQnRCLFFBQVEsQ0FBQ3NCLE1BQU0sR0FBRyxDQUFDLENBQUM7b0JBQ3RCO29CQUNBdEIsUUFBUSxDQUFDc0IsTUFBTSxDQUFDOXNCLEdBQUcsQ0FBQyxHQUFHLENBQUM7a0JBQzFCLENBQUMsTUFBTTtvQkFDTCxJQUFJLENBQUN3ckIsUUFBUSxDQUFDd0IsSUFBSSxFQUFFO3NCQUNsQnhCLFFBQVEsQ0FBQ3dCLElBQUksR0FBRyxDQUFDLENBQUM7b0JBQ3BCO29CQUNBeEIsUUFBUSxDQUFDd0IsSUFBSSxDQUFDaHRCLEdBQUcsQ0FBQyxHQUFHRCxLQUFLO2tCQUM1QjtnQkFDRixDQUFDLENBQUM7Z0JBQ0YsSUFBSXFELE1BQU0sQ0FBQ3FILElBQUksQ0FBQytnQixRQUFRLENBQUMsQ0FBQzVnQixNQUFNLEdBQUcsQ0FBQyxFQUFFO2tCQUNwQyxNQUFNbEksSUFBSSxDQUFDbXRCLFdBQVcsQ0FBQzFtQixXQUFXLENBQUNvb0IsT0FBTyxFQUFFL0YsUUFBUSxDQUFDO2dCQUN2RDtjQUNGO1lBQ0YsQ0FBQyxNQUFNO2NBQ0wsTUFBTSxJQUFJbm1CLEtBQUssQ0FBQyw0Q0FBNEMsQ0FBQztZQUMvRDtVQUNGLENBQUM7VUFFRDtVQUNBLE1BQU11c0IsU0FBU0EsQ0FBQSxFQUFHO1lBQ2hCLE1BQU1sdkIsSUFBSSxDQUFDbXRCLFdBQVcsQ0FBQ29DLHFCQUFxQixDQUFDLENBQUM7VUFDaEQsQ0FBQztVQUVEO1VBQ0EsTUFBTUgsTUFBTUEsQ0FBQ3RxQixFQUFFLEVBQUU7WUFDZixPQUFPOUUsSUFBSSxDQUFDNkosWUFBWSxDQUFDL0UsRUFBRSxDQUFDO1VBQzlCO1FBQUMsR0FDRW9wQixrQkFBa0IsQ0FDdEI7O1FBR0Q7UUFDQTtRQUNBO1FBQ0EsSUFBSXNCLG1CQUFtQjtRQUN2QixJQUFJOXpCLE1BQU0sQ0FBQ3V4QixRQUFRLEVBQUU7VUFDbkJ1QyxtQkFBbUIsR0FBR3h2QixJQUFJLENBQUNndEIsV0FBVyxDQUFDZ0IsbUJBQW1CLENBQ3hEcndCLElBQUksRUFDSjJ3QixrQkFDRixDQUFDO1FBQ0gsQ0FBQyxNQUFNO1VBQ0xrQixtQkFBbUIsR0FBR3h2QixJQUFJLENBQUNndEIsV0FBVyxDQUFDaUIsbUJBQW1CLENBQ3hEdHdCLElBQUksRUFDSjJ4QixrQkFDRixDQUFDO1FBQ0g7UUFFQSxNQUFNcFAsT0FBTyw0Q0FBQWhWLE1BQUEsQ0FBMkN2TixJQUFJLE9BQUc7UUFDL0QsTUFBTTh4QixPQUFPLEdBQUdBLENBQUEsS0FBTTtVQUNwQm5nQixPQUFPLENBQUM2RCxJQUFJLEdBQUc3RCxPQUFPLENBQUM2RCxJQUFJLENBQUMrTSxPQUFPLENBQUMsR0FBRzVRLE9BQU8sQ0FBQzJhLEdBQUcsQ0FBQy9KLE9BQU8sQ0FBQztRQUM3RCxDQUFDO1FBRUQsSUFBSSxDQUFDc1AsbUJBQW1CLEVBQUU7VUFDeEIsT0FBT0MsT0FBTyxDQUFDLENBQUM7UUFDbEI7UUFFQSxRQUFBM0Isb0JBQUEsR0FBTzBCLG1CQUFtQixjQUFBMUIsb0JBQUEsd0JBQUFDLHFCQUFBLEdBQW5CRCxvQkFBQSxDQUFxQjVvQixJQUFJLGNBQUE2b0IscUJBQUEsdUJBQXpCQSxxQkFBQSxDQUFBNWQsSUFBQSxDQUFBMmQsb0JBQUEsRUFBNEI0QixFQUFFLElBQUk7VUFDdkMsSUFBSSxDQUFDQSxFQUFFLEVBQUU7WUFDUEQsT0FBTyxDQUFDLENBQUM7VUFDWDtRQUNGLENBQUMsQ0FBQztNQUNKLENBQUM7TUFFRDtNQUNBO01BQ0E7TUFDQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtNQUNFcmxCLGNBQWNBLENBQUEsRUFBVTtRQUN0QixPQUFPLElBQUksQ0FBQytpQixXQUFXLENBQUMvaUIsY0FBYyxDQUFDLEdBQUFWLFNBQU8sQ0FBQztNQUNqRCxDQUFDO01BRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO01BQ0VnQixzQkFBc0JBLENBQUEsRUFBVTtRQUM5QixPQUFPLElBQUksQ0FBQ3lpQixXQUFXLENBQUN6aUIsc0JBQXNCLENBQUMsR0FBQWhCLFNBQU8sQ0FBQztNQUN6RCxDQUFDO01BRURpbUIsZ0JBQWdCQSxDQUFDcmxCLElBQUksRUFBRTtRQUNyQixJQUFJQSxJQUFJLENBQUNwQyxNQUFNLElBQUksQ0FBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FDM0IsT0FBT29DLElBQUksQ0FBQyxDQUFDLENBQUM7TUFDckIsQ0FBQztNQUVEc2xCLGVBQWVBLENBQUN0bEIsSUFBSSxFQUFFO1FBQ3BCLE1BQU0sR0FBRzFLLE9BQU8sQ0FBQyxHQUFHMEssSUFBSSxJQUFJLEVBQUU7UUFDOUIsTUFBTXVsQixVQUFVLEdBQUd4MEIsbUJBQW1CLENBQUN1RSxPQUFPLENBQUM7UUFFL0MsSUFBSUksSUFBSSxHQUFHLElBQUk7UUFDZixJQUFJc0ssSUFBSSxDQUFDcEMsTUFBTSxHQUFHLENBQUMsRUFBRTtVQUNuQixPQUFPO1lBQUV3RSxTQUFTLEVBQUUxTSxJQUFJLENBQUM4TztVQUFXLENBQUM7UUFDdkMsQ0FBQyxNQUFNO1VBQ0xnUCxLQUFLLENBQ0grUixVQUFVLEVBQ1ZwUCxLQUFLLENBQUNxUCxRQUFRLENBQ1pyUCxLQUFLLENBQUN5QixlQUFlLENBQUM7WUFDcEJuVSxVQUFVLEVBQUUwUyxLQUFLLENBQUNxUCxRQUFRLENBQUNyUCxLQUFLLENBQUMyQixLQUFLLENBQUMxaEIsTUFBTSxFQUFFN0IsU0FBUyxDQUFDLENBQUM7WUFDMURnUCxJQUFJLEVBQUU0UyxLQUFLLENBQUNxUCxRQUFRLENBQ2xCclAsS0FBSyxDQUFDMkIsS0FBSyxDQUFDMWhCLE1BQU0sRUFBRTZKLEtBQUssRUFBRTRYLFFBQVEsRUFBRXRqQixTQUFTLENBQ2hELENBQUM7WUFDRGlMLEtBQUssRUFBRTJXLEtBQUssQ0FBQ3FQLFFBQVEsQ0FBQ3JQLEtBQUssQ0FBQzJCLEtBQUssQ0FBQzJOLE1BQU0sRUFBRWx4QixTQUFTLENBQUMsQ0FBQztZQUNyRGlQLElBQUksRUFBRTJTLEtBQUssQ0FBQ3FQLFFBQVEsQ0FBQ3JQLEtBQUssQ0FBQzJCLEtBQUssQ0FBQzJOLE1BQU0sRUFBRWx4QixTQUFTLENBQUM7VUFDckQsQ0FBQyxDQUNILENBQ0YsQ0FBQztVQUVELE9BQUE3RCxhQUFBO1lBQ0UwUixTQUFTLEVBQUUxTSxJQUFJLENBQUM4TztVQUFVLEdBQ3ZCK2dCLFVBQVU7UUFFakI7TUFDRixDQUFDO01BRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7TUFDRXBtQixJQUFJQSxDQUFBLEVBQVU7UUFBQSxTQUFBWSxJQUFBLEdBQUFYLFNBQUEsQ0FBQXhCLE1BQUEsRUFBTm9DLElBQUksT0FBQUMsS0FBQSxDQUFBRixJQUFBLEdBQUFHLElBQUEsTUFBQUEsSUFBQSxHQUFBSCxJQUFBLEVBQUFHLElBQUE7VUFBSkYsSUFBSSxDQUFBRSxJQUFBLElBQUFkLFNBQUEsQ0FBQWMsSUFBQTtRQUFBO1FBQ1Y7UUFDQTtRQUNBO1FBQ0EsT0FBTyxJQUFJLENBQUMyaUIsV0FBVyxDQUFDMWpCLElBQUksQ0FDMUIsSUFBSSxDQUFDa21CLGdCQUFnQixDQUFDcmxCLElBQUksQ0FBQyxFQUMzQixJQUFJLENBQUNzbEIsZUFBZSxDQUFDdGxCLElBQUksQ0FDM0IsQ0FBQztNQUNILENBQUM7TUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtNQUNFVCxZQUFZQSxDQUFBLEVBQVU7UUFBQSxTQUFBYyxLQUFBLEdBQUFqQixTQUFBLENBQUF4QixNQUFBLEVBQU5vQyxJQUFJLE9BQUFDLEtBQUEsQ0FBQUksS0FBQSxHQUFBQyxLQUFBLE1BQUFBLEtBQUEsR0FBQUQsS0FBQSxFQUFBQyxLQUFBO1VBQUpOLElBQUksQ0FBQU0sS0FBQSxJQUFBbEIsU0FBQSxDQUFBa0IsS0FBQTtRQUFBO1FBQ2xCLE9BQU8sSUFBSSxDQUFDdWlCLFdBQVcsQ0FBQ3RqQixZQUFZLENBQ2xDLElBQUksQ0FBQzhsQixnQkFBZ0IsQ0FBQ3JsQixJQUFJLENBQUMsRUFDM0IsSUFBSSxDQUFDc2xCLGVBQWUsQ0FBQ3RsQixJQUFJLENBQzNCLENBQUM7TUFDSCxDQUFDO01BQ0Q7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7TUFDRStrQixPQUFPQSxDQUFBLEVBQVU7UUFBQSxTQUFBVyxLQUFBLEdBQUF0bUIsU0FBQSxDQUFBeEIsTUFBQSxFQUFOb0MsSUFBSSxPQUFBQyxLQUFBLENBQUF5bEIsS0FBQSxHQUFBQyxLQUFBLE1BQUFBLEtBQUEsR0FBQUQsS0FBQSxFQUFBQyxLQUFBO1VBQUozbEIsSUFBSSxDQUFBMmxCLEtBQUEsSUFBQXZtQixTQUFBLENBQUF1bUIsS0FBQTtRQUFBO1FBQ2IsT0FBTyxJQUFJLENBQUM5QyxXQUFXLENBQUNrQyxPQUFPLENBQzdCLElBQUksQ0FBQ00sZ0JBQWdCLENBQUNybEIsSUFBSSxDQUFDLEVBQzNCLElBQUksQ0FBQ3NsQixlQUFlLENBQUN0bEIsSUFBSSxDQUMzQixDQUFDO01BQ0g7SUFDRixDQUFDLENBQUM7SUFFRjVKLE1BQU0sQ0FBQ0MsTUFBTSxDQUFDdEMsS0FBSyxDQUFDOE0sVUFBVSxFQUFFO01BQzlCLE1BQU13QixjQUFjQSxDQUFDakIsTUFBTSxFQUFFa0IsR0FBRyxFQUFFMUosVUFBVSxFQUFFO1FBQzVDLElBQUlxUCxhQUFhLEdBQUcsTUFBTTdHLE1BQU0sQ0FBQ3dCLGNBQWMsQ0FDM0M7VUFDRXdILEtBQUssRUFBRSxTQUFBQSxDQUFTNVAsRUFBRSxFQUFFa0osTUFBTSxFQUFFO1lBQzFCcEIsR0FBRyxDQUFDOEgsS0FBSyxDQUFDeFIsVUFBVSxFQUFFNEIsRUFBRSxFQUFFa0osTUFBTSxDQUFDO1VBQ25DLENBQUM7VUFDRDhXLE9BQU8sRUFBRSxTQUFBQSxDQUFTaGdCLEVBQUUsRUFBRWtKLE1BQU0sRUFBRTtZQUM1QnBCLEdBQUcsQ0FBQ2tZLE9BQU8sQ0FBQzVoQixVQUFVLEVBQUU0QixFQUFFLEVBQUVrSixNQUFNLENBQUM7VUFDckMsQ0FBQztVQUNEbVcsT0FBTyxFQUFFLFNBQUFBLENBQVNyZixFQUFFLEVBQUU7WUFDcEI4SCxHQUFHLENBQUN1WCxPQUFPLENBQUNqaEIsVUFBVSxFQUFFNEIsRUFBRSxDQUFDO1VBQzdCO1FBQ0YsQ0FBQztRQUNEO1FBQ0E7UUFDQTtVQUFFMkksb0JBQW9CLEVBQUU7UUFBSyxDQUNqQyxDQUFDOztRQUVEO1FBQ0E7O1FBRUE7UUFDQWIsR0FBRyxDQUFDMEYsTUFBTSxDQUFDLGtCQUFpQjtVQUMxQixPQUFPLE1BQU1DLGFBQWEsQ0FBQzFQLElBQUksQ0FBQyxDQUFDO1FBQ25DLENBQUMsQ0FBQzs7UUFFRjtRQUNBLE9BQU8wUCxhQUFhO01BQ3RCLENBQUM7TUFFRDtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0FuSCxnQkFBZ0JBLENBQUM3RixRQUFRLEVBQXVCO1FBQUEsSUFBckI7VUFBRTJxQjtRQUFXLENBQUMsR0FBQXhtQixTQUFBLENBQUF4QixNQUFBLFFBQUF3QixTQUFBLFFBQUE3SyxTQUFBLEdBQUE2SyxTQUFBLE1BQUcsQ0FBQyxDQUFDO1FBQzVDO1FBQ0EsSUFBSTlFLGVBQWUsQ0FBQ3VyQixhQUFhLENBQUM1cUIsUUFBUSxDQUFDLEVBQUVBLFFBQVEsR0FBRztVQUFFUixHQUFHLEVBQUVRO1FBQVMsQ0FBQztRQUV6RSxJQUFJZ0YsS0FBSyxDQUFDdk4sT0FBTyxDQUFDdUksUUFBUSxDQUFDLEVBQUU7VUFDM0I7VUFDQTtVQUNBLE1BQU0sSUFBSTVDLEtBQUssQ0FBQyxtQ0FBbUMsQ0FBQztRQUN0RDtRQUVBLElBQUksQ0FBQzRDLFFBQVEsSUFBSyxLQUFLLElBQUlBLFFBQVEsSUFBSSxDQUFDQSxRQUFRLENBQUNSLEdBQUksRUFBRTtVQUNyRDtVQUNBLE9BQU87WUFBRUEsR0FBRyxFQUFFbXJCLFVBQVUsSUFBSXRELE1BQU0sQ0FBQzluQixFQUFFLENBQUM7VUFBRSxDQUFDO1FBQzNDO1FBRUEsT0FBT1MsUUFBUTtNQUNqQjtJQUNGLENBQUMsQ0FBQztJQUVGN0UsTUFBTSxDQUFDQyxNQUFNLENBQUN0QyxLQUFLLENBQUM4TSxVQUFVLENBQUMzTixTQUFTLEVBQUU7TUFDeEM7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTs7TUFFQTR5QixPQUFPQSxDQUFDN2dCLEdBQUcsRUFBRWxOLFFBQVEsRUFBRTtRQUNyQjtRQUNBLElBQUksQ0FBQ2tOLEdBQUcsRUFBRTtVQUNSLE1BQU0sSUFBSTVNLEtBQUssQ0FBQyw2QkFBNkIsQ0FBQztRQUNoRDs7UUFHQTtRQUNBNE0sR0FBRyxHQUFHN08sTUFBTSxDQUFDc3FCLE1BQU0sQ0FDakJ0cUIsTUFBTSxDQUFDMnZCLGNBQWMsQ0FBQzlnQixHQUFHLENBQUMsRUFDMUI3TyxNQUFNLENBQUM0dkIseUJBQXlCLENBQUMvZ0IsR0FBRyxDQUN0QyxDQUFDO1FBRUQsSUFBSSxLQUFLLElBQUlBLEdBQUcsRUFBRTtVQUNoQixJQUNFLENBQUNBLEdBQUcsQ0FBQ3hLLEdBQUcsSUFDUixFQUFFLE9BQU93SyxHQUFHLENBQUN4SyxHQUFHLEtBQUssUUFBUSxJQUFJd0ssR0FBRyxDQUFDeEssR0FBRyxZQUFZMUcsS0FBSyxDQUFDRCxRQUFRLENBQUMsRUFDbkU7WUFDQSxNQUFNLElBQUl1RSxLQUFLLENBQ2IsMEVBQ0YsQ0FBQztVQUNIO1FBQ0YsQ0FBQyxNQUFNO1VBQ0wsSUFBSTR0QixVQUFVLEdBQUcsSUFBSTs7VUFFckI7VUFDQTtVQUNBO1VBQ0EsSUFBSSxJQUFJLENBQUNDLG1CQUFtQixDQUFDLENBQUMsRUFBRTtZQUM5QixNQUFNQyxTQUFTLEdBQUcvRCxHQUFHLENBQUNnRSx3QkFBd0IsQ0FBQzFTLEdBQUcsQ0FBQyxDQUFDO1lBQ3BELElBQUksQ0FBQ3lTLFNBQVMsRUFBRTtjQUNkRixVQUFVLEdBQUcsS0FBSztZQUNwQjtVQUNGO1VBRUEsSUFBSUEsVUFBVSxFQUFFO1lBQ2RoaEIsR0FBRyxDQUFDeEssR0FBRyxHQUFHLElBQUksQ0FBQ3luQixVQUFVLENBQUMsQ0FBQztVQUM3QjtRQUNGOztRQUdBO1FBQ0E7UUFDQSxJQUFJbUUscUNBQXFDLEdBQUcsU0FBQUEsQ0FBU3RzQixNQUFNLEVBQUU7VUFDM0QsSUFBSTNJLE1BQU0sQ0FBQ2sxQixVQUFVLENBQUN2c0IsTUFBTSxDQUFDLEVBQUUsT0FBT0EsTUFBTTtVQUU1QyxJQUFJa0wsR0FBRyxDQUFDeEssR0FBRyxFQUFFO1lBQ1gsT0FBT3dLLEdBQUcsQ0FBQ3hLLEdBQUc7VUFDaEI7O1VBRUE7VUFDQTtVQUNBO1VBQ0F3SyxHQUFHLENBQUN4SyxHQUFHLEdBQUdWLE1BQU07VUFFaEIsT0FBT0EsTUFBTTtRQUNmLENBQUM7UUFFRCxNQUFNd3NCLGVBQWUsR0FBR0MsWUFBWSxDQUNsQ3p1QixRQUFRLEVBQ1JzdUIscUNBQ0YsQ0FBQztRQUVELElBQUksSUFBSSxDQUFDSCxtQkFBbUIsQ0FBQyxDQUFDLEVBQUU7VUFDOUIsTUFBTW5zQixNQUFNLEdBQUcsSUFBSSxDQUFDMHNCLGtCQUFrQixDQUFDLFFBQVEsRUFBRSxDQUFDeGhCLEdBQUcsQ0FBQyxFQUFFc2hCLGVBQWUsQ0FBQztVQUN4RSxPQUFPRixxQ0FBcUMsQ0FBQ3RzQixNQUFNLENBQUM7UUFDdEQ7O1FBRUE7UUFDQTtRQUNBLElBQUk7VUFDRjtVQUNBO1VBQ0E7VUFDQSxJQUFJQSxNQUFNO1VBQ1YsSUFBSSxDQUFDLENBQUN3c0IsZUFBZSxFQUFFO1lBQ3JCLElBQUksQ0FBQzFELFdBQVcsQ0FBQzhCLE1BQU0sQ0FBQzFmLEdBQUcsRUFBRXNoQixlQUFlLENBQUM7VUFDL0MsQ0FBQyxNQUFNO1lBQ0w7WUFDQTtZQUNBeHNCLE1BQU0sR0FBRyxJQUFJLENBQUM4b0IsV0FBVyxDQUFDOEIsTUFBTSxDQUFDMWYsR0FBRyxDQUFDO1VBQ3ZDO1VBRUEsT0FBT29oQixxQ0FBcUMsQ0FBQ3RzQixNQUFNLENBQUM7UUFDdEQsQ0FBQyxDQUFDLE9BQU9LLENBQUMsRUFBRTtVQUNWLElBQUlyQyxRQUFRLEVBQUU7WUFDWkEsUUFBUSxDQUFDcUMsQ0FBQyxDQUFDO1lBQ1gsT0FBTyxJQUFJO1VBQ2I7VUFDQSxNQUFNQSxDQUFDO1FBQ1Q7TUFDRixDQUFDO01BRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO01BQ0V1cUIsTUFBTUEsQ0FBQzFmLEdBQUcsRUFBRWxOLFFBQVEsRUFBRTtRQUNwQixPQUFPLElBQUksQ0FBQyt0QixPQUFPLENBQUM3Z0IsR0FBRyxFQUFFbE4sUUFBUSxDQUFDO01BQ3BDLENBQUM7TUFFRDJ1QixZQUFZQSxDQUFDemhCLEdBQUcsRUFBZ0I7UUFBQSxJQUFkM1AsT0FBTyxHQUFBOEosU0FBQSxDQUFBeEIsTUFBQSxRQUFBd0IsU0FBQSxRQUFBN0ssU0FBQSxHQUFBNkssU0FBQSxNQUFHLENBQUMsQ0FBQztRQUM1QjtRQUNBLElBQUksQ0FBQzZGLEdBQUcsRUFBRTtVQUNSLE1BQU0sSUFBSTVNLEtBQUssQ0FBQyw2QkFBNkIsQ0FBQztRQUNoRDs7UUFFQTtRQUNBNE0sR0FBRyxHQUFHN08sTUFBTSxDQUFDc3FCLE1BQU0sQ0FDZnRxQixNQUFNLENBQUMydkIsY0FBYyxDQUFDOWdCLEdBQUcsQ0FBQyxFQUMxQjdPLE1BQU0sQ0FBQzR2Qix5QkFBeUIsQ0FBQy9nQixHQUFHLENBQ3hDLENBQUM7UUFFRCxJQUFJLEtBQUssSUFBSUEsR0FBRyxFQUFFO1VBQ2hCLElBQ0ksQ0FBQ0EsR0FBRyxDQUFDeEssR0FBRyxJQUNSLEVBQUUsT0FBT3dLLEdBQUcsQ0FBQ3hLLEdBQUcsS0FBSyxRQUFRLElBQUl3SyxHQUFHLENBQUN4SyxHQUFHLFlBQVkxRyxLQUFLLENBQUNELFFBQVEsQ0FBQyxFQUNyRTtZQUNBLE1BQU0sSUFBSXVFLEtBQUssQ0FDWCwwRUFDSixDQUFDO1VBQ0g7UUFDRixDQUFDLE1BQU07VUFDTCxJQUFJNHRCLFVBQVUsR0FBRyxJQUFJOztVQUVyQjtVQUNBO1VBQ0E7VUFDQSxJQUFJLElBQUksQ0FBQ0MsbUJBQW1CLENBQUMsQ0FBQyxFQUFFO1lBQzlCLE1BQU1DLFNBQVMsR0FBRy9ELEdBQUcsQ0FBQ2dFLHdCQUF3QixDQUFDMVMsR0FBRyxDQUFDLENBQUM7WUFDcEQsSUFBSSxDQUFDeVMsU0FBUyxFQUFFO2NBQ2RGLFVBQVUsR0FBRyxLQUFLO1lBQ3BCO1VBQ0Y7VUFFQSxJQUFJQSxVQUFVLEVBQUU7WUFDZGhoQixHQUFHLENBQUN4SyxHQUFHLEdBQUcsSUFBSSxDQUFDeW5CLFVBQVUsQ0FBQyxDQUFDO1VBQzdCO1FBQ0Y7O1FBRUE7UUFDQTtRQUNBLElBQUltRSxxQ0FBcUMsR0FBRyxTQUFBQSxDQUFTdHNCLE1BQU0sRUFBRTtVQUMzRCxJQUFJM0ksTUFBTSxDQUFDazFCLFVBQVUsQ0FBQ3ZzQixNQUFNLENBQUMsRUFBRSxPQUFPQSxNQUFNO1VBRTVDLElBQUlrTCxHQUFHLENBQUN4SyxHQUFHLEVBQUU7WUFDWCxPQUFPd0ssR0FBRyxDQUFDeEssR0FBRztVQUNoQjs7VUFFQTtVQUNBO1VBQ0E7VUFDQXdLLEdBQUcsQ0FBQ3hLLEdBQUcsR0FBR1YsTUFBTTtVQUVoQixPQUFPQSxNQUFNO1FBQ2YsQ0FBQztRQUVELElBQUksSUFBSSxDQUFDbXNCLG1CQUFtQixDQUFDLENBQUMsRUFBRTtVQUM5QixNQUFNUyxPQUFPLEdBQUcsSUFBSSxDQUFDQyx1QkFBdUIsQ0FBQyxhQUFhLEVBQUUsQ0FBQzNoQixHQUFHLENBQUMsRUFBRTNQLE9BQU8sQ0FBQztVQUMzRXF4QixPQUFPLENBQUMvckIsSUFBSSxDQUFDeXJCLHFDQUFxQyxDQUFDO1VBQ25ETSxPQUFPLENBQUNFLFdBQVcsR0FBR0YsT0FBTyxDQUFDRSxXQUFXLENBQUNqc0IsSUFBSSxDQUFDeXJCLHFDQUFxQyxDQUFDO1VBQ3JGTSxPQUFPLENBQUNHLGFBQWEsR0FBR0gsT0FBTyxDQUFDRyxhQUFhLENBQUNsc0IsSUFBSSxDQUFDeXJCLHFDQUFxQyxDQUFDO1VBQ3pGLE9BQU9NLE9BQU87UUFDaEI7O1FBRUE7UUFDQTtRQUNBLE9BQU8sSUFBSSxDQUFDOUQsV0FBVyxDQUFDM29CLFdBQVcsQ0FBQytLLEdBQUcsQ0FBQyxDQUNyQ3JLLElBQUksQ0FBQ3lyQixxQ0FBcUMsQ0FBQztNQUNoRCxDQUFDO01BRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtNQUNFbnNCLFdBQVdBLENBQUMrSyxHQUFHLEVBQUUzUCxPQUFPLEVBQUU7UUFDeEIsT0FBTyxJQUFJLENBQUNveEIsWUFBWSxDQUFDemhCLEdBQUcsRUFBRTNQLE9BQU8sQ0FBQztNQUN4QyxDQUFDO01BRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7TUFDRTZHLFdBQVdBLENBQUNsQixRQUFRLEVBQUV1akIsUUFBUSxFQUF5QjtRQUVyRDtRQUNBO1FBQ0EsTUFBTWxwQixPQUFPLEdBQUE1RSxhQUFBLEtBQVMsQ0FBQTBPLFNBQUEsQ0FBQXhCLE1BQUEsUUFBQXJKLFNBQUEsR0FBQTZLLFNBQUEsUUFBeUIsSUFBSSxDQUFHO1FBQ3RELElBQUl0RSxVQUFVO1FBQ2QsSUFBSXhGLE9BQU8sSUFBSUEsT0FBTyxDQUFDa0gsTUFBTSxFQUFFO1VBQzdCO1VBQ0EsSUFBSWxILE9BQU8sQ0FBQ3dGLFVBQVUsRUFBRTtZQUN0QixJQUNFLEVBQ0UsT0FBT3hGLE9BQU8sQ0FBQ3dGLFVBQVUsS0FBSyxRQUFRLElBQ3RDeEYsT0FBTyxDQUFDd0YsVUFBVSxZQUFZL0csS0FBSyxDQUFDRCxRQUFRLENBQzdDLEVBRUQsTUFBTSxJQUFJdUUsS0FBSyxDQUFDLHVDQUF1QyxDQUFDO1lBQzFEeUMsVUFBVSxHQUFHeEYsT0FBTyxDQUFDd0YsVUFBVTtVQUNqQyxDQUFDLE1BQU0sSUFBSSxDQUFDRyxRQUFRLElBQUksQ0FBQ0EsUUFBUSxDQUFDUixHQUFHLEVBQUU7WUFDckNLLFVBQVUsR0FBRyxJQUFJLENBQUNvbkIsVUFBVSxDQUFDLENBQUM7WUFDOUI1c0IsT0FBTyxDQUFDNkgsV0FBVyxHQUFHLElBQUk7WUFDMUI3SCxPQUFPLENBQUN3RixVQUFVLEdBQUdBLFVBQVU7VUFDakM7UUFDRjtRQUVBRyxRQUFRLEdBQUdsSCxLQUFLLENBQUM4TSxVQUFVLENBQUNDLGdCQUFnQixDQUFDN0YsUUFBUSxFQUFFO1VBQ3JEMnFCLFVBQVUsRUFBRTlxQjtRQUNkLENBQUMsQ0FBQztRQUVGLElBQUksSUFBSSxDQUFDb3JCLG1CQUFtQixDQUFDLENBQUMsRUFBRTtVQUM5QixNQUFNbG1CLElBQUksR0FBRyxDQUFDL0UsUUFBUSxFQUFFdWpCLFFBQVEsRUFBRWxwQixPQUFPLENBQUM7VUFFMUMsT0FBTyxJQUFJLENBQUNzeEIsdUJBQXVCLENBQUMsYUFBYSxFQUFFNW1CLElBQUksRUFBRTFLLE9BQU8sQ0FBQztRQUNuRTs7UUFFQTtRQUNBO1FBQ0U7UUFDQTtRQUNBOztRQUVGLE9BQU8sSUFBSSxDQUFDdXRCLFdBQVcsQ0FBQzFtQixXQUFXLENBQ2pDbEIsUUFBUSxFQUNSdWpCLFFBQVEsRUFDUmxwQixPQUNGLENBQUM7TUFDSCxDQUFDO01BRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtNQUNFK3VCLE1BQU1BLENBQUNwcEIsUUFBUSxFQUFFdWpCLFFBQVEsRUFBeUI7UUFBQSxTQUFBdUksS0FBQSxHQUFBM25CLFNBQUEsQ0FBQXhCLE1BQUEsRUFBcEJvcEIsa0JBQWtCLE9BQUEvbUIsS0FBQSxDQUFBOG1CLEtBQUEsT0FBQUEsS0FBQSxXQUFBRSxLQUFBLE1BQUFBLEtBQUEsR0FBQUYsS0FBQSxFQUFBRSxLQUFBO1VBQWxCRCxrQkFBa0IsQ0FBQUMsS0FBQSxRQUFBN25CLFNBQUEsQ0FBQTZuQixLQUFBO1FBQUE7UUFDOUMsTUFBTWx2QixRQUFRLEdBQUdtdkIsbUJBQW1CLENBQUNGLGtCQUFrQixDQUFDOztRQUV4RDtRQUNBO1FBQ0EsTUFBTTF4QixPQUFPLEdBQUE1RSxhQUFBLEtBQVNzMkIsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFHO1FBQ3RELElBQUlsc0IsVUFBVTtRQUNkLElBQUl4RixPQUFPLElBQUlBLE9BQU8sQ0FBQ2tILE1BQU0sRUFBRTtVQUM3QjtVQUNBLElBQUlsSCxPQUFPLENBQUN3RixVQUFVLEVBQUU7WUFDdEIsSUFDRSxFQUNFLE9BQU94RixPQUFPLENBQUN3RixVQUFVLEtBQUssUUFBUSxJQUN0Q3hGLE9BQU8sQ0FBQ3dGLFVBQVUsWUFBWS9HLEtBQUssQ0FBQ0QsUUFBUSxDQUM3QyxFQUVELE1BQU0sSUFBSXVFLEtBQUssQ0FBQyx1Q0FBdUMsQ0FBQztZQUMxRHlDLFVBQVUsR0FBR3hGLE9BQU8sQ0FBQ3dGLFVBQVU7VUFDakMsQ0FBQyxNQUFNLElBQUksQ0FBQ0csUUFBUSxJQUFJLENBQUNBLFFBQVEsQ0FBQ1IsR0FBRyxFQUFFO1lBQ3JDSyxVQUFVLEdBQUcsSUFBSSxDQUFDb25CLFVBQVUsQ0FBQyxDQUFDO1lBQzlCNXNCLE9BQU8sQ0FBQzZILFdBQVcsR0FBRyxJQUFJO1lBQzFCN0gsT0FBTyxDQUFDd0YsVUFBVSxHQUFHQSxVQUFVO1VBQ2pDO1FBQ0Y7UUFFQUcsUUFBUSxHQUFHbEgsS0FBSyxDQUFDOE0sVUFBVSxDQUFDQyxnQkFBZ0IsQ0FBQzdGLFFBQVEsRUFBRTtVQUNyRDJxQixVQUFVLEVBQUU5cUI7UUFDZCxDQUFDLENBQUM7UUFFRixNQUFNeXJCLGVBQWUsR0FBR0MsWUFBWSxDQUFDenVCLFFBQVEsQ0FBQztRQUU5QyxJQUFJLElBQUksQ0FBQ211QixtQkFBbUIsQ0FBQyxDQUFDLEVBQUU7VUFDOUIsTUFBTWxtQixJQUFJLEdBQUcsQ0FBQy9FLFFBQVEsRUFBRXVqQixRQUFRLEVBQUVscEIsT0FBTyxDQUFDO1VBQzFDLE9BQU8sSUFBSSxDQUFDbXhCLGtCQUFrQixDQUFDLFFBQVEsRUFBRXptQixJQUFJLEVBQUVqSSxRQUFRLENBQUM7UUFDMUQ7O1FBRUE7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0EsSUFBSTtVQUNGO1VBQ0E7VUFDQTtVQUNBLE9BQU8sSUFBSSxDQUFDOHFCLFdBQVcsQ0FBQ3dCLE1BQU0sQ0FDNUJwcEIsUUFBUSxFQUNSdWpCLFFBQVEsRUFDUmxwQixPQUFPLEVBQ1BpeEIsZUFDRixDQUFDO1FBQ0gsQ0FBQyxDQUFDLE9BQU9uc0IsQ0FBQyxFQUFFO1VBQ1YsSUFBSXJDLFFBQVEsRUFBRTtZQUNaQSxRQUFRLENBQUNxQyxDQUFDLENBQUM7WUFDWCxPQUFPLElBQUk7VUFDYjtVQUNBLE1BQU1BLENBQUM7UUFDVDtNQUNGLENBQUM7TUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO01BQ0VrQixXQUFXQSxDQUFDTCxRQUFRLEVBQWdCO1FBQUEsSUFBZDNGLE9BQU8sR0FBQThKLFNBQUEsQ0FBQXhCLE1BQUEsUUFBQXdCLFNBQUEsUUFBQTdLLFNBQUEsR0FBQTZLLFNBQUEsTUFBRyxDQUFDLENBQUM7UUFDaENuRSxRQUFRLEdBQUdsSCxLQUFLLENBQUM4TSxVQUFVLENBQUNDLGdCQUFnQixDQUFDN0YsUUFBUSxDQUFDO1FBRXRELElBQUksSUFBSSxDQUFDaXJCLG1CQUFtQixDQUFDLENBQUMsRUFBRTtVQUM5QixPQUFPLElBQUksQ0FBQ1UsdUJBQXVCLENBQUMsYUFBYSxFQUFFLENBQUMzckIsUUFBUSxDQUFDLEVBQUUzRixPQUFPLENBQUM7UUFDekU7O1FBRUE7UUFDQTtRQUNBLE9BQU8sSUFBSSxDQUFDdXRCLFdBQVcsQ0FBQ3ZuQixXQUFXLENBQUNMLFFBQVEsQ0FBQztNQUMvQyxDQUFDO01BRUQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO01BQ0UyZSxNQUFNQSxDQUFDM2UsUUFBUSxFQUFFbEQsUUFBUSxFQUFFO1FBQ3pCa0QsUUFBUSxHQUFHbEgsS0FBSyxDQUFDOE0sVUFBVSxDQUFDQyxnQkFBZ0IsQ0FBQzdGLFFBQVEsQ0FBQztRQUV0RCxJQUFJLElBQUksQ0FBQ2lyQixtQkFBbUIsQ0FBQyxDQUFDLEVBQUU7VUFDOUIsT0FBTyxJQUFJLENBQUNPLGtCQUFrQixDQUFDLFFBQVEsRUFBRSxDQUFDeHJCLFFBQVEsQ0FBQyxFQUFFbEQsUUFBUSxDQUFDO1FBQ2hFOztRQUdBO1FBQ0E7UUFDQSxPQUFPLElBQUksQ0FBQzhxQixXQUFXLENBQUNqSixNQUFNLENBQUMzZSxRQUFRLENBQUM7TUFDMUMsQ0FBQztNQUdEO01BQ0E7TUFDQWlyQixtQkFBbUJBLENBQUEsRUFBRztRQUNwQjtRQUNBLE9BQU8sSUFBSSxDQUFDeEQsV0FBVyxJQUFJLElBQUksQ0FBQ0EsV0FBVyxLQUFLdHhCLE1BQU0sQ0FBQ3d4QixNQUFNO01BQy9ELENBQUM7TUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO01BQ0ksTUFBTTFqQixXQUFXQSxDQUFDakUsUUFBUSxFQUFFdWpCLFFBQVEsRUFBRWxwQixPQUFPLEVBQUU7UUFDN0MsT0FBTyxJQUFJLENBQUM2RyxXQUFXLENBQ3JCbEIsUUFBUSxFQUNSdWpCLFFBQVEsRUFBQTl0QixhQUFBLENBQUFBLGFBQUEsS0FFSDRFLE9BQU87VUFDVitILGFBQWEsRUFBRSxJQUFJO1VBQ25CYixNQUFNLEVBQUU7UUFBSSxFQUNiLENBQUM7TUFDTixDQUFDO01BR0g7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO01BQ0VBLE1BQU1BLENBQUN2QixRQUFRLEVBQUV1akIsUUFBUSxFQUFFbHBCLE9BQU8sRUFBRXlDLFFBQVEsRUFBRTtRQUM1QyxJQUFJLENBQUNBLFFBQVEsSUFBSSxPQUFPekMsT0FBTyxLQUFLLFVBQVUsRUFBRTtVQUM5Q3lDLFFBQVEsR0FBR3pDLE9BQU87VUFDbEJBLE9BQU8sR0FBRyxDQUFDLENBQUM7UUFDZDtRQUVBLE9BQU8sSUFBSSxDQUFDK3VCLE1BQU0sQ0FDaEJwcEIsUUFBUSxFQUNSdWpCLFFBQVEsRUFBQTl0QixhQUFBLENBQUFBLGFBQUEsS0FFSDRFLE9BQU87VUFDVitILGFBQWEsRUFBRSxJQUFJO1VBQ25CYixNQUFNLEVBQUU7UUFBSSxFQUNiLENBQUM7TUFDTixDQUFDO01BRUQ7TUFDQTtNQUNBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO01BQ0UsTUFBTStELGdCQUFnQkEsQ0FBQ1gsS0FBSyxFQUFFdEssT0FBTyxFQUFFO1FBQ3JDLElBQUlJLElBQUksR0FBRyxJQUFJO1FBQ2YsSUFBSSxDQUFDQSxJQUFJLENBQUNtdEIsV0FBVyxDQUFDdGlCLGdCQUFnQixJQUFJLENBQUM3SyxJQUFJLENBQUNtdEIsV0FBVyxDQUFDbGpCLGdCQUFnQixFQUMxRSxNQUFNLElBQUl0SCxLQUFLLENBQUMsc0RBQXNELENBQUM7UUFDekUsSUFBSTNDLElBQUksQ0FBQ210QixXQUFXLENBQUNsakIsZ0JBQWdCLEVBQUU7VUFDckMsTUFBTWpLLElBQUksQ0FBQ210QixXQUFXLENBQUNsakIsZ0JBQWdCLENBQUNDLEtBQUssRUFBRXRLLE9BQU8sQ0FBQztRQUN6RCxDQUFDLE1BQU07VUF4a0NYLElBQUk2eEIsR0FBRztVQUFDeDJCLE9BQU8sQ0FBQ0MsSUFBSSxDQUFDLGdCQUFnQixFQUFDO1lBQUN1MkIsR0FBR0EsQ0FBQ3IyQixDQUFDLEVBQUM7Y0FBQ3EyQixHQUFHLEdBQUNyMkIsQ0FBQztZQUFBO1VBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztVQTJrQ2xEcTJCLEdBQUcsQ0FBQ0MsS0FBSyx1RkFBQXhtQixNQUFBLENBQXdGdEwsT0FBTyxhQUFQQSxPQUFPLGVBQVBBLE9BQU8sQ0FBRWpDLElBQUksb0JBQUF1TixNQUFBLENBQXFCdEwsT0FBTyxDQUFDakMsSUFBSSxnQkFBQXVOLE1BQUEsQ0FBbUIrVSxJQUFJLENBQUNoTyxTQUFTLENBQUMvSCxLQUFLLENBQUMsQ0FBRyxDQUFHLENBQUM7VUFDOUwsTUFBTWxLLElBQUksQ0FBQ210QixXQUFXLENBQUN0aUIsZ0JBQWdCLENBQUNYLEtBQUssRUFBRXRLLE9BQU8sQ0FBQztRQUN6RDtNQUNGLENBQUM7TUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7TUFDRSxNQUFNcUssZ0JBQWdCQSxDQUFDQyxLQUFLLEVBQUV0SyxPQUFPLEVBQUU7UUFDckMsSUFBSUksSUFBSSxHQUFHLElBQUk7UUFDZixJQUFJLENBQUNBLElBQUksQ0FBQ210QixXQUFXLENBQUNsakIsZ0JBQWdCLEVBQ3BDLE1BQU0sSUFBSXRILEtBQUssQ0FBQyxzREFBc0QsQ0FBQztRQUV6RSxJQUFJO1VBQ0YsTUFBTTNDLElBQUksQ0FBQ210QixXQUFXLENBQUNsakIsZ0JBQWdCLENBQUNDLEtBQUssRUFBRXRLLE9BQU8sQ0FBQztRQUN6RCxDQUFDLENBQUMsT0FBTzhFLENBQUMsRUFBRTtVQUFBLElBQUE3RSxnQkFBQSxFQUFBQyxxQkFBQSxFQUFBQyxzQkFBQTtVQUNWLElBQ0UyRSxDQUFDLENBQUN3YixPQUFPLENBQUNoTixRQUFRLENBQ2hCLDhFQUNGLENBQUMsS0FBQXJULGdCQUFBLEdBQ0RuRSxNQUFNLENBQUM0RSxRQUFRLGNBQUFULGdCQUFBLGdCQUFBQyxxQkFBQSxHQUFmRCxnQkFBQSxDQUFpQlUsUUFBUSxjQUFBVCxxQkFBQSxnQkFBQUMsc0JBQUEsR0FBekJELHFCQUFBLENBQTJCVSxLQUFLLGNBQUFULHNCQUFBLGVBQWhDQSxzQkFBQSxDQUFrQzR4Qiw2QkFBNkIsRUFDL0Q7WUF6bUNSLElBQUlGLEdBQUc7WUFBQ3gyQixPQUFPLENBQUNDLElBQUksQ0FBQyxnQkFBZ0IsRUFBQztjQUFDdTJCLEdBQUdBLENBQUNyMkIsQ0FBQyxFQUFDO2dCQUFDcTJCLEdBQUcsR0FBQ3IyQixDQUFDO2NBQUE7WUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO1lBNG1DaERxMkIsR0FBRyxDQUFDRyxJQUFJLHNCQUFBMW1CLE1BQUEsQ0FBdUJoQixLQUFLLFdBQUFnQixNQUFBLENBQVVsTCxJQUFJLENBQUNvdEIsS0FBSyw4QkFBNEIsQ0FBQztZQUNyRixNQUFNcHRCLElBQUksQ0FBQ210QixXQUFXLENBQUNyaUIsY0FBYyxDQUFDWixLQUFLLENBQUM7WUFDNUMsTUFBTWxLLElBQUksQ0FBQ210QixXQUFXLENBQUNsakIsZ0JBQWdCLENBQUNDLEtBQUssRUFBRXRLLE9BQU8sQ0FBQztVQUN6RCxDQUFDLE1BQU07WUFDTDBQLE9BQU8sQ0FBQzNJLEtBQUssQ0FBQ2pDLENBQUMsQ0FBQztZQUNoQixNQUFNLElBQUloSixNQUFNLENBQUNpSCxLQUFLLDhEQUFBdUksTUFBQSxDQUE4RGxMLElBQUksQ0FBQ290QixLQUFLLFFBQUFsaUIsTUFBQSxDQUFPeEcsQ0FBQyxDQUFDd2IsT0FBTyxDQUFHLENBQUM7VUFDcEg7UUFDRjtNQUNGLENBQUM7TUFFRDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7TUFDRS9WLFdBQVdBLENBQUNELEtBQUssRUFBRXRLLE9BQU8sRUFBQztRQUN6QixPQUFPLElBQUksQ0FBQ3FLLGdCQUFnQixDQUFDQyxLQUFLLEVBQUV0SyxPQUFPLENBQUM7TUFDOUMsQ0FBQztNQUVELE1BQU1rTCxjQUFjQSxDQUFDWixLQUFLLEVBQUU7UUFDMUIsSUFBSWxLLElBQUksR0FBRyxJQUFJO1FBQ2YsSUFBSSxDQUFDQSxJQUFJLENBQUNtdEIsV0FBVyxDQUFDcmlCLGNBQWMsRUFDbEMsTUFBTSxJQUFJbkksS0FBSyxDQUFDLG9EQUFvRCxDQUFDO1FBQ3ZFLE1BQU0zQyxJQUFJLENBQUNtdEIsV0FBVyxDQUFDcmlCLGNBQWMsQ0FBQ1osS0FBSyxDQUFDO01BQzlDLENBQUM7TUFFRCxNQUFNL0QsbUJBQW1CQSxDQUFBLEVBQUc7UUFDMUIsSUFBSW5HLElBQUksR0FBRyxJQUFJO1FBQ2YsSUFBSSxDQUFDQSxJQUFJLENBQUNtdEIsV0FBVyxDQUFDaG5CLG1CQUFtQixFQUN2QyxNQUFNLElBQUl4RCxLQUFLLENBQUMseURBQXlELENBQUM7UUFDN0UsTUFBTTNDLElBQUksQ0FBQ210QixXQUFXLENBQUNobkIsbUJBQW1CLENBQUMsQ0FBQztNQUM3QyxDQUFDO01BRUQsTUFBTWhELDJCQUEyQkEsQ0FBQ0MsUUFBUSxFQUFFQyxZQUFZLEVBQUU7UUFDeEQsSUFBSXJELElBQUksR0FBRyxJQUFJO1FBQ2YsSUFBSSxFQUFFLE1BQU1BLElBQUksQ0FBQ210QixXQUFXLENBQUNocUIsMkJBQTJCLEdBQ3RELE1BQU0sSUFBSVIsS0FBSyxDQUNiLGlFQUNGLENBQUM7UUFDSCxNQUFNM0MsSUFBSSxDQUFDbXRCLFdBQVcsQ0FBQ2hxQiwyQkFBMkIsQ0FBQ0MsUUFBUSxFQUFFQyxZQUFZLENBQUM7TUFDNUUsQ0FBQztNQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtNQUNFTCxhQUFhQSxDQUFBLEVBQUc7UUFDZCxJQUFJaEQsSUFBSSxHQUFHLElBQUk7UUFDZixJQUFJLENBQUNBLElBQUksQ0FBQ210QixXQUFXLENBQUNucUIsYUFBYSxFQUFFO1VBQ25DLE1BQU0sSUFBSUwsS0FBSyxDQUFDLG1EQUFtRCxDQUFDO1FBQ3RFO1FBQ0EsT0FBTzNDLElBQUksQ0FBQ210QixXQUFXLENBQUNucUIsYUFBYSxDQUFDLENBQUM7TUFDekMsQ0FBQztNQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtNQUNFNnVCLFdBQVdBLENBQUEsRUFBRztRQUNaLElBQUk3eEIsSUFBSSxHQUFHLElBQUk7UUFDZixJQUFJLEVBQUVBLElBQUksQ0FBQ3NzQixPQUFPLENBQUM5ckIsS0FBSyxJQUFJUixJQUFJLENBQUNzc0IsT0FBTyxDQUFDOXJCLEtBQUssQ0FBQ2tCLEVBQUUsQ0FBQyxFQUFFO1VBQ2xELE1BQU0sSUFBSWlCLEtBQUssQ0FBQyxpREFBaUQsQ0FBQztRQUNwRTtRQUNBLE9BQU8zQyxJQUFJLENBQUNzc0IsT0FBTyxDQUFDOXJCLEtBQUssQ0FBQ2tCLEVBQUU7TUFDOUI7SUFDRixDQUFDLENBQUM7O0lBRUY7SUFDQSxTQUFTb3ZCLFlBQVlBLENBQUN6dUIsUUFBUSxFQUFFeXZCLGFBQWEsRUFBRTtNQUM3QyxPQUNFenZCLFFBQVEsSUFDUixVQUFTc0UsS0FBSyxFQUFFdEMsTUFBTSxFQUFFO1FBQ3RCLElBQUlzQyxLQUFLLEVBQUU7VUFDVHRFLFFBQVEsQ0FBQ3NFLEtBQUssQ0FBQztRQUNqQixDQUFDLE1BQU0sSUFBSSxPQUFPbXJCLGFBQWEsS0FBSyxVQUFVLEVBQUU7VUFDOUN6dkIsUUFBUSxDQUFDc0UsS0FBSyxFQUFFbXJCLGFBQWEsQ0FBQ3p0QixNQUFNLENBQUMsQ0FBQztRQUN4QyxDQUFDLE1BQU07VUFDTGhDLFFBQVEsQ0FBQ3NFLEtBQUssRUFBRXRDLE1BQU0sQ0FBQztRQUN6QjtNQUNGLENBQUM7SUFFTDs7SUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7SUFDQWhHLEtBQUssQ0FBQ0QsUUFBUSxHQUFHMHdCLE9BQU8sQ0FBQzF3QixRQUFROztJQUVqQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0lBQ0FDLEtBQUssQ0FBQ3NMLE1BQU0sR0FBRy9FLGVBQWUsQ0FBQytFLE1BQU07O0lBRXJDO0FBQ0E7QUFDQTtJQUNBdEwsS0FBSyxDQUFDOE0sVUFBVSxDQUFDeEIsTUFBTSxHQUFHdEwsS0FBSyxDQUFDc0wsTUFBTTs7SUFFdEM7QUFDQTtBQUNBO0lBQ0F0TCxLQUFLLENBQUM4TSxVQUFVLENBQUMvTSxRQUFRLEdBQUdDLEtBQUssQ0FBQ0QsUUFBUTs7SUFFMUM7QUFDQTtBQUNBO0lBQ0ExQyxNQUFNLENBQUN5UCxVQUFVLEdBQUc5TSxLQUFLLENBQUM4TSxVQUFVOztJQUVwQztJQUNBekssTUFBTSxDQUFDQyxNQUFNLENBQUN0QyxLQUFLLENBQUM4TSxVQUFVLENBQUMzTixTQUFTLEVBQUV1MEIsU0FBUyxDQUFDQyxtQkFBbUIsQ0FBQztJQUV4RSxTQUFTUixtQkFBbUJBLENBQUNsbkIsSUFBSSxFQUFFO01BQ2pDO01BQ0E7TUFDQSxJQUNFQSxJQUFJLENBQUNwQyxNQUFNLEtBQ1ZvQyxJQUFJLENBQUNBLElBQUksQ0FBQ3BDLE1BQU0sR0FBRyxDQUFDLENBQUMsS0FBS3JKLFNBQVMsSUFDbEN5TCxJQUFJLENBQUNBLElBQUksQ0FBQ3BDLE1BQU0sR0FBRyxDQUFDLENBQUMsWUFBWWlhLFFBQVEsQ0FBQyxFQUM1QztRQUNBLE9BQU83WCxJQUFJLENBQUNtUSxHQUFHLENBQUMsQ0FBQztNQUNuQjtJQUNGO0lBQUM1RixzQkFBQTtFQUFBLFNBQUFDLFdBQUE7SUFBQSxPQUFBRCxzQkFBQSxDQUFBQyxXQUFBO0VBQUE7RUFBQUQsc0JBQUE7QUFBQTtFQUFBN1UsSUFBQTtFQUFBK1UsS0FBQTtBQUFBLEc7Ozs7Ozs7Ozs7O0FDcnZDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTFXLEtBQUssQ0FBQzR6QixvQkFBb0IsR0FBRyxTQUFTQSxvQkFBb0JBLENBQUVyeUIsT0FBTyxFQUFFO0VBQ25Fa2UsS0FBSyxDQUFDbGUsT0FBTyxFQUFFYyxNQUFNLENBQUM7RUFDdEJyQyxLQUFLLENBQUNnQyxrQkFBa0IsR0FBR1QsT0FBTztBQUNwQyxDQUFDLEM7Ozs7Ozs7Ozs7Ozs7O0lDVEQsSUFBSTVFLGFBQWE7SUFBQ3VCLE1BQU0sQ0FBQ3JCLElBQUksQ0FBQyxzQ0FBc0MsRUFBQztNQUFDQyxPQUFPQSxDQUFDQyxDQUFDLEVBQUM7UUFBQ0osYUFBYSxHQUFDSSxDQUFDO01BQUE7SUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0lBQUMsSUFBSTRmLHdCQUF3QjtJQUFDemUsTUFBTSxDQUFDckIsSUFBSSxDQUFDLGdEQUFnRCxFQUFDO01BQUNDLE9BQU9BLENBQUNDLENBQUMsRUFBQztRQUFDNGYsd0JBQXdCLEdBQUM1ZixDQUFDO01BQUE7SUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0lBQUMsSUFBSU8sb0JBQW9CLENBQUMsQ0FBQyxFQUFFLENBQUMsTUFBTUEsb0JBQW9CLENBQUMsQ0FBQyxFQUFFLENBQUM7SUFBQyxNQUFBc2YsU0FBQTtJQUF6UzFlLE1BQU0sQ0FBQ2toQixNQUFNLENBQUM7TUFBQ3BpQixtQkFBbUIsRUFBQ0EsQ0FBQSxLQUFJQTtJQUFtQixDQUFDLENBQUM7SUFBckQsTUFBTUEsbUJBQW1CLEdBQUd1RSxPQUFPLElBQUk7TUFDNUM7TUFDQSxNQUFBcUIsSUFBQSxHQUFnRHJCLE9BQU8sSUFBSSxDQUFDLENBQUM7UUFBdkQ7VUFBRW9PLE1BQU07VUFBRUQ7UUFBNEIsQ0FBQyxHQUFBOU0sSUFBQTtRQUFkaXhCLFlBQVksR0FBQWxYLHdCQUFBLENBQUEvWixJQUFBLEVBQUFnYSxTQUFBO01BQzNDO01BQ0E7O01BRUEsT0FBQWpnQixhQUFBLENBQUFBLGFBQUEsS0FDS2szQixZQUFZLEdBQ1hua0IsVUFBVSxJQUFJQyxNQUFNLEdBQUc7UUFBRUQsVUFBVSxFQUFFQyxNQUFNLElBQUlEO01BQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUV4RSxDQUFDO0lBQUM4RyxzQkFBQTtFQUFBLFNBQUFDLFdBQUE7SUFBQSxPQUFBRCxzQkFBQSxDQUFBQyxXQUFBO0VBQUE7RUFBQUQsc0JBQUE7QUFBQTtFQUFBN1UsSUFBQTtFQUFBK1UsS0FBQTtBQUFBLEciLCJmaWxlIjoiL3BhY2thZ2VzL21vbmdvLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgbm9ybWFsaXplUHJvamVjdGlvbiB9IGZyb20gXCIuL21vbmdvX3V0aWxzXCI7XG5cbi8qKlxuICogUHJvdmlkZSBhIHN5bmNocm9ub3VzIENvbGxlY3Rpb24gQVBJIHVzaW5nIGZpYmVycywgYmFja2VkIGJ5XG4gKiBNb25nb0RCLiAgVGhpcyBpcyBvbmx5IGZvciB1c2Ugb24gdGhlIHNlcnZlciwgYW5kIG1vc3RseSBpZGVudGljYWxcbiAqIHRvIHRoZSBjbGllbnQgQVBJLlxuICpcbiAqIE5PVEU6IHRoZSBwdWJsaWMgQVBJIG1ldGhvZHMgbXVzdCBiZSBydW4gd2l0aGluIGEgZmliZXIuIElmIHlvdSBjYWxsXG4gKiB0aGVzZSBvdXRzaWRlIG9mIGEgZmliZXIgdGhleSB3aWxsIGV4cGxvZGUhXG4gKi9cblxuY29uc3QgcGF0aCA9IHJlcXVpcmUoXCJwYXRoXCIpO1xuY29uc3QgdXRpbCA9IHJlcXVpcmUoXCJ1dGlsXCIpO1xuXG4vKiogQHR5cGUge2ltcG9ydCgnbW9uZ29kYicpfSAqL1xudmFyIE1vbmdvREIgPSBOcG1Nb2R1bGVNb25nb2RiO1xuaW1wb3J0IHsgRG9jRmV0Y2hlciB9IGZyb20gXCIuL2RvY19mZXRjaGVyLmpzXCI7XG5pbXBvcnQge1xuICBBU1lOQ19DVVJTT1JfTUVUSE9EUyxcbiAgQ0xJRU5UX09OTFlfTUVUSE9EUyxcbiAgZ2V0QXN5bmNNZXRob2ROYW1lXG59IGZyb20gXCJtZXRlb3IvbWluaW1vbmdvL2NvbnN0YW50c1wiO1xuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSBcIm1ldGVvci9tZXRlb3JcIjtcblxuTW9uZ29JbnRlcm5hbHMgPSB7fTtcblxuTW9uZ29JbnRlcm5hbHMuX19wYWNrYWdlTmFtZSA9ICdtb25nbyc7XG5cbk1vbmdvSW50ZXJuYWxzLk5wbU1vZHVsZXMgPSB7XG4gIG1vbmdvZGI6IHtcbiAgICB2ZXJzaW9uOiBOcG1Nb2R1bGVNb25nb2RiVmVyc2lvbixcbiAgICBtb2R1bGU6IE1vbmdvREJcbiAgfVxufTtcblxuLy8gT2xkZXIgdmVyc2lvbiBvZiB3aGF0IGlzIG5vdyBhdmFpbGFibGUgdmlhXG4vLyBNb25nb0ludGVybmFscy5OcG1Nb2R1bGVzLm1vbmdvZGIubW9kdWxlLiAgSXQgd2FzIG5ldmVyIGRvY3VtZW50ZWQsIGJ1dFxuLy8gcGVvcGxlIGRvIHVzZSBpdC5cbi8vIFhYWCBDT01QQVQgV0lUSCAxLjAuMy4yXG5Nb25nb0ludGVybmFscy5OcG1Nb2R1bGUgPSBNb25nb0RCO1xuXG5jb25zdCBGSUxFX0FTU0VUX1NVRkZJWCA9ICdBc3NldCc7XG5jb25zdCBBU1NFVFNfRk9MREVSID0gJ2Fzc2V0cyc7XG5jb25zdCBBUFBfRk9MREVSID0gJ2FwcCc7XG5cbi8vIFRoaXMgaXMgdXNlZCB0byBhZGQgb3IgcmVtb3ZlIEVKU09OIGZyb20gdGhlIGJlZ2lubmluZyBvZiBldmVyeXRoaW5nIG5lc3RlZFxuLy8gaW5zaWRlIGFuIEVKU09OIGN1c3RvbSB0eXBlLiBJdCBzaG91bGQgb25seSBiZSBjYWxsZWQgb24gcHVyZSBKU09OIVxudmFyIHJlcGxhY2VOYW1lcyA9IGZ1bmN0aW9uIChmaWx0ZXIsIHRoaW5nKSB7XG4gIGlmICh0eXBlb2YgdGhpbmcgPT09IFwib2JqZWN0XCIgJiYgdGhpbmcgIT09IG51bGwpIHtcbiAgICBpZiAoXy5pc0FycmF5KHRoaW5nKSkge1xuICAgICAgcmV0dXJuIF8ubWFwKHRoaW5nLCBfLmJpbmQocmVwbGFjZU5hbWVzLCBudWxsLCBmaWx0ZXIpKTtcbiAgICB9XG4gICAgdmFyIHJldCA9IHt9O1xuICAgIF8uZWFjaCh0aGluZywgZnVuY3Rpb24gKHZhbHVlLCBrZXkpIHtcbiAgICAgIHJldFtmaWx0ZXIoa2V5KV0gPSByZXBsYWNlTmFtZXMoZmlsdGVyLCB2YWx1ZSk7XG4gICAgfSk7XG4gICAgcmV0dXJuIHJldDtcbiAgfVxuICByZXR1cm4gdGhpbmc7XG59O1xuXG4vLyBFbnN1cmUgdGhhdCBFSlNPTi5jbG9uZSBrZWVwcyBhIFRpbWVzdGFtcCBhcyBhIFRpbWVzdGFtcCAoaW5zdGVhZCBvZiBqdXN0XG4vLyBkb2luZyBhIHN0cnVjdHVyYWwgY2xvbmUpLlxuLy8gWFhYIGhvdyBvayBpcyB0aGlzPyB3aGF0IGlmIHRoZXJlIGFyZSBtdWx0aXBsZSBjb3BpZXMgb2YgTW9uZ29EQiBsb2FkZWQ/XG5Nb25nb0RCLlRpbWVzdGFtcC5wcm90b3R5cGUuY2xvbmUgPSBmdW5jdGlvbiAoKSB7XG4gIC8vIFRpbWVzdGFtcHMgc2hvdWxkIGJlIGltbXV0YWJsZS5cbiAgcmV0dXJuIHRoaXM7XG59O1xuXG52YXIgbWFrZU1vbmdvTGVnYWwgPSBmdW5jdGlvbiAobmFtZSkgeyByZXR1cm4gXCJFSlNPTlwiICsgbmFtZTsgfTtcbnZhciB1bm1ha2VNb25nb0xlZ2FsID0gZnVuY3Rpb24gKG5hbWUpIHsgcmV0dXJuIG5hbWUuc3Vic3RyKDUpOyB9O1xuXG52YXIgcmVwbGFjZU1vbmdvQXRvbVdpdGhNZXRlb3IgPSBmdW5jdGlvbiAoZG9jdW1lbnQpIHtcbiAgaWYgKGRvY3VtZW50IGluc3RhbmNlb2YgTW9uZ29EQi5CaW5hcnkpIHtcbiAgICAvLyBmb3IgYmFja3dhcmRzIGNvbXBhdGliaWxpdHlcbiAgICBpZiAoZG9jdW1lbnQuc3ViX3R5cGUgIT09IDApIHtcbiAgICAgIHJldHVybiBkb2N1bWVudDtcbiAgICB9XG4gICAgdmFyIGJ1ZmZlciA9IGRvY3VtZW50LnZhbHVlKHRydWUpO1xuICAgIHJldHVybiBuZXcgVWludDhBcnJheShidWZmZXIpO1xuICB9XG4gIGlmIChkb2N1bWVudCBpbnN0YW5jZW9mIE1vbmdvREIuT2JqZWN0SUQpIHtcbiAgICByZXR1cm4gbmV3IE1vbmdvLk9iamVjdElEKGRvY3VtZW50LnRvSGV4U3RyaW5nKCkpO1xuICB9XG4gIGlmIChkb2N1bWVudCBpbnN0YW5jZW9mIE1vbmdvREIuRGVjaW1hbDEyOCkge1xuICAgIHJldHVybiBEZWNpbWFsKGRvY3VtZW50LnRvU3RyaW5nKCkpO1xuICB9XG4gIGlmIChkb2N1bWVudFtcIkVKU09OJHR5cGVcIl0gJiYgZG9jdW1lbnRbXCJFSlNPTiR2YWx1ZVwiXSAmJiBfLnNpemUoZG9jdW1lbnQpID09PSAyKSB7XG4gICAgcmV0dXJuIEVKU09OLmZyb21KU09OVmFsdWUocmVwbGFjZU5hbWVzKHVubWFrZU1vbmdvTGVnYWwsIGRvY3VtZW50KSk7XG4gIH1cbiAgaWYgKGRvY3VtZW50IGluc3RhbmNlb2YgTW9uZ29EQi5UaW1lc3RhbXApIHtcbiAgICAvLyBGb3Igbm93LCB0aGUgTWV0ZW9yIHJlcHJlc2VudGF0aW9uIG9mIGEgTW9uZ28gdGltZXN0YW1wIHR5cGUgKG5vdCBhIGRhdGUhXG4gICAgLy8gdGhpcyBpcyBhIHdlaXJkIGludGVybmFsIHRoaW5nIHVzZWQgaW4gdGhlIG9wbG9nISkgaXMgdGhlIHNhbWUgYXMgdGhlXG4gICAgLy8gTW9uZ28gcmVwcmVzZW50YXRpb24uIFdlIG5lZWQgdG8gZG8gdGhpcyBleHBsaWNpdGx5IG9yIGVsc2Ugd2Ugd291bGQgZG8gYVxuICAgIC8vIHN0cnVjdHVyYWwgY2xvbmUgYW5kIGxvc2UgdGhlIHByb3RvdHlwZS5cbiAgICByZXR1cm4gZG9jdW1lbnQ7XG4gIH1cbiAgcmV0dXJuIHVuZGVmaW5lZDtcbn07XG5cbnZhciByZXBsYWNlTWV0ZW9yQXRvbVdpdGhNb25nbyA9IGZ1bmN0aW9uIChkb2N1bWVudCkge1xuICBpZiAoRUpTT04uaXNCaW5hcnkoZG9jdW1lbnQpKSB7XG4gICAgLy8gVGhpcyBkb2VzIG1vcmUgY29waWVzIHRoYW4gd2UnZCBsaWtlLCBidXQgaXMgbmVjZXNzYXJ5IGJlY2F1c2VcbiAgICAvLyBNb25nb0RCLkJTT04gb25seSBsb29rcyBsaWtlIGl0IHRha2VzIGEgVWludDhBcnJheSAoYW5kIGRvZXNuJ3QgYWN0dWFsbHlcbiAgICAvLyBzZXJpYWxpemUgaXQgY29ycmVjdGx5KS5cbiAgICByZXR1cm4gbmV3IE1vbmdvREIuQmluYXJ5KEJ1ZmZlci5mcm9tKGRvY3VtZW50KSk7XG4gIH1cbiAgaWYgKGRvY3VtZW50IGluc3RhbmNlb2YgTW9uZ29EQi5CaW5hcnkpIHtcbiAgICAgcmV0dXJuIGRvY3VtZW50O1xuICB9XG4gIGlmIChkb2N1bWVudCBpbnN0YW5jZW9mIE1vbmdvLk9iamVjdElEKSB7XG4gICAgcmV0dXJuIG5ldyBNb25nb0RCLk9iamVjdElEKGRvY3VtZW50LnRvSGV4U3RyaW5nKCkpO1xuICB9XG4gIGlmIChkb2N1bWVudCBpbnN0YW5jZW9mIE1vbmdvREIuVGltZXN0YW1wKSB7XG4gICAgLy8gRm9yIG5vdywgdGhlIE1ldGVvciByZXByZXNlbnRhdGlvbiBvZiBhIE1vbmdvIHRpbWVzdGFtcCB0eXBlIChub3QgYSBkYXRlIVxuICAgIC8vIHRoaXMgaXMgYSB3ZWlyZCBpbnRlcm5hbCB0aGluZyB1c2VkIGluIHRoZSBvcGxvZyEpIGlzIHRoZSBzYW1lIGFzIHRoZVxuICAgIC8vIE1vbmdvIHJlcHJlc2VudGF0aW9uLiBXZSBuZWVkIHRvIGRvIHRoaXMgZXhwbGljaXRseSBvciBlbHNlIHdlIHdvdWxkIGRvIGFcbiAgICAvLyBzdHJ1Y3R1cmFsIGNsb25lIGFuZCBsb3NlIHRoZSBwcm90b3R5cGUuXG4gICAgcmV0dXJuIGRvY3VtZW50O1xuICB9XG4gIGlmIChkb2N1bWVudCBpbnN0YW5jZW9mIERlY2ltYWwpIHtcbiAgICByZXR1cm4gTW9uZ29EQi5EZWNpbWFsMTI4LmZyb21TdHJpbmcoZG9jdW1lbnQudG9TdHJpbmcoKSk7XG4gIH1cbiAgaWYgKEVKU09OLl9pc0N1c3RvbVR5cGUoZG9jdW1lbnQpKSB7XG4gICAgcmV0dXJuIHJlcGxhY2VOYW1lcyhtYWtlTW9uZ29MZWdhbCwgRUpTT04udG9KU09OVmFsdWUoZG9jdW1lbnQpKTtcbiAgfVxuICAvLyBJdCBpcyBub3Qgb3JkaW5hcmlseSBwb3NzaWJsZSB0byBzdGljayBkb2xsYXItc2lnbiBrZXlzIGludG8gbW9uZ29cbiAgLy8gc28gd2UgZG9uJ3QgYm90aGVyIGNoZWNraW5nIGZvciB0aGluZ3MgdGhhdCBuZWVkIGVzY2FwaW5nIGF0IHRoaXMgdGltZS5cbiAgcmV0dXJuIHVuZGVmaW5lZDtcbn07XG5cbnZhciByZXBsYWNlVHlwZXMgPSBmdW5jdGlvbiAoZG9jdW1lbnQsIGF0b21UcmFuc2Zvcm1lcikge1xuICBpZiAodHlwZW9mIGRvY3VtZW50ICE9PSAnb2JqZWN0JyB8fCBkb2N1bWVudCA9PT0gbnVsbClcbiAgICByZXR1cm4gZG9jdW1lbnQ7XG5cbiAgdmFyIHJlcGxhY2VkVG9wTGV2ZWxBdG9tID0gYXRvbVRyYW5zZm9ybWVyKGRvY3VtZW50KTtcbiAgaWYgKHJlcGxhY2VkVG9wTGV2ZWxBdG9tICE9PSB1bmRlZmluZWQpXG4gICAgcmV0dXJuIHJlcGxhY2VkVG9wTGV2ZWxBdG9tO1xuXG4gIHZhciByZXQgPSBkb2N1bWVudDtcbiAgXy5lYWNoKGRvY3VtZW50LCBmdW5jdGlvbiAodmFsLCBrZXkpIHtcbiAgICB2YXIgdmFsUmVwbGFjZWQgPSByZXBsYWNlVHlwZXModmFsLCBhdG9tVHJhbnNmb3JtZXIpO1xuICAgIGlmICh2YWwgIT09IHZhbFJlcGxhY2VkKSB7XG4gICAgICAvLyBMYXp5IGNsb25lLiBTaGFsbG93IGNvcHkuXG4gICAgICBpZiAocmV0ID09PSBkb2N1bWVudClcbiAgICAgICAgcmV0ID0gXy5jbG9uZShkb2N1bWVudCk7XG4gICAgICByZXRba2V5XSA9IHZhbFJlcGxhY2VkO1xuICAgIH1cbiAgfSk7XG4gIHJldHVybiByZXQ7XG59O1xuXG5cbk1vbmdvQ29ubmVjdGlvbiA9IGZ1bmN0aW9uICh1cmwsIG9wdGlvbnMpIHtcbiAgdmFyIHNlbGYgPSB0aGlzO1xuICBvcHRpb25zID0gb3B0aW9ucyB8fCB7fTtcbiAgc2VsZi5fb2JzZXJ2ZU11bHRpcGxleGVycyA9IHt9O1xuICBzZWxmLl9vbkZhaWxvdmVySG9vayA9IG5ldyBIb29rO1xuXG4gIGNvbnN0IHVzZXJPcHRpb25zID0ge1xuICAgIC4uLihNb25nby5fY29ubmVjdGlvbk9wdGlvbnMgfHwge30pLFxuICAgIC4uLihNZXRlb3Iuc2V0dGluZ3M/LnBhY2thZ2VzPy5tb25nbz8ub3B0aW9ucyB8fCB7fSlcbiAgfTtcblxuICB2YXIgbW9uZ29PcHRpb25zID0gT2JqZWN0LmFzc2lnbih7XG4gICAgaWdub3JlVW5kZWZpbmVkOiB0cnVlLFxuICB9LCB1c2VyT3B0aW9ucyk7XG5cblxuXG4gIC8vIEludGVybmFsbHkgdGhlIG9wbG9nIGNvbm5lY3Rpb25zIHNwZWNpZnkgdGhlaXIgb3duIG1heFBvb2xTaXplXG4gIC8vIHdoaWNoIHdlIGRvbid0IHdhbnQgdG8gb3ZlcndyaXRlIHdpdGggYW55IHVzZXIgZGVmaW5lZCB2YWx1ZVxuICBpZiAoXy5oYXMob3B0aW9ucywgJ21heFBvb2xTaXplJykpIHtcbiAgICAvLyBJZiB3ZSBqdXN0IHNldCB0aGlzIGZvciBcInNlcnZlclwiLCByZXBsU2V0IHdpbGwgb3ZlcnJpZGUgaXQuIElmIHdlIGp1c3RcbiAgICAvLyBzZXQgaXQgZm9yIHJlcGxTZXQsIGl0IHdpbGwgYmUgaWdub3JlZCBpZiB3ZSdyZSBub3QgdXNpbmcgYSByZXBsU2V0LlxuICAgIG1vbmdvT3B0aW9ucy5tYXhQb29sU2l6ZSA9IG9wdGlvbnMubWF4UG9vbFNpemU7XG4gIH1cbiAgaWYgKF8uaGFzKG9wdGlvbnMsICdtaW5Qb29sU2l6ZScpKSB7XG4gICAgbW9uZ29PcHRpb25zLm1pblBvb2xTaXplID0gb3B0aW9ucy5taW5Qb29sU2l6ZTtcbiAgfVxuXG4gIC8vIFRyYW5zZm9ybSBvcHRpb25zIGxpa2UgXCJ0bHNDQUZpbGVBc3NldFwiOiBcImZpbGVuYW1lLnBlbVwiIGludG9cbiAgLy8gXCJ0bHNDQUZpbGVcIjogXCIvPGZ1bGxwYXRoPi9maWxlbmFtZS5wZW1cIlxuICBPYmplY3QuZW50cmllcyhtb25nb09wdGlvbnMgfHwge30pXG4gICAgLmZpbHRlcigoW2tleV0pID0+IGtleSAmJiBrZXkuZW5kc1dpdGgoRklMRV9BU1NFVF9TVUZGSVgpKVxuICAgIC5mb3JFYWNoKChba2V5LCB2YWx1ZV0pID0+IHtcbiAgICAgIGNvbnN0IG9wdGlvbk5hbWUgPSBrZXkucmVwbGFjZShGSUxFX0FTU0VUX1NVRkZJWCwgJycpO1xuICAgICAgbW9uZ29PcHRpb25zW29wdGlvbk5hbWVdID0gcGF0aC5qb2luKEFzc2V0cy5nZXRTZXJ2ZXJEaXIoKSxcbiAgICAgICAgQVNTRVRTX0ZPTERFUiwgQVBQX0ZPTERFUiwgdmFsdWUpO1xuICAgICAgZGVsZXRlIG1vbmdvT3B0aW9uc1trZXldO1xuICAgIH0pO1xuXG4gIHNlbGYuZGIgPSBudWxsO1xuICBzZWxmLl9vcGxvZ0hhbmRsZSA9IG51bGw7XG4gIHNlbGYuX2RvY0ZldGNoZXIgPSBudWxsO1xuXG4gIHNlbGYuY2xpZW50ID0gbmV3IE1vbmdvREIuTW9uZ29DbGllbnQodXJsLCBtb25nb09wdGlvbnMpO1xuICBzZWxmLmRiID0gc2VsZi5jbGllbnQuZGIoKTtcblxuICBzZWxmLmNsaWVudC5vbignc2VydmVyRGVzY3JpcHRpb25DaGFuZ2VkJywgTWV0ZW9yLmJpbmRFbnZpcm9ubWVudChldmVudCA9PiB7XG4gICAgLy8gV2hlbiB0aGUgY29ubmVjdGlvbiBpcyBubyBsb25nZXIgYWdhaW5zdCB0aGUgcHJpbWFyeSBub2RlLCBleGVjdXRlIGFsbFxuICAgIC8vIGZhaWxvdmVyIGhvb2tzLiBUaGlzIGlzIGltcG9ydGFudCBmb3IgdGhlIGRyaXZlciBhcyBpdCBoYXMgdG8gcmUtcG9vbCB0aGVcbiAgICAvLyBxdWVyeSB3aGVuIGl0IGhhcHBlbnMuXG4gICAgaWYgKFxuICAgICAgZXZlbnQucHJldmlvdXNEZXNjcmlwdGlvbi50eXBlICE9PSAnUlNQcmltYXJ5JyAmJlxuICAgICAgZXZlbnQubmV3RGVzY3JpcHRpb24udHlwZSA9PT0gJ1JTUHJpbWFyeSdcbiAgICApIHtcbiAgICAgIHNlbGYuX29uRmFpbG92ZXJIb29rLmVhY2goY2FsbGJhY2sgPT4ge1xuICAgICAgICBjYWxsYmFjaygpO1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH0pO1xuICAgIH1cbiAgfSkpO1xuXG4gIGlmIChvcHRpb25zLm9wbG9nVXJsICYmICEgUGFja2FnZVsnZGlzYWJsZS1vcGxvZyddKSB7XG4gICAgc2VsZi5fb3Bsb2dIYW5kbGUgPSBuZXcgT3Bsb2dIYW5kbGUob3B0aW9ucy5vcGxvZ1VybCwgc2VsZi5kYi5kYXRhYmFzZU5hbWUpO1xuICAgIHNlbGYuX2RvY0ZldGNoZXIgPSBuZXcgRG9jRmV0Y2hlcihzZWxmKTtcbiAgfVxuXG59O1xuXG5Nb25nb0Nvbm5lY3Rpb24ucHJvdG90eXBlLl9jbG9zZSA9IGFzeW5jIGZ1bmN0aW9uKCkge1xuICB2YXIgc2VsZiA9IHRoaXM7XG5cbiAgaWYgKCEgc2VsZi5kYilcbiAgICB0aHJvdyBFcnJvcihcImNsb3NlIGNhbGxlZCBiZWZvcmUgQ29ubmVjdGlvbiBjcmVhdGVkP1wiKTtcblxuICAvLyBYWFggcHJvYmFibHkgdW50ZXN0ZWRcbiAgdmFyIG9wbG9nSGFuZGxlID0gc2VsZi5fb3Bsb2dIYW5kbGU7XG4gIHNlbGYuX29wbG9nSGFuZGxlID0gbnVsbDtcbiAgaWYgKG9wbG9nSGFuZGxlKVxuICAgIGF3YWl0IG9wbG9nSGFuZGxlLnN0b3AoKTtcblxuICAvLyBVc2UgRnV0dXJlLndyYXAgc28gdGhhdCBlcnJvcnMgZ2V0IHRocm93bi4gVGhpcyBoYXBwZW5zIHRvXG4gIC8vIHdvcmsgZXZlbiBvdXRzaWRlIGEgZmliZXIgc2luY2UgdGhlICdjbG9zZScgbWV0aG9kIGlzIG5vdFxuICAvLyBhY3R1YWxseSBhc3luY2hyb25vdXMuXG4gIGF3YWl0IHNlbGYuY2xpZW50LmNsb3NlKCk7XG59O1xuXG5Nb25nb0Nvbm5lY3Rpb24ucHJvdG90eXBlLmNsb3NlID0gZnVuY3Rpb24gKCkge1xuICByZXR1cm4gdGhpcy5fY2xvc2UoKTtcbn07XG5cbk1vbmdvQ29ubmVjdGlvbi5wcm90b3R5cGUuX3NldE9wbG9nSGFuZGxlID0gZnVuY3Rpb24ob3Bsb2dIYW5kbGUpIHtcbiAgdGhpcy5fb3Bsb2dIYW5kbGUgPSBvcGxvZ0hhbmRsZTtcbiAgcmV0dXJuIHRoaXM7XG59O1xuXG4vLyBSZXR1cm5zIHRoZSBNb25nbyBDb2xsZWN0aW9uIG9iamVjdDsgbWF5IHlpZWxkLlxuTW9uZ29Db25uZWN0aW9uLnByb3RvdHlwZS5yYXdDb2xsZWN0aW9uID0gZnVuY3Rpb24gKGNvbGxlY3Rpb25OYW1lKSB7XG4gIHZhciBzZWxmID0gdGhpcztcblxuICBpZiAoISBzZWxmLmRiKVxuICAgIHRocm93IEVycm9yKFwicmF3Q29sbGVjdGlvbiBjYWxsZWQgYmVmb3JlIENvbm5lY3Rpb24gY3JlYXRlZD9cIik7XG5cbiAgcmV0dXJuIHNlbGYuZGIuY29sbGVjdGlvbihjb2xsZWN0aW9uTmFtZSk7XG59O1xuXG5Nb25nb0Nvbm5lY3Rpb24ucHJvdG90eXBlLmNyZWF0ZUNhcHBlZENvbGxlY3Rpb25Bc3luYyA9IGFzeW5jIGZ1bmN0aW9uIChcbiAgICBjb2xsZWN0aW9uTmFtZSwgYnl0ZVNpemUsIG1heERvY3VtZW50cykge1xuICB2YXIgc2VsZiA9IHRoaXM7XG5cbiAgaWYgKCEgc2VsZi5kYilcbiAgICB0aHJvdyBFcnJvcihcImNyZWF0ZUNhcHBlZENvbGxlY3Rpb25Bc3luYyBjYWxsZWQgYmVmb3JlIENvbm5lY3Rpb24gY3JlYXRlZD9cIik7XG5cblxuICBhd2FpdCBzZWxmLmRiLmNyZWF0ZUNvbGxlY3Rpb24oY29sbGVjdGlvbk5hbWUsXG4gICAgeyBjYXBwZWQ6IHRydWUsIHNpemU6IGJ5dGVTaXplLCBtYXg6IG1heERvY3VtZW50cyB9KTtcbn07XG5cbi8vIFRoaXMgc2hvdWxkIGJlIGNhbGxlZCBzeW5jaHJvbm91c2x5IHdpdGggYSB3cml0ZSwgdG8gY3JlYXRlIGFcbi8vIHRyYW5zYWN0aW9uIG9uIHRoZSBjdXJyZW50IHdyaXRlIGZlbmNlLCBpZiBhbnkuIEFmdGVyIHdlIGNhbiByZWFkXG4vLyB0aGUgd3JpdGUsIGFuZCBhZnRlciBvYnNlcnZlcnMgaGF2ZSBiZWVuIG5vdGlmaWVkIChvciBhdCBsZWFzdCxcbi8vIGFmdGVyIHRoZSBvYnNlcnZlciBub3RpZmllcnMgaGF2ZSBhZGRlZCB0aGVtc2VsdmVzIHRvIHRoZSB3cml0ZVxuLy8gZmVuY2UpLCB5b3Ugc2hvdWxkIGNhbGwgJ2NvbW1pdHRlZCgpJyBvbiB0aGUgb2JqZWN0IHJldHVybmVkLlxuTW9uZ29Db25uZWN0aW9uLnByb3RvdHlwZS5fbWF5YmVCZWdpbldyaXRlID0gZnVuY3Rpb24gKCkge1xuICBjb25zdCBmZW5jZSA9IEREUFNlcnZlci5fZ2V0Q3VycmVudEZlbmNlKCk7XG4gIGlmIChmZW5jZSkge1xuICAgIHJldHVybiBmZW5jZS5iZWdpbldyaXRlKCk7XG4gIH0gZWxzZSB7XG4gICAgcmV0dXJuIHtjb21taXR0ZWQ6IGZ1bmN0aW9uICgpIHt9fTtcbiAgfVxufTtcblxuLy8gSW50ZXJuYWwgaW50ZXJmYWNlOiBhZGRzIGEgY2FsbGJhY2sgd2hpY2ggaXMgY2FsbGVkIHdoZW4gdGhlIE1vbmdvIHByaW1hcnlcbi8vIGNoYW5nZXMuIFJldHVybnMgYSBzdG9wIGhhbmRsZS5cbk1vbmdvQ29ubmVjdGlvbi5wcm90b3R5cGUuX29uRmFpbG92ZXIgPSBmdW5jdGlvbiAoY2FsbGJhY2spIHtcbiAgcmV0dXJuIHRoaXMuX29uRmFpbG92ZXJIb29rLnJlZ2lzdGVyKGNhbGxiYWNrKTtcbn07XG5cblxuLy8vLy8vLy8vLy8vIFB1YmxpYyBBUEkgLy8vLy8vLy8vL1xuXG4vLyBUaGUgd3JpdGUgbWV0aG9kcyBibG9jayB1bnRpbCB0aGUgZGF0YWJhc2UgaGFzIGNvbmZpcm1lZCB0aGUgd3JpdGUgKGl0IG1heVxuLy8gbm90IGJlIHJlcGxpY2F0ZWQgb3Igc3RhYmxlIG9uIGRpc2ssIGJ1dCBvbmUgc2VydmVyIGhhcyBjb25maXJtZWQgaXQpIGlmIG5vXG4vLyBjYWxsYmFjayBpcyBwcm92aWRlZC4gSWYgYSBjYWxsYmFjayBpcyBwcm92aWRlZCwgdGhlbiB0aGV5IGNhbGwgdGhlIGNhbGxiYWNrXG4vLyB3aGVuIHRoZSB3cml0ZSBpcyBjb25maXJtZWQuIFRoZXkgcmV0dXJuIG5vdGhpbmcgb24gc3VjY2VzcywgYW5kIHJhaXNlIGFuXG4vLyBleGNlcHRpb24gb24gZmFpbHVyZS5cbi8vXG4vLyBBZnRlciBtYWtpbmcgYSB3cml0ZSAod2l0aCBpbnNlcnQsIHVwZGF0ZSwgcmVtb3ZlKSwgb2JzZXJ2ZXJzIGFyZVxuLy8gbm90aWZpZWQgYXN5bmNocm9ub3VzbHkuIElmIHlvdSB3YW50IHRvIHJlY2VpdmUgYSBjYWxsYmFjayBvbmNlIGFsbFxuLy8gb2YgdGhlIG9ic2VydmVyIG5vdGlmaWNhdGlvbnMgaGF2ZSBsYW5kZWQgZm9yIHlvdXIgd3JpdGUsIGRvIHRoZVxuLy8gd3JpdGVzIGluc2lkZSBhIHdyaXRlIGZlbmNlIChzZXQgRERQU2VydmVyLl9DdXJyZW50V3JpdGVGZW5jZSB0byBhIG5ld1xuLy8gX1dyaXRlRmVuY2UsIGFuZCB0aGVuIHNldCBhIGNhbGxiYWNrIG9uIHRoZSB3cml0ZSBmZW5jZS4pXG4vL1xuLy8gU2luY2Ugb3VyIGV4ZWN1dGlvbiBlbnZpcm9ubWVudCBpcyBzaW5nbGUtdGhyZWFkZWQsIHRoaXMgaXNcbi8vIHdlbGwtZGVmaW5lZCAtLSBhIHdyaXRlIFwiaGFzIGJlZW4gbWFkZVwiIGlmIGl0J3MgcmV0dXJuZWQsIGFuZCBhblxuLy8gb2JzZXJ2ZXIgXCJoYXMgYmVlbiBub3RpZmllZFwiIGlmIGl0cyBjYWxsYmFjayBoYXMgcmV0dXJuZWQuXG5cbnZhciB3cml0ZUNhbGxiYWNrID0gZnVuY3Rpb24gKHdyaXRlLCByZWZyZXNoLCBjYWxsYmFjaykge1xuICByZXR1cm4gZnVuY3Rpb24gKGVyciwgcmVzdWx0KSB7XG4gICAgaWYgKCEgZXJyKSB7XG4gICAgICAvLyBYWFggV2UgZG9uJ3QgaGF2ZSB0byBydW4gdGhpcyBvbiBlcnJvciwgcmlnaHQ/XG4gICAgICB0cnkge1xuICAgICAgICByZWZyZXNoKCk7XG4gICAgICB9IGNhdGNoIChyZWZyZXNoRXJyKSB7XG4gICAgICAgIGlmIChjYWxsYmFjaykge1xuICAgICAgICAgIGNhbGxiYWNrKHJlZnJlc2hFcnIpO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB0aHJvdyByZWZyZXNoRXJyO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIHdyaXRlLmNvbW1pdHRlZCgpO1xuICAgIGlmIChjYWxsYmFjaykge1xuICAgICAgY2FsbGJhY2soZXJyLCByZXN1bHQpO1xuICAgIH0gZWxzZSBpZiAoZXJyKSB7XG4gICAgICB0aHJvdyBlcnI7XG4gICAgfVxuICB9O1xufTtcblxudmFyIGJpbmRFbnZpcm9ubWVudEZvcldyaXRlID0gZnVuY3Rpb24gKGNhbGxiYWNrKSB7XG4gIHJldHVybiBNZXRlb3IuYmluZEVudmlyb25tZW50KGNhbGxiYWNrLCBcIk1vbmdvIHdyaXRlXCIpO1xufTtcblxuTW9uZ29Db25uZWN0aW9uLnByb3RvdHlwZS5pbnNlcnRBc3luYyA9IGFzeW5jIGZ1bmN0aW9uIChjb2xsZWN0aW9uX25hbWUsIGRvY3VtZW50KSB7XG4gIGNvbnN0IHNlbGYgPSB0aGlzO1xuXG4gIGlmIChjb2xsZWN0aW9uX25hbWUgPT09IFwiX19fbWV0ZW9yX2ZhaWx1cmVfdGVzdF9jb2xsZWN0aW9uXCIpIHtcbiAgICBjb25zdCBlID0gbmV3IEVycm9yKFwiRmFpbHVyZSB0ZXN0XCIpO1xuICAgIGUuX2V4cGVjdGVkQnlUZXN0ID0gdHJ1ZTtcbiAgICB0aHJvdyBlO1xuICB9XG5cbiAgaWYgKCEoTG9jYWxDb2xsZWN0aW9uLl9pc1BsYWluT2JqZWN0KGRvY3VtZW50KSAmJlxuICAgICAgICAhRUpTT04uX2lzQ3VzdG9tVHlwZShkb2N1bWVudCkpKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiT25seSBwbGFpbiBvYmplY3RzIG1heSBiZSBpbnNlcnRlZCBpbnRvIE1vbmdvREJcIik7XG4gIH1cblxuICB2YXIgd3JpdGUgPSBzZWxmLl9tYXliZUJlZ2luV3JpdGUoKTtcbiAgdmFyIHJlZnJlc2ggPSBhc3luYyBmdW5jdGlvbiAoKSB7XG4gICAgYXdhaXQgTWV0ZW9yLnJlZnJlc2goe2NvbGxlY3Rpb246IGNvbGxlY3Rpb25fbmFtZSwgaWQ6IGRvY3VtZW50Ll9pZCB9KTtcbiAgfTtcbiAgcmV0dXJuIHNlbGYucmF3Q29sbGVjdGlvbihjb2xsZWN0aW9uX25hbWUpLmluc2VydE9uZShcbiAgICByZXBsYWNlVHlwZXMoZG9jdW1lbnQsIHJlcGxhY2VNZXRlb3JBdG9tV2l0aE1vbmdvKSxcbiAgICB7XG4gICAgICBzYWZlOiB0cnVlLFxuICAgIH1cbiAgKS50aGVuKGFzeW5jICh7aW5zZXJ0ZWRJZH0pID0+IHtcbiAgICBhd2FpdCByZWZyZXNoKCk7XG4gICAgYXdhaXQgd3JpdGUuY29tbWl0dGVkKCk7XG4gICAgcmV0dXJuIGluc2VydGVkSWQ7XG4gIH0pLmNhdGNoKGFzeW5jIGUgPT4ge1xuICAgIGF3YWl0IHdyaXRlLmNvbW1pdHRlZCgpO1xuICAgIHRocm93IGU7XG4gIH0pO1xufTtcblxuXG4vLyBDYXVzZSBxdWVyaWVzIHRoYXQgbWF5IGJlIGFmZmVjdGVkIGJ5IHRoZSBzZWxlY3RvciB0byBwb2xsIGluIHRoaXMgd3JpdGVcbi8vIGZlbmNlLlxuTW9uZ29Db25uZWN0aW9uLnByb3RvdHlwZS5fcmVmcmVzaCA9IGFzeW5jIGZ1bmN0aW9uIChjb2xsZWN0aW9uTmFtZSwgc2VsZWN0b3IpIHtcbiAgdmFyIHJlZnJlc2hLZXkgPSB7Y29sbGVjdGlvbjogY29sbGVjdGlvbk5hbWV9O1xuICAvLyBJZiB3ZSBrbm93IHdoaWNoIGRvY3VtZW50cyB3ZSdyZSByZW1vdmluZywgZG9uJ3QgcG9sbCBxdWVyaWVzIHRoYXQgYXJlXG4gIC8vIHNwZWNpZmljIHRvIG90aGVyIGRvY3VtZW50cy4gKE5vdGUgdGhhdCBtdWx0aXBsZSBub3RpZmljYXRpb25zIGhlcmUgc2hvdWxkXG4gIC8vIG5vdCBjYXVzZSBtdWx0aXBsZSBwb2xscywgc2luY2UgYWxsIG91ciBsaXN0ZW5lciBpcyBkb2luZyBpcyBlbnF1ZXVlaW5nIGFcbiAgLy8gcG9sbC4pXG4gIHZhciBzcGVjaWZpY0lkcyA9IExvY2FsQ29sbGVjdGlvbi5faWRzTWF0Y2hlZEJ5U2VsZWN0b3Ioc2VsZWN0b3IpO1xuICBpZiAoc3BlY2lmaWNJZHMpIHtcbiAgICBmb3IgKGNvbnN0IGlkIG9mIHNwZWNpZmljSWRzKSB7XG4gICAgICBhd2FpdCBNZXRlb3IucmVmcmVzaChfLmV4dGVuZCh7aWQ6IGlkfSwgcmVmcmVzaEtleSkpO1xuICAgIH1cbiAgfSBlbHNlIHtcbiAgICBhd2FpdCBNZXRlb3IucmVmcmVzaChyZWZyZXNoS2V5KTtcbiAgfVxufTtcblxuTW9uZ29Db25uZWN0aW9uLnByb3RvdHlwZS5yZW1vdmVBc3luYyA9IGFzeW5jIGZ1bmN0aW9uIChjb2xsZWN0aW9uX25hbWUsIHNlbGVjdG9yKSB7XG4gIHZhciBzZWxmID0gdGhpcztcblxuICBpZiAoY29sbGVjdGlvbl9uYW1lID09PSBcIl9fX21ldGVvcl9mYWlsdXJlX3Rlc3RfY29sbGVjdGlvblwiKSB7XG4gICAgdmFyIGUgPSBuZXcgRXJyb3IoXCJGYWlsdXJlIHRlc3RcIik7XG4gICAgZS5fZXhwZWN0ZWRCeVRlc3QgPSB0cnVlO1xuICAgIHRocm93IGU7XG4gIH1cblxuICB2YXIgd3JpdGUgPSBzZWxmLl9tYXliZUJlZ2luV3JpdGUoKTtcbiAgdmFyIHJlZnJlc2ggPSBhc3luYyBmdW5jdGlvbiAoKSB7XG4gICAgYXdhaXQgc2VsZi5fcmVmcmVzaChjb2xsZWN0aW9uX25hbWUsIHNlbGVjdG9yKTtcbiAgfTtcblxuICByZXR1cm4gc2VsZi5yYXdDb2xsZWN0aW9uKGNvbGxlY3Rpb25fbmFtZSlcbiAgICAuZGVsZXRlTWFueShyZXBsYWNlVHlwZXMoc2VsZWN0b3IsIHJlcGxhY2VNZXRlb3JBdG9tV2l0aE1vbmdvKSwge1xuICAgICAgc2FmZTogdHJ1ZSxcbiAgICB9KVxuICAgIC50aGVuKGFzeW5jICh7IGRlbGV0ZWRDb3VudCB9KSA9PiB7XG4gICAgICBhd2FpdCByZWZyZXNoKCk7XG4gICAgICBhd2FpdCB3cml0ZS5jb21taXR0ZWQoKTtcbiAgICAgIHJldHVybiB0cmFuc2Zvcm1SZXN1bHQoeyByZXN1bHQgOiB7bW9kaWZpZWRDb3VudCA6IGRlbGV0ZWRDb3VudH0gfSkubnVtYmVyQWZmZWN0ZWQ7XG4gICAgfSkuY2F0Y2goYXN5bmMgKGVycikgPT4ge1xuICAgICAgICBhd2FpdCB3cml0ZS5jb21taXR0ZWQoKTtcbiAgICAgICAgdGhyb3cgZXJyO1xuICAgIH0pO1xufTtcblxuTW9uZ29Db25uZWN0aW9uLnByb3RvdHlwZS5kcm9wQ29sbGVjdGlvbkFzeW5jID0gYXN5bmMgZnVuY3Rpb24oY29sbGVjdGlvbk5hbWUpIHtcbiAgdmFyIHNlbGYgPSB0aGlzO1xuXG5cbiAgdmFyIHdyaXRlID0gc2VsZi5fbWF5YmVCZWdpbldyaXRlKCk7XG4gIHZhciByZWZyZXNoID0gZnVuY3Rpb24oKSB7XG4gICAgcmV0dXJuIE1ldGVvci5yZWZyZXNoKHtcbiAgICAgIGNvbGxlY3Rpb246IGNvbGxlY3Rpb25OYW1lLFxuICAgICAgaWQ6IG51bGwsXG4gICAgICBkcm9wQ29sbGVjdGlvbjogdHJ1ZSxcbiAgICB9KTtcbiAgfTtcblxuICByZXR1cm4gc2VsZlxuICAgIC5yYXdDb2xsZWN0aW9uKGNvbGxlY3Rpb25OYW1lKVxuICAgIC5kcm9wKClcbiAgICAudGhlbihhc3luYyByZXN1bHQgPT4ge1xuICAgICAgYXdhaXQgcmVmcmVzaCgpO1xuICAgICAgYXdhaXQgd3JpdGUuY29tbWl0dGVkKCk7XG4gICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH0pXG4gICAgLmNhdGNoKGFzeW5jIGUgPT4ge1xuICAgICAgYXdhaXQgd3JpdGUuY29tbWl0dGVkKCk7XG4gICAgICB0aHJvdyBlO1xuICAgIH0pO1xufTtcblxuLy8gRm9yIHRlc3Rpbmcgb25seS4gIFNsaWdodGx5IGJldHRlciB0aGFuIGBjLnJhd0RhdGFiYXNlKCkuZHJvcERhdGFiYXNlKClgXG4vLyBiZWNhdXNlIGl0IGxldHMgdGhlIHRlc3QncyBmZW5jZSB3YWl0IGZvciBpdCB0byBiZSBjb21wbGV0ZS5cbk1vbmdvQ29ubmVjdGlvbi5wcm90b3R5cGUuZHJvcERhdGFiYXNlQXN5bmMgPSBhc3luYyBmdW5jdGlvbiAoKSB7XG4gIHZhciBzZWxmID0gdGhpcztcblxuICB2YXIgd3JpdGUgPSBzZWxmLl9tYXliZUJlZ2luV3JpdGUoKTtcbiAgdmFyIHJlZnJlc2ggPSBhc3luYyBmdW5jdGlvbiAoKSB7XG4gICAgYXdhaXQgTWV0ZW9yLnJlZnJlc2goeyBkcm9wRGF0YWJhc2U6IHRydWUgfSk7XG4gIH07XG5cbiAgdHJ5IHtcbiAgICBhd2FpdCBzZWxmLmRiLl9kcm9wRGF0YWJhc2UoKTtcbiAgICBhd2FpdCByZWZyZXNoKCk7XG4gICAgYXdhaXQgd3JpdGUuY29tbWl0dGVkKCk7XG4gIH0gY2F0Y2ggKGUpIHtcbiAgICBhd2FpdCB3cml0ZS5jb21taXR0ZWQoKTtcbiAgICB0aHJvdyBlO1xuICB9XG59O1xuXG5Nb25nb0Nvbm5lY3Rpb24ucHJvdG90eXBlLnVwZGF0ZUFzeW5jID0gYXN5bmMgZnVuY3Rpb24gKGNvbGxlY3Rpb25fbmFtZSwgc2VsZWN0b3IsIG1vZCwgb3B0aW9ucykge1xuICB2YXIgc2VsZiA9IHRoaXM7XG5cbiAgaWYgKGNvbGxlY3Rpb25fbmFtZSA9PT0gXCJfX19tZXRlb3JfZmFpbHVyZV90ZXN0X2NvbGxlY3Rpb25cIikge1xuICAgIHZhciBlID0gbmV3IEVycm9yKFwiRmFpbHVyZSB0ZXN0XCIpO1xuICAgIGUuX2V4cGVjdGVkQnlUZXN0ID0gdHJ1ZTtcbiAgICB0aHJvdyBlO1xuICB9XG5cbiAgLy8gZXhwbGljaXQgc2FmZXR5IGNoZWNrLiBudWxsIGFuZCB1bmRlZmluZWQgY2FuIGNyYXNoIHRoZSBtb25nb1xuICAvLyBkcml2ZXIuIEFsdGhvdWdoIHRoZSBub2RlIGRyaXZlciBhbmQgbWluaW1vbmdvIGRvICdzdXBwb3J0J1xuICAvLyBub24tb2JqZWN0IG1vZGlmaWVyIGluIHRoYXQgdGhleSBkb24ndCBjcmFzaCwgdGhleSBhcmUgbm90XG4gIC8vIG1lYW5pbmdmdWwgb3BlcmF0aW9ucyBhbmQgZG8gbm90IGRvIGFueXRoaW5nLiBEZWZlbnNpdmVseSB0aHJvdyBhblxuICAvLyBlcnJvciBoZXJlLlxuICBpZiAoIW1vZCB8fCB0eXBlb2YgbW9kICE9PSAnb2JqZWN0Jykge1xuICAgIGNvbnN0IGVycm9yID0gbmV3IEVycm9yKFwiSW52YWxpZCBtb2RpZmllci4gTW9kaWZpZXIgbXVzdCBiZSBhbiBvYmplY3QuXCIpO1xuXG4gICAgdGhyb3cgZXJyb3I7XG4gIH1cblxuICBpZiAoIShMb2NhbENvbGxlY3Rpb24uX2lzUGxhaW5PYmplY3QobW9kKSAmJiAhRUpTT04uX2lzQ3VzdG9tVHlwZShtb2QpKSkge1xuICAgIGNvbnN0IGVycm9yID0gbmV3IEVycm9yKFxuICAgICAgICBcIk9ubHkgcGxhaW4gb2JqZWN0cyBtYXkgYmUgdXNlZCBhcyByZXBsYWNlbWVudFwiICtcbiAgICAgICAgXCIgZG9jdW1lbnRzIGluIE1vbmdvREJcIik7XG5cbiAgICB0aHJvdyBlcnJvcjtcbiAgfVxuXG4gIGlmICghb3B0aW9ucykgb3B0aW9ucyA9IHt9O1xuXG4gIHZhciB3cml0ZSA9IHNlbGYuX21heWJlQmVnaW5Xcml0ZSgpO1xuICB2YXIgcmVmcmVzaCA9IGFzeW5jIGZ1bmN0aW9uICgpIHtcbiAgICBhd2FpdCBzZWxmLl9yZWZyZXNoKGNvbGxlY3Rpb25fbmFtZSwgc2VsZWN0b3IpO1xuICB9O1xuXG4gIHZhciBjb2xsZWN0aW9uID0gc2VsZi5yYXdDb2xsZWN0aW9uKGNvbGxlY3Rpb25fbmFtZSk7XG4gIHZhciBtb25nb09wdHMgPSB7c2FmZTogdHJ1ZX07XG4gIC8vIEFkZCBzdXBwb3J0IGZvciBmaWx0ZXJlZCBwb3NpdGlvbmFsIG9wZXJhdG9yXG4gIGlmIChvcHRpb25zLmFycmF5RmlsdGVycyAhPT0gdW5kZWZpbmVkKSBtb25nb09wdHMuYXJyYXlGaWx0ZXJzID0gb3B0aW9ucy5hcnJheUZpbHRlcnM7XG4gIC8vIGV4cGxpY3RseSBlbnVtZXJhdGUgb3B0aW9ucyB0aGF0IG1pbmltb25nbyBzdXBwb3J0c1xuICBpZiAob3B0aW9ucy51cHNlcnQpIG1vbmdvT3B0cy51cHNlcnQgPSB0cnVlO1xuICBpZiAob3B0aW9ucy5tdWx0aSkgbW9uZ29PcHRzLm11bHRpID0gdHJ1ZTtcbiAgLy8gTGV0cyB5b3UgZ2V0IGEgbW9yZSBtb3JlIGZ1bGwgcmVzdWx0IGZyb20gTW9uZ29EQi4gVXNlIHdpdGggY2F1dGlvbjpcbiAgLy8gbWlnaHQgbm90IHdvcmsgd2l0aCBDLnVwc2VydCAoYXMgb3Bwb3NlZCB0byBDLnVwZGF0ZSh7dXBzZXJ0OnRydWV9KSBvclxuICAvLyB3aXRoIHNpbXVsYXRlZCB1cHNlcnQuXG4gIGlmIChvcHRpb25zLmZ1bGxSZXN1bHQpIG1vbmdvT3B0cy5mdWxsUmVzdWx0ID0gdHJ1ZTtcblxuICB2YXIgbW9uZ29TZWxlY3RvciA9IHJlcGxhY2VUeXBlcyhzZWxlY3RvciwgcmVwbGFjZU1ldGVvckF0b21XaXRoTW9uZ28pO1xuICB2YXIgbW9uZ29Nb2QgPSByZXBsYWNlVHlwZXMobW9kLCByZXBsYWNlTWV0ZW9yQXRvbVdpdGhNb25nbyk7XG5cbiAgdmFyIGlzTW9kaWZ5ID0gTG9jYWxDb2xsZWN0aW9uLl9pc01vZGlmaWNhdGlvbk1vZChtb25nb01vZCk7XG5cbiAgaWYgKG9wdGlvbnMuX2ZvcmJpZFJlcGxhY2UgJiYgIWlzTW9kaWZ5KSB7XG4gICAgdmFyIGVyciA9IG5ldyBFcnJvcihcIkludmFsaWQgbW9kaWZpZXIuIFJlcGxhY2VtZW50cyBhcmUgZm9yYmlkZGVuLlwiKTtcbiAgICB0aHJvdyBlcnI7XG4gIH1cblxuICAvLyBXZSd2ZSBhbHJlYWR5IHJ1biByZXBsYWNlVHlwZXMvcmVwbGFjZU1ldGVvckF0b21XaXRoTW9uZ28gb25cbiAgLy8gc2VsZWN0b3IgYW5kIG1vZC4gIFdlIGFzc3VtZSBpdCBkb2Vzbid0IG1hdHRlciwgYXMgZmFyIGFzXG4gIC8vIHRoZSBiZWhhdmlvciBvZiBtb2RpZmllcnMgaXMgY29uY2VybmVkLCB3aGV0aGVyIGBfbW9kaWZ5YFxuICAvLyBpcyBydW4gb24gRUpTT04gb3Igb24gbW9uZ28tY29udmVydGVkIEVKU09OLlxuXG4gIC8vIFJ1biB0aGlzIGNvZGUgdXAgZnJvbnQgc28gdGhhdCBpdCBmYWlscyBmYXN0IGlmIHNvbWVvbmUgdXNlc1xuICAvLyBhIE1vbmdvIHVwZGF0ZSBvcGVyYXRvciB3ZSBkb24ndCBzdXBwb3J0LlxuICBsZXQga25vd25JZDtcbiAgaWYgKG9wdGlvbnMudXBzZXJ0KSB7XG4gICAgdHJ5IHtcbiAgICAgIGxldCBuZXdEb2MgPSBMb2NhbENvbGxlY3Rpb24uX2NyZWF0ZVVwc2VydERvY3VtZW50KHNlbGVjdG9yLCBtb2QpO1xuICAgICAga25vd25JZCA9IG5ld0RvYy5faWQ7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICB0aHJvdyBlcnI7XG4gICAgfVxuICB9XG4gIGlmIChvcHRpb25zLnVwc2VydCAmJlxuICAgICAgISBpc01vZGlmeSAmJlxuICAgICAgISBrbm93bklkICYmXG4gICAgICBvcHRpb25zLmluc2VydGVkSWQgJiZcbiAgICAgICEgKG9wdGlvbnMuaW5zZXJ0ZWRJZCBpbnN0YW5jZW9mIE1vbmdvLk9iamVjdElEICYmXG4gICAgICAgICBvcHRpb25zLmdlbmVyYXRlZElkKSkge1xuICAgIC8vIEluIGNhc2Ugb2YgYW4gdXBzZXJ0IHdpdGggYSByZXBsYWNlbWVudCwgd2hlcmUgdGhlcmUgaXMgbm8gX2lkIGRlZmluZWRcbiAgICAvLyBpbiBlaXRoZXIgdGhlIHF1ZXJ5IG9yIHRoZSByZXBsYWNlbWVudCBkb2MsIG1vbmdvIHdpbGwgZ2VuZXJhdGUgYW4gaWQgaXRzZWxmLlxuICAgIC8vIFRoZXJlZm9yZSB3ZSBuZWVkIHRoaXMgc3BlY2lhbCBzdHJhdGVneSBpZiB3ZSB3YW50IHRvIGNvbnRyb2wgdGhlIGlkIG91cnNlbHZlcy5cblxuICAgIC8vIFdlIGRvbid0IG5lZWQgdG8gZG8gdGhpcyB3aGVuOlxuICAgIC8vIC0gVGhpcyBpcyBub3QgYSByZXBsYWNlbWVudCwgc28gd2UgY2FuIGFkZCBhbiBfaWQgdG8gJHNldE9uSW5zZXJ0XG4gICAgLy8gLSBUaGUgaWQgaXMgZGVmaW5lZCBieSBxdWVyeSBvciBtb2Qgd2UgY2FuIGp1c3QgYWRkIGl0IHRvIHRoZSByZXBsYWNlbWVudCBkb2NcbiAgICAvLyAtIFRoZSB1c2VyIGRpZCBub3Qgc3BlY2lmeSBhbnkgaWQgcHJlZmVyZW5jZSBhbmQgdGhlIGlkIGlzIGEgTW9uZ28gT2JqZWN0SWQsXG4gICAgLy8gICAgIHRoZW4gd2UgY2FuIGp1c3QgbGV0IE1vbmdvIGdlbmVyYXRlIHRoZSBpZFxuICAgIHJldHVybiBhd2FpdCBzaW11bGF0ZVVwc2VydFdpdGhJbnNlcnRlZElkKGNvbGxlY3Rpb24sIG1vbmdvU2VsZWN0b3IsIG1vbmdvTW9kLCBvcHRpb25zKVxuICAgICAgICAudGhlbihhc3luYyByZXN1bHQgPT4ge1xuICAgICAgICAgIGF3YWl0IHJlZnJlc2goKTtcbiAgICAgICAgICBhd2FpdCB3cml0ZS5jb21taXR0ZWQoKTtcbiAgICAgICAgICBpZiAocmVzdWx0ICYmICEgb3B0aW9ucy5fcmV0dXJuT2JqZWN0KSB7XG4gICAgICAgICAgICByZXR1cm4gcmVzdWx0Lm51bWJlckFmZmVjdGVkO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gIH0gZWxzZSB7XG4gICAgaWYgKG9wdGlvbnMudXBzZXJ0ICYmICFrbm93bklkICYmIG9wdGlvbnMuaW5zZXJ0ZWRJZCAmJiBpc01vZGlmeSkge1xuICAgICAgaWYgKCFtb25nb01vZC5oYXNPd25Qcm9wZXJ0eSgnJHNldE9uSW5zZXJ0JykpIHtcbiAgICAgICAgbW9uZ29Nb2QuJHNldE9uSW5zZXJ0ID0ge307XG4gICAgICB9XG4gICAgICBrbm93bklkID0gb3B0aW9ucy5pbnNlcnRlZElkO1xuICAgICAgT2JqZWN0LmFzc2lnbihtb25nb01vZC4kc2V0T25JbnNlcnQsIHJlcGxhY2VUeXBlcyh7X2lkOiBvcHRpb25zLmluc2VydGVkSWR9LCByZXBsYWNlTWV0ZW9yQXRvbVdpdGhNb25nbykpO1xuICAgIH1cblxuICAgIGNvbnN0IHN0cmluZ3MgPSBPYmplY3Qua2V5cyhtb25nb01vZCkuZmlsdGVyKChrZXkpID0+ICFrZXkuc3RhcnRzV2l0aChcIiRcIikpO1xuICAgIGxldCB1cGRhdGVNZXRob2QgPSBzdHJpbmdzLmxlbmd0aCA+IDAgPyAncmVwbGFjZU9uZScgOiAndXBkYXRlTWFueSc7XG4gICAgdXBkYXRlTWV0aG9kID1cbiAgICAgICAgdXBkYXRlTWV0aG9kID09PSAndXBkYXRlTWFueScgJiYgIW1vbmdvT3B0cy5tdWx0aVxuICAgICAgICAgICAgPyAndXBkYXRlT25lJ1xuICAgICAgICAgICAgOiB1cGRhdGVNZXRob2Q7XG4gICAgcmV0dXJuIGNvbGxlY3Rpb25bdXBkYXRlTWV0aG9kXVxuICAgICAgICAuYmluZChjb2xsZWN0aW9uKShtb25nb1NlbGVjdG9yLCBtb25nb01vZCwgbW9uZ29PcHRzKVxuICAgICAgICAudGhlbihhc3luYyByZXN1bHQgPT4ge1xuICAgICAgICAgIHZhciBtZXRlb3JSZXN1bHQgPSB0cmFuc2Zvcm1SZXN1bHQoe3Jlc3VsdH0pO1xuICAgICAgICAgIGlmIChtZXRlb3JSZXN1bHQgJiYgb3B0aW9ucy5fcmV0dXJuT2JqZWN0KSB7XG4gICAgICAgICAgICAvLyBJZiB0aGlzIHdhcyBhbiB1cHNlcnRBc3luYygpIGNhbGwsIGFuZCB3ZSBlbmRlZCB1cFxuICAgICAgICAgICAgLy8gaW5zZXJ0aW5nIGEgbmV3IGRvYyBhbmQgd2Uga25vdyBpdHMgaWQsIHRoZW5cbiAgICAgICAgICAgIC8vIHJldHVybiB0aGF0IGlkIGFzIHdlbGwuXG4gICAgICAgICAgICBpZiAob3B0aW9ucy51cHNlcnQgJiYgbWV0ZW9yUmVzdWx0Lmluc2VydGVkSWQpIHtcbiAgICAgICAgICAgICAgaWYgKGtub3duSWQpIHtcbiAgICAgICAgICAgICAgICBtZXRlb3JSZXN1bHQuaW5zZXJ0ZWRJZCA9IGtub3duSWQ7XG4gICAgICAgICAgICAgIH0gZWxzZSBpZiAobWV0ZW9yUmVzdWx0Lmluc2VydGVkSWQgaW5zdGFuY2VvZiBNb25nb0RCLk9iamVjdElEKSB7XG4gICAgICAgICAgICAgICAgbWV0ZW9yUmVzdWx0Lmluc2VydGVkSWQgPSBuZXcgTW9uZ28uT2JqZWN0SUQobWV0ZW9yUmVzdWx0Lmluc2VydGVkSWQudG9IZXhTdHJpbmcoKSk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGF3YWl0IHJlZnJlc2goKTtcbiAgICAgICAgICAgIGF3YWl0IHdyaXRlLmNvbW1pdHRlZCgpO1xuICAgICAgICAgICAgcmV0dXJuIG1ldGVvclJlc3VsdDtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgYXdhaXQgcmVmcmVzaCgpO1xuICAgICAgICAgICAgYXdhaXQgd3JpdGUuY29tbWl0dGVkKCk7XG4gICAgICAgICAgICByZXR1cm4gbWV0ZW9yUmVzdWx0Lm51bWJlckFmZmVjdGVkO1xuICAgICAgICAgIH1cbiAgICAgICAgfSkuY2F0Y2goYXN5bmMgKGVycikgPT4ge1xuICAgICAgICAgIGF3YWl0IHdyaXRlLmNvbW1pdHRlZCgpO1xuICAgICAgICAgIHRocm93IGVycjtcbiAgICAgICAgfSk7XG4gIH1cbn07XG5cbnZhciB0cmFuc2Zvcm1SZXN1bHQgPSBmdW5jdGlvbiAoZHJpdmVyUmVzdWx0KSB7XG4gIHZhciBtZXRlb3JSZXN1bHQgPSB7IG51bWJlckFmZmVjdGVkOiAwIH07XG4gIGlmIChkcml2ZXJSZXN1bHQpIHtcbiAgICB2YXIgbW9uZ29SZXN1bHQgPSBkcml2ZXJSZXN1bHQucmVzdWx0O1xuICAgIC8vIE9uIHVwZGF0ZXMgd2l0aCB1cHNlcnQ6dHJ1ZSwgdGhlIGluc2VydGVkIHZhbHVlcyBjb21lIGFzIGEgbGlzdCBvZlxuICAgIC8vIHVwc2VydGVkIHZhbHVlcyAtLSBldmVuIHdpdGggb3B0aW9ucy5tdWx0aSwgd2hlbiB0aGUgdXBzZXJ0IGRvZXMgaW5zZXJ0LFxuICAgIC8vIGl0IG9ubHkgaW5zZXJ0cyBvbmUgZWxlbWVudC5cbiAgICBpZiAobW9uZ29SZXN1bHQudXBzZXJ0ZWRDb3VudCkge1xuICAgICAgbWV0ZW9yUmVzdWx0Lm51bWJlckFmZmVjdGVkID0gbW9uZ29SZXN1bHQudXBzZXJ0ZWRDb3VudDtcblxuICAgICAgaWYgKG1vbmdvUmVzdWx0LnVwc2VydGVkSWQpIHtcbiAgICAgICAgbWV0ZW9yUmVzdWx0Lmluc2VydGVkSWQgPSBtb25nb1Jlc3VsdC51cHNlcnRlZElkO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICAvLyBuIHdhcyB1c2VkIGJlZm9yZSBNb25nbyA1LjAsIGluIE1vbmdvIDUuMCB3ZSBhcmUgbm90IHJlY2VpdmluZyB0aGlzIG5cbiAgICAgIC8vIGZpZWxkIGFuZCBzbyB3ZSBhcmUgdXNpbmcgbW9kaWZpZWRDb3VudCBpbnN0ZWFkXG4gICAgICBtZXRlb3JSZXN1bHQubnVtYmVyQWZmZWN0ZWQgPSBtb25nb1Jlc3VsdC5uIHx8IG1vbmdvUmVzdWx0Lm1hdGNoZWRDb3VudCB8fCBtb25nb1Jlc3VsdC5tb2RpZmllZENvdW50O1xuICAgIH1cbiAgfVxuXG4gIHJldHVybiBtZXRlb3JSZXN1bHQ7XG59O1xuXG5cbnZhciBOVU1fT1BUSU1JU1RJQ19UUklFUyA9IDM7XG5cbi8vIGV4cG9zZWQgZm9yIHRlc3Rpbmdcbk1vbmdvQ29ubmVjdGlvbi5faXNDYW5ub3RDaGFuZ2VJZEVycm9yID0gZnVuY3Rpb24gKGVycikge1xuXG4gIC8vIE1vbmdvIDMuMi4qIHJldHVybnMgZXJyb3IgYXMgbmV4dCBPYmplY3Q6XG4gIC8vIHtuYW1lOiBTdHJpbmcsIGNvZGU6IE51bWJlciwgZXJybXNnOiBTdHJpbmd9XG4gIC8vIE9sZGVyIE1vbmdvIHJldHVybnM6XG4gIC8vIHtuYW1lOiBTdHJpbmcsIGNvZGU6IE51bWJlciwgZXJyOiBTdHJpbmd9XG4gIHZhciBlcnJvciA9IGVyci5lcnJtc2cgfHwgZXJyLmVycjtcblxuICAvLyBXZSBkb24ndCB1c2UgdGhlIGVycm9yIGNvZGUgaGVyZVxuICAvLyBiZWNhdXNlIHRoZSBlcnJvciBjb2RlIHdlIG9ic2VydmVkIGl0IHByb2R1Y2luZyAoMTY4MzcpIGFwcGVhcnMgdG8gYmVcbiAgLy8gYSBmYXIgbW9yZSBnZW5lcmljIGVycm9yIGNvZGUgYmFzZWQgb24gZXhhbWluaW5nIHRoZSBzb3VyY2UuXG4gIGlmIChlcnJvci5pbmRleE9mKCdUaGUgX2lkIGZpZWxkIGNhbm5vdCBiZSBjaGFuZ2VkJykgPT09IDBcbiAgICB8fCBlcnJvci5pbmRleE9mKFwidGhlIChpbW11dGFibGUpIGZpZWxkICdfaWQnIHdhcyBmb3VuZCB0byBoYXZlIGJlZW4gYWx0ZXJlZCB0byBfaWRcIikgIT09IC0xKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cblxuICByZXR1cm4gZmFsc2U7XG59O1xuXG52YXIgc2ltdWxhdGVVcHNlcnRXaXRoSW5zZXJ0ZWRJZCA9IGFzeW5jIGZ1bmN0aW9uIChjb2xsZWN0aW9uLCBzZWxlY3RvciwgbW9kLCBvcHRpb25zKSB7XG4gIC8vIFNUUkFURUdZOiBGaXJzdCB0cnkgZG9pbmcgYW4gdXBzZXJ0IHdpdGggYSBnZW5lcmF0ZWQgSUQuXG4gIC8vIElmIHRoaXMgdGhyb3dzIGFuIGVycm9yIGFib3V0IGNoYW5naW5nIHRoZSBJRCBvbiBhbiBleGlzdGluZyBkb2N1bWVudFxuICAvLyB0aGVuIHdpdGhvdXQgYWZmZWN0aW5nIHRoZSBkYXRhYmFzZSwgd2Uga25vdyB3ZSBzaG91bGQgcHJvYmFibHkgdHJ5XG4gIC8vIGFuIHVwZGF0ZSB3aXRob3V0IHRoZSBnZW5lcmF0ZWQgSUQuIElmIGl0IGFmZmVjdGVkIDAgZG9jdW1lbnRzLFxuICAvLyB0aGVuIHdpdGhvdXQgYWZmZWN0aW5nIHRoZSBkYXRhYmFzZSwgd2UgdGhlIGRvY3VtZW50IHRoYXQgZmlyc3RcbiAgLy8gZ2F2ZSB0aGUgZXJyb3IgaXMgcHJvYmFibHkgcmVtb3ZlZCBhbmQgd2UgbmVlZCB0byB0cnkgYW4gaW5zZXJ0IGFnYWluXG4gIC8vIFdlIGdvIGJhY2sgdG8gc3RlcCBvbmUgYW5kIHJlcGVhdC5cbiAgLy8gTGlrZSBhbGwgXCJvcHRpbWlzdGljIHdyaXRlXCIgc2NoZW1lcywgd2UgcmVseSBvbiB0aGUgZmFjdCB0aGF0IGl0J3NcbiAgLy8gdW5saWtlbHkgb3VyIHdyaXRlcyB3aWxsIGNvbnRpbnVlIHRvIGJlIGludGVyZmVyZWQgd2l0aCB1bmRlciBub3JtYWxcbiAgLy8gY2lyY3Vtc3RhbmNlcyAodGhvdWdoIHN1ZmZpY2llbnRseSBoZWF2eSBjb250ZW50aW9uIHdpdGggd3JpdGVyc1xuICAvLyBkaXNhZ3JlZWluZyBvbiB0aGUgZXhpc3RlbmNlIG9mIGFuIG9iamVjdCB3aWxsIGNhdXNlIHdyaXRlcyB0byBmYWlsXG4gIC8vIGluIHRoZW9yeSkuXG5cbiAgdmFyIGluc2VydGVkSWQgPSBvcHRpb25zLmluc2VydGVkSWQ7IC8vIG11c3QgZXhpc3RcbiAgdmFyIG1vbmdvT3B0c0ZvclVwZGF0ZSA9IHtcbiAgICBzYWZlOiB0cnVlLFxuICAgIG11bHRpOiBvcHRpb25zLm11bHRpXG4gIH07XG4gIHZhciBtb25nb09wdHNGb3JJbnNlcnQgPSB7XG4gICAgc2FmZTogdHJ1ZSxcbiAgICB1cHNlcnQ6IHRydWVcbiAgfTtcblxuICB2YXIgcmVwbGFjZW1lbnRXaXRoSWQgPSBPYmplY3QuYXNzaWduKFxuICAgIHJlcGxhY2VUeXBlcyh7X2lkOiBpbnNlcnRlZElkfSwgcmVwbGFjZU1ldGVvckF0b21XaXRoTW9uZ28pLFxuICAgIG1vZCk7XG5cbiAgdmFyIHRyaWVzID0gTlVNX09QVElNSVNUSUNfVFJJRVM7XG5cbiAgdmFyIGRvVXBkYXRlID0gYXN5bmMgZnVuY3Rpb24gKCkge1xuICAgIHRyaWVzLS07XG4gICAgaWYgKCEgdHJpZXMpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIlVwc2VydCBmYWlsZWQgYWZ0ZXIgXCIgKyBOVU1fT1BUSU1JU1RJQ19UUklFUyArIFwiIHRyaWVzLlwiKTtcbiAgICB9IGVsc2Uge1xuICAgICAgbGV0IG1ldGhvZCA9IGNvbGxlY3Rpb24udXBkYXRlTWFueTtcbiAgICAgIGlmKCFPYmplY3Qua2V5cyhtb2QpLnNvbWUoa2V5ID0+IGtleS5zdGFydHNXaXRoKFwiJFwiKSkpe1xuICAgICAgICBtZXRob2QgPSBjb2xsZWN0aW9uLnJlcGxhY2VPbmUuYmluZChjb2xsZWN0aW9uKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBtZXRob2QoXG4gICAgICAgIHNlbGVjdG9yLFxuICAgICAgICBtb2QsXG4gICAgICAgIG1vbmdvT3B0c0ZvclVwZGF0ZSkudGhlbihyZXN1bHQgPT4ge1xuICAgICAgICBpZiAocmVzdWx0ICYmIChyZXN1bHQubW9kaWZpZWRDb3VudCB8fCByZXN1bHQudXBzZXJ0ZWRDb3VudCkpIHtcbiAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgbnVtYmVyQWZmZWN0ZWQ6IHJlc3VsdC5tb2RpZmllZENvdW50IHx8IHJlc3VsdC51cHNlcnRlZENvdW50LFxuICAgICAgICAgICAgaW5zZXJ0ZWRJZDogcmVzdWx0LnVwc2VydGVkSWQgfHwgdW5kZWZpbmVkLFxuICAgICAgICAgIH07XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmV0dXJuIGRvQ29uZGl0aW9uYWxJbnNlcnQoKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICB9O1xuXG4gIHZhciBkb0NvbmRpdGlvbmFsSW5zZXJ0ID0gZnVuY3Rpb24oKSB7XG4gICAgcmV0dXJuIGNvbGxlY3Rpb24ucmVwbGFjZU9uZShzZWxlY3RvciwgcmVwbGFjZW1lbnRXaXRoSWQsIG1vbmdvT3B0c0Zvckluc2VydClcbiAgICAgICAgLnRoZW4ocmVzdWx0ID0+ICh7XG4gICAgICAgICAgICBudW1iZXJBZmZlY3RlZDogcmVzdWx0LnVwc2VydGVkQ291bnQsXG4gICAgICAgICAgICBpbnNlcnRlZElkOiByZXN1bHQudXBzZXJ0ZWRJZCxcbiAgICAgICAgICB9KSkuY2F0Y2goZXJyID0+IHtcbiAgICAgICAgaWYgKE1vbmdvQ29ubmVjdGlvbi5faXNDYW5ub3RDaGFuZ2VJZEVycm9yKGVycikpIHtcbiAgICAgICAgICByZXR1cm4gZG9VcGRhdGUoKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuXG4gIH07XG4gIHJldHVybiBkb1VwZGF0ZSgpO1xufTtcblxuXG4vLyBYWFggTW9uZ29Db25uZWN0aW9uLnVwc2VydEFzeW5jKCkgZG9lcyBub3QgcmV0dXJuIHRoZSBpZCBvZiB0aGUgaW5zZXJ0ZWQgZG9jdW1lbnRcbi8vIHVubGVzcyB5b3Ugc2V0IGl0IGV4cGxpY2l0bHkgaW4gdGhlIHNlbGVjdG9yIG9yIG1vZGlmaWVyIChhcyBhIHJlcGxhY2VtZW50XG4vLyBkb2MpLlxuTW9uZ29Db25uZWN0aW9uLnByb3RvdHlwZS51cHNlcnRBc3luYyA9IGFzeW5jIGZ1bmN0aW9uIChjb2xsZWN0aW9uTmFtZSwgc2VsZWN0b3IsIG1vZCwgb3B0aW9ucykge1xuICB2YXIgc2VsZiA9IHRoaXM7XG5cblxuXG4gIGlmICh0eXBlb2Ygb3B0aW9ucyA9PT0gXCJmdW5jdGlvblwiICYmICEgY2FsbGJhY2spIHtcbiAgICBjYWxsYmFjayA9IG9wdGlvbnM7XG4gICAgb3B0aW9ucyA9IHt9O1xuICB9XG5cbiAgcmV0dXJuIHNlbGYudXBkYXRlQXN5bmMoY29sbGVjdGlvbk5hbWUsIHNlbGVjdG9yLCBtb2QsXG4gICAgICAgICAgICAgICAgICAgICBfLmV4dGVuZCh7fSwgb3B0aW9ucywge1xuICAgICAgICAgICAgICAgICAgICAgICB1cHNlcnQ6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgIF9yZXR1cm5PYmplY3Q6IHRydWVcbiAgICAgICAgICAgICAgICAgICAgIH0pKTtcbn07XG5cbk1vbmdvQ29ubmVjdGlvbi5wcm90b3R5cGUuZmluZCA9IGZ1bmN0aW9uIChjb2xsZWN0aW9uTmFtZSwgc2VsZWN0b3IsIG9wdGlvbnMpIHtcbiAgdmFyIHNlbGYgPSB0aGlzO1xuXG4gIGlmIChhcmd1bWVudHMubGVuZ3RoID09PSAxKVxuICAgIHNlbGVjdG9yID0ge307XG5cbiAgcmV0dXJuIG5ldyBDdXJzb3IoXG4gICAgc2VsZiwgbmV3IEN1cnNvckRlc2NyaXB0aW9uKGNvbGxlY3Rpb25OYW1lLCBzZWxlY3Rvciwgb3B0aW9ucykpO1xufTtcblxuTW9uZ29Db25uZWN0aW9uLnByb3RvdHlwZS5maW5kT25lQXN5bmMgPSBhc3luYyBmdW5jdGlvbiAoY29sbGVjdGlvbl9uYW1lLCBzZWxlY3Rvciwgb3B0aW9ucykge1xuICB2YXIgc2VsZiA9IHRoaXM7XG4gIGlmIChhcmd1bWVudHMubGVuZ3RoID09PSAxKSB7XG4gICAgc2VsZWN0b3IgPSB7fTtcbiAgfVxuXG4gIG9wdGlvbnMgPSBvcHRpb25zIHx8IHt9O1xuICBvcHRpb25zLmxpbWl0ID0gMTtcblxuICBjb25zdCByZXN1bHRzID0gYXdhaXQgc2VsZi5maW5kKGNvbGxlY3Rpb25fbmFtZSwgc2VsZWN0b3IsIG9wdGlvbnMpLmZldGNoKCk7XG5cbiAgcmV0dXJuIHJlc3VsdHNbMF07XG59O1xuXG4vLyBXZSdsbCBhY3R1YWxseSBkZXNpZ24gYW4gaW5kZXggQVBJIGxhdGVyLiBGb3Igbm93LCB3ZSBqdXN0IHBhc3MgdGhyb3VnaCB0b1xuLy8gTW9uZ28ncywgYnV0IG1ha2UgaXQgc3luY2hyb25vdXMuXG5Nb25nb0Nvbm5lY3Rpb24ucHJvdG90eXBlLmNyZWF0ZUluZGV4QXN5bmMgPSBhc3luYyBmdW5jdGlvbiAoY29sbGVjdGlvbk5hbWUsIGluZGV4LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9ucykge1xuICB2YXIgc2VsZiA9IHRoaXM7XG5cbiAgLy8gV2UgZXhwZWN0IHRoaXMgZnVuY3Rpb24gdG8gYmUgY2FsbGVkIGF0IHN0YXJ0dXAsIG5vdCBmcm9tIHdpdGhpbiBhIG1ldGhvZCxcbiAgLy8gc28gd2UgZG9uJ3QgaW50ZXJhY3Qgd2l0aCB0aGUgd3JpdGUgZmVuY2UuXG4gIHZhciBjb2xsZWN0aW9uID0gc2VsZi5yYXdDb2xsZWN0aW9uKGNvbGxlY3Rpb25OYW1lKTtcbiAgYXdhaXQgY29sbGVjdGlvbi5jcmVhdGVJbmRleChpbmRleCwgb3B0aW9ucyk7XG59O1xuXG4vLyBqdXN0IHRvIGJlIGNvbnNpc3RlbnQgd2l0aCB0aGUgb3RoZXIgbWV0aG9kc1xuTW9uZ29Db25uZWN0aW9uLnByb3RvdHlwZS5jcmVhdGVJbmRleCA9XG4gIE1vbmdvQ29ubmVjdGlvbi5wcm90b3R5cGUuY3JlYXRlSW5kZXhBc3luYztcblxuTW9uZ29Db25uZWN0aW9uLnByb3RvdHlwZS5jb3VudERvY3VtZW50cyA9IGZ1bmN0aW9uIChjb2xsZWN0aW9uTmFtZSwgLi4uYXJncykge1xuICBhcmdzID0gYXJncy5tYXAoYXJnID0+IHJlcGxhY2VUeXBlcyhhcmcsIHJlcGxhY2VNZXRlb3JBdG9tV2l0aE1vbmdvKSk7XG4gIGNvbnN0IGNvbGxlY3Rpb24gPSB0aGlzLnJhd0NvbGxlY3Rpb24oY29sbGVjdGlvbk5hbWUpO1xuICByZXR1cm4gY29sbGVjdGlvbi5jb3VudERvY3VtZW50cyguLi5hcmdzKTtcbn07XG5cbk1vbmdvQ29ubmVjdGlvbi5wcm90b3R5cGUuZXN0aW1hdGVkRG9jdW1lbnRDb3VudCA9IGZ1bmN0aW9uIChjb2xsZWN0aW9uTmFtZSwgLi4uYXJncykge1xuICBhcmdzID0gYXJncy5tYXAoYXJnID0+IHJlcGxhY2VUeXBlcyhhcmcsIHJlcGxhY2VNZXRlb3JBdG9tV2l0aE1vbmdvKSk7XG4gIGNvbnN0IGNvbGxlY3Rpb24gPSB0aGlzLnJhd0NvbGxlY3Rpb24oY29sbGVjdGlvbk5hbWUpO1xuICByZXR1cm4gY29sbGVjdGlvbi5lc3RpbWF0ZWREb2N1bWVudENvdW50KC4uLmFyZ3MpO1xufTtcblxuTW9uZ29Db25uZWN0aW9uLnByb3RvdHlwZS5lbnN1cmVJbmRleEFzeW5jID0gTW9uZ29Db25uZWN0aW9uLnByb3RvdHlwZS5jcmVhdGVJbmRleEFzeW5jO1xuXG5Nb25nb0Nvbm5lY3Rpb24ucHJvdG90eXBlLmRyb3BJbmRleEFzeW5jID0gYXN5bmMgZnVuY3Rpb24gKGNvbGxlY3Rpb25OYW1lLCBpbmRleCkge1xuICB2YXIgc2VsZiA9IHRoaXM7XG5cblxuICAvLyBUaGlzIGZ1bmN0aW9uIGlzIG9ubHkgdXNlZCBieSB0ZXN0IGNvZGUsIG5vdCB3aXRoaW4gYSBtZXRob2QsIHNvIHdlIGRvbid0XG4gIC8vIGludGVyYWN0IHdpdGggdGhlIHdyaXRlIGZlbmNlLlxuICB2YXIgY29sbGVjdGlvbiA9IHNlbGYucmF3Q29sbGVjdGlvbihjb2xsZWN0aW9uTmFtZSk7XG4gIHZhciBpbmRleE5hbWUgPSAgYXdhaXQgY29sbGVjdGlvbi5kcm9wSW5kZXgoaW5kZXgpO1xufTtcblxuXG5DTElFTlRfT05MWV9NRVRIT0RTLmZvckVhY2goZnVuY3Rpb24gKG0pIHtcbiAgTW9uZ29Db25uZWN0aW9uLnByb3RvdHlwZVttXSA9IGZ1bmN0aW9uICgpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICBgJHttfSArICBpcyBub3QgYXZhaWxhYmxlIG9uIHRoZSBzZXJ2ZXIuIFBsZWFzZSB1c2UgJHtnZXRBc3luY01ldGhvZE5hbWUoXG4gICAgICAgIG1cbiAgICAgICl9KCkgaW5zdGVhZC5gXG4gICAgKTtcbiAgfTtcbn0pO1xuXG4vLyBDVVJTT1JTXG5cbi8vIFRoZXJlIGFyZSBzZXZlcmFsIGNsYXNzZXMgd2hpY2ggcmVsYXRlIHRvIGN1cnNvcnM6XG4vL1xuLy8gQ3Vyc29yRGVzY3JpcHRpb24gcmVwcmVzZW50cyB0aGUgYXJndW1lbnRzIHVzZWQgdG8gY29uc3RydWN0IGEgY3Vyc29yOlxuLy8gY29sbGVjdGlvbk5hbWUsIHNlbGVjdG9yLCBhbmQgKGZpbmQpIG9wdGlvbnMuICBCZWNhdXNlIGl0IGlzIHVzZWQgYXMgYSBrZXlcbi8vIGZvciBjdXJzb3IgZGUtZHVwLCBldmVyeXRoaW5nIGluIGl0IHNob3VsZCBlaXRoZXIgYmUgSlNPTi1zdHJpbmdpZmlhYmxlIG9yXG4vLyBub3QgYWZmZWN0IG9ic2VydmVDaGFuZ2VzIG91dHB1dCAoZWcsIG9wdGlvbnMudHJhbnNmb3JtIGZ1bmN0aW9ucyBhcmUgbm90XG4vLyBzdHJpbmdpZmlhYmxlIGJ1dCBkbyBub3QgYWZmZWN0IG9ic2VydmVDaGFuZ2VzKS5cbi8vXG4vLyBTeW5jaHJvbm91c0N1cnNvciBpcyBhIHdyYXBwZXIgYXJvdW5kIGEgTW9uZ29EQiBjdXJzb3Jcbi8vIHdoaWNoIGluY2x1ZGVzIGZ1bGx5LXN5bmNocm9ub3VzIHZlcnNpb25zIG9mIGZvckVhY2gsIGV0Yy5cbi8vXG4vLyBDdXJzb3IgaXMgdGhlIGN1cnNvciBvYmplY3QgcmV0dXJuZWQgZnJvbSBmaW5kKCksIHdoaWNoIGltcGxlbWVudHMgdGhlXG4vLyBkb2N1bWVudGVkIE1vbmdvLkNvbGxlY3Rpb24gY3Vyc29yIEFQSS4gIEl0IHdyYXBzIGEgQ3Vyc29yRGVzY3JpcHRpb24gYW5kIGFcbi8vIFN5bmNocm9ub3VzQ3Vyc29yIChsYXppbHk6IGl0IGRvZXNuJ3QgY29udGFjdCBNb25nbyB1bnRpbCB5b3UgY2FsbCBhIG1ldGhvZFxuLy8gbGlrZSBmZXRjaCBvciBmb3JFYWNoIG9uIGl0KS5cbi8vXG4vLyBPYnNlcnZlSGFuZGxlIGlzIHRoZSBcIm9ic2VydmUgaGFuZGxlXCIgcmV0dXJuZWQgZnJvbSBvYnNlcnZlQ2hhbmdlcy4gSXQgaGFzIGFcbi8vIHJlZmVyZW5jZSB0byBhbiBPYnNlcnZlTXVsdGlwbGV4ZXIuXG4vL1xuLy8gT2JzZXJ2ZU11bHRpcGxleGVyIGFsbG93cyBtdWx0aXBsZSBpZGVudGljYWwgT2JzZXJ2ZUhhbmRsZXMgdG8gYmUgZHJpdmVuIGJ5IGFcbi8vIHNpbmdsZSBvYnNlcnZlIGRyaXZlci5cbi8vXG4vLyBUaGVyZSBhcmUgdHdvIFwib2JzZXJ2ZSBkcml2ZXJzXCIgd2hpY2ggZHJpdmUgT2JzZXJ2ZU11bHRpcGxleGVyczpcbi8vICAgLSBQb2xsaW5nT2JzZXJ2ZURyaXZlciBjYWNoZXMgdGhlIHJlc3VsdHMgb2YgYSBxdWVyeSBhbmQgcmVydW5zIGl0IHdoZW5cbi8vICAgICBuZWNlc3NhcnkuXG4vLyAgIC0gT3Bsb2dPYnNlcnZlRHJpdmVyIGZvbGxvd3MgdGhlIE1vbmdvIG9wZXJhdGlvbiBsb2cgdG8gZGlyZWN0bHkgb2JzZXJ2ZVxuLy8gICAgIGRhdGFiYXNlIGNoYW5nZXMuXG4vLyBCb3RoIGltcGxlbWVudGF0aW9ucyBmb2xsb3cgdGhlIHNhbWUgc2ltcGxlIGludGVyZmFjZTogd2hlbiB5b3UgY3JlYXRlIHRoZW0sXG4vLyB0aGV5IHN0YXJ0IHNlbmRpbmcgb2JzZXJ2ZUNoYW5nZXMgY2FsbGJhY2tzIChhbmQgYSByZWFkeSgpIGludm9jYXRpb24pIHRvXG4vLyB0aGVpciBPYnNlcnZlTXVsdGlwbGV4ZXIsIGFuZCB5b3Ugc3RvcCB0aGVtIGJ5IGNhbGxpbmcgdGhlaXIgc3RvcCgpIG1ldGhvZC5cblxuQ3Vyc29yRGVzY3JpcHRpb24gPSBmdW5jdGlvbiAoY29sbGVjdGlvbk5hbWUsIHNlbGVjdG9yLCBvcHRpb25zKSB7XG4gIHZhciBzZWxmID0gdGhpcztcbiAgc2VsZi5jb2xsZWN0aW9uTmFtZSA9IGNvbGxlY3Rpb25OYW1lO1xuICBzZWxmLnNlbGVjdG9yID0gTW9uZ28uQ29sbGVjdGlvbi5fcmV3cml0ZVNlbGVjdG9yKHNlbGVjdG9yKTtcbiAgc2VsZi5vcHRpb25zID0gb3B0aW9ucyB8fCB7fTtcbn07XG5cbkN1cnNvciA9IGZ1bmN0aW9uIChtb25nbywgY3Vyc29yRGVzY3JpcHRpb24pIHtcbiAgdmFyIHNlbGYgPSB0aGlzO1xuXG4gIHNlbGYuX21vbmdvID0gbW9uZ287XG4gIHNlbGYuX2N1cnNvckRlc2NyaXB0aW9uID0gY3Vyc29yRGVzY3JpcHRpb247XG4gIHNlbGYuX3N5bmNocm9ub3VzQ3Vyc29yID0gbnVsbDtcbn07XG5cbmZ1bmN0aW9uIHNldHVwU3luY2hyb25vdXNDdXJzb3IoY3Vyc29yLCBtZXRob2QpIHtcbiAgLy8gWW91IGNhbiBvbmx5IG9ic2VydmUgYSB0YWlsYWJsZSBjdXJzb3IuXG4gIGlmIChjdXJzb3IuX2N1cnNvckRlc2NyaXB0aW9uLm9wdGlvbnMudGFpbGFibGUpXG4gICAgdGhyb3cgbmV3IEVycm9yKCdDYW5ub3QgY2FsbCAnICsgbWV0aG9kICsgJyBvbiBhIHRhaWxhYmxlIGN1cnNvcicpO1xuXG4gIGlmICghY3Vyc29yLl9zeW5jaHJvbm91c0N1cnNvcikge1xuICAgIGN1cnNvci5fc3luY2hyb25vdXNDdXJzb3IgPSBjdXJzb3IuX21vbmdvLl9jcmVhdGVTeW5jaHJvbm91c0N1cnNvcihcbiAgICAgIGN1cnNvci5fY3Vyc29yRGVzY3JpcHRpb24sXG4gICAgICB7XG4gICAgICAgIC8vIE1ha2Ugc3VyZSB0aGF0IHRoZSBcImN1cnNvclwiIGFyZ3VtZW50IHRvIGZvckVhY2gvbWFwIGNhbGxiYWNrcyBpcyB0aGVcbiAgICAgICAgLy8gQ3Vyc29yLCBub3QgdGhlIFN5bmNocm9ub3VzQ3Vyc29yLlxuICAgICAgICBzZWxmRm9ySXRlcmF0aW9uOiBjdXJzb3IsXG4gICAgICAgIHVzZVRyYW5zZm9ybTogdHJ1ZSxcbiAgICAgIH1cbiAgICApO1xuICB9XG5cbiAgcmV0dXJuIGN1cnNvci5fc3luY2hyb25vdXNDdXJzb3I7XG59XG5cblxuQ3Vyc29yLnByb3RvdHlwZS5jb3VudEFzeW5jID0gYXN5bmMgZnVuY3Rpb24gKCkge1xuICBjb25zdCBjb2xsZWN0aW9uID0gdGhpcy5fbW9uZ28ucmF3Q29sbGVjdGlvbih0aGlzLl9jdXJzb3JEZXNjcmlwdGlvbi5jb2xsZWN0aW9uTmFtZSk7XG4gIHJldHVybiBhd2FpdCBjb2xsZWN0aW9uLmNvdW50RG9jdW1lbnRzKFxuICAgIHJlcGxhY2VUeXBlcyh0aGlzLl9jdXJzb3JEZXNjcmlwdGlvbi5zZWxlY3RvciwgcmVwbGFjZU1ldGVvckF0b21XaXRoTW9uZ28pLFxuICAgIHJlcGxhY2VUeXBlcyh0aGlzLl9jdXJzb3JEZXNjcmlwdGlvbi5vcHRpb25zLCByZXBsYWNlTWV0ZW9yQXRvbVdpdGhNb25nbyksXG4gICk7XG59O1xuXG5DdXJzb3IucHJvdG90eXBlLmNvdW50ID0gZnVuY3Rpb24gKCkge1xuICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgXCJjb3VudCgpIGlzIG5vdCBhdmFpYmxlIG9uIHRoZSBzZXJ2ZXIuIFBsZWFzZSB1c2UgY291bnRBc3luYygpIGluc3RlYWQuXCJcbiAgKTtcbn07XG5cblsuLi5BU1lOQ19DVVJTT1JfTUVUSE9EUywgU3ltYm9sLml0ZXJhdG9yLCBTeW1ib2wuYXN5bmNJdGVyYXRvcl0uZm9yRWFjaChtZXRob2ROYW1lID0+IHtcbiAgLy8gY291bnQgaXMgaGFuZGxlZCBzcGVjaWFsbHkgc2luY2Ugd2UgZG9uJ3Qgd2FudCB0byBjcmVhdGUgYSBjdXJzb3IuXG4gIC8vIGl0IGlzIHN0aWxsIGluY2x1ZGVkIGluIEFTWU5DX0NVUlNPUl9NRVRIT0RTIGJlY2F1c2Ugd2Ugc3RpbGwgd2FudCBhbiBhc3luYyB2ZXJzaW9uIG9mIGl0IHRvIGV4aXN0LlxuICBpZiAobWV0aG9kTmFtZSA9PT0gJ2NvdW50Jykge1xuICAgIHJldHVyblxuICB9XG4gIEN1cnNvci5wcm90b3R5cGVbbWV0aG9kTmFtZV0gPSBmdW5jdGlvbiAoLi4uYXJncykge1xuICAgIGNvbnN0IGN1cnNvciA9IHNldHVwU3luY2hyb25vdXNDdXJzb3IodGhpcywgbWV0aG9kTmFtZSk7XG4gICAgcmV0dXJuIGN1cnNvclttZXRob2ROYW1lXSguLi5hcmdzKTtcbiAgfTtcblxuICAvLyBUaGVzZSBtZXRob2RzIGFyZSBoYW5kbGVkIHNlcGFyYXRlbHkuXG4gIGlmIChtZXRob2ROYW1lID09PSBTeW1ib2wuaXRlcmF0b3IgfHwgbWV0aG9kTmFtZSA9PT0gU3ltYm9sLmFzeW5jSXRlcmF0b3IpIHtcbiAgICByZXR1cm47XG4gIH1cblxuICBjb25zdCBtZXRob2ROYW1lQXN5bmMgPSBnZXRBc3luY01ldGhvZE5hbWUobWV0aG9kTmFtZSk7XG4gIEN1cnNvci5wcm90b3R5cGVbbWV0aG9kTmFtZUFzeW5jXSA9IGZ1bmN0aW9uICguLi5hcmdzKSB7XG4gICAgdHJ5IHtcbiAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUodGhpc1ttZXRob2ROYW1lXSguLi5hcmdzKSk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHJldHVybiBQcm9taXNlLnJlamVjdChlcnJvcik7XG4gICAgfVxuICB9O1xufSk7XG5cbkN1cnNvci5wcm90b3R5cGUuZ2V0VHJhbnNmb3JtID0gZnVuY3Rpb24gKCkge1xuICByZXR1cm4gdGhpcy5fY3Vyc29yRGVzY3JpcHRpb24ub3B0aW9ucy50cmFuc2Zvcm07XG59O1xuXG4vLyBXaGVuIHlvdSBjYWxsIE1ldGVvci5wdWJsaXNoKCkgd2l0aCBhIGZ1bmN0aW9uIHRoYXQgcmV0dXJucyBhIEN1cnNvciwgd2UgbmVlZFxuLy8gdG8gdHJhbnNtdXRlIGl0IGludG8gdGhlIGVxdWl2YWxlbnQgc3Vic2NyaXB0aW9uLiAgVGhpcyBpcyB0aGUgZnVuY3Rpb24gdGhhdFxuLy8gZG9lcyB0aGF0LlxuQ3Vyc29yLnByb3RvdHlwZS5fcHVibGlzaEN1cnNvciA9IGZ1bmN0aW9uIChzdWIpIHtcbiAgdmFyIHNlbGYgPSB0aGlzO1xuICB2YXIgY29sbGVjdGlvbiA9IHNlbGYuX2N1cnNvckRlc2NyaXB0aW9uLmNvbGxlY3Rpb25OYW1lO1xuICByZXR1cm4gTW9uZ28uQ29sbGVjdGlvbi5fcHVibGlzaEN1cnNvcihzZWxmLCBzdWIsIGNvbGxlY3Rpb24pO1xufTtcblxuLy8gVXNlZCB0byBndWFyYW50ZWUgdGhhdCBwdWJsaXNoIGZ1bmN0aW9ucyByZXR1cm4gYXQgbW9zdCBvbmUgY3Vyc29yIHBlclxuLy8gY29sbGVjdGlvbi4gUHJpdmF0ZSwgYmVjYXVzZSB3ZSBtaWdodCBsYXRlciBoYXZlIGN1cnNvcnMgdGhhdCBpbmNsdWRlXG4vLyBkb2N1bWVudHMgZnJvbSBtdWx0aXBsZSBjb2xsZWN0aW9ucyBzb21laG93LlxuQ3Vyc29yLnByb3RvdHlwZS5fZ2V0Q29sbGVjdGlvbk5hbWUgPSBmdW5jdGlvbiAoKSB7XG4gIHZhciBzZWxmID0gdGhpcztcbiAgcmV0dXJuIHNlbGYuX2N1cnNvckRlc2NyaXB0aW9uLmNvbGxlY3Rpb25OYW1lO1xufTtcblxuQ3Vyc29yLnByb3RvdHlwZS5vYnNlcnZlID0gZnVuY3Rpb24gKGNhbGxiYWNrcykge1xuICB2YXIgc2VsZiA9IHRoaXM7XG4gIHJldHVybiBMb2NhbENvbGxlY3Rpb24uX29ic2VydmVGcm9tT2JzZXJ2ZUNoYW5nZXMoc2VsZiwgY2FsbGJhY2tzKTtcbn07XG5cbkN1cnNvci5wcm90b3R5cGUub2JzZXJ2ZUFzeW5jID0gZnVuY3Rpb24gKGNhbGxiYWNrcykge1xuICByZXR1cm4gbmV3IFByb21pc2UocmVzb2x2ZSA9PiByZXNvbHZlKHRoaXMub2JzZXJ2ZShjYWxsYmFja3MpKSk7XG59O1xuXG5DdXJzb3IucHJvdG90eXBlLm9ic2VydmVDaGFuZ2VzID0gZnVuY3Rpb24gKGNhbGxiYWNrcywgb3B0aW9ucyA9IHt9KSB7XG4gIHZhciBzZWxmID0gdGhpcztcbiAgdmFyIG1ldGhvZHMgPSBbXG4gICAgJ2FkZGVkQXQnLFxuICAgICdhZGRlZCcsXG4gICAgJ2NoYW5nZWRBdCcsXG4gICAgJ2NoYW5nZWQnLFxuICAgICdyZW1vdmVkQXQnLFxuICAgICdyZW1vdmVkJyxcbiAgICAnbW92ZWRUbydcbiAgXTtcbiAgdmFyIG9yZGVyZWQgPSBMb2NhbENvbGxlY3Rpb24uX29ic2VydmVDaGFuZ2VzQ2FsbGJhY2tzQXJlT3JkZXJlZChjYWxsYmFja3MpO1xuXG4gIGxldCBleGNlcHRpb25OYW1lID0gY2FsbGJhY2tzLl9mcm9tT2JzZXJ2ZSA/ICdvYnNlcnZlJyA6ICdvYnNlcnZlQ2hhbmdlcyc7XG4gIGV4Y2VwdGlvbk5hbWUgKz0gJyBjYWxsYmFjayc7XG4gIG1ldGhvZHMuZm9yRWFjaChmdW5jdGlvbiAobWV0aG9kKSB7XG4gICAgaWYgKGNhbGxiYWNrc1ttZXRob2RdICYmIHR5cGVvZiBjYWxsYmFja3NbbWV0aG9kXSA9PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgIGNhbGxiYWNrc1ttZXRob2RdID0gTWV0ZW9yLmJpbmRFbnZpcm9ubWVudChjYWxsYmFja3NbbWV0aG9kXSwgbWV0aG9kICsgZXhjZXB0aW9uTmFtZSk7XG4gICAgfVxuICB9KTtcblxuICByZXR1cm4gc2VsZi5fbW9uZ28uX29ic2VydmVDaGFuZ2VzKFxuICAgIHNlbGYuX2N1cnNvckRlc2NyaXB0aW9uLCBvcmRlcmVkLCBjYWxsYmFja3MsIG9wdGlvbnMubm9uTXV0YXRpbmdDYWxsYmFja3MpO1xufTtcblxuQ3Vyc29yLnByb3RvdHlwZS5vYnNlcnZlQ2hhbmdlc0FzeW5jID0gYXN5bmMgZnVuY3Rpb24gKGNhbGxiYWNrcywgb3B0aW9ucyA9IHt9KSB7XG4gIHJldHVybiB0aGlzLm9ic2VydmVDaGFuZ2VzKGNhbGxiYWNrcywgb3B0aW9ucyk7XG59O1xuXG5Nb25nb0Nvbm5lY3Rpb24ucHJvdG90eXBlLl9jcmVhdGVTeW5jaHJvbm91c0N1cnNvciA9IGZ1bmN0aW9uKFxuICAgIGN1cnNvckRlc2NyaXB0aW9uLCBvcHRpb25zKSB7XG4gIHZhciBzZWxmID0gdGhpcztcbiAgb3B0aW9ucyA9IF8ucGljayhvcHRpb25zIHx8IHt9LCAnc2VsZkZvckl0ZXJhdGlvbicsICd1c2VUcmFuc2Zvcm0nKTtcblxuICB2YXIgY29sbGVjdGlvbiA9IHNlbGYucmF3Q29sbGVjdGlvbihjdXJzb3JEZXNjcmlwdGlvbi5jb2xsZWN0aW9uTmFtZSk7XG4gIHZhciBjdXJzb3JPcHRpb25zID0gY3Vyc29yRGVzY3JpcHRpb24ub3B0aW9ucztcbiAgdmFyIG1vbmdvT3B0aW9ucyA9IHtcbiAgICBzb3J0OiBjdXJzb3JPcHRpb25zLnNvcnQsXG4gICAgbGltaXQ6IGN1cnNvck9wdGlvbnMubGltaXQsXG4gICAgc2tpcDogY3Vyc29yT3B0aW9ucy5za2lwLFxuICAgIHByb2plY3Rpb246IGN1cnNvck9wdGlvbnMuZmllbGRzIHx8IGN1cnNvck9wdGlvbnMucHJvamVjdGlvbixcbiAgICByZWFkUHJlZmVyZW5jZTogY3Vyc29yT3B0aW9ucy5yZWFkUHJlZmVyZW5jZSxcbiAgfTtcblxuICAvLyBEbyB3ZSB3YW50IGEgdGFpbGFibGUgY3Vyc29yICh3aGljaCBvbmx5IHdvcmtzIG9uIGNhcHBlZCBjb2xsZWN0aW9ucyk/XG4gIGlmIChjdXJzb3JPcHRpb25zLnRhaWxhYmxlKSB7XG4gICAgbW9uZ29PcHRpb25zLm51bWJlck9mUmV0cmllcyA9IC0xO1xuICB9XG5cbiAgdmFyIGRiQ3Vyc29yID0gY29sbGVjdGlvbi5maW5kKFxuICAgIHJlcGxhY2VUeXBlcyhjdXJzb3JEZXNjcmlwdGlvbi5zZWxlY3RvciwgcmVwbGFjZU1ldGVvckF0b21XaXRoTW9uZ28pLFxuICAgIG1vbmdvT3B0aW9ucyk7XG5cbiAgLy8gRG8gd2Ugd2FudCBhIHRhaWxhYmxlIGN1cnNvciAod2hpY2ggb25seSB3b3JrcyBvbiBjYXBwZWQgY29sbGVjdGlvbnMpP1xuICBpZiAoY3Vyc29yT3B0aW9ucy50YWlsYWJsZSkge1xuICAgIC8vIFdlIHdhbnQgYSB0YWlsYWJsZSBjdXJzb3IuLi5cbiAgICBkYkN1cnNvci5hZGRDdXJzb3JGbGFnKFwidGFpbGFibGVcIiwgdHJ1ZSlcbiAgICAvLyAuLi4gYW5kIGZvciB0aGUgc2VydmVyIHRvIHdhaXQgYSBiaXQgaWYgYW55IGdldE1vcmUgaGFzIG5vIGRhdGEgKHJhdGhlclxuICAgIC8vIHRoYW4gbWFraW5nIHVzIHB1dCB0aGUgcmVsZXZhbnQgc2xlZXBzIGluIHRoZSBjbGllbnQpLi4uXG4gICAgZGJDdXJzb3IuYWRkQ3Vyc29yRmxhZyhcImF3YWl0RGF0YVwiLCB0cnVlKVxuXG4gICAgLy8gQW5kIGlmIHRoaXMgaXMgb24gdGhlIG9wbG9nIGNvbGxlY3Rpb24gYW5kIHRoZSBjdXJzb3Igc3BlY2lmaWVzIGEgJ3RzJyxcbiAgICAvLyB0aGVuIHNldCB0aGUgdW5kb2N1bWVudGVkIG9wbG9nIHJlcGxheSBmbGFnLCB3aGljaCBkb2VzIGEgc3BlY2lhbCBzY2FuIHRvXG4gICAgLy8gZmluZCB0aGUgZmlyc3QgZG9jdW1lbnQgKGluc3RlYWQgb2YgY3JlYXRpbmcgYW4gaW5kZXggb24gdHMpLiBUaGlzIGlzIGFcbiAgICAvLyB2ZXJ5IGhhcmQtY29kZWQgTW9uZ28gZmxhZyB3aGljaCBvbmx5IHdvcmtzIG9uIHRoZSBvcGxvZyBjb2xsZWN0aW9uIGFuZFxuICAgIC8vIG9ubHkgd29ya3Mgd2l0aCB0aGUgdHMgZmllbGQuXG4gICAgaWYgKGN1cnNvckRlc2NyaXB0aW9uLmNvbGxlY3Rpb25OYW1lID09PSBPUExPR19DT0xMRUNUSU9OICYmXG4gICAgICAgIGN1cnNvckRlc2NyaXB0aW9uLnNlbGVjdG9yLnRzKSB7XG4gICAgICBkYkN1cnNvci5hZGRDdXJzb3JGbGFnKFwib3Bsb2dSZXBsYXlcIiwgdHJ1ZSlcbiAgICB9XG4gIH1cblxuICBpZiAodHlwZW9mIGN1cnNvck9wdGlvbnMubWF4VGltZU1zICE9PSAndW5kZWZpbmVkJykge1xuICAgIGRiQ3Vyc29yID0gZGJDdXJzb3IubWF4VGltZU1TKGN1cnNvck9wdGlvbnMubWF4VGltZU1zKTtcbiAgfVxuICBpZiAodHlwZW9mIGN1cnNvck9wdGlvbnMuaGludCAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICBkYkN1cnNvciA9IGRiQ3Vyc29yLmhpbnQoY3Vyc29yT3B0aW9ucy5oaW50KTtcbiAgfVxuXG4gIHJldHVybiBuZXcgQXN5bmNocm9ub3VzQ3Vyc29yKGRiQ3Vyc29yLCBjdXJzb3JEZXNjcmlwdGlvbiwgb3B0aW9ucywgY29sbGVjdGlvbik7XG59O1xuXG4vKipcbiAqIFRoaXMgaXMganVzdCBhIGxpZ2h0IHdyYXBwZXIgZm9yIHRoZSBjdXJzb3IuIFRoZSBnb2FsIGhlcmUgaXMgdG8gZW5zdXJlIGNvbXBhdGliaWxpdHkgZXZlbiBpZlxuICogdGhlcmUgYXJlIGJyZWFraW5nIGNoYW5nZXMgb24gdGhlIE1vbmdvREIgZHJpdmVyLlxuICpcbiAqIEBjb25zdHJ1Y3RvclxuICovXG5jbGFzcyBBc3luY2hyb25vdXNDdXJzb3Ige1xuICBjb25zdHJ1Y3RvcihkYkN1cnNvciwgY3Vyc29yRGVzY3JpcHRpb24sIG9wdGlvbnMpIHtcbiAgICB0aGlzLl9kYkN1cnNvciA9IGRiQ3Vyc29yO1xuICAgIHRoaXMuX2N1cnNvckRlc2NyaXB0aW9uID0gY3Vyc29yRGVzY3JpcHRpb247XG5cbiAgICB0aGlzLl9zZWxmRm9ySXRlcmF0aW9uID0gb3B0aW9ucy5zZWxmRm9ySXRlcmF0aW9uIHx8IHRoaXM7XG4gICAgaWYgKG9wdGlvbnMudXNlVHJhbnNmb3JtICYmIGN1cnNvckRlc2NyaXB0aW9uLm9wdGlvbnMudHJhbnNmb3JtKSB7XG4gICAgICB0aGlzLl90cmFuc2Zvcm0gPSBMb2NhbENvbGxlY3Rpb24ud3JhcFRyYW5zZm9ybShcbiAgICAgICAgICBjdXJzb3JEZXNjcmlwdGlvbi5vcHRpb25zLnRyYW5zZm9ybSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuX3RyYW5zZm9ybSA9IG51bGw7XG4gICAgfVxuXG4gICAgdGhpcy5fdmlzaXRlZElkcyA9IG5ldyBMb2NhbENvbGxlY3Rpb24uX0lkTWFwO1xuICB9XG5cbiAgW1N5bWJvbC5hc3luY0l0ZXJhdG9yXSgpIHtcbiAgICB2YXIgY3Vyc29yID0gdGhpcztcbiAgICByZXR1cm4ge1xuICAgICAgYXN5bmMgbmV4dCgpIHtcbiAgICAgICAgY29uc3QgdmFsdWUgPSBhd2FpdCBjdXJzb3IuX25leHRPYmplY3RQcm9taXNlKCk7XG4gICAgICAgIHJldHVybiB7IGRvbmU6ICF2YWx1ZSwgdmFsdWUgfTtcbiAgICAgIH0sXG4gICAgfTtcbiAgfVxuXG4gIC8vIFJldHVybnMgYSBQcm9taXNlIGZvciB0aGUgbmV4dCBvYmplY3QgZnJvbSB0aGUgdW5kZXJseWluZyBjdXJzb3IgKGJlZm9yZVxuICAvLyB0aGUgTW9uZ28tPk1ldGVvciB0eXBlIHJlcGxhY2VtZW50KS5cbiAgYXN5bmMgX3Jhd05leHRPYmplY3RQcm9taXNlKCkge1xuICAgIHRyeSB7XG4gICAgICByZXR1cm4gdGhpcy5fZGJDdXJzb3IubmV4dCgpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoZSk7XG4gICAgfVxuICB9XG5cbiAgLy8gUmV0dXJucyBhIFByb21pc2UgZm9yIHRoZSBuZXh0IG9iamVjdCBmcm9tIHRoZSBjdXJzb3IsIHNraXBwaW5nIHRob3NlIHdob3NlXG4gIC8vIElEcyB3ZSd2ZSBhbHJlYWR5IHNlZW4gYW5kIHJlcGxhY2luZyBNb25nbyBhdG9tcyB3aXRoIE1ldGVvciBhdG9tcy5cbiAgYXN5bmMgX25leHRPYmplY3RQcm9taXNlICgpIHtcbiAgICB3aGlsZSAodHJ1ZSkge1xuICAgICAgdmFyIGRvYyA9IGF3YWl0IHRoaXMuX3Jhd05leHRPYmplY3RQcm9taXNlKCk7XG5cbiAgICAgIGlmICghZG9jKSByZXR1cm4gbnVsbDtcbiAgICAgIGRvYyA9IHJlcGxhY2VUeXBlcyhkb2MsIHJlcGxhY2VNb25nb0F0b21XaXRoTWV0ZW9yKTtcblxuICAgICAgaWYgKCF0aGlzLl9jdXJzb3JEZXNjcmlwdGlvbi5vcHRpb25zLnRhaWxhYmxlICYmIF8uaGFzKGRvYywgJ19pZCcpKSB7XG4gICAgICAgIC8vIERpZCBNb25nbyBnaXZlIHVzIGR1cGxpY2F0ZSBkb2N1bWVudHMgaW4gdGhlIHNhbWUgY3Vyc29yPyBJZiBzbyxcbiAgICAgICAgLy8gaWdub3JlIHRoaXMgb25lLiAoRG8gdGhpcyBiZWZvcmUgdGhlIHRyYW5zZm9ybSwgc2luY2UgdHJhbnNmb3JtIG1pZ2h0XG4gICAgICAgIC8vIHJldHVybiBzb21lIHVucmVsYXRlZCB2YWx1ZS4pIFdlIGRvbid0IGRvIHRoaXMgZm9yIHRhaWxhYmxlIGN1cnNvcnMsXG4gICAgICAgIC8vIGJlY2F1c2Ugd2Ugd2FudCB0byBtYWludGFpbiBPKDEpIG1lbW9yeSB1c2FnZS4gQW5kIGlmIHRoZXJlIGlzbid0IF9pZFxuICAgICAgICAvLyBmb3Igc29tZSByZWFzb24gKG1heWJlIGl0J3MgdGhlIG9wbG9nKSwgdGhlbiB3ZSBkb24ndCBkbyB0aGlzIGVpdGhlci5cbiAgICAgICAgLy8gKEJlIGNhcmVmdWwgdG8gZG8gdGhpcyBmb3IgZmFsc2V5IGJ1dCBleGlzdGluZyBfaWQsIHRob3VnaC4pXG4gICAgICAgIGlmICh0aGlzLl92aXNpdGVkSWRzLmhhcyhkb2MuX2lkKSkgY29udGludWU7XG4gICAgICAgIHRoaXMuX3Zpc2l0ZWRJZHMuc2V0KGRvYy5faWQsIHRydWUpO1xuICAgICAgfVxuXG4gICAgICBpZiAodGhpcy5fdHJhbnNmb3JtKVxuICAgICAgICBkb2MgPSB0aGlzLl90cmFuc2Zvcm0oZG9jKTtcblxuICAgICAgcmV0dXJuIGRvYztcbiAgICB9XG4gIH1cblxuICAvLyBSZXR1cm5zIGEgcHJvbWlzZSB3aGljaCBpcyByZXNvbHZlZCB3aXRoIHRoZSBuZXh0IG9iamVjdCAobGlrZSB3aXRoXG4gIC8vIF9uZXh0T2JqZWN0UHJvbWlzZSkgb3IgcmVqZWN0ZWQgaWYgdGhlIGN1cnNvciBkb2Vzbid0IHJldHVybiB3aXRoaW5cbiAgLy8gdGltZW91dE1TIG1zLlxuICBfbmV4dE9iamVjdFByb21pc2VXaXRoVGltZW91dCh0aW1lb3V0TVMpIHtcbiAgICBpZiAoIXRpbWVvdXRNUykge1xuICAgICAgcmV0dXJuIHRoaXMuX25leHRPYmplY3RQcm9taXNlKCk7XG4gICAgfVxuICAgIGNvbnN0IG5leHRPYmplY3RQcm9taXNlID0gdGhpcy5fbmV4dE9iamVjdFByb21pc2UoKTtcbiAgICBjb25zdCB0aW1lb3V0RXJyID0gbmV3IEVycm9yKCdDbGllbnQtc2lkZSB0aW1lb3V0IHdhaXRpbmcgZm9yIG5leHQgb2JqZWN0Jyk7XG4gICAgY29uc3QgdGltZW91dFByb21pc2UgPSBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgcmVqZWN0KHRpbWVvdXRFcnIpO1xuICAgICAgfSwgdGltZW91dE1TKTtcbiAgICB9KTtcbiAgICByZXR1cm4gUHJvbWlzZS5yYWNlKFtuZXh0T2JqZWN0UHJvbWlzZSwgdGltZW91dFByb21pc2VdKVxuICAgICAgICAuY2F0Y2goKGVycikgPT4ge1xuICAgICAgICAgIGlmIChlcnIgPT09IHRpbWVvdXRFcnIpIHtcbiAgICAgICAgICAgIHRoaXMuY2xvc2UoKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgdGhyb3cgZXJyO1xuICAgICAgICB9KTtcbiAgfVxuXG4gIGFzeW5jIGZvckVhY2goY2FsbGJhY2ssIHRoaXNBcmcpIHtcbiAgICAvLyBHZXQgYmFjayB0byB0aGUgYmVnaW5uaW5nLlxuICAgIHRoaXMuX3Jld2luZCgpO1xuXG4gICAgbGV0IGlkeCA9IDA7XG4gICAgd2hpbGUgKHRydWUpIHtcbiAgICAgIGNvbnN0IGRvYyA9IGF3YWl0IHRoaXMuX25leHRPYmplY3RQcm9taXNlKCk7XG4gICAgICBpZiAoIWRvYykgcmV0dXJuO1xuICAgICAgYXdhaXQgY2FsbGJhY2suY2FsbCh0aGlzQXJnLCBkb2MsIGlkeCsrLCB0aGlzLl9zZWxmRm9ySXRlcmF0aW9uKTtcbiAgICB9XG4gIH1cblxuICBhc3luYyBtYXAoY2FsbGJhY2ssIHRoaXNBcmcpIHtcbiAgICBjb25zdCByZXN1bHRzID0gW107XG4gICAgYXdhaXQgdGhpcy5mb3JFYWNoKGFzeW5jIChkb2MsIGluZGV4KSA9PiB7XG4gICAgICByZXN1bHRzLnB1c2goYXdhaXQgY2FsbGJhY2suY2FsbCh0aGlzQXJnLCBkb2MsIGluZGV4LCB0aGlzLl9zZWxmRm9ySXRlcmF0aW9uKSk7XG4gICAgfSk7XG5cbiAgICByZXR1cm4gcmVzdWx0cztcbiAgfVxuXG4gIF9yZXdpbmQoKSB7XG4gICAgLy8ga25vd24gdG8gYmUgc3luY2hyb25vdXNcbiAgICB0aGlzLl9kYkN1cnNvci5yZXdpbmQoKTtcblxuICAgIHRoaXMuX3Zpc2l0ZWRJZHMgPSBuZXcgTG9jYWxDb2xsZWN0aW9uLl9JZE1hcDtcbiAgfVxuXG4gIC8vIE1vc3RseSB1c2FibGUgZm9yIHRhaWxhYmxlIGN1cnNvcnMuXG4gIGNsb3NlKCkge1xuICAgIHRoaXMuX2RiQ3Vyc29yLmNsb3NlKCk7XG4gIH1cblxuICBmZXRjaCgpIHtcbiAgICByZXR1cm4gdGhpcy5tYXAoXy5pZGVudGl0eSk7XG4gIH1cblxuICAvKipcbiAgICogRklYTUU6IChub2RlOjM0NjgwKSBbTU9OR09EQiBEUklWRVJdIFdhcm5pbmc6IGN1cnNvci5jb3VudCBpcyBkZXByZWNhdGVkIGFuZCB3aWxsIGJlXG4gICAqICByZW1vdmVkIGluIHRoZSBuZXh0IG1ham9yIHZlcnNpb24sIHBsZWFzZSB1c2UgYGNvbGxlY3Rpb24uZXN0aW1hdGVkRG9jdW1lbnRDb3VudGAgb3JcbiAgICogIGBjb2xsZWN0aW9uLmNvdW50RG9jdW1lbnRzYCBpbnN0ZWFkLlxuICAgKi9cbiAgY291bnQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2RiQ3Vyc29yLmNvdW50KCk7XG4gIH1cblxuICAvLyBUaGlzIG1ldGhvZCBpcyBOT1Qgd3JhcHBlZCBpbiBDdXJzb3IuXG4gIGFzeW5jIGdldFJhd09iamVjdHMob3JkZXJlZCkge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICBpZiAob3JkZXJlZCkge1xuICAgICAgcmV0dXJuIHNlbGYuZmV0Y2goKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdmFyIHJlc3VsdHMgPSBuZXcgTG9jYWxDb2xsZWN0aW9uLl9JZE1hcDtcbiAgICAgIGF3YWl0IHNlbGYuZm9yRWFjaChmdW5jdGlvbiAoZG9jKSB7XG4gICAgICAgIHJlc3VsdHMuc2V0KGRvYy5faWQsIGRvYyk7XG4gICAgICB9KTtcbiAgICAgIHJldHVybiByZXN1bHRzO1xuICAgIH1cbiAgfVxufVxuXG52YXIgU3luY2hyb25vdXNDdXJzb3IgPSBmdW5jdGlvbiAoZGJDdXJzb3IsIGN1cnNvckRlc2NyaXB0aW9uLCBvcHRpb25zLCBjb2xsZWN0aW9uKSB7XG4gIHZhciBzZWxmID0gdGhpcztcbiAgb3B0aW9ucyA9IF8ucGljayhvcHRpb25zIHx8IHt9LCAnc2VsZkZvckl0ZXJhdGlvbicsICd1c2VUcmFuc2Zvcm0nKTtcblxuICBzZWxmLl9kYkN1cnNvciA9IGRiQ3Vyc29yO1xuICBzZWxmLl9jdXJzb3JEZXNjcmlwdGlvbiA9IGN1cnNvckRlc2NyaXB0aW9uO1xuICAvLyBUaGUgXCJzZWxmXCIgYXJndW1lbnQgcGFzc2VkIHRvIGZvckVhY2gvbWFwIGNhbGxiYWNrcy4gSWYgd2UncmUgd3JhcHBlZFxuICAvLyBpbnNpZGUgYSB1c2VyLXZpc2libGUgQ3Vyc29yLCB3ZSB3YW50IHRvIHByb3ZpZGUgdGhlIG91dGVyIGN1cnNvciFcbiAgc2VsZi5fc2VsZkZvckl0ZXJhdGlvbiA9IG9wdGlvbnMuc2VsZkZvckl0ZXJhdGlvbiB8fCBzZWxmO1xuICBpZiAob3B0aW9ucy51c2VUcmFuc2Zvcm0gJiYgY3Vyc29yRGVzY3JpcHRpb24ub3B0aW9ucy50cmFuc2Zvcm0pIHtcbiAgICBzZWxmLl90cmFuc2Zvcm0gPSBMb2NhbENvbGxlY3Rpb24ud3JhcFRyYW5zZm9ybShcbiAgICAgIGN1cnNvckRlc2NyaXB0aW9uLm9wdGlvbnMudHJhbnNmb3JtKTtcbiAgfSBlbHNlIHtcbiAgICBzZWxmLl90cmFuc2Zvcm0gPSBudWxsO1xuICB9XG5cbiAgc2VsZi5fc3luY2hyb25vdXNDb3VudCA9IEZ1dHVyZS53cmFwKFxuICAgIGNvbGxlY3Rpb24uY291bnREb2N1bWVudHMuYmluZChcbiAgICAgIGNvbGxlY3Rpb24sXG4gICAgICByZXBsYWNlVHlwZXMoY3Vyc29yRGVzY3JpcHRpb24uc2VsZWN0b3IsIHJlcGxhY2VNZXRlb3JBdG9tV2l0aE1vbmdvKSxcbiAgICAgIHJlcGxhY2VUeXBlcyhjdXJzb3JEZXNjcmlwdGlvbi5vcHRpb25zLCByZXBsYWNlTWV0ZW9yQXRvbVdpdGhNb25nbyksXG4gICAgKVxuICApO1xuICBzZWxmLl92aXNpdGVkSWRzID0gbmV3IExvY2FsQ29sbGVjdGlvbi5fSWRNYXA7XG59O1xuXG5fLmV4dGVuZChTeW5jaHJvbm91c0N1cnNvci5wcm90b3R5cGUsIHtcbiAgLy8gUmV0dXJucyBhIFByb21pc2UgZm9yIHRoZSBuZXh0IG9iamVjdCBmcm9tIHRoZSB1bmRlcmx5aW5nIGN1cnNvciAoYmVmb3JlXG4gIC8vIHRoZSBNb25nby0+TWV0ZW9yIHR5cGUgcmVwbGFjZW1lbnQpLlxuICBfcmF3TmV4dE9iamVjdFByb21pc2U6IGZ1bmN0aW9uICgpIHtcbiAgICBjb25zdCBzZWxmID0gdGhpcztcbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgc2VsZi5fZGJDdXJzb3IubmV4dCgoZXJyLCBkb2MpID0+IHtcbiAgICAgICAgaWYgKGVycikge1xuICAgICAgICAgIHJlamVjdChlcnIpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJlc29sdmUoZG9jKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfSk7XG4gIH0sXG5cbiAgLy8gUmV0dXJucyBhIFByb21pc2UgZm9yIHRoZSBuZXh0IG9iamVjdCBmcm9tIHRoZSBjdXJzb3IsIHNraXBwaW5nIHRob3NlIHdob3NlXG4gIC8vIElEcyB3ZSd2ZSBhbHJlYWR5IHNlZW4gYW5kIHJlcGxhY2luZyBNb25nbyBhdG9tcyB3aXRoIE1ldGVvciBhdG9tcy5cbiAgX25leHRPYmplY3RQcm9taXNlOiBhc3luYyBmdW5jdGlvbiAoKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuXG4gICAgd2hpbGUgKHRydWUpIHtcbiAgICAgIHZhciBkb2MgPSBhd2FpdCBzZWxmLl9yYXdOZXh0T2JqZWN0UHJvbWlzZSgpO1xuXG4gICAgICBpZiAoIWRvYykgcmV0dXJuIG51bGw7XG4gICAgICBkb2MgPSByZXBsYWNlVHlwZXMoZG9jLCByZXBsYWNlTW9uZ29BdG9tV2l0aE1ldGVvcik7XG5cbiAgICAgIGlmICghc2VsZi5fY3Vyc29yRGVzY3JpcHRpb24ub3B0aW9ucy50YWlsYWJsZSAmJiBfLmhhcyhkb2MsICdfaWQnKSkge1xuICAgICAgICAvLyBEaWQgTW9uZ28gZ2l2ZSB1cyBkdXBsaWNhdGUgZG9jdW1lbnRzIGluIHRoZSBzYW1lIGN1cnNvcj8gSWYgc28sXG4gICAgICAgIC8vIGlnbm9yZSB0aGlzIG9uZS4gKERvIHRoaXMgYmVmb3JlIHRoZSB0cmFuc2Zvcm0sIHNpbmNlIHRyYW5zZm9ybSBtaWdodFxuICAgICAgICAvLyByZXR1cm4gc29tZSB1bnJlbGF0ZWQgdmFsdWUuKSBXZSBkb24ndCBkbyB0aGlzIGZvciB0YWlsYWJsZSBjdXJzb3JzLFxuICAgICAgICAvLyBiZWNhdXNlIHdlIHdhbnQgdG8gbWFpbnRhaW4gTygxKSBtZW1vcnkgdXNhZ2UuIEFuZCBpZiB0aGVyZSBpc24ndCBfaWRcbiAgICAgICAgLy8gZm9yIHNvbWUgcmVhc29uIChtYXliZSBpdCdzIHRoZSBvcGxvZyksIHRoZW4gd2UgZG9uJ3QgZG8gdGhpcyBlaXRoZXIuXG4gICAgICAgIC8vIChCZSBjYXJlZnVsIHRvIGRvIHRoaXMgZm9yIGZhbHNleSBidXQgZXhpc3RpbmcgX2lkLCB0aG91Z2guKVxuICAgICAgICBpZiAoc2VsZi5fdmlzaXRlZElkcy5oYXMoZG9jLl9pZCkpIGNvbnRpbnVlO1xuICAgICAgICBzZWxmLl92aXNpdGVkSWRzLnNldChkb2MuX2lkLCB0cnVlKTtcbiAgICAgIH1cblxuICAgICAgaWYgKHNlbGYuX3RyYW5zZm9ybSlcbiAgICAgICAgZG9jID0gc2VsZi5fdHJhbnNmb3JtKGRvYyk7XG5cbiAgICAgIHJldHVybiBkb2M7XG4gICAgfVxuICB9LFxuXG4gIC8vIFJldHVybnMgYSBwcm9taXNlIHdoaWNoIGlzIHJlc29sdmVkIHdpdGggdGhlIG5leHQgb2JqZWN0IChsaWtlIHdpdGhcbiAgLy8gX25leHRPYmplY3RQcm9taXNlKSBvciByZWplY3RlZCBpZiB0aGUgY3Vyc29yIGRvZXNuJ3QgcmV0dXJuIHdpdGhpblxuICAvLyB0aW1lb3V0TVMgbXMuXG4gIF9uZXh0T2JqZWN0UHJvbWlzZVdpdGhUaW1lb3V0OiBmdW5jdGlvbiAodGltZW91dE1TKSB7XG4gICAgY29uc3Qgc2VsZiA9IHRoaXM7XG4gICAgaWYgKCF0aW1lb3V0TVMpIHtcbiAgICAgIHJldHVybiBzZWxmLl9uZXh0T2JqZWN0UHJvbWlzZSgpO1xuICAgIH1cbiAgICBjb25zdCBuZXh0T2JqZWN0UHJvbWlzZSA9IHNlbGYuX25leHRPYmplY3RQcm9taXNlKCk7XG4gICAgY29uc3QgdGltZW91dEVyciA9IG5ldyBFcnJvcignQ2xpZW50LXNpZGUgdGltZW91dCB3YWl0aW5nIGZvciBuZXh0IG9iamVjdCcpO1xuICAgIGNvbnN0IHRpbWVvdXRQcm9taXNlID0gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgY29uc3QgdGltZXIgPSBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgcmVqZWN0KHRpbWVvdXRFcnIpO1xuICAgICAgfSwgdGltZW91dE1TKTtcbiAgICB9KTtcbiAgICByZXR1cm4gUHJvbWlzZS5yYWNlKFtuZXh0T2JqZWN0UHJvbWlzZSwgdGltZW91dFByb21pc2VdKVxuICAgICAgLmNhdGNoKChlcnIpID0+IHtcbiAgICAgICAgaWYgKGVyciA9PT0gdGltZW91dEVycikge1xuICAgICAgICAgIHNlbGYuY2xvc2UoKTtcbiAgICAgICAgfVxuICAgICAgICB0aHJvdyBlcnI7XG4gICAgICB9KTtcbiAgfSxcblxuICBfbmV4dE9iamVjdDogZnVuY3Rpb24gKCkge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICByZXR1cm4gc2VsZi5fbmV4dE9iamVjdFByb21pc2UoKS5hd2FpdCgpO1xuICB9LFxuXG4gIGZvckVhY2g6IGZ1bmN0aW9uIChjYWxsYmFjaywgdGhpc0FyZykge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICBjb25zdCB3cmFwcGVkRm4gPSBNZXRlb3Iud3JhcEZuKGNhbGxiYWNrKTtcblxuICAgIC8vIEdldCBiYWNrIHRvIHRoZSBiZWdpbm5pbmcuXG4gICAgc2VsZi5fcmV3aW5kKCk7XG5cbiAgICAvLyBXZSBpbXBsZW1lbnQgdGhlIGxvb3Agb3Vyc2VsZiBpbnN0ZWFkIG9mIHVzaW5nIHNlbGYuX2RiQ3Vyc29yLmVhY2gsXG4gICAgLy8gYmVjYXVzZSBcImVhY2hcIiB3aWxsIGNhbGwgaXRzIGNhbGxiYWNrIG91dHNpZGUgb2YgYSBmaWJlciB3aGljaCBtYWtlcyBpdFxuICAgIC8vIG11Y2ggbW9yZSBjb21wbGV4IHRvIG1ha2UgdGhpcyBmdW5jdGlvbiBzeW5jaHJvbm91cy5cbiAgICB2YXIgaW5kZXggPSAwO1xuICAgIHdoaWxlICh0cnVlKSB7XG4gICAgICB2YXIgZG9jID0gc2VsZi5fbmV4dE9iamVjdCgpO1xuICAgICAgaWYgKCFkb2MpIHJldHVybjtcbiAgICAgIHdyYXBwZWRGbi5jYWxsKHRoaXNBcmcsIGRvYywgaW5kZXgrKywgc2VsZi5fc2VsZkZvckl0ZXJhdGlvbik7XG4gICAgfVxuICB9LFxuXG4gIC8vIFhYWCBBbGxvdyBvdmVybGFwcGluZyBjYWxsYmFjayBleGVjdXRpb25zIGlmIGNhbGxiYWNrIHlpZWxkcy5cbiAgbWFwOiBmdW5jdGlvbiAoY2FsbGJhY2ssIHRoaXNBcmcpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgY29uc3Qgd3JhcHBlZEZuID0gTWV0ZW9yLndyYXBGbihjYWxsYmFjayk7XG4gICAgdmFyIHJlcyA9IFtdO1xuICAgIHNlbGYuZm9yRWFjaChmdW5jdGlvbiAoZG9jLCBpbmRleCkge1xuICAgICAgcmVzLnB1c2god3JhcHBlZEZuLmNhbGwodGhpc0FyZywgZG9jLCBpbmRleCwgc2VsZi5fc2VsZkZvckl0ZXJhdGlvbikpO1xuICAgIH0pO1xuICAgIHJldHVybiByZXM7XG4gIH0sXG5cbiAgX3Jld2luZDogZnVuY3Rpb24gKCkge1xuICAgIHZhciBzZWxmID0gdGhpcztcblxuICAgIC8vIGtub3duIHRvIGJlIHN5bmNocm9ub3VzXG4gICAgc2VsZi5fZGJDdXJzb3IucmV3aW5kKCk7XG5cbiAgICBzZWxmLl92aXNpdGVkSWRzID0gbmV3IExvY2FsQ29sbGVjdGlvbi5fSWRNYXA7XG4gIH0sXG5cbiAgLy8gTW9zdGx5IHVzYWJsZSBmb3IgdGFpbGFibGUgY3Vyc29ycy5cbiAgY2xvc2U6IGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG5cbiAgICBzZWxmLl9kYkN1cnNvci5jbG9zZSgpO1xuICB9LFxuXG4gIGZldGNoOiBmdW5jdGlvbiAoKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgIHJldHVybiBzZWxmLm1hcChfLmlkZW50aXR5KTtcbiAgfSxcblxuICBjb3VudDogZnVuY3Rpb24gKCkge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICByZXR1cm4gc2VsZi5fc3luY2hyb25vdXNDb3VudCgpLndhaXQoKTtcbiAgfSxcblxuICAvLyBUaGlzIG1ldGhvZCBpcyBOT1Qgd3JhcHBlZCBpbiBDdXJzb3IuXG4gIGdldFJhd09iamVjdHM6IGZ1bmN0aW9uIChvcmRlcmVkKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgIGlmIChvcmRlcmVkKSB7XG4gICAgICByZXR1cm4gc2VsZi5mZXRjaCgpO1xuICAgIH0gZWxzZSB7XG4gICAgICB2YXIgcmVzdWx0cyA9IG5ldyBMb2NhbENvbGxlY3Rpb24uX0lkTWFwO1xuICAgICAgc2VsZi5mb3JFYWNoKGZ1bmN0aW9uIChkb2MpIHtcbiAgICAgICAgcmVzdWx0cy5zZXQoZG9jLl9pZCwgZG9jKTtcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuIHJlc3VsdHM7XG4gICAgfVxuICB9XG59KTtcblxuU3luY2hyb25vdXNDdXJzb3IucHJvdG90eXBlW1N5bWJvbC5pdGVyYXRvcl0gPSBmdW5jdGlvbiAoKSB7XG4gIHZhciBzZWxmID0gdGhpcztcblxuICAvLyBHZXQgYmFjayB0byB0aGUgYmVnaW5uaW5nLlxuICBzZWxmLl9yZXdpbmQoKTtcblxuICByZXR1cm4ge1xuICAgIG5leHQoKSB7XG4gICAgICBjb25zdCBkb2MgPSBzZWxmLl9uZXh0T2JqZWN0KCk7XG4gICAgICByZXR1cm4gZG9jID8ge1xuICAgICAgICB2YWx1ZTogZG9jXG4gICAgICB9IDoge1xuICAgICAgICBkb25lOiB0cnVlXG4gICAgICB9O1xuICAgIH1cbiAgfTtcbn07XG5cblN5bmNocm9ub3VzQ3Vyc29yLnByb3RvdHlwZVtTeW1ib2wuYXN5bmNJdGVyYXRvcl0gPSBmdW5jdGlvbiAoKSB7XG4gIGNvbnN0IHN5bmNSZXN1bHQgPSB0aGlzW1N5bWJvbC5pdGVyYXRvcl0oKTtcbiAgcmV0dXJuIHtcbiAgICBhc3luYyBuZXh0KCkge1xuICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZShzeW5jUmVzdWx0Lm5leHQoKSk7XG4gICAgfVxuICB9O1xufVxuXG4vLyBUYWlscyB0aGUgY3Vyc29yIGRlc2NyaWJlZCBieSBjdXJzb3JEZXNjcmlwdGlvbiwgbW9zdCBsaWtlbHkgb24gdGhlXG4vLyBvcGxvZy4gQ2FsbHMgZG9jQ2FsbGJhY2sgd2l0aCBlYWNoIGRvY3VtZW50IGZvdW5kLiBJZ25vcmVzIGVycm9ycyBhbmQganVzdFxuLy8gcmVzdGFydHMgdGhlIHRhaWwgb24gZXJyb3IuXG4vL1xuLy8gSWYgdGltZW91dE1TIGlzIHNldCwgdGhlbiBpZiB3ZSBkb24ndCBnZXQgYSBuZXcgZG9jdW1lbnQgZXZlcnkgdGltZW91dE1TLFxuLy8ga2lsbCBhbmQgcmVzdGFydCB0aGUgY3Vyc29yLiBUaGlzIGlzIHByaW1hcmlseSBhIHdvcmthcm91bmQgZm9yICM4NTk4LlxuTW9uZ29Db25uZWN0aW9uLnByb3RvdHlwZS50YWlsID0gZnVuY3Rpb24gKGN1cnNvckRlc2NyaXB0aW9uLCBkb2NDYWxsYmFjaywgdGltZW91dE1TKSB7XG4gIHZhciBzZWxmID0gdGhpcztcbiAgaWYgKCFjdXJzb3JEZXNjcmlwdGlvbi5vcHRpb25zLnRhaWxhYmxlKVxuICAgIHRocm93IG5ldyBFcnJvcihcIkNhbiBvbmx5IHRhaWwgYSB0YWlsYWJsZSBjdXJzb3JcIik7XG5cbiAgdmFyIGN1cnNvciA9IHNlbGYuX2NyZWF0ZVN5bmNocm9ub3VzQ3Vyc29yKGN1cnNvckRlc2NyaXB0aW9uKTtcblxuICB2YXIgc3RvcHBlZCA9IGZhbHNlO1xuICB2YXIgbGFzdFRTO1xuXG4gIE1ldGVvci5kZWZlcihhc3luYyBmdW5jdGlvbiBsb29wKCkge1xuICAgIHZhciBkb2MgPSBudWxsO1xuICAgIHdoaWxlICh0cnVlKSB7XG4gICAgICBpZiAoc3RvcHBlZClcbiAgICAgICAgcmV0dXJuO1xuICAgICAgdHJ5IHtcbiAgICAgICAgZG9jID0gYXdhaXQgY3Vyc29yLl9uZXh0T2JqZWN0UHJvbWlzZVdpdGhUaW1lb3V0KHRpbWVvdXRNUyk7XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgLy8gVGhlcmUncyBubyBnb29kIHdheSB0byBmaWd1cmUgb3V0IGlmIHRoaXMgd2FzIGFjdHVhbGx5IGFuIGVycm9yIGZyb21cbiAgICAgICAgLy8gTW9uZ28sIG9yIGp1c3QgY2xpZW50LXNpZGUgKGluY2x1ZGluZyBvdXIgb3duIHRpbWVvdXQgZXJyb3IpLiBBaFxuICAgICAgICAvLyB3ZWxsLiBCdXQgZWl0aGVyIHdheSwgd2UgbmVlZCB0byByZXRyeSB0aGUgY3Vyc29yICh1bmxlc3MgdGhlIGZhaWx1cmVcbiAgICAgICAgLy8gd2FzIGJlY2F1c2UgdGhlIG9ic2VydmUgZ290IHN0b3BwZWQpLlxuICAgICAgICBkb2MgPSBudWxsO1xuICAgICAgfVxuICAgICAgLy8gU2luY2Ugd2UgYXdhaXRlZCBhIHByb21pc2UgYWJvdmUsIHdlIG5lZWQgdG8gY2hlY2sgYWdhaW4gdG8gc2VlIGlmXG4gICAgICAvLyB3ZSd2ZSBiZWVuIHN0b3BwZWQgYmVmb3JlIGNhbGxpbmcgdGhlIGNhbGxiYWNrLlxuICAgICAgaWYgKHN0b3BwZWQpXG4gICAgICAgIHJldHVybjtcbiAgICAgIGlmIChkb2MpIHtcbiAgICAgICAgLy8gSWYgYSB0YWlsYWJsZSBjdXJzb3IgY29udGFpbnMgYSBcInRzXCIgZmllbGQsIHVzZSBpdCB0byByZWNyZWF0ZSB0aGVcbiAgICAgICAgLy8gY3Vyc29yIG9uIGVycm9yLiAoXCJ0c1wiIGlzIGEgc3RhbmRhcmQgdGhhdCBNb25nbyB1c2VzIGludGVybmFsbHkgZm9yXG4gICAgICAgIC8vIHRoZSBvcGxvZywgYW5kIHRoZXJlJ3MgYSBzcGVjaWFsIGZsYWcgdGhhdCBsZXRzIHlvdSBkbyBiaW5hcnkgc2VhcmNoXG4gICAgICAgIC8vIG9uIGl0IGluc3RlYWQgb2YgbmVlZGluZyB0byB1c2UgYW4gaW5kZXguKVxuICAgICAgICBsYXN0VFMgPSBkb2MudHM7XG4gICAgICAgIGRvY0NhbGxiYWNrKGRvYyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB2YXIgbmV3U2VsZWN0b3IgPSBfLmNsb25lKGN1cnNvckRlc2NyaXB0aW9uLnNlbGVjdG9yKTtcbiAgICAgICAgaWYgKGxhc3RUUykge1xuICAgICAgICAgIG5ld1NlbGVjdG9yLnRzID0geyRndDogbGFzdFRTfTtcbiAgICAgICAgfVxuICAgICAgICBjdXJzb3IgPSBzZWxmLl9jcmVhdGVTeW5jaHJvbm91c0N1cnNvcihuZXcgQ3Vyc29yRGVzY3JpcHRpb24oXG4gICAgICAgICAgY3Vyc29yRGVzY3JpcHRpb24uY29sbGVjdGlvbk5hbWUsXG4gICAgICAgICAgbmV3U2VsZWN0b3IsXG4gICAgICAgICAgY3Vyc29yRGVzY3JpcHRpb24ub3B0aW9ucykpO1xuICAgICAgICAvLyBNb25nbyBmYWlsb3ZlciB0YWtlcyBtYW55IHNlY29uZHMuICBSZXRyeSBpbiBhIGJpdC4gIChXaXRob3V0IHRoaXNcbiAgICAgICAgLy8gc2V0VGltZW91dCwgd2UgcGVnIHRoZSBDUFUgYXQgMTAwJSBhbmQgbmV2ZXIgbm90aWNlIHRoZSBhY3R1YWxcbiAgICAgICAgLy8gZmFpbG92ZXIuXG4gICAgICAgIHNldFRpbWVvdXQobG9vcCwgMTAwKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgfVxuICB9KTtcblxuICByZXR1cm4ge1xuICAgIHN0b3A6IGZ1bmN0aW9uICgpIHtcbiAgICAgIHN0b3BwZWQgPSB0cnVlO1xuICAgICAgY3Vyc29yLmNsb3NlKCk7XG4gICAgfVxuICB9O1xufTtcblxuY29uc3Qgb3Bsb2dDb2xsZWN0aW9uV2FybmluZ3MgPSBbXTtcblxuT2JqZWN0LmFzc2lnbihNb25nb0Nvbm5lY3Rpb24ucHJvdG90eXBlLCB7XG4gIF9vYnNlcnZlQ2hhbmdlczogYXN5bmMgZnVuY3Rpb24gKFxuICAgICAgY3Vyc29yRGVzY3JpcHRpb24sIG9yZGVyZWQsIGNhbGxiYWNrcywgbm9uTXV0YXRpbmdDYWxsYmFja3MpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgY29uc3QgY29sbGVjdGlvbk5hbWUgPSBjdXJzb3JEZXNjcmlwdGlvbi5jb2xsZWN0aW9uTmFtZTtcblxuICAgIGlmIChjdXJzb3JEZXNjcmlwdGlvbi5vcHRpb25zLnRhaWxhYmxlKSB7XG4gICAgICByZXR1cm4gc2VsZi5fb2JzZXJ2ZUNoYW5nZXNUYWlsYWJsZShjdXJzb3JEZXNjcmlwdGlvbiwgb3JkZXJlZCwgY2FsbGJhY2tzKTtcbiAgICB9XG5cbiAgICAvLyBZb3UgbWF5IG5vdCBmaWx0ZXIgb3V0IF9pZCB3aGVuIG9ic2VydmluZyBjaGFuZ2VzLCBiZWNhdXNlIHRoZSBpZCBpcyBhIGNvcmVcbiAgICAvLyBwYXJ0IG9mIHRoZSBvYnNlcnZlQ2hhbmdlcyBBUEkuXG4gICAgY29uc3QgZmllbGRzT3B0aW9ucyA9IGN1cnNvckRlc2NyaXB0aW9uLm9wdGlvbnMucHJvamVjdGlvbiB8fCBjdXJzb3JEZXNjcmlwdGlvbi5vcHRpb25zLmZpZWxkcztcbiAgICBpZiAoZmllbGRzT3B0aW9ucyAmJlxuICAgICAgICAoZmllbGRzT3B0aW9ucy5faWQgPT09IDAgfHxcbiAgICAgICAgICAgIGZpZWxkc09wdGlvbnMuX2lkID09PSBmYWxzZSkpIHtcbiAgICAgIHRocm93IEVycm9yKFwiWW91IG1heSBub3Qgb2JzZXJ2ZSBhIGN1cnNvciB3aXRoIHtmaWVsZHM6IHtfaWQ6IDB9fVwiKTtcbiAgICB9XG5cbiAgICB2YXIgb2JzZXJ2ZUtleSA9IEVKU09OLnN0cmluZ2lmeShcbiAgICAgICAgXy5leHRlbmQoe29yZGVyZWQ6IG9yZGVyZWR9LCBjdXJzb3JEZXNjcmlwdGlvbikpO1xuXG4gICAgdmFyIG11bHRpcGxleGVyLCBvYnNlcnZlRHJpdmVyO1xuICAgIHZhciBmaXJzdEhhbmRsZSA9IGZhbHNlO1xuXG4gICAgLy8gRmluZCBhIG1hdGNoaW5nIE9ic2VydmVNdWx0aXBsZXhlciwgb3IgY3JlYXRlIGEgbmV3IG9uZS4gVGhpcyBuZXh0IGJsb2NrIGlzXG4gICAgLy8gZ3VhcmFudGVlZCB0byBub3QgeWllbGQgKGFuZCBpdCBkb2Vzbid0IGNhbGwgYW55dGhpbmcgdGhhdCBjYW4gb2JzZXJ2ZSBhXG4gICAgLy8gbmV3IHF1ZXJ5KSwgc28gbm8gb3RoZXIgY2FsbHMgdG8gdGhpcyBmdW5jdGlvbiBjYW4gaW50ZXJsZWF2ZSB3aXRoIGl0LlxuICAgIGlmIChfLmhhcyhzZWxmLl9vYnNlcnZlTXVsdGlwbGV4ZXJzLCBvYnNlcnZlS2V5KSkge1xuICAgICAgbXVsdGlwbGV4ZXIgPSBzZWxmLl9vYnNlcnZlTXVsdGlwbGV4ZXJzW29ic2VydmVLZXldO1xuICAgIH0gZWxzZSB7XG4gICAgICBmaXJzdEhhbmRsZSA9IHRydWU7XG4gICAgICAvLyBDcmVhdGUgYSBuZXcgT2JzZXJ2ZU11bHRpcGxleGVyLlxuICAgICAgbXVsdGlwbGV4ZXIgPSBuZXcgT2JzZXJ2ZU11bHRpcGxleGVyKHtcbiAgICAgICAgb3JkZXJlZDogb3JkZXJlZCxcbiAgICAgICAgb25TdG9wOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgZGVsZXRlIHNlbGYuX29ic2VydmVNdWx0aXBsZXhlcnNbb2JzZXJ2ZUtleV07XG4gICAgICAgICAgcmV0dXJuIG9ic2VydmVEcml2ZXIuc3RvcCgpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9XG5cbiAgICB2YXIgb2JzZXJ2ZUhhbmRsZSA9IG5ldyBPYnNlcnZlSGFuZGxlKG11bHRpcGxleGVyLFxuICAgICAgICBjYWxsYmFja3MsXG4gICAgICAgIG5vbk11dGF0aW5nQ2FsbGJhY2tzLFxuICAgICk7XG5cbiAgICBjb25zdCBvcGxvZ09wdGlvbnMgPSBzZWxmPy5fb3Bsb2dIYW5kbGU/Ll9vcGxvZ09wdGlvbnMgfHwge307XG4gIGNvbnN0IHsgaW5jbHVkZUNvbGxlY3Rpb25zLCBleGNsdWRlQ29sbGVjdGlvbnMgfSA9IG9wbG9nT3B0aW9ucztpZiAoZmlyc3RIYW5kbGUpIHtcbiAgICAgIHZhciBtYXRjaGVyLCBzb3J0ZXI7XG4gICAgICB2YXIgY2FuVXNlT3Bsb2cgPSBfLmFsbChbXG4gICAgICAgIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAvLyBBdCBhIGJhcmUgbWluaW11bSwgdXNpbmcgdGhlIG9wbG9nIHJlcXVpcmVzIHVzIHRvIGhhdmUgYW4gb3Bsb2csIHRvXG4gICAgICAgICAgLy8gd2FudCB1bm9yZGVyZWQgY2FsbGJhY2tzLCBhbmQgdG8gbm90IHdhbnQgYSBjYWxsYmFjayBvbiB0aGUgcG9sbHNcbiAgICAgICAgICAvLyB0aGF0IHdvbid0IGhhcHBlbi5cbiAgICAgICAgICByZXR1cm4gc2VsZi5fb3Bsb2dIYW5kbGUgJiYgIW9yZGVyZWQgJiZcbiAgICAgICAgICAgICAgIWNhbGxiYWNrcy5fdGVzdE9ubHlQb2xsQ2FsbGJhY2s7fSwgZnVuY3Rpb24gKCkge1xuICAgICAgICAvLyBXZSBhbHNvIG5lZWQgdG8gY2hlY2ssIGlmIHRoZSBjb2xsZWN0aW9uIG9mIHRoaXMgQ3Vyc29yIGlzIGFjdHVhbGx5IGJlaW5nIFwid2F0Y2hlZFwiIGJ5IHRoZSBPcGxvZyBoYW5kbGVcbiAgICAgICAgLy8gaWYgbm90LCB3ZSBoYXZlIHRvIGZhbGxiYWNrIHRvIGxvbmcgcG9sbGluZ1xuICAgICAgICBpZiAoZXhjbHVkZUNvbGxlY3Rpb25zPy5sZW5ndGggJiYgZXhjbHVkZUNvbGxlY3Rpb25zLmluY2x1ZGVzKGNvbGxlY3Rpb25OYW1lKSkge1xuICAgICAgICAgIGlmICghb3Bsb2dDb2xsZWN0aW9uV2FybmluZ3MuaW5jbHVkZXMoY29sbGVjdGlvbk5hbWUpKSB7XG4gICAgICAgICAgICBjb25zb2xlLndhcm4oYE1ldGVvci5zZXR0aW5ncy5wYWNrYWdlcy5tb25nby5vcGxvZ0V4Y2x1ZGVDb2xsZWN0aW9ucyBpbmNsdWRlcyB0aGUgY29sbGVjdGlvbiAke2NvbGxlY3Rpb25OYW1lfSAtIHlvdXIgc3Vic2NyaXB0aW9ucyB3aWxsIG9ubHkgdXNlIGxvbmcgcG9sbGluZyFgKTtcbiAgICAgICAgICAgIG9wbG9nQ29sbGVjdGlvbldhcm5pbmdzLnB1c2goY29sbGVjdGlvbk5hbWUpOyAvLyB3ZSBvbmx5IHdhbnQgdG8gc2hvdyB0aGUgd2FybmluZ3Mgb25jZSBwZXIgY29sbGVjdGlvbiFcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpbmNsdWRlQ29sbGVjdGlvbnM/Lmxlbmd0aCAmJiAhaW5jbHVkZUNvbGxlY3Rpb25zLmluY2x1ZGVzKGNvbGxlY3Rpb25OYW1lKSkge1xuICAgICAgICAgIGlmICghb3Bsb2dDb2xsZWN0aW9uV2FybmluZ3MuaW5jbHVkZXMoY29sbGVjdGlvbk5hbWUpKSB7XG4gICAgICAgICAgICBjb25zb2xlLndhcm4oYE1ldGVvci5zZXR0aW5ncy5wYWNrYWdlcy5tb25nby5vcGxvZ0luY2x1ZGVDb2xsZWN0aW9ucyBkb2VzIG5vdCBpbmNsdWRlIHRoZSBjb2xsZWN0aW9uICR7Y29sbGVjdGlvbk5hbWV9IC0geW91ciBzdWJzY3JpcHRpb25zIHdpbGwgb25seSB1c2UgbG9uZyBwb2xsaW5nIWApO1xuICAgICAgICAgICAgb3Bsb2dDb2xsZWN0aW9uV2FybmluZ3MucHVzaChjb2xsZWN0aW9uTmFtZSk7IC8vIHdlIG9ubHkgd2FudCB0byBzaG93IHRoZSB3YXJuaW5ncyBvbmNlIHBlciBjb2xsZWN0aW9uIVxuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH0sIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAvLyBXZSBuZWVkIHRvIGJlIGFibGUgdG8gY29tcGlsZSB0aGUgc2VsZWN0b3IuIEZhbGwgYmFjayB0byBwb2xsaW5nIGZvclxuICAgICAgICAgIC8vIHNvbWUgbmV3ZmFuZ2xlZCAkc2VsZWN0b3IgdGhhdCBtaW5pbW9uZ28gZG9lc24ndCBzdXBwb3J0IHlldC5cbiAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgbWF0Y2hlciA9IG5ldyBNaW5pbW9uZ28uTWF0Y2hlcihjdXJzb3JEZXNjcmlwdGlvbi5zZWxlY3Rvcik7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICAvLyBYWFggbWFrZSBhbGwgY29tcGlsYXRpb24gZXJyb3JzIE1pbmltb25nb0Vycm9yIG9yIHNvbWV0aGluZ1xuICAgICAgICAgICAgLy8gICAgIHNvIHRoYXQgdGhpcyBkb2Vzbid0IGlnbm9yZSB1bnJlbGF0ZWQgZXhjZXB0aW9uc1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgIH1cbiAgICAgICAgfSwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgIC8vIC4uLiBhbmQgdGhlIHNlbGVjdG9yIGl0c2VsZiBuZWVkcyB0byBzdXBwb3J0IG9wbG9nLlxuICAgICAgICAgIHJldHVybiBPcGxvZ09ic2VydmVEcml2ZXIuY3Vyc29yU3VwcG9ydGVkKGN1cnNvckRlc2NyaXB0aW9uLCBtYXRjaGVyKTtcbiAgICAgICAgfSwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgIC8vIEFuZCB3ZSBuZWVkIHRvIGJlIGFibGUgdG8gY29tcGlsZSB0aGUgc29ydCwgaWYgYW55LiAgZWcsIGNhbid0IGJlXG4gICAgICAgICAgLy8geyRuYXR1cmFsOiAxfS5cbiAgICAgICAgICBpZiAoIWN1cnNvckRlc2NyaXB0aW9uLm9wdGlvbnMuc29ydClcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICBzb3J0ZXIgPSBuZXcgTWluaW1vbmdvLlNvcnRlcihjdXJzb3JEZXNjcmlwdGlvbi5vcHRpb25zLnNvcnQpO1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgLy8gWFhYIG1ha2UgYWxsIGNvbXBpbGF0aW9uIGVycm9ycyBNaW5pbW9uZ29FcnJvciBvciBzb21ldGhpbmdcbiAgICAgICAgICAgIC8vICAgICBzbyB0aGF0IHRoaXMgZG9lc24ndCBpZ25vcmUgdW5yZWxhdGVkIGV4Y2VwdGlvbnNcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICB9XG4gICAgICAgIH1dLCBmdW5jdGlvbiAoZikgeyByZXR1cm4gZigpOyB9KTsgIC8vIGludm9rZSBlYWNoIGZ1bmN0aW9uXG5cbiAgICAgIHZhciBkcml2ZXJDbGFzcyA9IGNhblVzZU9wbG9nID8gT3Bsb2dPYnNlcnZlRHJpdmVyIDogUG9sbGluZ09ic2VydmVEcml2ZXI7XG4gICAgICBvYnNlcnZlRHJpdmVyID0gbmV3IGRyaXZlckNsYXNzKHtcbiAgICAgICAgY3Vyc29yRGVzY3JpcHRpb246IGN1cnNvckRlc2NyaXB0aW9uLFxuICAgICAgICBtb25nb0hhbmRsZTogc2VsZixcbiAgICAgICAgbXVsdGlwbGV4ZXI6IG11bHRpcGxleGVyLFxuICAgICAgICBvcmRlcmVkOiBvcmRlcmVkLFxuICAgICAgICBtYXRjaGVyOiBtYXRjaGVyLCAgLy8gaWdub3JlZCBieSBwb2xsaW5nXG4gICAgICAgIHNvcnRlcjogc29ydGVyLCAgLy8gaWdub3JlZCBieSBwb2xsaW5nXG4gICAgICAgIF90ZXN0T25seVBvbGxDYWxsYmFjazogY2FsbGJhY2tzLl90ZXN0T25seVBvbGxDYWxsYmFja1xuICAgICAgfSk7XG5cbiAgICAgIGlmIChvYnNlcnZlRHJpdmVyLl9pbml0KSB7XG4gICAgICAgIGF3YWl0IG9ic2VydmVEcml2ZXIuX2luaXQoKTtcbiAgICAgIH1cblxuICAgICAgLy8gVGhpcyBmaWVsZCBpcyBvbmx5IHNldCBmb3IgdXNlIGluIHRlc3RzLlxuICAgICAgbXVsdGlwbGV4ZXIuX29ic2VydmVEcml2ZXIgPSBvYnNlcnZlRHJpdmVyO1xuICAgIH1cbiAgICBzZWxmLl9vYnNlcnZlTXVsdGlwbGV4ZXJzW29ic2VydmVLZXldID0gbXVsdGlwbGV4ZXI7XG4gICAgLy8gQmxvY2tzIHVudGlsIHRoZSBpbml0aWFsIGFkZHMgaGF2ZSBiZWVuIHNlbnQuXG4gICAgYXdhaXQgbXVsdGlwbGV4ZXIuYWRkSGFuZGxlQW5kU2VuZEluaXRpYWxBZGRzKG9ic2VydmVIYW5kbGUpO1xuXG4gICAgcmV0dXJuIG9ic2VydmVIYW5kbGU7XG4gIH0sXG5cbn0pO1xuXG5cbi8vIExpc3RlbiBmb3IgdGhlIGludmFsaWRhdGlvbiBtZXNzYWdlcyB0aGF0IHdpbGwgdHJpZ2dlciB1cyB0byBwb2xsIHRoZVxuLy8gZGF0YWJhc2UgZm9yIGNoYW5nZXMuIElmIHRoaXMgc2VsZWN0b3Igc3BlY2lmaWVzIHNwZWNpZmljIElEcywgc3BlY2lmeSB0aGVtXG4vLyBoZXJlLCBzbyB0aGF0IHVwZGF0ZXMgdG8gZGlmZmVyZW50IHNwZWNpZmljIElEcyBkb24ndCBjYXVzZSB1cyB0byBwb2xsLlxuLy8gbGlzdGVuQ2FsbGJhY2sgaXMgdGhlIHNhbWUga2luZCBvZiAobm90aWZpY2F0aW9uLCBjb21wbGV0ZSkgY2FsbGJhY2sgcGFzc2VkXG4vLyB0byBJbnZhbGlkYXRpb25Dcm9zc2Jhci5saXN0ZW4uXG5cbmxpc3RlbkFsbCA9IGFzeW5jIGZ1bmN0aW9uIChjdXJzb3JEZXNjcmlwdGlvbiwgbGlzdGVuQ2FsbGJhY2spIHtcbiAgY29uc3QgbGlzdGVuZXJzID0gW107XG4gIGF3YWl0IGZvckVhY2hUcmlnZ2VyKGN1cnNvckRlc2NyaXB0aW9uLCBmdW5jdGlvbiAodHJpZ2dlcikge1xuICAgIGxpc3RlbmVycy5wdXNoKEREUFNlcnZlci5fSW52YWxpZGF0aW9uQ3Jvc3NiYXIubGlzdGVuKFxuICAgICAgdHJpZ2dlciwgbGlzdGVuQ2FsbGJhY2spKTtcbiAgfSk7XG5cbiAgcmV0dXJuIHtcbiAgICBzdG9wOiBmdW5jdGlvbiAoKSB7XG4gICAgICBfLmVhY2gobGlzdGVuZXJzLCBmdW5jdGlvbiAobGlzdGVuZXIpIHtcbiAgICAgICAgbGlzdGVuZXIuc3RvcCgpO1xuICAgICAgfSk7XG4gICAgfVxuICB9O1xufTtcblxuZm9yRWFjaFRyaWdnZXIgPSBhc3luYyBmdW5jdGlvbiAoY3Vyc29yRGVzY3JpcHRpb24sIHRyaWdnZXJDYWxsYmFjaykge1xuICBjb25zdCBrZXkgPSB7Y29sbGVjdGlvbjogY3Vyc29yRGVzY3JpcHRpb24uY29sbGVjdGlvbk5hbWV9O1xuICBjb25zdCBzcGVjaWZpY0lkcyA9IExvY2FsQ29sbGVjdGlvbi5faWRzTWF0Y2hlZEJ5U2VsZWN0b3IoXG4gICAgY3Vyc29yRGVzY3JpcHRpb24uc2VsZWN0b3IpO1xuICBpZiAoc3BlY2lmaWNJZHMpIHtcbiAgICBmb3IgKGNvbnN0IGlkIG9mIHNwZWNpZmljSWRzKSB7XG4gICAgICBhd2FpdCB0cmlnZ2VyQ2FsbGJhY2soXy5leHRlbmQoe2lkOiBpZH0sIGtleSkpO1xuICAgIH1cbiAgICBhd2FpdCB0cmlnZ2VyQ2FsbGJhY2soXy5leHRlbmQoe2Ryb3BDb2xsZWN0aW9uOiB0cnVlLCBpZDogbnVsbH0sIGtleSkpO1xuICB9IGVsc2Uge1xuICAgIGF3YWl0IHRyaWdnZXJDYWxsYmFjayhrZXkpO1xuICB9XG4gIC8vIEV2ZXJ5b25lIGNhcmVzIGFib3V0IHRoZSBkYXRhYmFzZSBiZWluZyBkcm9wcGVkLlxuICBhd2FpdCB0cmlnZ2VyQ2FsbGJhY2soeyBkcm9wRGF0YWJhc2U6IHRydWUgfSk7XG59O1xuXG4vLyBvYnNlcnZlQ2hhbmdlcyBmb3IgdGFpbGFibGUgY3Vyc29ycyBvbiBjYXBwZWQgY29sbGVjdGlvbnMuXG4vL1xuLy8gU29tZSBkaWZmZXJlbmNlcyBmcm9tIG5vcm1hbCBjdXJzb3JzOlxuLy8gICAtIFdpbGwgbmV2ZXIgcHJvZHVjZSBhbnl0aGluZyBvdGhlciB0aGFuICdhZGRlZCcgb3IgJ2FkZGVkQmVmb3JlJy4gSWYgeW91XG4vLyAgICAgZG8gdXBkYXRlIGEgZG9jdW1lbnQgdGhhdCBoYXMgYWxyZWFkeSBiZWVuIHByb2R1Y2VkLCB0aGlzIHdpbGwgbm90IG5vdGljZVxuLy8gICAgIGl0LlxuLy8gICAtIElmIHlvdSBkaXNjb25uZWN0IGFuZCByZWNvbm5lY3QgZnJvbSBNb25nbywgaXQgd2lsbCBlc3NlbnRpYWxseSByZXN0YXJ0XG4vLyAgICAgdGhlIHF1ZXJ5LCB3aGljaCB3aWxsIGxlYWQgdG8gZHVwbGljYXRlIHJlc3VsdHMuIFRoaXMgaXMgcHJldHR5IGJhZCxcbi8vICAgICBidXQgaWYgeW91IGluY2x1ZGUgYSBmaWVsZCBjYWxsZWQgJ3RzJyB3aGljaCBpcyBpbnNlcnRlZCBhc1xuLy8gICAgIG5ldyBNb25nb0ludGVybmFscy5Nb25nb1RpbWVzdGFtcCgwLCAwKSAod2hpY2ggaXMgaW5pdGlhbGl6ZWQgdG8gdGhlXG4vLyAgICAgY3VycmVudCBNb25nby1zdHlsZSB0aW1lc3RhbXApLCB3ZSdsbCBiZSBhYmxlIHRvIGZpbmQgdGhlIHBsYWNlIHRvXG4vLyAgICAgcmVzdGFydCBwcm9wZXJseS4gKFRoaXMgZmllbGQgaXMgc3BlY2lmaWNhbGx5IHVuZGVyc3Rvb2QgYnkgTW9uZ28gd2l0aCBhblxuLy8gICAgIG9wdGltaXphdGlvbiB3aGljaCBhbGxvd3MgaXQgdG8gZmluZCB0aGUgcmlnaHQgcGxhY2UgdG8gc3RhcnQgd2l0aG91dFxuLy8gICAgIGFuIGluZGV4IG9uIHRzLiBJdCdzIGhvdyB0aGUgb3Bsb2cgd29ya3MuKVxuLy8gICAtIE5vIGNhbGxiYWNrcyBhcmUgdHJpZ2dlcmVkIHN5bmNocm9ub3VzbHkgd2l0aCB0aGUgY2FsbCAodGhlcmUncyBub1xuLy8gICAgIGRpZmZlcmVudGlhdGlvbiBiZXR3ZWVuIFwiaW5pdGlhbCBkYXRhXCIgYW5kIFwibGF0ZXIgY2hhbmdlc1wiOyBldmVyeXRoaW5nXG4vLyAgICAgdGhhdCBtYXRjaGVzIHRoZSBxdWVyeSBnZXRzIHNlbnQgYXN5bmNocm9ub3VzbHkpLlxuLy8gICAtIERlLWR1cGxpY2F0aW9uIGlzIG5vdCBpbXBsZW1lbnRlZC5cbi8vICAgLSBEb2VzIG5vdCB5ZXQgaW50ZXJhY3Qgd2l0aCB0aGUgd3JpdGUgZmVuY2UuIFByb2JhYmx5LCB0aGlzIHNob3VsZCB3b3JrIGJ5XG4vLyAgICAgaWdub3JpbmcgcmVtb3ZlcyAod2hpY2ggZG9uJ3Qgd29yayBvbiBjYXBwZWQgY29sbGVjdGlvbnMpIGFuZCB1cGRhdGVzXG4vLyAgICAgKHdoaWNoIGRvbid0IGFmZmVjdCB0YWlsYWJsZSBjdXJzb3JzKSwgYW5kIGp1c3Qga2VlcGluZyB0cmFjayBvZiB0aGUgSURcbi8vICAgICBvZiB0aGUgaW5zZXJ0ZWQgb2JqZWN0LCBhbmQgY2xvc2luZyB0aGUgd3JpdGUgZmVuY2Ugb25jZSB5b3UgZ2V0IHRvIHRoYXRcbi8vICAgICBJRCAob3IgdGltZXN0YW1wPykuICBUaGlzIGRvZXNuJ3Qgd29yayB3ZWxsIGlmIHRoZSBkb2N1bWVudCBkb2Vzbid0IG1hdGNoXG4vLyAgICAgdGhlIHF1ZXJ5LCB0aG91Z2guICBPbiB0aGUgb3RoZXIgaGFuZCwgdGhlIHdyaXRlIGZlbmNlIGNhbiBjbG9zZVxuLy8gICAgIGltbWVkaWF0ZWx5IGlmIGl0IGRvZXMgbm90IG1hdGNoIHRoZSBxdWVyeS4gU28gaWYgd2UgdHJ1c3QgbWluaW1vbmdvXG4vLyAgICAgZW5vdWdoIHRvIGFjY3VyYXRlbHkgZXZhbHVhdGUgdGhlIHF1ZXJ5IGFnYWluc3QgdGhlIHdyaXRlIGZlbmNlLCB3ZVxuLy8gICAgIHNob3VsZCBiZSBhYmxlIHRvIGRvIHRoaXMuLi4gIE9mIGNvdXJzZSwgbWluaW1vbmdvIGRvZXNuJ3QgZXZlbiBzdXBwb3J0XG4vLyAgICAgTW9uZ28gVGltZXN0YW1wcyB5ZXQuXG5Nb25nb0Nvbm5lY3Rpb24ucHJvdG90eXBlLl9vYnNlcnZlQ2hhbmdlc1RhaWxhYmxlID0gZnVuY3Rpb24gKFxuICAgIGN1cnNvckRlc2NyaXB0aW9uLCBvcmRlcmVkLCBjYWxsYmFja3MpIHtcbiAgdmFyIHNlbGYgPSB0aGlzO1xuXG4gIC8vIFRhaWxhYmxlIGN1cnNvcnMgb25seSBldmVyIGNhbGwgYWRkZWQvYWRkZWRCZWZvcmUgY2FsbGJhY2tzLCBzbyBpdCdzIGFuXG4gIC8vIGVycm9yIGlmIHlvdSBkaWRuJ3QgcHJvdmlkZSB0aGVtLlxuICBpZiAoKG9yZGVyZWQgJiYgIWNhbGxiYWNrcy5hZGRlZEJlZm9yZSkgfHxcbiAgICAgICghb3JkZXJlZCAmJiAhY2FsbGJhY2tzLmFkZGVkKSkge1xuICAgIHRocm93IG5ldyBFcnJvcihcIkNhbid0IG9ic2VydmUgYW4gXCIgKyAob3JkZXJlZCA/IFwib3JkZXJlZFwiIDogXCJ1bm9yZGVyZWRcIilcbiAgICAgICAgICAgICAgICAgICAgKyBcIiB0YWlsYWJsZSBjdXJzb3Igd2l0aG91dCBhIFwiXG4gICAgICAgICAgICAgICAgICAgICsgKG9yZGVyZWQgPyBcImFkZGVkQmVmb3JlXCIgOiBcImFkZGVkXCIpICsgXCIgY2FsbGJhY2tcIik7XG4gIH1cblxuICByZXR1cm4gc2VsZi50YWlsKGN1cnNvckRlc2NyaXB0aW9uLCBmdW5jdGlvbiAoZG9jKSB7XG4gICAgdmFyIGlkID0gZG9jLl9pZDtcbiAgICBkZWxldGUgZG9jLl9pZDtcbiAgICAvLyBUaGUgdHMgaXMgYW4gaW1wbGVtZW50YXRpb24gZGV0YWlsLiBIaWRlIGl0LlxuICAgIGRlbGV0ZSBkb2MudHM7XG4gICAgaWYgKG9yZGVyZWQpIHtcbiAgICAgIGNhbGxiYWNrcy5hZGRlZEJlZm9yZShpZCwgZG9jLCBudWxsKTtcbiAgICB9IGVsc2Uge1xuICAgICAgY2FsbGJhY2tzLmFkZGVkKGlkLCBkb2MpO1xuICAgIH1cbiAgfSk7XG59O1xuXG4vLyBYWFggV2UgcHJvYmFibHkgbmVlZCB0byBmaW5kIGEgYmV0dGVyIHdheSB0byBleHBvc2UgdGhpcy4gUmlnaHQgbm93XG4vLyBpdCdzIG9ubHkgdXNlZCBieSB0ZXN0cywgYnV0IGluIGZhY3QgeW91IG5lZWQgaXQgaW4gbm9ybWFsXG4vLyBvcGVyYXRpb24gdG8gaW50ZXJhY3Qgd2l0aCBjYXBwZWQgY29sbGVjdGlvbnMuXG5Nb25nb0ludGVybmFscy5Nb25nb1RpbWVzdGFtcCA9IE1vbmdvREIuVGltZXN0YW1wO1xuXG5Nb25nb0ludGVybmFscy5Db25uZWN0aW9uID0gTW9uZ29Db25uZWN0aW9uO1xuIiwiaW1wb3J0IHsgTnBtTW9kdWxlTW9uZ29kYiB9IGZyb20gXCJtZXRlb3IvbnBtLW1vbmdvXCI7XG5jb25zdCB7IExvbmcgfSA9IE5wbU1vZHVsZU1vbmdvZGI7XG5cbk9QTE9HX0NPTExFQ1RJT04gPSAnb3Bsb2cucnMnO1xuXG52YXIgVE9PX0ZBUl9CRUhJTkQgPSBwcm9jZXNzLmVudi5NRVRFT1JfT1BMT0dfVE9PX0ZBUl9CRUhJTkQgfHwgMjAwMDtcbnZhciBUQUlMX1RJTUVPVVQgPSArcHJvY2Vzcy5lbnYuTUVURU9SX09QTE9HX1RBSUxfVElNRU9VVCB8fCAzMDAwMDtcblxuaWRGb3JPcCA9IGZ1bmN0aW9uIChvcCkge1xuICBpZiAob3Aub3AgPT09ICdkJylcbiAgICByZXR1cm4gb3Auby5faWQ7XG4gIGVsc2UgaWYgKG9wLm9wID09PSAnaScpXG4gICAgcmV0dXJuIG9wLm8uX2lkO1xuICBlbHNlIGlmIChvcC5vcCA9PT0gJ3UnKVxuICAgIHJldHVybiBvcC5vMi5faWQ7XG4gIGVsc2UgaWYgKG9wLm9wID09PSAnYycpXG4gICAgdGhyb3cgRXJyb3IoXCJPcGVyYXRvciAnYycgZG9lc24ndCBzdXBwbHkgYW4gb2JqZWN0IHdpdGggaWQ6IFwiICtcbiAgICAgICAgICAgICAgICBFSlNPTi5zdHJpbmdpZnkob3ApKTtcbiAgZWxzZVxuICAgIHRocm93IEVycm9yKFwiVW5rbm93biBvcDogXCIgKyBFSlNPTi5zdHJpbmdpZnkob3ApKTtcbn07XG5cbk9wbG9nSGFuZGxlID0gZnVuY3Rpb24gKG9wbG9nVXJsLCBkYk5hbWUpIHtcbiAgdmFyIHNlbGYgPSB0aGlzO1xuICBzZWxmLl9vcGxvZ1VybCA9IG9wbG9nVXJsO1xuICBzZWxmLl9kYk5hbWUgPSBkYk5hbWU7XG5cbiAgc2VsZi5fb3Bsb2dMYXN0RW50cnlDb25uZWN0aW9uID0gbnVsbDtcbiAgc2VsZi5fb3Bsb2dUYWlsQ29ubmVjdGlvbiA9IG51bGw7XG4gIHNlbGYuX29wbG9nT3B0aW9ucyA9IG51bGw7XG4gIHNlbGYuX3N0b3BwZWQgPSBmYWxzZTtcbiAgc2VsZi5fdGFpbEhhbmRsZSA9IG51bGw7XG4gIHNlbGYuX3JlYWR5UHJvbWlzZVJlc29sdmVyID0gbnVsbDtcbiAgc2VsZi5fcmVhZHlQcm9taXNlID0gbmV3IFByb21pc2UociA9PiBzZWxmLl9yZWFkeVByb21pc2VSZXNvbHZlciA9IHIpO1xuICBzZWxmLl9jcm9zc2JhciA9IG5ldyBERFBTZXJ2ZXIuX0Nyb3NzYmFyKHtcbiAgICBmYWN0UGFja2FnZTogXCJtb25nby1saXZlZGF0YVwiLCBmYWN0TmFtZTogXCJvcGxvZy13YXRjaGVyc1wiXG4gIH0pO1xuICBzZWxmLl9iYXNlT3Bsb2dTZWxlY3RvciA9IHtcbiAgICBuczogbmV3IFJlZ0V4cChcIl4oPzpcIiArIFtcbiAgICAgIE1ldGVvci5fZXNjYXBlUmVnRXhwKHNlbGYuX2RiTmFtZSArIFwiLlwiKSxcbiAgICAgIE1ldGVvci5fZXNjYXBlUmVnRXhwKFwiYWRtaW4uJGNtZFwiKSxcbiAgICBdLmpvaW4oXCJ8XCIpICsgXCIpXCIpLFxuXG4gICAgJG9yOiBbXG4gICAgICB7IG9wOiB7ICRpbjogWydpJywgJ3UnLCAnZCddIH0gfSxcbiAgICAgIC8vIGRyb3AgY29sbGVjdGlvblxuICAgICAgeyBvcDogJ2MnLCAnby5kcm9wJzogeyAkZXhpc3RzOiB0cnVlIH0gfSxcbiAgICAgIHsgb3A6ICdjJywgJ28uZHJvcERhdGFiYXNlJzogMSB9LFxuICAgICAgeyBvcDogJ2MnLCAnby5hcHBseU9wcyc6IHsgJGV4aXN0czogdHJ1ZSB9IH0sXG4gICAgXVxuICB9O1xuXG4gIC8vIERhdGEgc3RydWN0dXJlcyB0byBzdXBwb3J0IHdhaXRVbnRpbENhdWdodFVwKCkuIEVhY2ggb3Bsb2cgZW50cnkgaGFzIGFcbiAgLy8gTW9uZ29UaW1lc3RhbXAgb2JqZWN0IG9uIGl0ICh3aGljaCBpcyBub3QgdGhlIHNhbWUgYXMgYSBEYXRlIC0tLSBpdCdzIGFcbiAgLy8gY29tYmluYXRpb24gb2YgdGltZSBhbmQgYW4gaW5jcmVtZW50aW5nIGNvdW50ZXI7IHNlZVxuICAvLyBodHRwOi8vZG9jcy5tb25nb2RiLm9yZy9tYW51YWwvcmVmZXJlbmNlL2Jzb24tdHlwZXMvI3RpbWVzdGFtcHMpLlxuICAvL1xuICAvLyBfY2F0Y2hpbmdVcEZ1dHVyZXMgaXMgYW4gYXJyYXkgb2Yge3RzOiBNb25nb1RpbWVzdGFtcCwgZnV0dXJlOiBGdXR1cmV9XG4gIC8vIG9iamVjdHMsIHNvcnRlZCBieSBhc2NlbmRpbmcgdGltZXN0YW1wLiBfbGFzdFByb2Nlc3NlZFRTIGlzIHRoZVxuICAvLyBNb25nb1RpbWVzdGFtcCBvZiB0aGUgbGFzdCBvcGxvZyBlbnRyeSB3ZSd2ZSBwcm9jZXNzZWQuXG4gIC8vXG4gIC8vIEVhY2ggdGltZSB3ZSBjYWxsIHdhaXRVbnRpbENhdWdodFVwLCB3ZSB0YWtlIGEgcGVlayBhdCB0aGUgZmluYWwgb3Bsb2dcbiAgLy8gZW50cnkgaW4gdGhlIGRiLiAgSWYgd2UndmUgYWxyZWFkeSBwcm9jZXNzZWQgaXQgKGllLCBpdCBpcyBub3QgZ3JlYXRlciB0aGFuXG4gIC8vIF9sYXN0UHJvY2Vzc2VkVFMpLCB3YWl0VW50aWxDYXVnaHRVcCBpbW1lZGlhdGVseSByZXR1cm5zLiBPdGhlcndpc2UsXG4gIC8vIHdhaXRVbnRpbENhdWdodFVwIG1ha2VzIGEgbmV3IEZ1dHVyZSBhbmQgaW5zZXJ0cyBpdCBhbG9uZyB3aXRoIHRoZSBmaW5hbFxuICAvLyB0aW1lc3RhbXAgZW50cnkgdGhhdCBpdCByZWFkLCBpbnRvIF9jYXRjaGluZ1VwRnV0dXJlcy4gd2FpdFVudGlsQ2F1Z2h0VXBcbiAgLy8gdGhlbiB3YWl0cyBvbiB0aGF0IGZ1dHVyZSwgd2hpY2ggaXMgcmVzb2x2ZWQgb25jZSBfbGFzdFByb2Nlc3NlZFRTIGlzXG4gIC8vIGluY3JlbWVudGVkIHRvIGJlIHBhc3QgaXRzIHRpbWVzdGFtcCBieSB0aGUgd29ya2VyIGZpYmVyLlxuICAvL1xuICAvLyBYWFggdXNlIGEgcHJpb3JpdHkgcXVldWUgb3Igc29tZXRoaW5nIGVsc2UgdGhhdCdzIGZhc3RlciB0aGFuIGFuIGFycmF5XG4gIHNlbGYuX2NhdGNoaW5nVXBSZXNvbHZlcnMgPSBbXTtcbiAgc2VsZi5fbGFzdFByb2Nlc3NlZFRTID0gbnVsbDtcblxuICBzZWxmLl9vblNraXBwZWRFbnRyaWVzSG9vayA9IG5ldyBIb29rKHtcbiAgICBkZWJ1Z1ByaW50RXhjZXB0aW9uczogXCJvblNraXBwZWRFbnRyaWVzIGNhbGxiYWNrXCJcbiAgfSk7XG5cbiAgc2VsZi5fZW50cnlRdWV1ZSA9IG5ldyBNZXRlb3IuX0RvdWJsZUVuZGVkUXVldWUoKTtcbiAgc2VsZi5fd29ya2VyQWN0aXZlID0gZmFsc2U7XG5cbiAgc2VsZi5fc3RhcnRUcmFpbGluZ1Byb21pc2UgPSBzZWxmLl9zdGFydFRhaWxpbmcoKTtcbiAgLy9UT0RPW2ZpYmVyc10gV2h5IHdhaXQ/XG59O1xuXG5Nb25nb0ludGVybmFscy5PcGxvZ0hhbmRsZSA9IE9wbG9nSGFuZGxlO1xuXG5PYmplY3QuYXNzaWduKE9wbG9nSGFuZGxlLnByb3RvdHlwZSwge1xuICBzdG9wOiBhc3luYyBmdW5jdGlvbiAoKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgIGlmIChzZWxmLl9zdG9wcGVkKVxuICAgICAgcmV0dXJuO1xuICAgIHNlbGYuX3N0b3BwZWQgPSB0cnVlO1xuICAgIGlmIChzZWxmLl90YWlsSGFuZGxlKVxuICAgICAgYXdhaXQgc2VsZi5fdGFpbEhhbmRsZS5zdG9wKCk7XG4gICAgLy8gWFhYIHNob3VsZCBjbG9zZSBjb25uZWN0aW9ucyB0b29cbiAgfSxcbiAgX29uT3Bsb2dFbnRyeTogYXN5bmMgZnVuY3Rpb24odHJpZ2dlciwgY2FsbGJhY2spIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgaWYgKHNlbGYuX3N0b3BwZWQpXG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJDYWxsZWQgb25PcGxvZ0VudHJ5IG9uIHN0b3BwZWQgaGFuZGxlIVwiKTtcblxuICAgIC8vIENhbGxpbmcgb25PcGxvZ0VudHJ5IHJlcXVpcmVzIHVzIHRvIHdhaXQgZm9yIHRoZSB0YWlsaW5nIHRvIGJlIHJlYWR5LlxuICAgIGF3YWl0IHNlbGYuX3JlYWR5UHJvbWlzZTtcblxuICAgIHZhciBvcmlnaW5hbENhbGxiYWNrID0gY2FsbGJhY2s7XG4gICAgY2FsbGJhY2sgPSBNZXRlb3IuYmluZEVudmlyb25tZW50KGZ1bmN0aW9uIChub3RpZmljYXRpb24pIHtcbiAgICAgIG9yaWdpbmFsQ2FsbGJhY2sobm90aWZpY2F0aW9uKTtcbiAgICB9LCBmdW5jdGlvbiAoZXJyKSB7XG4gICAgICBNZXRlb3IuX2RlYnVnKFwiRXJyb3IgaW4gb3Bsb2cgY2FsbGJhY2tcIiwgZXJyKTtcbiAgICB9KTtcbiAgICB2YXIgbGlzdGVuSGFuZGxlID0gc2VsZi5fY3Jvc3NiYXIubGlzdGVuKHRyaWdnZXIsIGNhbGxiYWNrKTtcbiAgICByZXR1cm4ge1xuICAgICAgc3RvcDogYXN5bmMgZnVuY3Rpb24gKCkge1xuICAgICAgICBhd2FpdCBsaXN0ZW5IYW5kbGUuc3RvcCgpO1xuICAgICAgfVxuICAgIH07XG4gIH0sXG4gIG9uT3Bsb2dFbnRyeTogZnVuY3Rpb24gKHRyaWdnZXIsIGNhbGxiYWNrKSB7XG4gICAgcmV0dXJuIHRoaXMuX29uT3Bsb2dFbnRyeSh0cmlnZ2VyLCBjYWxsYmFjayk7XG4gIH0sXG4gIC8vIFJlZ2lzdGVyIGEgY2FsbGJhY2sgdG8gYmUgaW52b2tlZCBhbnkgdGltZSB3ZSBza2lwIG9wbG9nIGVudHJpZXMgKGVnLFxuICAvLyBiZWNhdXNlIHdlIGFyZSB0b28gZmFyIGJlaGluZCkuXG4gIG9uU2tpcHBlZEVudHJpZXM6IGZ1bmN0aW9uIChjYWxsYmFjaykge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICBpZiAoc2VsZi5fc3RvcHBlZClcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIkNhbGxlZCBvblNraXBwZWRFbnRyaWVzIG9uIHN0b3BwZWQgaGFuZGxlIVwiKTtcbiAgICByZXR1cm4gc2VsZi5fb25Ta2lwcGVkRW50cmllc0hvb2sucmVnaXN0ZXIoY2FsbGJhY2spO1xuICB9LFxuXG4gIGFzeW5jIF93YWl0VW50aWxDYXVnaHRVcCgpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgaWYgKHNlbGYuX3N0b3BwZWQpXG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJDYWxsZWQgd2FpdFVudGlsQ2F1Z2h0VXAgb24gc3RvcHBlZCBoYW5kbGUhXCIpO1xuXG4gICAgLy8gQ2FsbGluZyB3YWl0VW50aWxDYXVnaHRVcCByZXF1cmllcyB1cyB0byB3YWl0IGZvciB0aGUgb3Bsb2cgY29ubmVjdGlvbiB0b1xuICAgIC8vIGJlIHJlYWR5LlxuICAgIGF3YWl0IHNlbGYuX3JlYWR5UHJvbWlzZTtcbiAgICB2YXIgbGFzdEVudHJ5O1xuXG4gICAgd2hpbGUgKCFzZWxmLl9zdG9wcGVkKSB7XG4gICAgICAvLyBXZSBuZWVkIHRvIG1ha2UgdGhlIHNlbGVjdG9yIGF0IGxlYXN0IGFzIHJlc3RyaWN0aXZlIGFzIHRoZSBhY3R1YWxcbiAgICAgIC8vIHRhaWxpbmcgc2VsZWN0b3IgKGllLCB3ZSBuZWVkIHRvIHNwZWNpZnkgdGhlIERCIG5hbWUpIG9yIGVsc2Ugd2UgbWlnaHRcbiAgICAgIC8vIGZpbmQgYSBUUyB0aGF0IHdvbid0IHNob3cgdXAgaW4gdGhlIGFjdHVhbCB0YWlsIHN0cmVhbS5cbiAgICAgIHRyeSB7XG4gICAgICAgIGxhc3RFbnRyeSA9IGF3YWl0IHNlbGYuX29wbG9nTGFzdEVudHJ5Q29ubmVjdGlvbi5maW5kT25lQXN5bmMoXG4gICAgICAgICAgT1BMT0dfQ09MTEVDVElPTixcbiAgICAgICAgICBzZWxmLl9iYXNlT3Bsb2dTZWxlY3RvcixcbiAgICAgICAgICB7IHByb2plY3Rpb246IHsgdHM6IDEgfSwgc29ydDogeyAkbmF0dXJhbDogLTEgfSB9XG4gICAgICAgICk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAvLyBEdXJpbmcgZmFpbG92ZXIgKGVnKSBpZiB3ZSBnZXQgYW4gZXhjZXB0aW9uIHdlIHNob3VsZCBsb2cgYW5kIHJldHJ5XG4gICAgICAgIC8vIGluc3RlYWQgb2YgY3Jhc2hpbmcuXG4gICAgICAgIE1ldGVvci5fZGVidWcoXCJHb3QgZXhjZXB0aW9uIHdoaWxlIHJlYWRpbmcgbGFzdCBlbnRyeVwiLCBlKTtcbiAgICAgICAgYXdhaXQgTWV0ZW9yLl9zbGVlcEZvck1zKDEwMCk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKHNlbGYuX3N0b3BwZWQpXG4gICAgICByZXR1cm47XG5cbiAgICBpZiAoIWxhc3RFbnRyeSkge1xuICAgICAgLy8gUmVhbGx5LCBub3RoaW5nIGluIHRoZSBvcGxvZz8gV2VsbCwgd2UndmUgcHJvY2Vzc2VkIGV2ZXJ5dGhpbmcuXG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgdmFyIHRzID0gbGFzdEVudHJ5LnRzO1xuICAgIGlmICghdHMpXG4gICAgICB0aHJvdyBFcnJvcihcIm9wbG9nIGVudHJ5IHdpdGhvdXQgdHM6IFwiICsgRUpTT04uc3RyaW5naWZ5KGxhc3RFbnRyeSkpO1xuXG4gICAgaWYgKHNlbGYuX2xhc3RQcm9jZXNzZWRUUyAmJiB0cy5sZXNzVGhhbk9yRXF1YWwoc2VsZi5fbGFzdFByb2Nlc3NlZFRTKSkge1xuICAgICAgLy8gV2UndmUgYWxyZWFkeSBjYXVnaHQgdXAgdG8gaGVyZS5cbiAgICAgIHJldHVybjtcbiAgICB9XG5cblxuICAgIC8vIEluc2VydCB0aGUgZnV0dXJlIGludG8gb3VyIGxpc3QuIEFsbW9zdCBhbHdheXMsIHRoaXMgd2lsbCBiZSBhdCB0aGUgZW5kLFxuICAgIC8vIGJ1dCBpdCdzIGNvbmNlaXZhYmxlIHRoYXQgaWYgd2UgZmFpbCBvdmVyIGZyb20gb25lIHByaW1hcnkgdG8gYW5vdGhlcixcbiAgICAvLyB0aGUgb3Bsb2cgZW50cmllcyB3ZSBzZWUgd2lsbCBnbyBiYWNrd2FyZHMuXG4gICAgdmFyIGluc2VydEFmdGVyID0gc2VsZi5fY2F0Y2hpbmdVcFJlc29sdmVycy5sZW5ndGg7XG4gICAgd2hpbGUgKGluc2VydEFmdGVyIC0gMSA+IDAgJiYgc2VsZi5fY2F0Y2hpbmdVcFJlc29sdmVyc1tpbnNlcnRBZnRlciAtIDFdLnRzLmdyZWF0ZXJUaGFuKHRzKSkge1xuICAgICAgaW5zZXJ0QWZ0ZXItLTtcbiAgICB9XG4gICAgbGV0IHByb21pc2VSZXNvbHZlciA9IG51bGw7XG4gICAgY29uc3QgcHJvbWlzZVRvQXdhaXQgPSBuZXcgUHJvbWlzZShyID0+IHByb21pc2VSZXNvbHZlciA9IHIpO1xuICAgIHNlbGYuX2NhdGNoaW5nVXBSZXNvbHZlcnMuc3BsaWNlKGluc2VydEFmdGVyLCAwLCB7dHM6IHRzLCByZXNvbHZlcjogcHJvbWlzZVJlc29sdmVyfSk7XG4gICAgYXdhaXQgcHJvbWlzZVRvQXdhaXQ7XG4gIH0sXG5cbiAgLy8gQ2FsbHMgYGNhbGxiYWNrYCBvbmNlIHRoZSBvcGxvZyBoYXMgYmVlbiBwcm9jZXNzZWQgdXAgdG8gYSBwb2ludCB0aGF0IGlzXG4gIC8vIHJvdWdobHkgXCJub3dcIjogc3BlY2lmaWNhbGx5LCBvbmNlIHdlJ3ZlIHByb2Nlc3NlZCBhbGwgb3BzIHRoYXQgYXJlXG4gIC8vIGN1cnJlbnRseSB2aXNpYmxlLlxuICAvLyBYWFggYmVjb21lIGNvbnZpbmNlZCB0aGF0IHRoaXMgaXMgYWN0dWFsbHkgc2FmZSBldmVuIGlmIG9wbG9nQ29ubmVjdGlvblxuICAvLyBpcyBzb21lIGtpbmQgb2YgcG9vbFxuICB3YWl0VW50aWxDYXVnaHRVcDogYXN5bmMgZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiB0aGlzLl93YWl0VW50aWxDYXVnaHRVcCgpO1xuICB9LFxuXG4gIF9zdGFydFRhaWxpbmc6IGFzeW5jIGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgLy8gRmlyc3QsIG1ha2Ugc3VyZSB0aGF0IHdlJ3JlIHRhbGtpbmcgdG8gdGhlIGxvY2FsIGRhdGFiYXNlLlxuICAgIHZhciBtb25nb2RiVXJpID0gTnBtLnJlcXVpcmUoJ21vbmdvZGItdXJpJyk7XG4gICAgaWYgKG1vbmdvZGJVcmkucGFyc2Uoc2VsZi5fb3Bsb2dVcmwpLmRhdGFiYXNlICE9PSAnbG9jYWwnKSB7XG4gICAgICB0aHJvdyBFcnJvcihcIiRNT05HT19PUExPR19VUkwgbXVzdCBiZSBzZXQgdG8gdGhlICdsb2NhbCcgZGF0YWJhc2Ugb2YgXCIgK1xuICAgICAgICAgIFwiYSBNb25nbyByZXBsaWNhIHNldFwiKTtcbiAgICB9XG5cbiAgICAvLyBXZSBtYWtlIHR3byBzZXBhcmF0ZSBjb25uZWN0aW9ucyB0byBNb25nby4gVGhlIE5vZGUgTW9uZ28gZHJpdmVyXG4gICAgLy8gaW1wbGVtZW50cyBhIG5haXZlIHJvdW5kLXJvYmluIGNvbm5lY3Rpb24gcG9vbDogZWFjaCBcImNvbm5lY3Rpb25cIiBpcyBhXG4gICAgLy8gcG9vbCBvZiBzZXZlcmFsICg1IGJ5IGRlZmF1bHQpIFRDUCBjb25uZWN0aW9ucywgYW5kIGVhY2ggcmVxdWVzdCBpc1xuICAgIC8vIHJvdGF0ZWQgdGhyb3VnaCB0aGUgcG9vbHMuIFRhaWxhYmxlIGN1cnNvciBxdWVyaWVzIGJsb2NrIG9uIHRoZSBzZXJ2ZXJcbiAgICAvLyB1bnRpbCB0aGVyZSBpcyBzb21lIGRhdGEgdG8gcmV0dXJuIChvciB1bnRpbCBhIGZldyBzZWNvbmRzIGhhdmVcbiAgICAvLyBwYXNzZWQpLiBTbyBpZiB0aGUgY29ubmVjdGlvbiBwb29sIHVzZWQgZm9yIHRhaWxpbmcgY3Vyc29ycyBpcyB0aGUgc2FtZVxuICAgIC8vIHBvb2wgdXNlZCBmb3Igb3RoZXIgcXVlcmllcywgdGhlIG90aGVyIHF1ZXJpZXMgd2lsbCBiZSBkZWxheWVkIGJ5IHNlY29uZHNcbiAgICAvLyAxLzUgb2YgdGhlIHRpbWUuXG4gICAgLy9cbiAgICAvLyBUaGUgdGFpbCBjb25uZWN0aW9uIHdpbGwgb25seSBldmVyIGJlIHJ1bm5pbmcgYSBzaW5nbGUgdGFpbCBjb21tYW5kLCBzb1xuICAgIC8vIGl0IG9ubHkgbmVlZHMgdG8gbWFrZSBvbmUgdW5kZXJseWluZyBUQ1AgY29ubmVjdGlvbi5cbiAgICBzZWxmLl9vcGxvZ1RhaWxDb25uZWN0aW9uID0gbmV3IE1vbmdvQ29ubmVjdGlvbihcbiAgICAgICAgc2VsZi5fb3Bsb2dVcmwsIHttYXhQb29sU2l6ZTogMSwgbWluUG9vbFNpemU6IDF9KTtcbiAgICAvLyBYWFggYmV0dGVyIGRvY3MsIGJ1dDogaXQncyB0byBnZXQgbW9ub3RvbmljIHJlc3VsdHNcbiAgICAvLyBYWFggaXMgaXQgc2FmZSB0byBzYXkgXCJpZiB0aGVyZSdzIGFuIGluIGZsaWdodCBxdWVyeSwganVzdCB1c2UgaXRzXG4gICAgLy8gICAgIHJlc3VsdHNcIj8gSSBkb24ndCB0aGluayBzbyBidXQgc2hvdWxkIGNvbnNpZGVyIHRoYXRcbiAgICBzZWxmLl9vcGxvZ0xhc3RFbnRyeUNvbm5lY3Rpb24gPSBuZXcgTW9uZ29Db25uZWN0aW9uKFxuICAgICAgICBzZWxmLl9vcGxvZ1VybCwge21heFBvb2xTaXplOiAxLCBtaW5Qb29sU2l6ZTogMX0pO1xuXG5cbiAgICAvLyBOb3csIG1ha2Ugc3VyZSB0aGF0IHRoZXJlIGFjdHVhbGx5IGlzIGEgcmVwbCBzZXQgaGVyZS4gSWYgbm90LCBvcGxvZ1xuICAgIC8vIHRhaWxpbmcgd29uJ3QgZXZlciBmaW5kIGFueXRoaW5nIVxuICAgIC8vIE1vcmUgb24gdGhlIGlzTWFzdGVyRG9jXG4gICAgLy8gaHR0cHM6Ly9kb2NzLm1vbmdvZGIuY29tL21hbnVhbC9yZWZlcmVuY2UvY29tbWFuZC9pc01hc3Rlci9cbiAgICBjb25zdCBpc01hc3RlckRvYyA9IGF3YWl0IG5ldyBQcm9taXNlKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgIHNlbGYuX29wbG9nTGFzdEVudHJ5Q29ubmVjdGlvbi5kYlxuICAgICAgICAuYWRtaW4oKVxuICAgICAgICAuY29tbWFuZCh7IGlzbWFzdGVyOiAxIH0sIGZ1bmN0aW9uIChlcnIsIHJlc3VsdCkge1xuICAgICAgICAgIGlmIChlcnIpIHJlamVjdChlcnIpO1xuICAgICAgICAgIGVsc2UgcmVzb2x2ZShyZXN1bHQpO1xuICAgICAgICB9KTtcbiAgICB9KTtcblxuICAgIGlmICghKGlzTWFzdGVyRG9jICYmIGlzTWFzdGVyRG9jLnNldE5hbWUpKSB7XG4gICAgICB0aHJvdyBFcnJvcihcIiRNT05HT19PUExPR19VUkwgbXVzdCBiZSBzZXQgdG8gdGhlICdsb2NhbCcgZGF0YWJhc2Ugb2YgXCIgK1xuICAgICAgICAgIFwiYSBNb25nbyByZXBsaWNhIHNldFwiKTtcbiAgICB9XG5cbiAgICAvLyBGaW5kIHRoZSBsYXN0IG9wbG9nIGVudHJ5LlxuICAgIHZhciBsYXN0T3Bsb2dFbnRyeSA9IGF3YWl0IHNlbGYuX29wbG9nTGFzdEVudHJ5Q29ubmVjdGlvbi5maW5kT25lQXN5bmMoXG4gICAgICBPUExPR19DT0xMRUNUSU9OLFxuICAgICAge30sXG4gICAgICB7IHNvcnQ6IHsgJG5hdHVyYWw6IC0xIH0sIHByb2plY3Rpb246IHsgdHM6IDEgfSB9XG4gICAgKTtcblxuICAgIHZhciBvcGxvZ1NlbGVjdG9yID0gT2JqZWN0LmFzc2lnbih7fSwgc2VsZi5fYmFzZU9wbG9nU2VsZWN0b3IpO1xuICAgIGlmIChsYXN0T3Bsb2dFbnRyeSkge1xuICAgICAgLy8gU3RhcnQgYWZ0ZXIgdGhlIGxhc3QgZW50cnkgdGhhdCBjdXJyZW50bHkgZXhpc3RzLlxuICAgICAgb3Bsb2dTZWxlY3Rvci50cyA9IHskZ3Q6IGxhc3RPcGxvZ0VudHJ5LnRzfTtcbiAgICAgIC8vIElmIHRoZXJlIGFyZSBhbnkgY2FsbHMgdG8gY2FsbFdoZW5Qcm9jZXNzZWRMYXRlc3QgYmVmb3JlIGFueSBvdGhlclxuICAgICAgLy8gb3Bsb2cgZW50cmllcyBzaG93IHVwLCBhbGxvdyBjYWxsV2hlblByb2Nlc3NlZExhdGVzdCB0byBjYWxsIGl0c1xuICAgICAgLy8gY2FsbGJhY2sgaW1tZWRpYXRlbHkuXG4gICAgICBzZWxmLl9sYXN0UHJvY2Vzc2VkVFMgPSBsYXN0T3Bsb2dFbnRyeS50cztcbiAgICB9XG5cbiAgICAvLyBUaGVzZSAyIHNldHRpbmdzIGFsbG93IHlvdSB0byBlaXRoZXIgb25seSB3YXRjaCBjZXJ0YWluIGNvbGxlY3Rpb25zIChvcGxvZ0luY2x1ZGVDb2xsZWN0aW9ucyksIG9yIGV4Y2x1ZGUgc29tZSBjb2xsZWN0aW9ucyB5b3UgZG9uJ3Qgd2FudCB0byB3YXRjaCBmb3Igb3Bsb2cgdXBkYXRlcyAob3Bsb2dFeGNsdWRlQ29sbGVjdGlvbnMpXG4gICAgLy8gVXNhZ2U6XG4gICAgLy8gc2V0dGluZ3MuanNvbiA9IHtcbiAgICAvLyAgIFwicGFja2FnZXNcIjoge1xuICAgIC8vICAgICBcIm1vbmdvXCI6IHtcbiAgICAvLyAgICAgICBcIm9wbG9nRXhjbHVkZUNvbGxlY3Rpb25zXCI6IFtcInByb2R1Y3RzXCIsIFwicHJpY2VzXCJdIC8vIFRoaXMgd291bGQgZXhjbHVkZSBib3RoIGNvbGxlY3Rpb25zIFwicHJvZHVjdHNcIiBhbmQgXCJwcmljZXNcIiBmcm9tIGFueSBvcGxvZyB0YWlsaW5nLiBcbiAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEJld2FyZSEgVGhpcyBtZWFucywgdGhhdCBubyBzdWJzY3JpcHRpb25zIG9uIHRoZXNlIDIgY29sbGVjdGlvbnMgd2lsbCB1cGRhdGUgYW55bW9yZSFcbiAgICAvLyAgICAgfVxuICAgIC8vICAgfVxuICAgIC8vIH1cbiAgICBjb25zdCBpbmNsdWRlQ29sbGVjdGlvbnMgPSBNZXRlb3Iuc2V0dGluZ3M/LnBhY2thZ2VzPy5tb25nbz8ub3Bsb2dJbmNsdWRlQ29sbGVjdGlvbnM7XG4gICAgY29uc3QgZXhjbHVkZUNvbGxlY3Rpb25zID0gTWV0ZW9yLnNldHRpbmdzPy5wYWNrYWdlcz8ubW9uZ28/Lm9wbG9nRXhjbHVkZUNvbGxlY3Rpb25zO1xuICAgIGlmIChpbmNsdWRlQ29sbGVjdGlvbnM/Lmxlbmd0aCAmJiBleGNsdWRlQ29sbGVjdGlvbnM/Lmxlbmd0aCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiQ2FuJ3QgdXNlIGJvdGggbW9uZ28gb3Bsb2cgc2V0dGluZ3Mgb3Bsb2dJbmNsdWRlQ29sbGVjdGlvbnMgYW5kIG9wbG9nRXhjbHVkZUNvbGxlY3Rpb25zIGF0IHRoZSBzYW1lIHRpbWUuXCIpO1xuICAgIH1cbiAgICBpZiAoZXhjbHVkZUNvbGxlY3Rpb25zPy5sZW5ndGgpIHtcbiAgICAgIG9wbG9nU2VsZWN0b3IubnMgPSB7XG4gICAgICAgICRyZWdleDogb3Bsb2dTZWxlY3Rvci5ucyxcbiAgICAgICAgJG5pbjogZXhjbHVkZUNvbGxlY3Rpb25zLm1hcCgoY29sbE5hbWUpID0+IGAke3NlbGYuX2RiTmFtZX0uJHtjb2xsTmFtZX1gKVxuICAgICAgfVxuICAgICAgc2VsZi5fb3Bsb2dPcHRpb25zID0geyBleGNsdWRlQ29sbGVjdGlvbnMgfTtcbiAgICB9XG4gICAgZWxzZSBpZiAoaW5jbHVkZUNvbGxlY3Rpb25zPy5sZW5ndGgpIHtcbiAgICAgIG9wbG9nU2VsZWN0b3IgPSB7ICRhbmQ6IFtcbiAgICAgICAgeyAkb3I6IFtcbiAgICAgICAgICB7IG5zOiAvXmFkbWluXFwuXFwkY21kLyB9LFxuICAgICAgICAgIHsgbnM6IHsgJGluOiBpbmNsdWRlQ29sbGVjdGlvbnMubWFwKChjb2xsTmFtZSkgPT4gYCR7c2VsZi5fZGJOYW1lfS4ke2NvbGxOYW1lfWApIH0gfVxuICAgICAgICBdIH0sXG4gICAgICAgIHsgJG9yOiBvcGxvZ1NlbGVjdG9yLiRvciB9LCAvLyB0aGUgaW5pdGlhbCAkb3IgdG8gc2VsZWN0IG9ubHkgY2VydGFpbiBvcGVyYXRpb25zIChvcClcbiAgICAgICAgeyB0czogb3Bsb2dTZWxlY3Rvci50cyB9XG4gICAgICBdIH07XG4gICAgICBzZWxmLl9vcGxvZ09wdGlvbnMgPSB7IGluY2x1ZGVDb2xsZWN0aW9ucyB9O1xuICAgIH1cblxuICAgIHZhciBjdXJzb3JEZXNjcmlwdGlvbiA9IG5ldyBDdXJzb3JEZXNjcmlwdGlvbihcbiAgICAgICAgT1BMT0dfQ09MTEVDVElPTiwgb3Bsb2dTZWxlY3Rvciwge3RhaWxhYmxlOiB0cnVlfSk7XG5cbiAgICAvLyBTdGFydCB0YWlsaW5nIHRoZSBvcGxvZy5cbiAgICAvL1xuICAgIC8vIFdlIHJlc3RhcnQgdGhlIGxvdy1sZXZlbCBvcGxvZyBxdWVyeSBldmVyeSAzMCBzZWNvbmRzIGlmIHdlIGRpZG4ndCBnZXQgYVxuICAgIC8vIGRvYy4gVGhpcyBpcyBhIHdvcmthcm91bmQgZm9yICM4NTk4OiB0aGUgTm9kZSBNb25nbyBkcml2ZXIgaGFzIGF0IGxlYXN0XG4gICAgLy8gb25lIGJ1ZyB0aGF0IGNhbiBsZWFkIHRvIHF1ZXJ5IGNhbGxiYWNrcyBuZXZlciBnZXR0aW5nIGNhbGxlZCAoZXZlbiB3aXRoXG4gICAgLy8gYW4gZXJyb3IpIHdoZW4gbGVhZGVyc2hpcCBmYWlsb3ZlciBvY2N1ci5cbiAgICBzZWxmLl90YWlsSGFuZGxlID0gc2VsZi5fb3Bsb2dUYWlsQ29ubmVjdGlvbi50YWlsKFxuICAgICAgICBjdXJzb3JEZXNjcmlwdGlvbixcbiAgICAgICAgZnVuY3Rpb24gKGRvYykge1xuICAgICAgICAgIHNlbGYuX2VudHJ5UXVldWUucHVzaChkb2MpO1xuICAgICAgICAgIHNlbGYuX21heWJlU3RhcnRXb3JrZXIoKTtcbiAgICAgICAgfSxcbiAgICAgICAgVEFJTF9USU1FT1VUXG4gICAgKTtcblxuICAgIHNlbGYuX3JlYWR5UHJvbWlzZVJlc29sdmVyKCk7XG4gIH0sXG5cbiAgX21heWJlU3RhcnRXb3JrZXI6IGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgaWYgKHNlbGYuX3dvcmtlckFjdGl2ZSkgcmV0dXJuO1xuICAgIHNlbGYuX3dvcmtlckFjdGl2ZSA9IHRydWU7XG5cbiAgICBNZXRlb3IuZGVmZXIoYXN5bmMgZnVuY3Rpb24gKCkge1xuICAgICAgLy8gTWF5IGJlIGNhbGxlZCByZWN1cnNpdmVseSBpbiBjYXNlIG9mIHRyYW5zYWN0aW9ucy5cbiAgICAgIGFzeW5jIGZ1bmN0aW9uIGhhbmRsZURvYyhkb2MpIHtcbiAgICAgICAgaWYgKGRvYy5ucyA9PT0gXCJhZG1pbi4kY21kXCIpIHtcbiAgICAgICAgICBpZiAoZG9jLm8uYXBwbHlPcHMpIHtcbiAgICAgICAgICAgIC8vIFRoaXMgd2FzIGEgc3VjY2Vzc2Z1bCB0cmFuc2FjdGlvbiwgc28gd2UgbmVlZCB0byBhcHBseSB0aGVcbiAgICAgICAgICAgIC8vIG9wZXJhdGlvbnMgdGhhdCB3ZXJlIGludm9sdmVkLlxuICAgICAgICAgICAgbGV0IG5leHRUaW1lc3RhbXAgPSBkb2MudHM7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IG9wIG9mIGRvYy5vLmFwcGx5T3BzKSB7XG4gICAgICAgICAgICAgIC8vIFNlZSBodHRwczovL2dpdGh1Yi5jb20vbWV0ZW9yL21ldGVvci9pc3N1ZXMvMTA0MjAuXG4gICAgICAgICAgICAgIGlmICghb3AudHMpIHtcbiAgICAgICAgICAgICAgICBvcC50cyA9IG5leHRUaW1lc3RhbXA7XG4gICAgICAgICAgICAgICAgbmV4dFRpbWVzdGFtcCA9IG5leHRUaW1lc3RhbXAuYWRkKExvbmcuT05FKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBhd2FpdCBoYW5kbGVEb2Mob3ApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH1cbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJVbmtub3duIGNvbW1hbmQgXCIgKyBFSlNPTi5zdHJpbmdpZnkoZG9jKSk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCB0cmlnZ2VyID0ge1xuICAgICAgICAgIGRyb3BDb2xsZWN0aW9uOiBmYWxzZSxcbiAgICAgICAgICBkcm9wRGF0YWJhc2U6IGZhbHNlLFxuICAgICAgICAgIG9wOiBkb2MsXG4gICAgICAgIH07XG5cbiAgICAgICAgaWYgKHR5cGVvZiBkb2MubnMgPT09IFwic3RyaW5nXCIgJiZcbiAgICAgICAgICAgIGRvYy5ucy5zdGFydHNXaXRoKHNlbGYuX2RiTmFtZSArIFwiLlwiKSkge1xuICAgICAgICAgIHRyaWdnZXIuY29sbGVjdGlvbiA9IGRvYy5ucy5zbGljZShzZWxmLl9kYk5hbWUubGVuZ3RoICsgMSk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBJcyBpdCBhIHNwZWNpYWwgY29tbWFuZCBhbmQgdGhlIGNvbGxlY3Rpb24gbmFtZSBpcyBoaWRkZW5cbiAgICAgICAgLy8gc29tZXdoZXJlIGluIG9wZXJhdG9yP1xuICAgICAgICBpZiAodHJpZ2dlci5jb2xsZWN0aW9uID09PSBcIiRjbWRcIikge1xuICAgICAgICAgIGlmIChkb2Muby5kcm9wRGF0YWJhc2UpIHtcbiAgICAgICAgICAgIGRlbGV0ZSB0cmlnZ2VyLmNvbGxlY3Rpb247XG4gICAgICAgICAgICB0cmlnZ2VyLmRyb3BEYXRhYmFzZSA9IHRydWU7XG4gICAgICAgICAgfSBlbHNlIGlmIChfLmhhcyhkb2MubywgXCJkcm9wXCIpKSB7XG4gICAgICAgICAgICB0cmlnZ2VyLmNvbGxlY3Rpb24gPSBkb2Muby5kcm9wO1xuICAgICAgICAgICAgdHJpZ2dlci5kcm9wQ29sbGVjdGlvbiA9IHRydWU7XG4gICAgICAgICAgICB0cmlnZ2VyLmlkID0gbnVsbDtcbiAgICAgICAgICB9IGVsc2UgaWYgKFwiY3JlYXRlXCIgaW4gZG9jLm8gJiYgXCJpZEluZGV4XCIgaW4gZG9jLm8pIHtcbiAgICAgICAgICAgIC8vIEEgY29sbGVjdGlvbiBnb3QgaW1wbGljaXRseSBjcmVhdGVkIHdpdGhpbiBhIHRyYW5zYWN0aW9uLiBUaGVyZSdzXG4gICAgICAgICAgICAvLyBubyBuZWVkIHRvIGRvIGFueXRoaW5nIGFib3V0IGl0LlxuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aHJvdyBFcnJvcihcIlVua25vd24gY29tbWFuZCBcIiArIEVKU09OLnN0cmluZ2lmeShkb2MpKTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAvLyBBbGwgb3RoZXIgb3BzIGhhdmUgYW4gaWQuXG4gICAgICAgICAgdHJpZ2dlci5pZCA9IGlkRm9yT3AoZG9jKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGF3YWl0IHNlbGYuX2Nyb3NzYmFyLmZpcmUodHJpZ2dlcik7XG4gICAgICB9XG5cbiAgICAgIHRyeSB7XG4gICAgICAgIHdoaWxlICghIHNlbGYuX3N0b3BwZWQgJiZcbiAgICAgICAgICAgICAgICEgc2VsZi5fZW50cnlRdWV1ZS5pc0VtcHR5KCkpIHtcbiAgICAgICAgICAvLyBBcmUgd2UgdG9vIGZhciBiZWhpbmQ/IEp1c3QgdGVsbCBvdXIgb2JzZXJ2ZXJzIHRoYXQgdGhleSBuZWVkIHRvXG4gICAgICAgICAgLy8gcmVwb2xsLCBhbmQgZHJvcCBvdXIgcXVldWUuXG4gICAgICAgICAgaWYgKHNlbGYuX2VudHJ5UXVldWUubGVuZ3RoID4gVE9PX0ZBUl9CRUhJTkQpIHtcbiAgICAgICAgICAgIHZhciBsYXN0RW50cnkgPSBzZWxmLl9lbnRyeVF1ZXVlLnBvcCgpO1xuICAgICAgICAgICAgc2VsZi5fZW50cnlRdWV1ZS5jbGVhcigpO1xuXG4gICAgICAgICAgICBzZWxmLl9vblNraXBwZWRFbnRyaWVzSG9vay5lYWNoKGZ1bmN0aW9uIChjYWxsYmFjaykge1xuICAgICAgICAgICAgICBjYWxsYmFjaygpO1xuICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAvLyBGcmVlIGFueSB3YWl0VW50aWxDYXVnaHRVcCgpIGNhbGxzIHRoYXQgd2VyZSB3YWl0aW5nIGZvciB1cyB0b1xuICAgICAgICAgICAgLy8gcGFzcyBzb21ldGhpbmcgdGhhdCB3ZSBqdXN0IHNraXBwZWQuXG4gICAgICAgICAgICBzZWxmLl9zZXRMYXN0UHJvY2Vzc2VkVFMobGFzdEVudHJ5LnRzKTtcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIGNvbnN0IGRvYyA9IHNlbGYuX2VudHJ5UXVldWUuc2hpZnQoKTtcblxuICAgICAgICAgIC8vIEZpcmUgdHJpZ2dlcihzKSBmb3IgdGhpcyBkb2MuXG4gICAgICAgICAgYXdhaXQgaGFuZGxlRG9jKGRvYyk7XG5cbiAgICAgICAgICAvLyBOb3cgdGhhdCB3ZSd2ZSBwcm9jZXNzZWQgdGhpcyBvcGVyYXRpb24sIHByb2Nlc3MgcGVuZGluZ1xuICAgICAgICAgIC8vIHNlcXVlbmNlcnMuXG4gICAgICAgICAgaWYgKGRvYy50cykge1xuICAgICAgICAgICAgc2VsZi5fc2V0TGFzdFByb2Nlc3NlZFRTKGRvYy50cyk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRocm93IEVycm9yKFwib3Bsb2cgZW50cnkgd2l0aG91dCB0czogXCIgKyBFSlNPTi5zdHJpbmdpZnkoZG9jKSk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9IGZpbmFsbHkge1xuICAgICAgICBzZWxmLl93b3JrZXJBY3RpdmUgPSBmYWxzZTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfSxcblxuICBfc2V0TGFzdFByb2Nlc3NlZFRTOiBmdW5jdGlvbiAodHMpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgc2VsZi5fbGFzdFByb2Nlc3NlZFRTID0gdHM7XG4gICAgd2hpbGUgKCFfLmlzRW1wdHkoc2VsZi5fY2F0Y2hpbmdVcFJlc29sdmVycykgJiYgc2VsZi5fY2F0Y2hpbmdVcFJlc29sdmVyc1swXS50cy5sZXNzVGhhbk9yRXF1YWwoc2VsZi5fbGFzdFByb2Nlc3NlZFRTKSkge1xuICAgICAgdmFyIHNlcXVlbmNlciA9IHNlbGYuX2NhdGNoaW5nVXBSZXNvbHZlcnMuc2hpZnQoKTtcbiAgICAgIHNlcXVlbmNlci5yZXNvbHZlcigpO1xuICAgIH1cbiAgfSxcblxuICAvL01ldGhvZHMgdXNlZCBvbiB0ZXN0cyB0byBkaW5hbWljYWxseSBjaGFuZ2UgVE9PX0ZBUl9CRUhJTkRcbiAgX2RlZmluZVRvb0ZhckJlaGluZDogZnVuY3Rpb24odmFsdWUpIHtcbiAgICBUT09fRkFSX0JFSElORCA9IHZhbHVlO1xuICB9LFxuICBfcmVzZXRUb29GYXJCZWhpbmQ6IGZ1bmN0aW9uKCkge1xuICAgIFRPT19GQVJfQkVISU5EID0gcHJvY2Vzcy5lbnYuTUVURU9SX09QTE9HX1RPT19GQVJfQkVISU5EIHx8IDIwMDA7XG4gIH1cbn0pO1xuIiwibGV0IG5leHRPYnNlcnZlSGFuZGxlSWQgPSAxO1xuXG5PYnNlcnZlTXVsdGlwbGV4ZXIgPSBjbGFzcyB7XG4gIGNvbnN0cnVjdG9yKHsgb3JkZXJlZCwgb25TdG9wID0gKCkgPT4ge30gfSA9IHt9KSB7XG4gICAgaWYgKG9yZGVyZWQgPT09IHVuZGVmaW5lZCkgdGhyb3cgRXJyb3IoXCJtdXN0IHNwZWNpZnkgb3JkZXJlZFwiKTtcblxuICAgIFBhY2thZ2VbJ2ZhY3RzLWJhc2UnXSAmJiBQYWNrYWdlWydmYWN0cy1iYXNlJ10uRmFjdHMuaW5jcmVtZW50U2VydmVyRmFjdChcbiAgICAgICAgXCJtb25nby1saXZlZGF0YVwiLCBcIm9ic2VydmUtbXVsdGlwbGV4ZXJzXCIsIDEpO1xuXG4gICAgdGhpcy5fb3JkZXJlZCA9IG9yZGVyZWQ7XG4gICAgdGhpcy5fb25TdG9wID0gb25TdG9wO1xuICAgIHRoaXMuX3F1ZXVlID0gbmV3IE1ldGVvci5fQXN5bmNocm9ub3VzUXVldWUoKTtcbiAgICB0aGlzLl9oYW5kbGVzID0ge307XG4gICAgdGhpcy5fcmVzb2x2ZXIgPSBudWxsO1xuICAgIHRoaXMuX3JlYWR5UHJvbWlzZSA9IG5ldyBQcm9taXNlKHIgPT4gdGhpcy5fcmVzb2x2ZXIgPSByKS50aGVuKCgpID0+IHRoaXMuX2lzUmVhZHkgPSB0cnVlKTtcbiAgICB0aGlzLl9jYWNoZSA9IG5ldyBMb2NhbENvbGxlY3Rpb24uX0NhY2hpbmdDaGFuZ2VPYnNlcnZlcih7XG4gICAgICBvcmRlcmVkfSk7XG4gICAgLy8gTnVtYmVyIG9mIGFkZEhhbmRsZUFuZFNlbmRJbml0aWFsQWRkcyB0YXNrcyBzY2hlZHVsZWQgYnV0IG5vdCB5ZXRcbiAgICAvLyBydW5uaW5nLiByZW1vdmVIYW5kbGUgdXNlcyB0aGlzIHRvIGtub3cgaWYgaXQncyB0aW1lIHRvIGNhbGwgdGhlIG9uU3RvcFxuICAgIC8vIGNhbGxiYWNrLlxuICAgIHRoaXMuX2FkZEhhbmRsZVRhc2tzU2NoZWR1bGVkQnV0Tm90UGVyZm9ybWVkID0gMDtcblxuICAgIGNvbnN0IHNlbGYgPSB0aGlzO1xuICAgIHRoaXMuY2FsbGJhY2tOYW1lcygpLmZvckVhY2goY2FsbGJhY2tOYW1lID0+IHtcbiAgICAgIHRoaXNbY2FsbGJhY2tOYW1lXSA9IGZ1bmN0aW9uKC8qIC4uLiAqLykge1xuICAgICAgICBzZWxmLl9hcHBseUNhbGxiYWNrKGNhbGxiYWNrTmFtZSwgXy50b0FycmF5KGFyZ3VtZW50cykpO1xuICAgICAgfTtcbiAgICB9KTtcbiAgfVxuXG4gIGFkZEhhbmRsZUFuZFNlbmRJbml0aWFsQWRkcyhoYW5kbGUpIHtcbiAgICByZXR1cm4gdGhpcy5fYWRkSGFuZGxlQW5kU2VuZEluaXRpYWxBZGRzKGhhbmRsZSk7XG4gIH1cblxuICBhc3luYyBfYWRkSGFuZGxlQW5kU2VuZEluaXRpYWxBZGRzKGhhbmRsZSkge1xuICAgICsrdGhpcy5fYWRkSGFuZGxlVGFza3NTY2hlZHVsZWRCdXROb3RQZXJmb3JtZWQ7XG5cbiAgICBQYWNrYWdlWydmYWN0cy1iYXNlJ10gJiYgUGFja2FnZVsnZmFjdHMtYmFzZSddLkZhY3RzLmluY3JlbWVudFNlcnZlckZhY3QoXG4gICAgICAgIFwibW9uZ28tbGl2ZWRhdGFcIiwgXCJvYnNlcnZlLWhhbmRsZXNcIiwgMSk7XG5cbiAgICBjb25zdCBzZWxmID0gdGhpcztcbiAgICBhd2FpdCB0aGlzLl9xdWV1ZS5ydW5UYXNrKGFzeW5jIGZ1bmN0aW9uICgpIHtcbiAgICAgIHNlbGYuX2hhbmRsZXNbaGFuZGxlLl9pZF0gPSBoYW5kbGU7XG4gICAgICAvLyBTZW5kIG91dCB3aGF0ZXZlciBhZGRzIHdlIGhhdmUgc28gZmFyICh3aGV0aGVyIHRoZVxuICAgICAgLy8gbXVsdGlwbGV4ZXIgaXMgcmVhZHkpLlxuICAgICAgYXdhaXQgc2VsZi5fc2VuZEFkZHMoaGFuZGxlKTtcbiAgICAgIC0tc2VsZi5fYWRkSGFuZGxlVGFza3NTY2hlZHVsZWRCdXROb3RQZXJmb3JtZWQ7XG4gICAgfSk7XG4gICAgYXdhaXQgdGhpcy5fcmVhZHlQcm9taXNlO1xuICB9XG5cbiAgLy8gUmVtb3ZlIGFuIG9ic2VydmUgaGFuZGxlLiBJZiBpdCB3YXMgdGhlIGxhc3Qgb2JzZXJ2ZSBoYW5kbGUsIGNhbGwgdGhlXG4gIC8vIG9uU3RvcCBjYWxsYmFjazsgeW91IGNhbm5vdCBhZGQgYW55IG1vcmUgb2JzZXJ2ZSBoYW5kbGVzIGFmdGVyIHRoaXMuXG4gIC8vXG4gIC8vIFRoaXMgaXMgbm90IHN5bmNocm9uaXplZCB3aXRoIHBvbGxzIGFuZCBoYW5kbGUgYWRkaXRpb25zOiB0aGlzIG1lYW5zIHRoYXRcbiAgLy8geW91IGNhbiBzYWZlbHkgY2FsbCBpdCBmcm9tIHdpdGhpbiBhbiBvYnNlcnZlIGNhbGxiYWNrLCBidXQgaXQgYWxzbyBtZWFuc1xuICAvLyB0aGF0IHdlIGhhdmUgdG8gYmUgY2FyZWZ1bCB3aGVuIHdlIGl0ZXJhdGUgb3ZlciBfaGFuZGxlcy5cbiAgYXN5bmMgcmVtb3ZlSGFuZGxlKGlkKSB7XG4gICAgLy8gVGhpcyBzaG91bGQgbm90IGJlIHBvc3NpYmxlOiB5b3UgY2FuIG9ubHkgY2FsbCByZW1vdmVIYW5kbGUgYnkgaGF2aW5nXG4gICAgLy8gYWNjZXNzIHRvIHRoZSBPYnNlcnZlSGFuZGxlLCB3aGljaCBpc24ndCByZXR1cm5lZCB0byB1c2VyIGNvZGUgdW50aWwgdGhlXG4gICAgLy8gbXVsdGlwbGV4IGlzIHJlYWR5LlxuICAgIGlmICghdGhpcy5fcmVhZHkoKSlcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIkNhbid0IHJlbW92ZSBoYW5kbGVzIHVudGlsIHRoZSBtdWx0aXBsZXggaXMgcmVhZHlcIik7XG5cbiAgICBkZWxldGUgdGhpcy5faGFuZGxlc1tpZF07XG5cbiAgICBQYWNrYWdlWydmYWN0cy1iYXNlJ10gJiYgUGFja2FnZVsnZmFjdHMtYmFzZSddLkZhY3RzLmluY3JlbWVudFNlcnZlckZhY3QoXG4gICAgICAgIFwibW9uZ28tbGl2ZWRhdGFcIiwgXCJvYnNlcnZlLWhhbmRsZXNcIiwgLTEpO1xuXG4gICAgaWYgKF8uaXNFbXB0eSh0aGlzLl9oYW5kbGVzKSAmJlxuICAgICAgICB0aGlzLl9hZGRIYW5kbGVUYXNrc1NjaGVkdWxlZEJ1dE5vdFBlcmZvcm1lZCA9PT0gMCkge1xuICAgICAgYXdhaXQgdGhpcy5fc3RvcCgpO1xuICAgIH1cbiAgfVxuICBhc3luYyBfc3RvcChvcHRpb25zKSB7XG4gICAgb3B0aW9ucyA9IG9wdGlvbnMgfHwge307XG5cbiAgICAvLyBJdCBzaG91bGRuJ3QgYmUgcG9zc2libGUgZm9yIHVzIHRvIHN0b3Agd2hlbiBhbGwgb3VyIGhhbmRsZXMgc3RpbGxcbiAgICAvLyBoYXZlbid0IGJlZW4gcmV0dXJuZWQgZnJvbSBvYnNlcnZlQ2hhbmdlcyFcbiAgICBpZiAoISB0aGlzLl9yZWFkeSgpICYmICEgb3B0aW9ucy5mcm9tUXVlcnlFcnJvcilcbiAgICAgIHRocm93IEVycm9yKFwic3VycHJpc2luZyBfc3RvcDogbm90IHJlYWR5XCIpO1xuXG4gICAgLy8gQ2FsbCBzdG9wIGNhbGxiYWNrICh3aGljaCBraWxscyB0aGUgdW5kZXJseWluZyBwcm9jZXNzIHdoaWNoIHNlbmRzIHVzXG4gICAgLy8gY2FsbGJhY2tzIGFuZCByZW1vdmVzIHVzIGZyb20gdGhlIGNvbm5lY3Rpb24ncyBkaWN0aW9uYXJ5KS5cbiAgICBhd2FpdCB0aGlzLl9vblN0b3AoKTtcbiAgICBQYWNrYWdlWydmYWN0cy1iYXNlJ10gJiYgUGFja2FnZVsnZmFjdHMtYmFzZSddLkZhY3RzLmluY3JlbWVudFNlcnZlckZhY3QoXG4gICAgICAgIFwibW9uZ28tbGl2ZWRhdGFcIiwgXCJvYnNlcnZlLW11bHRpcGxleGVyc1wiLCAtMSk7XG5cbiAgICAvLyBDYXVzZSBmdXR1cmUgYWRkSGFuZGxlQW5kU2VuZEluaXRpYWxBZGRzIGNhbGxzIHRvIHRocm93IChidXQgdGhlIG9uU3RvcFxuICAgIC8vIGNhbGxiYWNrIHNob3VsZCBtYWtlIG91ciBjb25uZWN0aW9uIGZvcmdldCBhYm91dCB1cykuXG4gICAgdGhpcy5faGFuZGxlcyA9IG51bGw7XG4gIH1cblxuICAvLyBBbGxvd3MgYWxsIGFkZEhhbmRsZUFuZFNlbmRJbml0aWFsQWRkcyBjYWxscyB0byByZXR1cm4sIG9uY2UgYWxsIHByZWNlZGluZ1xuICAvLyBhZGRzIGhhdmUgYmVlbiBwcm9jZXNzZWQuIERvZXMgbm90IGJsb2NrLlxuICBhc3luYyByZWFkeSgpIHtcbiAgICBjb25zdCBzZWxmID0gdGhpcztcbiAgICB0aGlzLl9xdWV1ZS5xdWV1ZVRhc2soZnVuY3Rpb24gKCkge1xuICAgICAgaWYgKHNlbGYuX3JlYWR5KCkpXG4gICAgICAgIHRocm93IEVycm9yKFwiY2FuJ3QgbWFrZSBPYnNlcnZlTXVsdGlwbGV4IHJlYWR5IHR3aWNlIVwiKTtcblxuICAgICAgaWYgKCFzZWxmLl9yZXNvbHZlcikge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJNaXNzaW5nIHJlc29sdmVyXCIpO1xuICAgICAgfVxuXG4gICAgICBzZWxmLl9yZXNvbHZlcigpO1xuICAgICAgc2VsZi5faXNSZWFkeSA9IHRydWU7XG4gICAgfSk7XG4gIH1cblxuICAvLyBJZiB0cnlpbmcgdG8gZXhlY3V0ZSB0aGUgcXVlcnkgcmVzdWx0cyBpbiBhbiBlcnJvciwgY2FsbCB0aGlzLiBUaGlzIGlzXG4gIC8vIGludGVuZGVkIGZvciBwZXJtYW5lbnQgZXJyb3JzLCBub3QgdHJhbnNpZW50IG5ldHdvcmsgZXJyb3JzIHRoYXQgY291bGQgYmVcbiAgLy8gZml4ZWQuIEl0IHNob3VsZCBvbmx5IGJlIGNhbGxlZCBiZWZvcmUgcmVhZHkoKSwgYmVjYXVzZSBpZiB5b3UgY2FsbGVkIHJlYWR5XG4gIC8vIHRoYXQgbWVhbnQgdGhhdCB5b3UgbWFuYWdlZCB0byBydW4gdGhlIHF1ZXJ5IG9uY2UuIEl0IHdpbGwgc3RvcCB0aGlzXG4gIC8vIE9ic2VydmVNdWx0aXBsZXggYW5kIGNhdXNlIGFkZEhhbmRsZUFuZFNlbmRJbml0aWFsQWRkcyBjYWxscyAoYW5kIHRodXNcbiAgLy8gb2JzZXJ2ZUNoYW5nZXMgY2FsbHMpIHRvIHRocm93IHRoZSBlcnJvci5cbiAgYXN5bmMgcXVlcnlFcnJvcihlcnIpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgYXdhaXQgdGhpcy5fcXVldWUucnVuVGFzayhmdW5jdGlvbiAoKSB7XG4gICAgICBpZiAoc2VsZi5fcmVhZHkoKSlcbiAgICAgICAgdGhyb3cgRXJyb3IoXCJjYW4ndCBjbGFpbSBxdWVyeSBoYXMgYW4gZXJyb3IgYWZ0ZXIgaXQgd29ya2VkIVwiKTtcbiAgICAgIHNlbGYuX3N0b3Aoe2Zyb21RdWVyeUVycm9yOiB0cnVlfSk7XG4gICAgICB0aHJvdyBlcnI7XG4gICAgfSk7XG4gIH1cblxuICAvLyBDYWxscyBcImNiXCIgb25jZSB0aGUgZWZmZWN0cyBvZiBhbGwgXCJyZWFkeVwiLCBcImFkZEhhbmRsZUFuZFNlbmRJbml0aWFsQWRkc1wiXG4gIC8vIGFuZCBvYnNlcnZlIGNhbGxiYWNrcyB3aGljaCBjYW1lIGJlZm9yZSB0aGlzIGNhbGwgaGF2ZSBiZWVuIHByb3BhZ2F0ZWQgdG9cbiAgLy8gYWxsIGhhbmRsZXMuIFwicmVhZHlcIiBtdXN0IGhhdmUgYWxyZWFkeSBiZWVuIGNhbGxlZCBvbiB0aGlzIG11bHRpcGxleGVyLlxuICBhc3luYyBvbkZsdXNoKGNiKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgIGF3YWl0IHRoaXMuX3F1ZXVlLnF1ZXVlVGFzayhhc3luYyBmdW5jdGlvbiAoKSB7XG4gICAgICBpZiAoIXNlbGYuX3JlYWR5KCkpXG4gICAgICAgIHRocm93IEVycm9yKFwib25seSBjYWxsIG9uRmx1c2ggb24gYSBtdWx0aXBsZXhlciB0aGF0IHdpbGwgYmUgcmVhZHlcIik7XG4gICAgICBhd2FpdCBjYigpO1xuICAgIH0pO1xuICB9XG4gIGNhbGxiYWNrTmFtZXMoKSB7XG4gICAgaWYgKHRoaXMuX29yZGVyZWQpXG4gICAgICByZXR1cm4gW1wiYWRkZWRCZWZvcmVcIiwgXCJjaGFuZ2VkXCIsIFwibW92ZWRCZWZvcmVcIiwgXCJyZW1vdmVkXCJdO1xuICAgIGVsc2VcbiAgICAgIHJldHVybiBbXCJhZGRlZFwiLCBcImNoYW5nZWRcIiwgXCJyZW1vdmVkXCJdO1xuICB9XG4gIF9yZWFkeSgpIHtcbiAgICByZXR1cm4gISF0aGlzLl9pc1JlYWR5O1xuICB9XG4gIF9hcHBseUNhbGxiYWNrKGNhbGxiYWNrTmFtZSwgYXJncykge1xuICAgIGNvbnN0IHNlbGYgPSB0aGlzO1xuICAgIHRoaXMuX3F1ZXVlLnF1ZXVlVGFzayhhc3luYyBmdW5jdGlvbiAoKSB7XG4gICAgICAvLyBJZiB3ZSBzdG9wcGVkIGluIHRoZSBtZWFudGltZSwgZG8gbm90aGluZy5cbiAgICAgIGlmICghc2VsZi5faGFuZGxlcylcbiAgICAgICAgcmV0dXJuO1xuXG4gICAgICAvLyBGaXJzdCwgYXBwbHkgdGhlIGNoYW5nZSB0byB0aGUgY2FjaGUuXG4gICAgICBhd2FpdCBzZWxmLl9jYWNoZS5hcHBseUNoYW5nZVtjYWxsYmFja05hbWVdLmFwcGx5KG51bGwsIGFyZ3MpO1xuICAgICAgLy8gSWYgd2UgaGF2ZW4ndCBmaW5pc2hlZCB0aGUgaW5pdGlhbCBhZGRzLCB0aGVuIHdlIHNob3VsZCBvbmx5IGJlIGdldHRpbmdcbiAgICAgIC8vIGFkZHMuXG4gICAgICBpZiAoIXNlbGYuX3JlYWR5KCkgJiZcbiAgICAgICAgICAoY2FsbGJhY2tOYW1lICE9PSAnYWRkZWQnICYmIGNhbGxiYWNrTmFtZSAhPT0gJ2FkZGVkQmVmb3JlJykpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiR290IFwiICsgY2FsbGJhY2tOYW1lICsgXCIgZHVyaW5nIGluaXRpYWwgYWRkc1wiKTtcbiAgICAgIH1cblxuICAgICAgLy8gTm93IG11bHRpcGxleCB0aGUgY2FsbGJhY2tzIG91dCB0byBhbGwgb2JzZXJ2ZSBoYW5kbGVzLiBJdCdzIE9LIGlmXG4gICAgICAvLyB0aGVzZSBjYWxscyB5aWVsZDsgc2luY2Ugd2UncmUgaW5zaWRlIGEgdGFzaywgbm8gb3RoZXIgdXNlIG9mIG91ciBxdWV1ZVxuICAgICAgLy8gY2FuIGNvbnRpbnVlIHVudGlsIHRoZXNlIGFyZSBkb25lLiAoQnV0IHdlIGRvIGhhdmUgdG8gYmUgY2FyZWZ1bCB0byBub3RcbiAgICAgIC8vIHVzZSBhIGhhbmRsZSB0aGF0IGdvdCByZW1vdmVkLCBiZWNhdXNlIHJlbW92ZUhhbmRsZSBkb2VzIG5vdCB1c2UgdGhlXG4gICAgICAvLyBxdWV1ZTsgdGh1cywgd2UgaXRlcmF0ZSBvdmVyIGFuIGFycmF5IG9mIGtleXMgdGhhdCB3ZSBjb250cm9sLilcbiAgICAgIGZvciAoY29uc3QgaGFuZGxlSWQgb2YgT2JqZWN0LmtleXMoc2VsZi5faGFuZGxlcykpIHtcbiAgICAgICAgdmFyIGhhbmRsZSA9IHNlbGYuX2hhbmRsZXMgJiYgc2VsZi5faGFuZGxlc1toYW5kbGVJZF07XG4gICAgICAgIGlmICghaGFuZGxlKSByZXR1cm47XG4gICAgICAgIHZhciBjYWxsYmFjayA9IGhhbmRsZVsnXycgKyBjYWxsYmFja05hbWVdO1xuICAgICAgICAvLyBjbG9uZSBhcmd1bWVudHMgc28gdGhhdCBjYWxsYmFja3MgY2FuIG11dGF0ZSB0aGVpciBhcmd1bWVudHNcblxuICAgICAgICBjYWxsYmFjayAmJlxuICAgICAgICAgIChhd2FpdCBjYWxsYmFjay5hcHBseShcbiAgICAgICAgICAgIG51bGwsXG4gICAgICAgICAgICBoYW5kbGUubm9uTXV0YXRpbmdDYWxsYmFja3MgPyBhcmdzIDogRUpTT04uY2xvbmUoYXJncylcbiAgICAgICAgICApKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuXG4gIC8vIFNlbmRzIGluaXRpYWwgYWRkcyB0byBhIGhhbmRsZS4gSXQgc2hvdWxkIG9ubHkgYmUgY2FsbGVkIGZyb20gd2l0aGluIGEgdGFza1xuICAvLyAodGhlIHRhc2sgdGhhdCBpcyBwcm9jZXNzaW5nIHRoZSBhZGRIYW5kbGVBbmRTZW5kSW5pdGlhbEFkZHMgY2FsbCkuIEl0XG4gIC8vIHN5bmNocm9ub3VzbHkgaW52b2tlcyB0aGUgaGFuZGxlJ3MgYWRkZWQgb3IgYWRkZWRCZWZvcmU7IHRoZXJlJ3Mgbm8gbmVlZCB0b1xuICAvLyBmbHVzaCB0aGUgcXVldWUgYWZ0ZXJ3YXJkcyB0byBlbnN1cmUgdGhhdCB0aGUgY2FsbGJhY2tzIGdldCBvdXQuXG4gIGFzeW5jIF9zZW5kQWRkcyhoYW5kbGUpIHtcbiAgICB2YXIgYWRkID0gdGhpcy5fb3JkZXJlZCA/IGhhbmRsZS5fYWRkZWRCZWZvcmUgOiBoYW5kbGUuX2FkZGVkO1xuICAgIGlmICghYWRkKVxuICAgICAgcmV0dXJuO1xuICAgIC8vIG5vdGU6IGRvY3MgbWF5IGJlIGFuIF9JZE1hcCBvciBhbiBPcmRlcmVkRGljdFxuICAgIGF3YWl0IHRoaXMuX2NhY2hlLmRvY3MuZm9yRWFjaEFzeW5jKGFzeW5jIChkb2MsIGlkKSA9PiB7XG4gICAgICBpZiAoIV8uaGFzKHRoaXMuX2hhbmRsZXMsIGhhbmRsZS5faWQpKVxuICAgICAgICB0aHJvdyBFcnJvcihcImhhbmRsZSBnb3QgcmVtb3ZlZCBiZWZvcmUgc2VuZGluZyBpbml0aWFsIGFkZHMhXCIpO1xuICAgICAgY29uc3QgeyBfaWQsIC4uLmZpZWxkcyB9ID0gaGFuZGxlLm5vbk11dGF0aW5nQ2FsbGJhY2tzID8gZG9jXG4gICAgICAgICAgOiBFSlNPTi5jbG9uZShkb2MpO1xuICAgICAgaWYgKHRoaXMuX29yZGVyZWQpXG4gICAgICAgIGF3YWl0IGFkZChpZCwgZmllbGRzLCBudWxsKTsgLy8gd2UncmUgZ29pbmcgaW4gb3JkZXIsIHNvIGFkZCBhdCBlbmRcbiAgICAgIGVsc2VcbiAgICAgICAgYXdhaXQgYWRkKGlkLCBmaWVsZHMpO1xuICAgIH0pO1xuICB9XG59O1xuXG4vLyBXaGVuIHRoZSBjYWxsYmFja3MgZG8gbm90IG11dGF0ZSB0aGUgYXJndW1lbnRzLCB3ZSBjYW4gc2tpcCBhIGxvdCBvZiBkYXRhIGNsb25lc1xuT2JzZXJ2ZUhhbmRsZSA9IGNsYXNzIHtcbiAgY29uc3RydWN0b3IobXVsdGlwbGV4ZXIsIGNhbGxiYWNrcywgbm9uTXV0YXRpbmdDYWxsYmFja3MgPSBmYWxzZSkge1xuICAgIHRoaXMuX211bHRpcGxleGVyID0gbXVsdGlwbGV4ZXI7XG4gICAgbXVsdGlwbGV4ZXIuY2FsbGJhY2tOYW1lcygpLmZvckVhY2goKG5hbWUpID0+IHtcbiAgICAgIGlmIChjYWxsYmFja3NbbmFtZV0pIHtcbiAgICAgICAgdGhpc1snXycgKyBuYW1lXSA9IGNhbGxiYWNrc1tuYW1lXTtcbiAgICAgIH0gZWxzZSBpZiAobmFtZSA9PT0gXCJhZGRlZEJlZm9yZVwiICYmIGNhbGxiYWNrcy5hZGRlZCkge1xuICAgICAgICAvLyBTcGVjaWFsIGNhc2U6IGlmIHlvdSBzcGVjaWZ5IFwiYWRkZWRcIiBhbmQgXCJtb3ZlZEJlZm9yZVwiLCB5b3UgZ2V0IGFuXG4gICAgICAgIC8vIG9yZGVyZWQgb2JzZXJ2ZSB3aGVyZSBmb3Igc29tZSByZWFzb24geW91IGRvbid0IGdldCBvcmRlcmluZyBkYXRhIG9uXG4gICAgICAgIC8vIHRoZSBhZGRzLiAgSSBkdW5ubywgd2Ugd3JvdGUgdGVzdHMgZm9yIGl0LCB0aGVyZSBtdXN0IGhhdmUgYmVlbiBhXG4gICAgICAgIC8vIHJlYXNvbi5cbiAgICAgICAgdGhpcy5fYWRkZWRCZWZvcmUgPSBhc3luYyBmdW5jdGlvbiAoaWQsIGZpZWxkcywgYmVmb3JlKSB7XG4gICAgICAgICAgYXdhaXQgY2FsbGJhY2tzLmFkZGVkKGlkLCBmaWVsZHMpO1xuICAgICAgICB9O1xuICAgICAgfVxuICAgIH0pO1xuICAgIHRoaXMuX3N0b3BwZWQgPSBmYWxzZTtcbiAgICB0aGlzLl9pZCA9IG5leHRPYnNlcnZlSGFuZGxlSWQrKztcbiAgICB0aGlzLm5vbk11dGF0aW5nQ2FsbGJhY2tzID0gbm9uTXV0YXRpbmdDYWxsYmFja3M7XG4gIH1cblxuICBhc3luYyBzdG9wKCkge1xuICAgIGlmICh0aGlzLl9zdG9wcGVkKSByZXR1cm47XG4gICAgdGhpcy5fc3RvcHBlZCA9IHRydWU7XG4gICAgYXdhaXQgdGhpcy5fbXVsdGlwbGV4ZXIucmVtb3ZlSGFuZGxlKHRoaXMuX2lkKTtcbiAgfVxufTtcbiIsImV4cG9ydCBjbGFzcyBEb2NGZXRjaGVyIHtcbiAgY29uc3RydWN0b3IobW9uZ29Db25uZWN0aW9uKSB7XG4gICAgdGhpcy5fbW9uZ29Db25uZWN0aW9uID0gbW9uZ29Db25uZWN0aW9uO1xuICAgIC8vIE1hcCBmcm9tIG9wIC0+IFtjYWxsYmFja11cbiAgICB0aGlzLl9jYWxsYmFja3NGb3JPcCA9IG5ldyBNYXAoKTtcbiAgfVxuXG4gIC8vIEZldGNoZXMgZG9jdW1lbnQgXCJpZFwiIGZyb20gY29sbGVjdGlvbk5hbWUsIHJldHVybmluZyBpdCBvciBudWxsIGlmIG5vdFxuICAvLyBmb3VuZC5cbiAgLy9cbiAgLy8gSWYgeW91IG1ha2UgbXVsdGlwbGUgY2FsbHMgdG8gZmV0Y2goKSB3aXRoIHRoZSBzYW1lIG9wIHJlZmVyZW5jZSxcbiAgLy8gRG9jRmV0Y2hlciBtYXkgYXNzdW1lIHRoYXQgdGhleSBhbGwgcmV0dXJuIHRoZSBzYW1lIGRvY3VtZW50LiAoSXQgZG9lc1xuICAvLyBub3QgY2hlY2sgdG8gc2VlIGlmIGNvbGxlY3Rpb25OYW1lL2lkIG1hdGNoLilcbiAgLy9cbiAgLy8gWW91IG1heSBhc3N1bWUgdGhhdCBjYWxsYmFjayBpcyBuZXZlciBjYWxsZWQgc3luY2hyb25vdXNseSAoYW5kIGluIGZhY3RcbiAgLy8gT3Bsb2dPYnNlcnZlRHJpdmVyIGRvZXMgc28pLlxuICBhc3luYyBmZXRjaChjb2xsZWN0aW9uTmFtZSwgaWQsIG9wLCBjYWxsYmFjaykge1xuICAgIGNvbnN0IHNlbGYgPSB0aGlzO1xuXG4gICAgXG4gICAgY2hlY2soY29sbGVjdGlvbk5hbWUsIFN0cmluZyk7XG4gICAgY2hlY2sob3AsIE9iamVjdCk7XG5cblxuICAgIC8vIElmIHRoZXJlJ3MgYWxyZWFkeSBhbiBpbi1wcm9ncmVzcyBmZXRjaCBmb3IgdGhpcyBjYWNoZSBrZXksIHlpZWxkIHVudGlsXG4gICAgLy8gaXQncyBkb25lIGFuZCByZXR1cm4gd2hhdGV2ZXIgaXQgcmV0dXJucy5cbiAgICBpZiAoc2VsZi5fY2FsbGJhY2tzRm9yT3AuaGFzKG9wKSkge1xuICAgICAgc2VsZi5fY2FsbGJhY2tzRm9yT3AuZ2V0KG9wKS5wdXNoKGNhbGxiYWNrKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjb25zdCBjYWxsYmFja3MgPSBbY2FsbGJhY2tdO1xuICAgIHNlbGYuX2NhbGxiYWNrc0Zvck9wLnNldChvcCwgY2FsbGJhY2tzKTtcblxuICAgIHRyeSB7XG4gICAgICB2YXIgZG9jID1cbiAgICAgICAgKGF3YWl0IHNlbGYuX21vbmdvQ29ubmVjdGlvbi5maW5kT25lQXN5bmMoY29sbGVjdGlvbk5hbWUsIHtcbiAgICAgICAgICBfaWQ6IGlkLFxuICAgICAgICB9KSkgfHwgbnVsbDtcbiAgICAgIC8vIFJldHVybiBkb2MgdG8gYWxsIHJlbGV2YW50IGNhbGxiYWNrcy4gTm90ZSB0aGF0IHRoaXMgYXJyYXkgY2FuXG4gICAgICAvLyBjb250aW51ZSB0byBncm93IGR1cmluZyBjYWxsYmFjayBleGNlY3V0aW9uLlxuICAgICAgd2hpbGUgKGNhbGxiYWNrcy5sZW5ndGggPiAwKSB7XG4gICAgICAgIC8vIENsb25lIHRoZSBkb2N1bWVudCBzbyB0aGF0IHRoZSB2YXJpb3VzIGNhbGxzIHRvIGZldGNoIGRvbid0IHJldHVyblxuICAgICAgICAvLyBvYmplY3RzIHRoYXQgYXJlIGludGVydHdpbmdsZWQgd2l0aCBlYWNoIG90aGVyLiBDbG9uZSBiZWZvcmVcbiAgICAgICAgLy8gcG9wcGluZyB0aGUgZnV0dXJlLCBzbyB0aGF0IGlmIGNsb25lIHRocm93cywgdGhlIGVycm9yIGdldHMgcGFzc2VkXG4gICAgICAgIC8vIHRvIHRoZSBuZXh0IGNhbGxiYWNrLlxuICAgICAgICBjYWxsYmFja3MucG9wKCkobnVsbCwgRUpTT04uY2xvbmUoZG9jKSk7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgd2hpbGUgKGNhbGxiYWNrcy5sZW5ndGggPiAwKSB7XG4gICAgICAgIGNhbGxiYWNrcy5wb3AoKShlKTtcbiAgICAgIH1cbiAgICB9IGZpbmFsbHkge1xuICAgICAgLy8gWFhYIGNvbnNpZGVyIGtlZXBpbmcgdGhlIGRvYyBhcm91bmQgZm9yIGEgcGVyaW9kIG9mIHRpbWUgYmVmb3JlXG4gICAgICAvLyByZW1vdmluZyBmcm9tIHRoZSBjYWNoZVxuICAgICAgc2VsZi5fY2FsbGJhY2tzRm9yT3AuZGVsZXRlKG9wKTtcbiAgICB9XG4gIH1cbn1cbiIsInZhciBQT0xMSU5HX1RIUk9UVExFX01TID0gK3Byb2Nlc3MuZW52Lk1FVEVPUl9QT0xMSU5HX1RIUk9UVExFX01TIHx8IDUwO1xudmFyIFBPTExJTkdfSU5URVJWQUxfTVMgPSArcHJvY2Vzcy5lbnYuTUVURU9SX1BPTExJTkdfSU5URVJWQUxfTVMgfHwgMTAgKiAxMDAwO1xuXG5Qb2xsaW5nT2JzZXJ2ZURyaXZlciA9IGZ1bmN0aW9uIChvcHRpb25zKSB7XG4gIGNvbnN0IHNlbGYgPSB0aGlzO1xuICBzZWxmLl9vcHRpb25zID0gb3B0aW9ucztcblxuICBzZWxmLl9jdXJzb3JEZXNjcmlwdGlvbiA9IG9wdGlvbnMuY3Vyc29yRGVzY3JpcHRpb247XG4gIHNlbGYuX21vbmdvSGFuZGxlID0gb3B0aW9ucy5tb25nb0hhbmRsZTtcbiAgc2VsZi5fb3JkZXJlZCA9IG9wdGlvbnMub3JkZXJlZDtcbiAgc2VsZi5fbXVsdGlwbGV4ZXIgPSBvcHRpb25zLm11bHRpcGxleGVyO1xuICBzZWxmLl9zdG9wQ2FsbGJhY2tzID0gW107XG4gIHNlbGYuX3N0b3BwZWQgPSBmYWxzZTtcblxuICBzZWxmLl9jdXJzb3IgPSBzZWxmLl9tb25nb0hhbmRsZS5fY3JlYXRlU3luY2hyb25vdXNDdXJzb3IoXG4gICAgc2VsZi5fY3Vyc29yRGVzY3JpcHRpb24pO1xuXG4gIC8vIHByZXZpb3VzIHJlc3VsdHMgc25hcHNob3QuICBvbiBlYWNoIHBvbGwgY3ljbGUsIGRpZmZzIGFnYWluc3RcbiAgLy8gcmVzdWx0cyBkcml2ZXMgdGhlIGNhbGxiYWNrcy5cbiAgc2VsZi5fcmVzdWx0cyA9IG51bGw7XG5cbiAgLy8gVGhlIG51bWJlciBvZiBfcG9sbE1vbmdvIGNhbGxzIHRoYXQgaGF2ZSBiZWVuIGFkZGVkIHRvIHNlbGYuX3Rhc2tRdWV1ZSBidXRcbiAgLy8gaGF2ZSBub3Qgc3RhcnRlZCBydW5uaW5nLiBVc2VkIHRvIG1ha2Ugc3VyZSB3ZSBuZXZlciBzY2hlZHVsZSBtb3JlIHRoYW4gb25lXG4gIC8vIF9wb2xsTW9uZ28gKG90aGVyIHRoYW4gcG9zc2libHkgdGhlIG9uZSB0aGF0IGlzIGN1cnJlbnRseSBydW5uaW5nKS4gSXQnc1xuICAvLyBhbHNvIHVzZWQgYnkgX3N1c3BlbmRQb2xsaW5nIHRvIHByZXRlbmQgdGhlcmUncyBhIHBvbGwgc2NoZWR1bGVkLiBVc3VhbGx5LFxuICAvLyBpdCdzIGVpdGhlciAwIChmb3IgXCJubyBwb2xscyBzY2hlZHVsZWQgb3RoZXIgdGhhbiBtYXliZSBvbmUgY3VycmVudGx5XG4gIC8vIHJ1bm5pbmdcIikgb3IgMSAoZm9yIFwiYSBwb2xsIHNjaGVkdWxlZCB0aGF0IGlzbid0IHJ1bm5pbmcgeWV0XCIpLCBidXQgaXQgY2FuXG4gIC8vIGFsc28gYmUgMiBpZiBpbmNyZW1lbnRlZCBieSBfc3VzcGVuZFBvbGxpbmcuXG4gIHNlbGYuX3BvbGxzU2NoZWR1bGVkQnV0Tm90U3RhcnRlZCA9IDA7XG4gIHNlbGYuX3BlbmRpbmdXcml0ZXMgPSBbXTsgLy8gcGVvcGxlIHRvIG5vdGlmeSB3aGVuIHBvbGxpbmcgY29tcGxldGVzXG5cbiAgLy8gTWFrZSBzdXJlIHRvIGNyZWF0ZSBhIHNlcGFyYXRlbHkgdGhyb3R0bGVkIGZ1bmN0aW9uIGZvciBlYWNoXG4gIC8vIFBvbGxpbmdPYnNlcnZlRHJpdmVyIG9iamVjdC5cbiAgc2VsZi5fZW5zdXJlUG9sbElzU2NoZWR1bGVkID0gXy50aHJvdHRsZShcbiAgICBzZWxmLl91bnRocm90dGxlZEVuc3VyZVBvbGxJc1NjaGVkdWxlZCxcbiAgICBzZWxmLl9jdXJzb3JEZXNjcmlwdGlvbi5vcHRpb25zLnBvbGxpbmdUaHJvdHRsZU1zIHx8IFBPTExJTkdfVEhST1RUTEVfTVMgLyogbXMgKi8pO1xuXG4gIC8vIFhYWCBmaWd1cmUgb3V0IGlmIHdlIHN0aWxsIG5lZWQgYSBxdWV1ZVxuICBzZWxmLl90YXNrUXVldWUgPSBuZXcgTWV0ZW9yLl9Bc3luY2hyb25vdXNRdWV1ZSgpO1xuXG4gIFxufTtcblxuXy5leHRlbmQoUG9sbGluZ09ic2VydmVEcml2ZXIucHJvdG90eXBlLCB7XG4gIF9pbml0OiBhc3luYyBmdW5jdGlvbiAoKSB7XG4gICAgY29uc3Qgc2VsZiA9IHRoaXM7XG4gICAgY29uc3Qgb3B0aW9ucyA9IHNlbGYuX29wdGlvbnM7XG4gICAgY29uc3QgbGlzdGVuZXJzSGFuZGxlID0gYXdhaXQgbGlzdGVuQWxsKFxuICAgICAgc2VsZi5fY3Vyc29yRGVzY3JpcHRpb24sIGZ1bmN0aW9uIChub3RpZmljYXRpb24pIHtcbiAgICAgICAgLy8gV2hlbiBzb21lb25lIGRvZXMgYSB0cmFuc2FjdGlvbiB0aGF0IG1pZ2h0IGFmZmVjdCB1cywgc2NoZWR1bGUgYSBwb2xsXG4gICAgICAgIC8vIG9mIHRoZSBkYXRhYmFzZS4gSWYgdGhhdCB0cmFuc2FjdGlvbiBoYXBwZW5zIGluc2lkZSBvZiBhIHdyaXRlIGZlbmNlLFxuICAgICAgICAvLyBibG9jayB0aGUgZmVuY2UgdW50aWwgd2UndmUgcG9sbGVkIGFuZCBub3RpZmllZCBvYnNlcnZlcnMuXG4gICAgICAgIGNvbnN0IGZlbmNlID0gRERQU2VydmVyLl9nZXRDdXJyZW50RmVuY2UoKTtcbiAgICAgICAgaWYgKGZlbmNlKVxuICAgICAgICAgIHNlbGYuX3BlbmRpbmdXcml0ZXMucHVzaChmZW5jZS5iZWdpbldyaXRlKCkpO1xuICAgICAgICAvLyBFbnN1cmUgYSBwb2xsIGlzIHNjaGVkdWxlZC4uLiBidXQgaWYgd2UgYWxyZWFkeSBrbm93IHRoYXQgb25lIGlzLFxuICAgICAgICAvLyBkb24ndCBoaXQgdGhlIHRocm90dGxlZCBfZW5zdXJlUG9sbElzU2NoZWR1bGVkIGZ1bmN0aW9uICh3aGljaCBtaWdodFxuICAgICAgICAvLyBsZWFkIHRvIHVzIGNhbGxpbmcgaXQgdW5uZWNlc3NhcmlseSBpbiA8cG9sbGluZ1Rocm90dGxlTXM+IG1zKS5cbiAgICAgICAgaWYgKHNlbGYuX3BvbGxzU2NoZWR1bGVkQnV0Tm90U3RhcnRlZCA9PT0gMClcbiAgICAgICAgICBzZWxmLl9lbnN1cmVQb2xsSXNTY2hlZHVsZWQoKTtcbiAgICAgIH1cbiAgICApO1xuICAgIHNlbGYuX3N0b3BDYWxsYmFja3MucHVzaChhc3luYyBmdW5jdGlvbiAoKSB7IGF3YWl0IGxpc3RlbmVyc0hhbmRsZS5zdG9wKCk7IH0pO1xuICBcbiAgICAvLyBldmVyeSBvbmNlIGFuZCBhIHdoaWxlLCBwb2xsIGV2ZW4gaWYgd2UgZG9uJ3QgdGhpbmsgd2UncmUgZGlydHksIGZvclxuICAgIC8vIGV2ZW50dWFsIGNvbnNpc3RlbmN5IHdpdGggZGF0YWJhc2Ugd3JpdGVzIGZyb20gb3V0c2lkZSB0aGUgTWV0ZW9yXG4gICAgLy8gdW5pdmVyc2UuXG4gICAgLy9cbiAgICAvLyBGb3IgdGVzdGluZywgdGhlcmUncyBhbiB1bmRvY3VtZW50ZWQgY2FsbGJhY2sgYXJndW1lbnQgdG8gb2JzZXJ2ZUNoYW5nZXNcbiAgICAvLyB3aGljaCBkaXNhYmxlcyB0aW1lLWJhc2VkIHBvbGxpbmcgYW5kIGdldHMgY2FsbGVkIGF0IHRoZSBiZWdpbm5pbmcgb2YgZWFjaFxuICAgIC8vIHBvbGwuXG4gICAgaWYgKG9wdGlvbnMuX3Rlc3RPbmx5UG9sbENhbGxiYWNrKSB7XG4gICAgICBzZWxmLl90ZXN0T25seVBvbGxDYWxsYmFjayA9IG9wdGlvbnMuX3Rlc3RPbmx5UG9sbENhbGxiYWNrO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBwb2xsaW5nSW50ZXJ2YWwgPVxuICAgICAgICAgICAgc2VsZi5fY3Vyc29yRGVzY3JpcHRpb24ub3B0aW9ucy5wb2xsaW5nSW50ZXJ2YWxNcyB8fFxuICAgICAgICAgICAgc2VsZi5fY3Vyc29yRGVzY3JpcHRpb24ub3B0aW9ucy5fcG9sbGluZ0ludGVydmFsIHx8IC8vIENPTVBBVCB3aXRoIDEuMlxuICAgICAgICAgICAgUE9MTElOR19JTlRFUlZBTF9NUztcbiAgICAgIGNvbnN0IGludGVydmFsSGFuZGxlID0gTWV0ZW9yLnNldEludGVydmFsKFxuICAgICAgICBfLmJpbmQoc2VsZi5fZW5zdXJlUG9sbElzU2NoZWR1bGVkLCBzZWxmKSwgcG9sbGluZ0ludGVydmFsKTtcbiAgICAgIHNlbGYuX3N0b3BDYWxsYmFja3MucHVzaChmdW5jdGlvbiAoKSB7XG4gICAgICAgIE1ldGVvci5jbGVhckludGVydmFsKGludGVydmFsSGFuZGxlKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgICBcbiAgICAvLyBNYWtlIHN1cmUgd2UgYWN0dWFsbHkgcG9sbCBzb29uIVxuICAgIGF3YWl0IHRoaXMuX3VudGhyb3R0bGVkRW5zdXJlUG9sbElzU2NoZWR1bGVkKCk7XG5cbiAgICBQYWNrYWdlWydmYWN0cy1iYXNlJ10gJiYgUGFja2FnZVsnZmFjdHMtYmFzZSddLkZhY3RzLmluY3JlbWVudFNlcnZlckZhY3QoXG4gICAgICAgIFwibW9uZ28tbGl2ZWRhdGFcIiwgXCJvYnNlcnZlLWRyaXZlcnMtcG9sbGluZ1wiLCAxKTtcbiAgfSxcbiAgLy8gVGhpcyBpcyBhbHdheXMgY2FsbGVkIHRocm91Z2ggXy50aHJvdHRsZSAoZXhjZXB0IG9uY2UgYXQgc3RhcnR1cCkuXG4gIF91bnRocm90dGxlZEVuc3VyZVBvbGxJc1NjaGVkdWxlZDogYXN5bmMgZnVuY3Rpb24gKCkge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICBpZiAoc2VsZi5fcG9sbHNTY2hlZHVsZWRCdXROb3RTdGFydGVkID4gMClcbiAgICAgIHJldHVybjtcbiAgICArK3NlbGYuX3BvbGxzU2NoZWR1bGVkQnV0Tm90U3RhcnRlZDtcbiAgICBhd2FpdCBzZWxmLl90YXNrUXVldWUucnVuVGFzayhhc3luYyBmdW5jdGlvbiAoKSB7XG4gICAgICBhd2FpdCBzZWxmLl9wb2xsTW9uZ28oKTtcbiAgICB9KTtcbiAgfSxcblxuICAvLyB0ZXN0LW9ubHkgaW50ZXJmYWNlIGZvciBjb250cm9sbGluZyBwb2xsaW5nLlxuICAvL1xuICAvLyBfc3VzcGVuZFBvbGxpbmcgYmxvY2tzIHVudGlsIGFueSBjdXJyZW50bHkgcnVubmluZyBhbmQgc2NoZWR1bGVkIHBvbGxzIGFyZVxuICAvLyBkb25lLCBhbmQgcHJldmVudHMgYW55IGZ1cnRoZXIgcG9sbHMgZnJvbSBiZWluZyBzY2hlZHVsZWQuIChuZXdcbiAgLy8gT2JzZXJ2ZUhhbmRsZXMgY2FuIGJlIGFkZGVkIGFuZCByZWNlaXZlIHRoZWlyIGluaXRpYWwgYWRkZWQgY2FsbGJhY2tzLFxuICAvLyB0aG91Z2guKVxuICAvL1xuICAvLyBfcmVzdW1lUG9sbGluZyBpbW1lZGlhdGVseSBwb2xscywgYW5kIGFsbG93cyBmdXJ0aGVyIHBvbGxzIHRvIG9jY3VyLlxuICBfc3VzcGVuZFBvbGxpbmc6IGZ1bmN0aW9uKCkge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAvLyBQcmV0ZW5kIHRoYXQgdGhlcmUncyBhbm90aGVyIHBvbGwgc2NoZWR1bGVkICh3aGljaCB3aWxsIHByZXZlbnRcbiAgICAvLyBfZW5zdXJlUG9sbElzU2NoZWR1bGVkIGZyb20gcXVldWVpbmcgYW55IG1vcmUgcG9sbHMpLlxuICAgICsrc2VsZi5fcG9sbHNTY2hlZHVsZWRCdXROb3RTdGFydGVkO1xuICAgIC8vIE5vdyBibG9jayB1bnRpbCBhbGwgY3VycmVudGx5IHJ1bm5pbmcgb3Igc2NoZWR1bGVkIHBvbGxzIGFyZSBkb25lLlxuICAgIHNlbGYuX3Rhc2tRdWV1ZS5ydW5UYXNrKGZ1bmN0aW9uKCkge30pO1xuXG4gICAgLy8gQ29uZmlybSB0aGF0IHRoZXJlIGlzIG9ubHkgb25lIFwicG9sbFwiICh0aGUgZmFrZSBvbmUgd2UncmUgcHJldGVuZGluZyB0b1xuICAgIC8vIGhhdmUpIHNjaGVkdWxlZC5cbiAgICBpZiAoc2VsZi5fcG9sbHNTY2hlZHVsZWRCdXROb3RTdGFydGVkICE9PSAxKVxuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiX3BvbGxzU2NoZWR1bGVkQnV0Tm90U3RhcnRlZCBpcyBcIiArXG4gICAgICAgICAgICAgICAgICAgICAgc2VsZi5fcG9sbHNTY2hlZHVsZWRCdXROb3RTdGFydGVkKTtcbiAgfSxcbiAgX3Jlc3VtZVBvbGxpbmc6IGFzeW5jIGZ1bmN0aW9uKCkge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAvLyBXZSBzaG91bGQgYmUgaW4gdGhlIHNhbWUgc3RhdGUgYXMgaW4gdGhlIGVuZCBvZiBfc3VzcGVuZFBvbGxpbmcuXG4gICAgaWYgKHNlbGYuX3BvbGxzU2NoZWR1bGVkQnV0Tm90U3RhcnRlZCAhPT0gMSlcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIl9wb2xsc1NjaGVkdWxlZEJ1dE5vdFN0YXJ0ZWQgaXMgXCIgK1xuICAgICAgICAgICAgICAgICAgICAgIHNlbGYuX3BvbGxzU2NoZWR1bGVkQnV0Tm90U3RhcnRlZCk7XG4gICAgLy8gUnVuIGEgcG9sbCBzeW5jaHJvbm91c2x5ICh3aGljaCB3aWxsIGNvdW50ZXJhY3QgdGhlXG4gICAgLy8gKytfcG9sbHNTY2hlZHVsZWRCdXROb3RTdGFydGVkIGZyb20gX3N1c3BlbmRQb2xsaW5nKS5cbiAgICBhd2FpdCBzZWxmLl90YXNrUXVldWUucnVuVGFzayhhc3luYyBmdW5jdGlvbiAoKSB7XG4gICAgICBhd2FpdCBzZWxmLl9wb2xsTW9uZ28oKTtcbiAgICB9KTtcbiAgfSxcblxuICBhc3luYyBfcG9sbE1vbmdvKCkge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAtLXNlbGYuX3BvbGxzU2NoZWR1bGVkQnV0Tm90U3RhcnRlZDtcblxuICAgIGlmIChzZWxmLl9zdG9wcGVkKVxuICAgICAgcmV0dXJuO1xuXG4gICAgdmFyIGZpcnN0ID0gZmFsc2U7XG4gICAgdmFyIG5ld1Jlc3VsdHM7XG4gICAgdmFyIG9sZFJlc3VsdHMgPSBzZWxmLl9yZXN1bHRzO1xuICAgIGlmICghb2xkUmVzdWx0cykge1xuICAgICAgZmlyc3QgPSB0cnVlO1xuICAgICAgLy8gWFhYIG1heWJlIHVzZSBPcmRlcmVkRGljdCBpbnN0ZWFkP1xuICAgICAgb2xkUmVzdWx0cyA9IHNlbGYuX29yZGVyZWQgPyBbXSA6IG5ldyBMb2NhbENvbGxlY3Rpb24uX0lkTWFwO1xuICAgIH1cblxuICAgIHNlbGYuX3Rlc3RPbmx5UG9sbENhbGxiYWNrICYmIHNlbGYuX3Rlc3RPbmx5UG9sbENhbGxiYWNrKCk7XG5cbiAgICAvLyBTYXZlIHRoZSBsaXN0IG9mIHBlbmRpbmcgd3JpdGVzIHdoaWNoIHRoaXMgcm91bmQgd2lsbCBjb21taXQuXG4gICAgdmFyIHdyaXRlc0ZvckN5Y2xlID0gc2VsZi5fcGVuZGluZ1dyaXRlcztcbiAgICBzZWxmLl9wZW5kaW5nV3JpdGVzID0gW107XG5cbiAgICAvLyBHZXQgdGhlIG5ldyBxdWVyeSByZXN1bHRzLiAoVGhpcyB5aWVsZHMuKVxuICAgIHRyeSB7XG4gICAgICBuZXdSZXN1bHRzID0gYXdhaXQgc2VsZi5fY3Vyc29yLmdldFJhd09iamVjdHMoc2VsZi5fb3JkZXJlZCk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgaWYgKGZpcnN0ICYmIHR5cGVvZihlLmNvZGUpID09PSAnbnVtYmVyJykge1xuICAgICAgICAvLyBUaGlzIGlzIGFuIGVycm9yIGRvY3VtZW50IHNlbnQgdG8gdXMgYnkgbW9uZ29kLCBub3QgYSBjb25uZWN0aW9uXG4gICAgICAgIC8vIGVycm9yIGdlbmVyYXRlZCBieSB0aGUgY2xpZW50LiBBbmQgd2UndmUgbmV2ZXIgc2VlbiB0aGlzIHF1ZXJ5IHdvcmtcbiAgICAgICAgLy8gc3VjY2Vzc2Z1bGx5LiBQcm9iYWJseSBpdCdzIGEgYmFkIHNlbGVjdG9yIG9yIHNvbWV0aGluZywgc28gd2Ugc2hvdWxkXG4gICAgICAgIC8vIE5PVCByZXRyeS4gSW5zdGVhZCwgd2Ugc2hvdWxkIGhhbHQgdGhlIG9ic2VydmUgKHdoaWNoIGVuZHMgdXAgY2FsbGluZ1xuICAgICAgICAvLyBgc3RvcGAgb24gdXMpLlxuICAgICAgICBhd2FpdCBzZWxmLl9tdWx0aXBsZXhlci5xdWVyeUVycm9yKFxuICAgICAgICAgICAgbmV3IEVycm9yKFxuICAgICAgICAgICAgICAgIFwiRXhjZXB0aW9uIHdoaWxlIHBvbGxpbmcgcXVlcnkgXCIgK1xuICAgICAgICAgICAgICAgIEpTT04uc3RyaW5naWZ5KHNlbGYuX2N1cnNvckRlc2NyaXB0aW9uKSArIFwiOiBcIiArIGUubWVzc2FnZSkpO1xuICAgICAgfVxuXG4gICAgICAvLyBnZXRSYXdPYmplY3RzIGNhbiB0aHJvdyBpZiB3ZSdyZSBoYXZpbmcgdHJvdWJsZSB0YWxraW5nIHRvIHRoZVxuICAgICAgLy8gZGF0YWJhc2UuICBUaGF0J3MgZmluZSAtLS0gd2Ugd2lsbCByZXBvbGwgbGF0ZXIgYW55d2F5LiBCdXQgd2Ugc2hvdWxkXG4gICAgICAvLyBtYWtlIHN1cmUgbm90IHRvIGxvc2UgdHJhY2sgb2YgdGhpcyBjeWNsZSdzIHdyaXRlcy5cbiAgICAgIC8vIChJdCBhbHNvIGNhbiB0aHJvdyBpZiB0aGVyZSdzIGp1c3Qgc29tZXRoaW5nIGludmFsaWQgYWJvdXQgdGhpcyBxdWVyeTtcbiAgICAgIC8vIHVuZm9ydHVuYXRlbHkgdGhlIE9ic2VydmVEcml2ZXIgQVBJIGRvZXNuJ3QgcHJvdmlkZSBhIGdvb2Qgd2F5IHRvXG4gICAgICAvLyBcImNhbmNlbFwiIHRoZSBvYnNlcnZlIGZyb20gdGhlIGluc2lkZSBpbiB0aGlzIGNhc2UuXG4gICAgICBBcnJheS5wcm90b3R5cGUucHVzaC5hcHBseShzZWxmLl9wZW5kaW5nV3JpdGVzLCB3cml0ZXNGb3JDeWNsZSk7XG4gICAgICBNZXRlb3IuX2RlYnVnKFwiRXhjZXB0aW9uIHdoaWxlIHBvbGxpbmcgcXVlcnkgXCIgK1xuICAgICAgICAgIEpTT04uc3RyaW5naWZ5KHNlbGYuX2N1cnNvckRlc2NyaXB0aW9uKSwgZSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgLy8gUnVuIGRpZmZzLlxuICAgIGlmICghc2VsZi5fc3RvcHBlZCkge1xuICAgICAgTG9jYWxDb2xsZWN0aW9uLl9kaWZmUXVlcnlDaGFuZ2VzKFxuICAgICAgICAgIHNlbGYuX29yZGVyZWQsIG9sZFJlc3VsdHMsIG5ld1Jlc3VsdHMsIHNlbGYuX211bHRpcGxleGVyKTtcbiAgICB9XG5cbiAgICAvLyBTaWduYWxzIHRoZSBtdWx0aXBsZXhlciB0byBhbGxvdyBhbGwgb2JzZXJ2ZUNoYW5nZXMgY2FsbHMgdGhhdCBzaGFyZSB0aGlzXG4gICAgLy8gbXVsdGlwbGV4ZXIgdG8gcmV0dXJuLiAoVGhpcyBoYXBwZW5zIGFzeW5jaHJvbm91c2x5LCB2aWEgdGhlXG4gICAgLy8gbXVsdGlwbGV4ZXIncyBxdWV1ZS4pXG4gICAgaWYgKGZpcnN0KVxuICAgICAgc2VsZi5fbXVsdGlwbGV4ZXIucmVhZHkoKTtcblxuICAgIC8vIFJlcGxhY2Ugc2VsZi5fcmVzdWx0cyBhdG9taWNhbGx5LiAgKFRoaXMgYXNzaWdubWVudCBpcyB3aGF0IG1ha2VzIGBmaXJzdGBcbiAgICAvLyBzdGF5IHRocm91Z2ggb24gdGhlIG5leHQgY3ljbGUsIHNvIHdlJ3ZlIHdhaXRlZCB1bnRpbCBhZnRlciB3ZSd2ZVxuICAgIC8vIGNvbW1pdHRlZCB0byByZWFkeS1pbmcgdGhlIG11bHRpcGxleGVyLilcbiAgICBzZWxmLl9yZXN1bHRzID0gbmV3UmVzdWx0cztcblxuICAgIC8vIE9uY2UgdGhlIE9ic2VydmVNdWx0aXBsZXhlciBoYXMgcHJvY2Vzc2VkIGV2ZXJ5dGhpbmcgd2UndmUgZG9uZSBpbiB0aGlzXG4gICAgLy8gcm91bmQsIG1hcmsgYWxsIHRoZSB3cml0ZXMgd2hpY2ggZXhpc3RlZCBiZWZvcmUgdGhpcyBjYWxsIGFzXG4gICAgLy8gY29tbW1pdHRlZC4gKElmIG5ldyB3cml0ZXMgaGF2ZSBzaG93biB1cCBpbiB0aGUgbWVhbnRpbWUsIHRoZXJlJ2xsXG4gICAgLy8gYWxyZWFkeSBiZSBhbm90aGVyIF9wb2xsTW9uZ28gdGFzayBzY2hlZHVsZWQuKVxuICAgIGF3YWl0IHNlbGYuX211bHRpcGxleGVyLm9uRmx1c2goYXN5bmMgZnVuY3Rpb24gKCkge1xuICAgICAgZm9yIChjb25zdCB3IG9mIHdyaXRlc0ZvckN5Y2xlKSB7XG4gICAgICAgIGF3YWl0IHcuY29tbWl0dGVkKCk7XG4gICAgICB9XG4gICAgfSk7XG4gIH0sXG5cbiAgc3RvcDogZnVuY3Rpb24gKCkge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICBzZWxmLl9zdG9wcGVkID0gdHJ1ZTtcbiAgICBjb25zdCBzdG9wQ2FsbGJhY2tzQ2FsbGVyID0gYXN5bmMgZnVuY3Rpb24oYykge1xuICAgICAgYXdhaXQgYygpO1xuICAgIH07XG5cbiAgICBfLmVhY2goc2VsZi5fc3RvcENhbGxiYWNrcywgc3RvcENhbGxiYWNrc0NhbGxlcik7XG4gICAgLy8gUmVsZWFzZSBhbnkgd3JpdGUgZmVuY2VzIHRoYXQgYXJlIHdhaXRpbmcgb24gdXMuXG4gICAgXy5lYWNoKHNlbGYuX3BlbmRpbmdXcml0ZXMsIGFzeW5jIGZ1bmN0aW9uICh3KSB7XG4gICAgICBhd2FpdCB3LmNvbW1pdHRlZCgpO1xuICAgIH0pO1xuICAgIFBhY2thZ2VbJ2ZhY3RzLWJhc2UnXSAmJiBQYWNrYWdlWydmYWN0cy1iYXNlJ10uRmFjdHMuaW5jcmVtZW50U2VydmVyRmFjdChcbiAgICAgIFwibW9uZ28tbGl2ZWRhdGFcIiwgXCJvYnNlcnZlLWRyaXZlcnMtcG9sbGluZ1wiLCAtMSk7XG4gIH1cbn0pO1xuIiwiaW1wb3J0IHsgb3Bsb2dWMlYxQ29udmVydGVyIH0gZnJvbSBcIi4vb3Bsb2dfdjJfY29udmVydGVyXCI7XG5pbXBvcnQgeyBjaGVjaywgTWF0Y2ggfSBmcm9tICdtZXRlb3IvY2hlY2snO1xuXG52YXIgUEhBU0UgPSB7XG4gIFFVRVJZSU5HOiBcIlFVRVJZSU5HXCIsXG4gIEZFVENISU5HOiBcIkZFVENISU5HXCIsXG4gIFNURUFEWTogXCJTVEVBRFlcIlxufTtcblxuLy8gRXhjZXB0aW9uIHRocm93biBieSBfbmVlZFRvUG9sbFF1ZXJ5IHdoaWNoIHVucm9sbHMgdGhlIHN0YWNrIHVwIHRvIHRoZVxuLy8gZW5jbG9zaW5nIGNhbGwgdG8gZmluaXNoSWZOZWVkVG9Qb2xsUXVlcnkuXG52YXIgU3dpdGNoZWRUb1F1ZXJ5ID0gZnVuY3Rpb24gKCkge307XG52YXIgZmluaXNoSWZOZWVkVG9Qb2xsUXVlcnkgPSBmdW5jdGlvbiAoZikge1xuICByZXR1cm4gZnVuY3Rpb24gKCkge1xuICAgIHRyeSB7XG4gICAgICBmLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgaWYgKCEoZSBpbnN0YW5jZW9mIFN3aXRjaGVkVG9RdWVyeSkpXG4gICAgICAgIHRocm93IGU7XG4gICAgfVxuICB9O1xufTtcblxudmFyIGN1cnJlbnRJZCA9IDA7XG5cbi8vIE9wbG9nT2JzZXJ2ZURyaXZlciBpcyBhbiBhbHRlcm5hdGl2ZSB0byBQb2xsaW5nT2JzZXJ2ZURyaXZlciB3aGljaCBmb2xsb3dzXG4vLyB0aGUgTW9uZ28gb3BlcmF0aW9uIGxvZyBpbnN0ZWFkIG9mIGp1c3QgcmUtcG9sbGluZyB0aGUgcXVlcnkuIEl0IG9iZXlzIHRoZVxuLy8gc2FtZSBzaW1wbGUgaW50ZXJmYWNlOiBjb25zdHJ1Y3RpbmcgaXQgc3RhcnRzIHNlbmRpbmcgb2JzZXJ2ZUNoYW5nZXNcbi8vIGNhbGxiYWNrcyAoYW5kIGEgcmVhZHkoKSBpbnZvY2F0aW9uKSB0byB0aGUgT2JzZXJ2ZU11bHRpcGxleGVyLCBhbmQgeW91IHN0b3Bcbi8vIGl0IGJ5IGNhbGxpbmcgdGhlIHN0b3AoKSBtZXRob2QuXG5PcGxvZ09ic2VydmVEcml2ZXIgPSBmdW5jdGlvbiAob3B0aW9ucykge1xuICBjb25zdCBzZWxmID0gdGhpcztcbiAgc2VsZi5fdXNlc09wbG9nID0gdHJ1ZTsgIC8vIHRlc3RzIGxvb2sgYXQgdGhpc1xuXG4gIHNlbGYuX2lkID0gY3VycmVudElkO1xuICBjdXJyZW50SWQrKztcblxuICBzZWxmLl9jdXJzb3JEZXNjcmlwdGlvbiA9IG9wdGlvbnMuY3Vyc29yRGVzY3JpcHRpb247XG4gIHNlbGYuX21vbmdvSGFuZGxlID0gb3B0aW9ucy5tb25nb0hhbmRsZTtcbiAgc2VsZi5fbXVsdGlwbGV4ZXIgPSBvcHRpb25zLm11bHRpcGxleGVyO1xuXG4gIGlmIChvcHRpb25zLm9yZGVyZWQpIHtcbiAgICB0aHJvdyBFcnJvcihcIk9wbG9nT2JzZXJ2ZURyaXZlciBvbmx5IHN1cHBvcnRzIHVub3JkZXJlZCBvYnNlcnZlQ2hhbmdlc1wiKTtcbiAgfVxuXG4gIGNvbnN0IHNvcnRlciA9IG9wdGlvbnMuc29ydGVyO1xuICAvLyBXZSBkb24ndCBzdXBwb3J0ICRuZWFyIGFuZCBvdGhlciBnZW8tcXVlcmllcyBzbyBpdCdzIE9LIHRvIGluaXRpYWxpemUgdGhlXG4gIC8vIGNvbXBhcmF0b3Igb25seSBvbmNlIGluIHRoZSBjb25zdHJ1Y3Rvci5cbiAgY29uc3QgY29tcGFyYXRvciA9IHNvcnRlciAmJiBzb3J0ZXIuZ2V0Q29tcGFyYXRvcigpO1xuXG4gIGlmIChvcHRpb25zLmN1cnNvckRlc2NyaXB0aW9uLm9wdGlvbnMubGltaXQpIHtcbiAgICAvLyBUaGVyZSBhcmUgc2V2ZXJhbCBwcm9wZXJ0aWVzIG9yZGVyZWQgZHJpdmVyIGltcGxlbWVudHM6XG4gICAgLy8gLSBfbGltaXQgaXMgYSBwb3NpdGl2ZSBudW1iZXJcbiAgICAvLyAtIF9jb21wYXJhdG9yIGlzIGEgZnVuY3Rpb24tY29tcGFyYXRvciBieSB3aGljaCB0aGUgcXVlcnkgaXMgb3JkZXJlZFxuICAgIC8vIC0gX3VucHVibGlzaGVkQnVmZmVyIGlzIG5vbi1udWxsIE1pbi9NYXggSGVhcCxcbiAgICAvLyAgICAgICAgICAgICAgICAgICAgICB0aGUgZW1wdHkgYnVmZmVyIGluIFNURUFEWSBwaGFzZSBpbXBsaWVzIHRoYXQgdGhlXG4gICAgLy8gICAgICAgICAgICAgICAgICAgICAgZXZlcnl0aGluZyB0aGF0IG1hdGNoZXMgdGhlIHF1ZXJpZXMgc2VsZWN0b3IgZml0c1xuICAgIC8vICAgICAgICAgICAgICAgICAgICAgIGludG8gcHVibGlzaGVkIHNldC5cbiAgICAvLyAtIF9wdWJsaXNoZWQgLSBNYXggSGVhcCAoYWxzbyBpbXBsZW1lbnRzIElkTWFwIG1ldGhvZHMpXG5cbiAgICBjb25zdCBoZWFwT3B0aW9ucyA9IHsgSWRNYXA6IExvY2FsQ29sbGVjdGlvbi5fSWRNYXAgfTtcbiAgICBzZWxmLl9saW1pdCA9IHNlbGYuX2N1cnNvckRlc2NyaXB0aW9uLm9wdGlvbnMubGltaXQ7XG4gICAgc2VsZi5fY29tcGFyYXRvciA9IGNvbXBhcmF0b3I7XG4gICAgc2VsZi5fc29ydGVyID0gc29ydGVyO1xuICAgIHNlbGYuX3VucHVibGlzaGVkQnVmZmVyID0gbmV3IE1pbk1heEhlYXAoY29tcGFyYXRvciwgaGVhcE9wdGlvbnMpO1xuICAgIC8vIFdlIG5lZWQgc29tZXRoaW5nIHRoYXQgY2FuIGZpbmQgTWF4IHZhbHVlIGluIGFkZGl0aW9uIHRvIElkTWFwIGludGVyZmFjZVxuICAgIHNlbGYuX3B1Ymxpc2hlZCA9IG5ldyBNYXhIZWFwKGNvbXBhcmF0b3IsIGhlYXBPcHRpb25zKTtcbiAgfSBlbHNlIHtcbiAgICBzZWxmLl9saW1pdCA9IDA7XG4gICAgc2VsZi5fY29tcGFyYXRvciA9IG51bGw7XG4gICAgc2VsZi5fc29ydGVyID0gbnVsbDtcbiAgICBzZWxmLl91bnB1Ymxpc2hlZEJ1ZmZlciA9IG51bGw7XG4gICAgc2VsZi5fcHVibGlzaGVkID0gbmV3IExvY2FsQ29sbGVjdGlvbi5fSWRNYXA7XG4gIH1cblxuICAvLyBJbmRpY2F0ZXMgaWYgaXQgaXMgc2FmZSB0byBpbnNlcnQgYSBuZXcgZG9jdW1lbnQgYXQgdGhlIGVuZCBvZiB0aGUgYnVmZmVyXG4gIC8vIGZvciB0aGlzIHF1ZXJ5LiBpLmUuIGl0IGlzIGtub3duIHRoYXQgdGhlcmUgYXJlIG5vIGRvY3VtZW50cyBtYXRjaGluZyB0aGVcbiAgLy8gc2VsZWN0b3IgdGhvc2UgYXJlIG5vdCBpbiBwdWJsaXNoZWQgb3IgYnVmZmVyLlxuICBzZWxmLl9zYWZlQXBwZW5kVG9CdWZmZXIgPSBmYWxzZTtcblxuICBzZWxmLl9zdG9wcGVkID0gZmFsc2U7XG4gIHNlbGYuX3N0b3BIYW5kbGVzID0gW107XG4gIHNlbGYuX2FkZFN0b3BIYW5kbGVzID0gZnVuY3Rpb24gKG5ld1N0b3BIYW5kbGVzKSB7XG4gICAgY29uc3QgZXhwZWN0ZWRQYXR0ZXJuID0gTWF0Y2guT2JqZWN0SW5jbHVkaW5nKHsgc3RvcDogRnVuY3Rpb24gfSk7XG4gICAgLy8gU2luZ2xlIGl0ZW0gb3IgYXJyYXlcbiAgICBjaGVjayhuZXdTdG9wSGFuZGxlcywgTWF0Y2guT25lT2YoW2V4cGVjdGVkUGF0dGVybl0sIGV4cGVjdGVkUGF0dGVybikpO1xuICAgIHNlbGYuX3N0b3BIYW5kbGVzLnB1c2gobmV3U3RvcEhhbmRsZXMpO1xuICB9XG5cbiAgUGFja2FnZVsnZmFjdHMtYmFzZSddICYmIFBhY2thZ2VbJ2ZhY3RzLWJhc2UnXS5GYWN0cy5pbmNyZW1lbnRTZXJ2ZXJGYWN0KFxuICAgIFwibW9uZ28tbGl2ZWRhdGFcIiwgXCJvYnNlcnZlLWRyaXZlcnMtb3Bsb2dcIiwgMSk7XG5cbiAgc2VsZi5fcmVnaXN0ZXJQaGFzZUNoYW5nZShQSEFTRS5RVUVSWUlORyk7XG5cbiAgc2VsZi5fbWF0Y2hlciA9IG9wdGlvbnMubWF0Y2hlcjtcbiAgLy8gd2UgYXJlIG5vdyB1c2luZyBwcm9qZWN0aW9uLCBub3QgZmllbGRzIGluIHRoZSBjdXJzb3IgZGVzY3JpcHRpb24gZXZlbiBpZiB5b3UgcGFzcyB7ZmllbGRzfVxuICAvLyBpbiB0aGUgY3Vyc29yIGNvbnN0cnVjdGlvblxuICBjb25zdCBwcm9qZWN0aW9uID0gc2VsZi5fY3Vyc29yRGVzY3JpcHRpb24ub3B0aW9ucy5maWVsZHMgfHwgc2VsZi5fY3Vyc29yRGVzY3JpcHRpb24ub3B0aW9ucy5wcm9qZWN0aW9uIHx8IHt9O1xuICBzZWxmLl9wcm9qZWN0aW9uRm4gPSBMb2NhbENvbGxlY3Rpb24uX2NvbXBpbGVQcm9qZWN0aW9uKHByb2plY3Rpb24pO1xuICAvLyBQcm9qZWN0aW9uIGZ1bmN0aW9uLCByZXN1bHQgb2YgY29tYmluaW5nIGltcG9ydGFudCBmaWVsZHMgZm9yIHNlbGVjdG9yIGFuZFxuICAvLyBleGlzdGluZyBmaWVsZHMgcHJvamVjdGlvblxuICBzZWxmLl9zaGFyZWRQcm9qZWN0aW9uID0gc2VsZi5fbWF0Y2hlci5jb21iaW5lSW50b1Byb2plY3Rpb24ocHJvamVjdGlvbik7XG4gIGlmIChzb3J0ZXIpXG4gICAgc2VsZi5fc2hhcmVkUHJvamVjdGlvbiA9IHNvcnRlci5jb21iaW5lSW50b1Byb2plY3Rpb24oc2VsZi5fc2hhcmVkUHJvamVjdGlvbik7XG4gIHNlbGYuX3NoYXJlZFByb2plY3Rpb25GbiA9IExvY2FsQ29sbGVjdGlvbi5fY29tcGlsZVByb2plY3Rpb24oXG4gICAgc2VsZi5fc2hhcmVkUHJvamVjdGlvbik7XG5cbiAgc2VsZi5fbmVlZFRvRmV0Y2ggPSBuZXcgTG9jYWxDb2xsZWN0aW9uLl9JZE1hcDtcbiAgc2VsZi5fY3VycmVudGx5RmV0Y2hpbmcgPSBudWxsO1xuICBzZWxmLl9mZXRjaEdlbmVyYXRpb24gPSAwO1xuXG4gIHNlbGYuX3JlcXVlcnlXaGVuRG9uZVRoaXNRdWVyeSA9IGZhbHNlO1xuICBzZWxmLl93cml0ZXNUb0NvbW1pdFdoZW5XZVJlYWNoU3RlYWR5ID0gW107XG5cblxuXG4gfTtcblxuXy5leHRlbmQoT3Bsb2dPYnNlcnZlRHJpdmVyLnByb3RvdHlwZSwge1xuICBfaW5pdDogYXN5bmMgZnVuY3Rpb24oKSB7XG4gICAgY29uc3Qgc2VsZiA9IHRoaXM7XG5cbiAgICAvLyBJZiB0aGUgb3Bsb2cgaGFuZGxlIHRlbGxzIHVzIHRoYXQgaXQgc2tpcHBlZCBzb21lIGVudHJpZXMgKGJlY2F1c2UgaXQgZ290XG4gICAgLy8gYmVoaW5kLCBzYXkpLCByZS1wb2xsLlxuICAgIHNlbGYuX2FkZFN0b3BIYW5kbGVzKHNlbGYuX21vbmdvSGFuZGxlLl9vcGxvZ0hhbmRsZS5vblNraXBwZWRFbnRyaWVzKFxuICAgICAgZmluaXNoSWZOZWVkVG9Qb2xsUXVlcnkoZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gc2VsZi5fbmVlZFRvUG9sbFF1ZXJ5KCk7XG4gICAgICB9KVxuICAgICkpO1xuICAgIFxuICAgIGF3YWl0IGZvckVhY2hUcmlnZ2VyKHNlbGYuX2N1cnNvckRlc2NyaXB0aW9uLCBhc3luYyBmdW5jdGlvbiAodHJpZ2dlcikge1xuICAgICAgc2VsZi5fYWRkU3RvcEhhbmRsZXMoYXdhaXQgc2VsZi5fbW9uZ29IYW5kbGUuX29wbG9nSGFuZGxlLm9uT3Bsb2dFbnRyeShcbiAgICAgICAgdHJpZ2dlciwgZnVuY3Rpb24gKG5vdGlmaWNhdGlvbikge1xuICAgICAgICAgIGZpbmlzaElmTmVlZFRvUG9sbFF1ZXJ5KGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGNvbnN0IG9wID0gbm90aWZpY2F0aW9uLm9wO1xuICAgICAgICAgICAgaWYgKG5vdGlmaWNhdGlvbi5kcm9wQ29sbGVjdGlvbiB8fCBub3RpZmljYXRpb24uZHJvcERhdGFiYXNlKSB7XG4gICAgICAgICAgICAgIC8vIE5vdGU6IHRoaXMgY2FsbCBpcyBub3QgYWxsb3dlZCB0byBibG9jayBvbiBhbnl0aGluZyAoZXNwZWNpYWxseVxuICAgICAgICAgICAgICAvLyBvbiB3YWl0aW5nIGZvciBvcGxvZyBlbnRyaWVzIHRvIGNhdGNoIHVwKSBiZWNhdXNlIHRoYXQgd2lsbCBibG9ja1xuICAgICAgICAgICAgICAvLyBvbk9wbG9nRW50cnkhXG4gICAgICAgICAgICAgIHJldHVybiBzZWxmLl9uZWVkVG9Qb2xsUXVlcnkoKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIC8vIEFsbCBvdGhlciBvcGVyYXRvcnMgc2hvdWxkIGJlIGhhbmRsZWQgZGVwZW5kaW5nIG9uIHBoYXNlXG4gICAgICAgICAgICAgIGlmIChzZWxmLl9waGFzZSA9PT0gUEhBU0UuUVVFUllJTkcpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gc2VsZi5faGFuZGxlT3Bsb2dFbnRyeVF1ZXJ5aW5nKG9wKTtcbiAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gc2VsZi5faGFuZGxlT3Bsb2dFbnRyeVN0ZWFkeU9yRmV0Y2hpbmcob3ApO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSkoKTtcbiAgICAgICAgfVxuICAgICAgKSk7XG4gICAgfSk7XG4gIFxuICAgIC8vIFhYWCBvcmRlcmluZyB3LnIudC4gZXZlcnl0aGluZyBlbHNlP1xuICAgIHNlbGYuX2FkZFN0b3BIYW5kbGVzKGF3YWl0IGxpc3RlbkFsbChcbiAgICAgIHNlbGYuX2N1cnNvckRlc2NyaXB0aW9uLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgIC8vIElmIHdlJ3JlIG5vdCBpbiBhIHByZS1maXJlIHdyaXRlIGZlbmNlLCB3ZSBkb24ndCBoYXZlIHRvIGRvIGFueXRoaW5nLlxuICAgICAgICBjb25zdCBmZW5jZSA9IEREUFNlcnZlci5fZ2V0Q3VycmVudEZlbmNlKCk7XG4gICAgICAgIGlmICghZmVuY2UgfHwgZmVuY2UuZmlyZWQpXG4gICAgICAgICAgcmV0dXJuO1xuICBcbiAgICAgICAgaWYgKGZlbmNlLl9vcGxvZ09ic2VydmVEcml2ZXJzKSB7XG4gICAgICAgICAgZmVuY2UuX29wbG9nT2JzZXJ2ZURyaXZlcnNbc2VsZi5faWRdID0gc2VsZjtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgXG4gICAgICAgIGZlbmNlLl9vcGxvZ09ic2VydmVEcml2ZXJzID0ge307XG4gICAgICAgIGZlbmNlLl9vcGxvZ09ic2VydmVEcml2ZXJzW3NlbGYuX2lkXSA9IHNlbGY7XG4gIFxuICAgICAgICBmZW5jZS5vbkJlZm9yZUZpcmUoYXN5bmMgZnVuY3Rpb24gKCkge1xuICAgICAgICAgIGNvbnN0IGRyaXZlcnMgPSBmZW5jZS5fb3Bsb2dPYnNlcnZlRHJpdmVycztcbiAgICAgICAgICBkZWxldGUgZmVuY2UuX29wbG9nT2JzZXJ2ZURyaXZlcnM7XG4gIFxuICAgICAgICAgIC8vIFRoaXMgZmVuY2UgY2Fubm90IGZpcmUgdW50aWwgd2UndmUgY2F1Z2h0IHVwIHRvIFwidGhpcyBwb2ludFwiIGluIHRoZVxuICAgICAgICAgIC8vIG9wbG9nLCBhbmQgYWxsIG9ic2VydmVycyBtYWRlIGl0IGJhY2sgdG8gdGhlIHN0ZWFkeSBzdGF0ZS5cbiAgICAgICAgICBhd2FpdCBzZWxmLl9tb25nb0hhbmRsZS5fb3Bsb2dIYW5kbGUud2FpdFVudGlsQ2F1Z2h0VXAoKTtcbiAgXG4gICAgICAgICAgZm9yIChjb25zdCBkcml2ZXIgb2YgT2JqZWN0LnZhbHVlcyhkcml2ZXJzKSkge1xuICAgICAgICAgICAgaWYgKGRyaXZlci5fc3RvcHBlZClcbiAgICAgICAgICAgICAgY29udGludWU7XG4gIFxuICAgICAgICAgICAgY29uc3Qgd3JpdGUgPSBhd2FpdCBmZW5jZS5iZWdpbldyaXRlKCk7XG4gICAgICAgICAgICBpZiAoZHJpdmVyLl9waGFzZSA9PT0gUEhBU0UuU1RFQURZKSB7XG4gICAgICAgICAgICAgIC8vIE1ha2Ugc3VyZSB0aGF0IGFsbCBvZiB0aGUgY2FsbGJhY2tzIGhhdmUgbWFkZSBpdCB0aHJvdWdoIHRoZVxuICAgICAgICAgICAgICAvLyBtdWx0aXBsZXhlciBhbmQgYmVlbiBkZWxpdmVyZWQgdG8gT2JzZXJ2ZUhhbmRsZXMgYmVmb3JlIGNvbW1pdHRpbmdcbiAgICAgICAgICAgICAgLy8gd3JpdGVzLlxuICAgICAgICAgICAgICBhd2FpdCBkcml2ZXIuX211bHRpcGxleGVyLm9uRmx1c2god3JpdGUuY29tbWl0dGVkKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIGRyaXZlci5fd3JpdGVzVG9Db21taXRXaGVuV2VSZWFjaFN0ZWFkeS5wdXNoKHdyaXRlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICkpO1xuICBcbiAgICAvLyBXaGVuIE1vbmdvIGZhaWxzIG92ZXIsIHdlIG5lZWQgdG8gcmVwb2xsIHRoZSBxdWVyeSwgaW4gY2FzZSB3ZSBwcm9jZXNzZWQgYW5cbiAgICAvLyBvcGxvZyBlbnRyeSB0aGF0IGdvdCByb2xsZWQgYmFjay5cbiAgICBzZWxmLl9hZGRTdG9wSGFuZGxlcyhzZWxmLl9tb25nb0hhbmRsZS5fb25GYWlsb3ZlcihmaW5pc2hJZk5lZWRUb1BvbGxRdWVyeShcbiAgICAgIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgcmV0dXJuIHNlbGYuX25lZWRUb1BvbGxRdWVyeSgpO1xuICAgICAgfSkpKTtcbiAgXG4gICAgLy8gR2l2ZSBfb2JzZXJ2ZUNoYW5nZXMgYSBjaGFuY2UgdG8gYWRkIHRoZSBuZXcgT2JzZXJ2ZUhhbmRsZSB0byBvdXJcbiAgICAvLyBtdWx0aXBsZXhlciwgc28gdGhhdCB0aGUgYWRkZWQgY2FsbHMgZ2V0IHN0cmVhbWVkLlxuICAgIHJldHVybiBzZWxmLl9ydW5Jbml0aWFsUXVlcnkoKTtcbiAgfSxcbiAgX2FkZFB1Ymxpc2hlZDogZnVuY3Rpb24gKGlkLCBkb2MpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgTWV0ZW9yLl9ub1lpZWxkc0FsbG93ZWQoZnVuY3Rpb24gKCkge1xuICAgICAgdmFyIGZpZWxkcyA9IF8uY2xvbmUoZG9jKTtcbiAgICAgIGRlbGV0ZSBmaWVsZHMuX2lkO1xuICAgICAgc2VsZi5fcHVibGlzaGVkLnNldChpZCwgc2VsZi5fc2hhcmVkUHJvamVjdGlvbkZuKGRvYykpO1xuICAgICAgc2VsZi5fbXVsdGlwbGV4ZXIuYWRkZWQoaWQsIHNlbGYuX3Byb2plY3Rpb25GbihmaWVsZHMpKTtcblxuICAgICAgLy8gQWZ0ZXIgYWRkaW5nIHRoaXMgZG9jdW1lbnQsIHRoZSBwdWJsaXNoZWQgc2V0IG1pZ2h0IGJlIG92ZXJmbG93ZWRcbiAgICAgIC8vIChleGNlZWRpbmcgY2FwYWNpdHkgc3BlY2lmaWVkIGJ5IGxpbWl0KS4gSWYgc28sIHB1c2ggdGhlIG1heGltdW1cbiAgICAgIC8vIGVsZW1lbnQgdG8gdGhlIGJ1ZmZlciwgd2UgbWlnaHQgd2FudCB0byBzYXZlIGl0IGluIG1lbW9yeSB0byByZWR1Y2UgdGhlXG4gICAgICAvLyBhbW91bnQgb2YgTW9uZ28gbG9va3VwcyBpbiB0aGUgZnV0dXJlLlxuICAgICAgaWYgKHNlbGYuX2xpbWl0ICYmIHNlbGYuX3B1Ymxpc2hlZC5zaXplKCkgPiBzZWxmLl9saW1pdCkge1xuICAgICAgICAvLyBYWFggaW4gdGhlb3J5IHRoZSBzaXplIG9mIHB1Ymxpc2hlZCBpcyBubyBtb3JlIHRoYW4gbGltaXQrMVxuICAgICAgICBpZiAoc2VsZi5fcHVibGlzaGVkLnNpemUoKSAhPT0gc2VsZi5fbGltaXQgKyAxKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiQWZ0ZXIgYWRkaW5nIHRvIHB1Ymxpc2hlZCwgXCIgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAoc2VsZi5fcHVibGlzaGVkLnNpemUoKSAtIHNlbGYuX2xpbWl0KSArXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFwiIGRvY3VtZW50cyBhcmUgb3ZlcmZsb3dpbmcgdGhlIHNldFwiKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHZhciBvdmVyZmxvd2luZ0RvY0lkID0gc2VsZi5fcHVibGlzaGVkLm1heEVsZW1lbnRJZCgpO1xuICAgICAgICB2YXIgb3ZlcmZsb3dpbmdEb2MgPSBzZWxmLl9wdWJsaXNoZWQuZ2V0KG92ZXJmbG93aW5nRG9jSWQpO1xuXG4gICAgICAgIGlmIChFSlNPTi5lcXVhbHMob3ZlcmZsb3dpbmdEb2NJZCwgaWQpKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiVGhlIGRvY3VtZW50IGp1c3QgYWRkZWQgaXMgb3ZlcmZsb3dpbmcgdGhlIHB1Ymxpc2hlZCBzZXRcIik7XG4gICAgICAgIH1cblxuICAgICAgICBzZWxmLl9wdWJsaXNoZWQucmVtb3ZlKG92ZXJmbG93aW5nRG9jSWQpO1xuICAgICAgICBzZWxmLl9tdWx0aXBsZXhlci5yZW1vdmVkKG92ZXJmbG93aW5nRG9jSWQpO1xuICAgICAgICBzZWxmLl9hZGRCdWZmZXJlZChvdmVyZmxvd2luZ0RvY0lkLCBvdmVyZmxvd2luZ0RvYyk7XG4gICAgICB9XG4gICAgfSk7XG4gIH0sXG4gIF9yZW1vdmVQdWJsaXNoZWQ6IGZ1bmN0aW9uIChpZCkge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICBNZXRlb3IuX25vWWllbGRzQWxsb3dlZChmdW5jdGlvbiAoKSB7XG4gICAgICBzZWxmLl9wdWJsaXNoZWQucmVtb3ZlKGlkKTtcbiAgICAgIHNlbGYuX211bHRpcGxleGVyLnJlbW92ZWQoaWQpO1xuICAgICAgaWYgKCEgc2VsZi5fbGltaXQgfHwgc2VsZi5fcHVibGlzaGVkLnNpemUoKSA9PT0gc2VsZi5fbGltaXQpXG4gICAgICAgIHJldHVybjtcblxuICAgICAgaWYgKHNlbGYuX3B1Ymxpc2hlZC5zaXplKCkgPiBzZWxmLl9saW1pdClcbiAgICAgICAgdGhyb3cgRXJyb3IoXCJzZWxmLl9wdWJsaXNoZWQgZ290IHRvbyBiaWdcIik7XG5cbiAgICAgIC8vIE9LLCB3ZSBhcmUgcHVibGlzaGluZyBsZXNzIHRoYW4gdGhlIGxpbWl0LiBNYXliZSB3ZSBzaG91bGQgbG9vayBpbiB0aGVcbiAgICAgIC8vIGJ1ZmZlciB0byBmaW5kIHRoZSBuZXh0IGVsZW1lbnQgcGFzdCB3aGF0IHdlIHdlcmUgcHVibGlzaGluZyBiZWZvcmUuXG5cbiAgICAgIGlmICghc2VsZi5fdW5wdWJsaXNoZWRCdWZmZXIuZW1wdHkoKSkge1xuICAgICAgICAvLyBUaGVyZSdzIHNvbWV0aGluZyBpbiB0aGUgYnVmZmVyOyBtb3ZlIHRoZSBmaXJzdCB0aGluZyBpbiBpdCB0b1xuICAgICAgICAvLyBfcHVibGlzaGVkLlxuICAgICAgICB2YXIgbmV3RG9jSWQgPSBzZWxmLl91bnB1Ymxpc2hlZEJ1ZmZlci5taW5FbGVtZW50SWQoKTtcbiAgICAgICAgdmFyIG5ld0RvYyA9IHNlbGYuX3VucHVibGlzaGVkQnVmZmVyLmdldChuZXdEb2NJZCk7XG4gICAgICAgIHNlbGYuX3JlbW92ZUJ1ZmZlcmVkKG5ld0RvY0lkKTtcbiAgICAgICAgc2VsZi5fYWRkUHVibGlzaGVkKG5ld0RvY0lkLCBuZXdEb2MpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG5cbiAgICAgIC8vIFRoZXJlJ3Mgbm90aGluZyBpbiB0aGUgYnVmZmVyLiAgVGhpcyBjb3VsZCBtZWFuIG9uZSBvZiBhIGZldyB0aGluZ3MuXG5cbiAgICAgIC8vIChhKSBXZSBjb3VsZCBiZSBpbiB0aGUgbWlkZGxlIG9mIHJlLXJ1bm5pbmcgdGhlIHF1ZXJ5IChzcGVjaWZpY2FsbHksIHdlXG4gICAgICAvLyBjb3VsZCBiZSBpbiBfcHVibGlzaE5ld1Jlc3VsdHMpLiBJbiB0aGF0IGNhc2UsIF91bnB1Ymxpc2hlZEJ1ZmZlciBpc1xuICAgICAgLy8gZW1wdHkgYmVjYXVzZSB3ZSBjbGVhciBpdCBhdCB0aGUgYmVnaW5uaW5nIG9mIF9wdWJsaXNoTmV3UmVzdWx0cy4gSW5cbiAgICAgIC8vIHRoaXMgY2FzZSwgb3VyIGNhbGxlciBhbHJlYWR5IGtub3dzIHRoZSBlbnRpcmUgYW5zd2VyIHRvIHRoZSBxdWVyeSBhbmRcbiAgICAgIC8vIHdlIGRvbid0IG5lZWQgdG8gZG8gYW55dGhpbmcgZmFuY3kgaGVyZS4gIEp1c3QgcmV0dXJuLlxuICAgICAgaWYgKHNlbGYuX3BoYXNlID09PSBQSEFTRS5RVUVSWUlORylcbiAgICAgICAgcmV0dXJuO1xuXG4gICAgICAvLyAoYikgV2UncmUgcHJldHR5IGNvbmZpZGVudCB0aGF0IHRoZSB1bmlvbiBvZiBfcHVibGlzaGVkIGFuZFxuICAgICAgLy8gX3VucHVibGlzaGVkQnVmZmVyIGNvbnRhaW4gYWxsIGRvY3VtZW50cyB0aGF0IG1hdGNoIHNlbGVjdG9yLiBCZWNhdXNlXG4gICAgICAvLyBfdW5wdWJsaXNoZWRCdWZmZXIgaXMgZW1wdHksIHRoYXQgbWVhbnMgd2UncmUgY29uZmlkZW50IHRoYXQgX3B1Ymxpc2hlZFxuICAgICAgLy8gY29udGFpbnMgYWxsIGRvY3VtZW50cyB0aGF0IG1hdGNoIHNlbGVjdG9yLiBTbyB3ZSBoYXZlIG5vdGhpbmcgdG8gZG8uXG4gICAgICBpZiAoc2VsZi5fc2FmZUFwcGVuZFRvQnVmZmVyKVxuICAgICAgICByZXR1cm47XG5cbiAgICAgIC8vIChjKSBNYXliZSB0aGVyZSBhcmUgb3RoZXIgZG9jdW1lbnRzIG91dCB0aGVyZSB0aGF0IHNob3VsZCBiZSBpbiBvdXJcbiAgICAgIC8vIGJ1ZmZlci4gQnV0IGluIHRoYXQgY2FzZSwgd2hlbiB3ZSBlbXB0aWVkIF91bnB1Ymxpc2hlZEJ1ZmZlciBpblxuICAgICAgLy8gX3JlbW92ZUJ1ZmZlcmVkLCB3ZSBzaG91bGQgaGF2ZSBjYWxsZWQgX25lZWRUb1BvbGxRdWVyeSwgd2hpY2ggd2lsbFxuICAgICAgLy8gZWl0aGVyIHB1dCBzb21ldGhpbmcgaW4gX3VucHVibGlzaGVkQnVmZmVyIG9yIHNldCBfc2FmZUFwcGVuZFRvQnVmZmVyXG4gICAgICAvLyAob3IgYm90aCksIGFuZCBpdCB3aWxsIHB1dCB1cyBpbiBRVUVSWUlORyBmb3IgdGhhdCB3aG9sZSB0aW1lLiBTbyBpblxuICAgICAgLy8gZmFjdCwgd2Ugc2hvdWxkbid0IGJlIGFibGUgdG8gZ2V0IGhlcmUuXG5cbiAgICAgIHRocm93IG5ldyBFcnJvcihcIkJ1ZmZlciBpbmV4cGxpY2FibHkgZW1wdHlcIik7XG4gICAgfSk7XG4gIH0sXG4gIF9jaGFuZ2VQdWJsaXNoZWQ6IGZ1bmN0aW9uIChpZCwgb2xkRG9jLCBuZXdEb2MpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgTWV0ZW9yLl9ub1lpZWxkc0FsbG93ZWQoZnVuY3Rpb24gKCkge1xuICAgICAgc2VsZi5fcHVibGlzaGVkLnNldChpZCwgc2VsZi5fc2hhcmVkUHJvamVjdGlvbkZuKG5ld0RvYykpO1xuICAgICAgdmFyIHByb2plY3RlZE5ldyA9IHNlbGYuX3Byb2plY3Rpb25GbihuZXdEb2MpO1xuICAgICAgdmFyIHByb2plY3RlZE9sZCA9IHNlbGYuX3Byb2plY3Rpb25GbihvbGREb2MpO1xuICAgICAgdmFyIGNoYW5nZWQgPSBEaWZmU2VxdWVuY2UubWFrZUNoYW5nZWRGaWVsZHMoXG4gICAgICAgIHByb2plY3RlZE5ldywgcHJvamVjdGVkT2xkKTtcbiAgICAgIGlmICghXy5pc0VtcHR5KGNoYW5nZWQpKVxuICAgICAgICBzZWxmLl9tdWx0aXBsZXhlci5jaGFuZ2VkKGlkLCBjaGFuZ2VkKTtcbiAgICB9KTtcbiAgfSxcbiAgX2FkZEJ1ZmZlcmVkOiBmdW5jdGlvbiAoaWQsIGRvYykge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICBNZXRlb3IuX25vWWllbGRzQWxsb3dlZChmdW5jdGlvbiAoKSB7XG4gICAgICBzZWxmLl91bnB1Ymxpc2hlZEJ1ZmZlci5zZXQoaWQsIHNlbGYuX3NoYXJlZFByb2plY3Rpb25Gbihkb2MpKTtcblxuICAgICAgLy8gSWYgc29tZXRoaW5nIGlzIG92ZXJmbG93aW5nIHRoZSBidWZmZXIsIHdlIGp1c3QgcmVtb3ZlIGl0IGZyb20gY2FjaGVcbiAgICAgIGlmIChzZWxmLl91bnB1Ymxpc2hlZEJ1ZmZlci5zaXplKCkgPiBzZWxmLl9saW1pdCkge1xuICAgICAgICB2YXIgbWF4QnVmZmVyZWRJZCA9IHNlbGYuX3VucHVibGlzaGVkQnVmZmVyLm1heEVsZW1lbnRJZCgpO1xuXG4gICAgICAgIHNlbGYuX3VucHVibGlzaGVkQnVmZmVyLnJlbW92ZShtYXhCdWZmZXJlZElkKTtcblxuICAgICAgICAvLyBTaW5jZSBzb21ldGhpbmcgbWF0Y2hpbmcgaXMgcmVtb3ZlZCBmcm9tIGNhY2hlIChib3RoIHB1Ymxpc2hlZCBzZXQgYW5kXG4gICAgICAgIC8vIGJ1ZmZlciksIHNldCBmbGFnIHRvIGZhbHNlXG4gICAgICAgIHNlbGYuX3NhZmVBcHBlbmRUb0J1ZmZlciA9IGZhbHNlO1xuICAgICAgfVxuICAgIH0pO1xuICB9LFxuICAvLyBJcyBjYWxsZWQgZWl0aGVyIHRvIHJlbW92ZSB0aGUgZG9jIGNvbXBsZXRlbHkgZnJvbSBtYXRjaGluZyBzZXQgb3IgdG8gbW92ZVxuICAvLyBpdCB0byB0aGUgcHVibGlzaGVkIHNldCBsYXRlci5cbiAgX3JlbW92ZUJ1ZmZlcmVkOiBmdW5jdGlvbiAoaWQpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgTWV0ZW9yLl9ub1lpZWxkc0FsbG93ZWQoZnVuY3Rpb24gKCkge1xuICAgICAgc2VsZi5fdW5wdWJsaXNoZWRCdWZmZXIucmVtb3ZlKGlkKTtcbiAgICAgIC8vIFRvIGtlZXAgdGhlIGNvbnRyYWN0IFwiYnVmZmVyIGlzIG5ldmVyIGVtcHR5IGluIFNURUFEWSBwaGFzZSB1bmxlc3MgdGhlXG4gICAgICAvLyBldmVyeXRoaW5nIG1hdGNoaW5nIGZpdHMgaW50byBwdWJsaXNoZWRcIiB0cnVlLCB3ZSBwb2xsIGV2ZXJ5dGhpbmcgYXNcbiAgICAgIC8vIHNvb24gYXMgd2Ugc2VlIHRoZSBidWZmZXIgYmVjb21pbmcgZW1wdHkuXG4gICAgICBpZiAoISBzZWxmLl91bnB1Ymxpc2hlZEJ1ZmZlci5zaXplKCkgJiYgISBzZWxmLl9zYWZlQXBwZW5kVG9CdWZmZXIpXG4gICAgICAgIHNlbGYuX25lZWRUb1BvbGxRdWVyeSgpO1xuICAgIH0pO1xuICB9LFxuICAvLyBDYWxsZWQgd2hlbiBhIGRvY3VtZW50IGhhcyBqb2luZWQgdGhlIFwiTWF0Y2hpbmdcIiByZXN1bHRzIHNldC5cbiAgLy8gVGFrZXMgcmVzcG9uc2liaWxpdHkgb2Yga2VlcGluZyBfdW5wdWJsaXNoZWRCdWZmZXIgaW4gc3luYyB3aXRoIF9wdWJsaXNoZWRcbiAgLy8gYW5kIHRoZSBlZmZlY3Qgb2YgbGltaXQgZW5mb3JjZWQuXG4gIF9hZGRNYXRjaGluZzogZnVuY3Rpb24gKGRvYykge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICBNZXRlb3IuX25vWWllbGRzQWxsb3dlZChmdW5jdGlvbiAoKSB7XG4gICAgICB2YXIgaWQgPSBkb2MuX2lkO1xuICAgICAgaWYgKHNlbGYuX3B1Ymxpc2hlZC5oYXMoaWQpKVxuICAgICAgICB0aHJvdyBFcnJvcihcInRyaWVkIHRvIGFkZCBzb21ldGhpbmcgYWxyZWFkeSBwdWJsaXNoZWQgXCIgKyBpZCk7XG4gICAgICBpZiAoc2VsZi5fbGltaXQgJiYgc2VsZi5fdW5wdWJsaXNoZWRCdWZmZXIuaGFzKGlkKSlcbiAgICAgICAgdGhyb3cgRXJyb3IoXCJ0cmllZCB0byBhZGQgc29tZXRoaW5nIGFscmVhZHkgZXhpc3RlZCBpbiBidWZmZXIgXCIgKyBpZCk7XG5cbiAgICAgIHZhciBsaW1pdCA9IHNlbGYuX2xpbWl0O1xuICAgICAgdmFyIGNvbXBhcmF0b3IgPSBzZWxmLl9jb21wYXJhdG9yO1xuICAgICAgdmFyIG1heFB1Ymxpc2hlZCA9IChsaW1pdCAmJiBzZWxmLl9wdWJsaXNoZWQuc2l6ZSgpID4gMCkgP1xuICAgICAgICBzZWxmLl9wdWJsaXNoZWQuZ2V0KHNlbGYuX3B1Ymxpc2hlZC5tYXhFbGVtZW50SWQoKSkgOiBudWxsO1xuICAgICAgdmFyIG1heEJ1ZmZlcmVkID0gKGxpbWl0ICYmIHNlbGYuX3VucHVibGlzaGVkQnVmZmVyLnNpemUoKSA+IDApXG4gICAgICAgID8gc2VsZi5fdW5wdWJsaXNoZWRCdWZmZXIuZ2V0KHNlbGYuX3VucHVibGlzaGVkQnVmZmVyLm1heEVsZW1lbnRJZCgpKVxuICAgICAgICA6IG51bGw7XG4gICAgICAvLyBUaGUgcXVlcnkgaXMgdW5saW1pdGVkIG9yIGRpZG4ndCBwdWJsaXNoIGVub3VnaCBkb2N1bWVudHMgeWV0IG9yIHRoZVxuICAgICAgLy8gbmV3IGRvY3VtZW50IHdvdWxkIGZpdCBpbnRvIHB1Ymxpc2hlZCBzZXQgcHVzaGluZyB0aGUgbWF4aW11bSBlbGVtZW50XG4gICAgICAvLyBvdXQsIHRoZW4gd2UgbmVlZCB0byBwdWJsaXNoIHRoZSBkb2MuXG4gICAgICB2YXIgdG9QdWJsaXNoID0gISBsaW1pdCB8fCBzZWxmLl9wdWJsaXNoZWQuc2l6ZSgpIDwgbGltaXQgfHxcbiAgICAgICAgY29tcGFyYXRvcihkb2MsIG1heFB1Ymxpc2hlZCkgPCAwO1xuXG4gICAgICAvLyBPdGhlcndpc2Ugd2UgbWlnaHQgbmVlZCB0byBidWZmZXIgaXQgKG9ubHkgaW4gY2FzZSBvZiBsaW1pdGVkIHF1ZXJ5KS5cbiAgICAgIC8vIEJ1ZmZlcmluZyBpcyBhbGxvd2VkIGlmIHRoZSBidWZmZXIgaXMgbm90IGZpbGxlZCB1cCB5ZXQgYW5kIGFsbFxuICAgICAgLy8gbWF0Y2hpbmcgZG9jcyBhcmUgZWl0aGVyIGluIHRoZSBwdWJsaXNoZWQgc2V0IG9yIGluIHRoZSBidWZmZXIuXG4gICAgICB2YXIgY2FuQXBwZW5kVG9CdWZmZXIgPSAhdG9QdWJsaXNoICYmIHNlbGYuX3NhZmVBcHBlbmRUb0J1ZmZlciAmJlxuICAgICAgICBzZWxmLl91bnB1Ymxpc2hlZEJ1ZmZlci5zaXplKCkgPCBsaW1pdDtcblxuICAgICAgLy8gT3IgaWYgaXQgaXMgc21hbGwgZW5vdWdoIHRvIGJlIHNhZmVseSBpbnNlcnRlZCB0byB0aGUgbWlkZGxlIG9yIHRoZVxuICAgICAgLy8gYmVnaW5uaW5nIG9mIHRoZSBidWZmZXIuXG4gICAgICB2YXIgY2FuSW5zZXJ0SW50b0J1ZmZlciA9ICF0b1B1Ymxpc2ggJiYgbWF4QnVmZmVyZWQgJiZcbiAgICAgICAgY29tcGFyYXRvcihkb2MsIG1heEJ1ZmZlcmVkKSA8PSAwO1xuXG4gICAgICB2YXIgdG9CdWZmZXIgPSBjYW5BcHBlbmRUb0J1ZmZlciB8fCBjYW5JbnNlcnRJbnRvQnVmZmVyO1xuXG4gICAgICBpZiAodG9QdWJsaXNoKSB7XG4gICAgICAgIHNlbGYuX2FkZFB1Ymxpc2hlZChpZCwgZG9jKTtcbiAgICAgIH0gZWxzZSBpZiAodG9CdWZmZXIpIHtcbiAgICAgICAgc2VsZi5fYWRkQnVmZmVyZWQoaWQsIGRvYyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvLyBkcm9wcGluZyBpdCBhbmQgbm90IHNhdmluZyB0byB0aGUgY2FjaGVcbiAgICAgICAgc2VsZi5fc2FmZUFwcGVuZFRvQnVmZmVyID0gZmFsc2U7XG4gICAgICB9XG4gICAgfSk7XG4gIH0sXG4gIC8vIENhbGxlZCB3aGVuIGEgZG9jdW1lbnQgbGVhdmVzIHRoZSBcIk1hdGNoaW5nXCIgcmVzdWx0cyBzZXQuXG4gIC8vIFRha2VzIHJlc3BvbnNpYmlsaXR5IG9mIGtlZXBpbmcgX3VucHVibGlzaGVkQnVmZmVyIGluIHN5bmMgd2l0aCBfcHVibGlzaGVkXG4gIC8vIGFuZCB0aGUgZWZmZWN0IG9mIGxpbWl0IGVuZm9yY2VkLlxuICBfcmVtb3ZlTWF0Y2hpbmc6IGZ1bmN0aW9uIChpZCkge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICBNZXRlb3IuX25vWWllbGRzQWxsb3dlZChmdW5jdGlvbiAoKSB7XG4gICAgICBpZiAoISBzZWxmLl9wdWJsaXNoZWQuaGFzKGlkKSAmJiAhIHNlbGYuX2xpbWl0KVxuICAgICAgICB0aHJvdyBFcnJvcihcInRyaWVkIHRvIHJlbW92ZSBzb21ldGhpbmcgbWF0Y2hpbmcgYnV0IG5vdCBjYWNoZWQgXCIgKyBpZCk7XG5cbiAgICAgIGlmIChzZWxmLl9wdWJsaXNoZWQuaGFzKGlkKSkge1xuICAgICAgICBzZWxmLl9yZW1vdmVQdWJsaXNoZWQoaWQpO1xuICAgICAgfSBlbHNlIGlmIChzZWxmLl91bnB1Ymxpc2hlZEJ1ZmZlci5oYXMoaWQpKSB7XG4gICAgICAgIHNlbGYuX3JlbW92ZUJ1ZmZlcmVkKGlkKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfSxcbiAgX2hhbmRsZURvYzogZnVuY3Rpb24gKGlkLCBuZXdEb2MpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgTWV0ZW9yLl9ub1lpZWxkc0FsbG93ZWQoZnVuY3Rpb24gKCkge1xuICAgICAgdmFyIG1hdGNoZXNOb3cgPSBuZXdEb2MgJiYgc2VsZi5fbWF0Y2hlci5kb2N1bWVudE1hdGNoZXMobmV3RG9jKS5yZXN1bHQ7XG5cbiAgICAgIHZhciBwdWJsaXNoZWRCZWZvcmUgPSBzZWxmLl9wdWJsaXNoZWQuaGFzKGlkKTtcbiAgICAgIHZhciBidWZmZXJlZEJlZm9yZSA9IHNlbGYuX2xpbWl0ICYmIHNlbGYuX3VucHVibGlzaGVkQnVmZmVyLmhhcyhpZCk7XG4gICAgICB2YXIgY2FjaGVkQmVmb3JlID0gcHVibGlzaGVkQmVmb3JlIHx8IGJ1ZmZlcmVkQmVmb3JlO1xuXG4gICAgICBpZiAobWF0Y2hlc05vdyAmJiAhY2FjaGVkQmVmb3JlKSB7XG4gICAgICAgIHNlbGYuX2FkZE1hdGNoaW5nKG5ld0RvYyk7XG4gICAgICB9IGVsc2UgaWYgKGNhY2hlZEJlZm9yZSAmJiAhbWF0Y2hlc05vdykge1xuICAgICAgICBzZWxmLl9yZW1vdmVNYXRjaGluZyhpZCk7XG4gICAgICB9IGVsc2UgaWYgKGNhY2hlZEJlZm9yZSAmJiBtYXRjaGVzTm93KSB7XG4gICAgICAgIHZhciBvbGREb2MgPSBzZWxmLl9wdWJsaXNoZWQuZ2V0KGlkKTtcbiAgICAgICAgdmFyIGNvbXBhcmF0b3IgPSBzZWxmLl9jb21wYXJhdG9yO1xuICAgICAgICB2YXIgbWluQnVmZmVyZWQgPSBzZWxmLl9saW1pdCAmJiBzZWxmLl91bnB1Ymxpc2hlZEJ1ZmZlci5zaXplKCkgJiZcbiAgICAgICAgICBzZWxmLl91bnB1Ymxpc2hlZEJ1ZmZlci5nZXQoc2VsZi5fdW5wdWJsaXNoZWRCdWZmZXIubWluRWxlbWVudElkKCkpO1xuICAgICAgICB2YXIgbWF4QnVmZmVyZWQ7XG5cbiAgICAgICAgaWYgKHB1Ymxpc2hlZEJlZm9yZSkge1xuICAgICAgICAgIC8vIFVubGltaXRlZCBjYXNlIHdoZXJlIHRoZSBkb2N1bWVudCBzdGF5cyBpbiBwdWJsaXNoZWQgb25jZSBpdFxuICAgICAgICAgIC8vIG1hdGNoZXMgb3IgdGhlIGNhc2Ugd2hlbiB3ZSBkb24ndCBoYXZlIGVub3VnaCBtYXRjaGluZyBkb2NzIHRvXG4gICAgICAgICAgLy8gcHVibGlzaCBvciB0aGUgY2hhbmdlZCBidXQgbWF0Y2hpbmcgZG9jIHdpbGwgc3RheSBpbiBwdWJsaXNoZWRcbiAgICAgICAgICAvLyBhbnl3YXlzLlxuICAgICAgICAgIC8vXG4gICAgICAgICAgLy8gWFhYOiBXZSByZWx5IG9uIHRoZSBlbXB0aW5lc3Mgb2YgYnVmZmVyLiBCZSBzdXJlIHRvIG1haW50YWluIHRoZVxuICAgICAgICAgIC8vIGZhY3QgdGhhdCBidWZmZXIgY2FuJ3QgYmUgZW1wdHkgaWYgdGhlcmUgYXJlIG1hdGNoaW5nIGRvY3VtZW50cyBub3RcbiAgICAgICAgICAvLyBwdWJsaXNoZWQuIE5vdGFibHksIHdlIGRvbid0IHdhbnQgdG8gc2NoZWR1bGUgcmVwb2xsIGFuZCBjb250aW51ZVxuICAgICAgICAgIC8vIHJlbHlpbmcgb24gdGhpcyBwcm9wZXJ0eS5cbiAgICAgICAgICB2YXIgc3RheXNJblB1Ymxpc2hlZCA9ICEgc2VsZi5fbGltaXQgfHxcbiAgICAgICAgICAgIHNlbGYuX3VucHVibGlzaGVkQnVmZmVyLnNpemUoKSA9PT0gMCB8fFxuICAgICAgICAgICAgY29tcGFyYXRvcihuZXdEb2MsIG1pbkJ1ZmZlcmVkKSA8PSAwO1xuXG4gICAgICAgICAgaWYgKHN0YXlzSW5QdWJsaXNoZWQpIHtcbiAgICAgICAgICAgIHNlbGYuX2NoYW5nZVB1Ymxpc2hlZChpZCwgb2xkRG9jLCBuZXdEb2MpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAvLyBhZnRlciB0aGUgY2hhbmdlIGRvYyBkb2Vzbid0IHN0YXkgaW4gdGhlIHB1Ymxpc2hlZCwgcmVtb3ZlIGl0XG4gICAgICAgICAgICBzZWxmLl9yZW1vdmVQdWJsaXNoZWQoaWQpO1xuICAgICAgICAgICAgLy8gYnV0IGl0IGNhbiBtb3ZlIGludG8gYnVmZmVyZWQgbm93LCBjaGVjayBpdFxuICAgICAgICAgICAgbWF4QnVmZmVyZWQgPSBzZWxmLl91bnB1Ymxpc2hlZEJ1ZmZlci5nZXQoXG4gICAgICAgICAgICAgIHNlbGYuX3VucHVibGlzaGVkQnVmZmVyLm1heEVsZW1lbnRJZCgpKTtcblxuICAgICAgICAgICAgdmFyIHRvQnVmZmVyID0gc2VsZi5fc2FmZUFwcGVuZFRvQnVmZmVyIHx8XG4gICAgICAgICAgICAgICAgICAobWF4QnVmZmVyZWQgJiYgY29tcGFyYXRvcihuZXdEb2MsIG1heEJ1ZmZlcmVkKSA8PSAwKTtcblxuICAgICAgICAgICAgaWYgKHRvQnVmZmVyKSB7XG4gICAgICAgICAgICAgIHNlbGYuX2FkZEJ1ZmZlcmVkKGlkLCBuZXdEb2MpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgLy8gVGhyb3cgYXdheSBmcm9tIGJvdGggcHVibGlzaGVkIHNldCBhbmQgYnVmZmVyXG4gICAgICAgICAgICAgIHNlbGYuX3NhZmVBcHBlbmRUb0J1ZmZlciA9IGZhbHNlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIGlmIChidWZmZXJlZEJlZm9yZSkge1xuICAgICAgICAgIG9sZERvYyA9IHNlbGYuX3VucHVibGlzaGVkQnVmZmVyLmdldChpZCk7XG4gICAgICAgICAgLy8gcmVtb3ZlIHRoZSBvbGQgdmVyc2lvbiBtYW51YWxseSBpbnN0ZWFkIG9mIHVzaW5nIF9yZW1vdmVCdWZmZXJlZCBzb1xuICAgICAgICAgIC8vIHdlIGRvbid0IHRyaWdnZXIgdGhlIHF1ZXJ5aW5nIGltbWVkaWF0ZWx5LiAgaWYgd2UgZW5kIHRoaXMgYmxvY2tcbiAgICAgICAgICAvLyB3aXRoIHRoZSBidWZmZXIgZW1wdHksIHdlIHdpbGwgbmVlZCB0byB0cmlnZ2VyIHRoZSBxdWVyeSBwb2xsXG4gICAgICAgICAgLy8gbWFudWFsbHkgdG9vLlxuICAgICAgICAgIHNlbGYuX3VucHVibGlzaGVkQnVmZmVyLnJlbW92ZShpZCk7XG5cbiAgICAgICAgICB2YXIgbWF4UHVibGlzaGVkID0gc2VsZi5fcHVibGlzaGVkLmdldChcbiAgICAgICAgICAgIHNlbGYuX3B1Ymxpc2hlZC5tYXhFbGVtZW50SWQoKSk7XG4gICAgICAgICAgbWF4QnVmZmVyZWQgPSBzZWxmLl91bnB1Ymxpc2hlZEJ1ZmZlci5zaXplKCkgJiZcbiAgICAgICAgICAgICAgICBzZWxmLl91bnB1Ymxpc2hlZEJ1ZmZlci5nZXQoXG4gICAgICAgICAgICAgICAgICBzZWxmLl91bnB1Ymxpc2hlZEJ1ZmZlci5tYXhFbGVtZW50SWQoKSk7XG5cbiAgICAgICAgICAvLyB0aGUgYnVmZmVyZWQgZG9jIHdhcyB1cGRhdGVkLCBpdCBjb3VsZCBtb3ZlIHRvIHB1Ymxpc2hlZFxuICAgICAgICAgIHZhciB0b1B1Ymxpc2ggPSBjb21wYXJhdG9yKG5ld0RvYywgbWF4UHVibGlzaGVkKSA8IDA7XG5cbiAgICAgICAgICAvLyBvciBzdGF5cyBpbiBidWZmZXIgZXZlbiBhZnRlciB0aGUgY2hhbmdlXG4gICAgICAgICAgdmFyIHN0YXlzSW5CdWZmZXIgPSAoISB0b1B1Ymxpc2ggJiYgc2VsZi5fc2FmZUFwcGVuZFRvQnVmZmVyKSB8fFxuICAgICAgICAgICAgICAgICghdG9QdWJsaXNoICYmIG1heEJ1ZmZlcmVkICYmXG4gICAgICAgICAgICAgICAgIGNvbXBhcmF0b3IobmV3RG9jLCBtYXhCdWZmZXJlZCkgPD0gMCk7XG5cbiAgICAgICAgICBpZiAodG9QdWJsaXNoKSB7XG4gICAgICAgICAgICBzZWxmLl9hZGRQdWJsaXNoZWQoaWQsIG5ld0RvYyk7XG4gICAgICAgICAgfSBlbHNlIGlmIChzdGF5c0luQnVmZmVyKSB7XG4gICAgICAgICAgICAvLyBzdGF5cyBpbiBidWZmZXIgYnV0IGNoYW5nZXNcbiAgICAgICAgICAgIHNlbGYuX3VucHVibGlzaGVkQnVmZmVyLnNldChpZCwgbmV3RG9jKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgLy8gVGhyb3cgYXdheSBmcm9tIGJvdGggcHVibGlzaGVkIHNldCBhbmQgYnVmZmVyXG4gICAgICAgICAgICBzZWxmLl9zYWZlQXBwZW5kVG9CdWZmZXIgPSBmYWxzZTtcbiAgICAgICAgICAgIC8vIE5vcm1hbGx5IHRoaXMgY2hlY2sgd291bGQgaGF2ZSBiZWVuIGRvbmUgaW4gX3JlbW92ZUJ1ZmZlcmVkIGJ1dFxuICAgICAgICAgICAgLy8gd2UgZGlkbid0IHVzZSBpdCwgc28gd2UgbmVlZCB0byBkbyBpdCBvdXJzZWxmIG5vdy5cbiAgICAgICAgICAgIGlmICghIHNlbGYuX3VucHVibGlzaGVkQnVmZmVyLnNpemUoKSkge1xuICAgICAgICAgICAgICBzZWxmLl9uZWVkVG9Qb2xsUXVlcnkoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiY2FjaGVkQmVmb3JlIGltcGxpZXMgZWl0aGVyIG9mIHB1Ymxpc2hlZEJlZm9yZSBvciBidWZmZXJlZEJlZm9yZSBpcyB0cnVlLlwiKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pO1xuICB9LFxuICBfZmV0Y2hNb2RpZmllZERvY3VtZW50czogZnVuY3Rpb24gKCkge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICBzZWxmLl9yZWdpc3RlclBoYXNlQ2hhbmdlKFBIQVNFLkZFVENISU5HKTtcbiAgICAvLyBEZWZlciwgYmVjYXVzZSBub3RoaW5nIGNhbGxlZCBmcm9tIHRoZSBvcGxvZyBlbnRyeSBoYW5kbGVyIG1heSB5aWVsZCxcbiAgICAvLyBidXQgZmV0Y2goKSB5aWVsZHMuXG4gICAgTWV0ZW9yLmRlZmVyKGZpbmlzaElmTmVlZFRvUG9sbFF1ZXJ5KGFzeW5jIGZ1bmN0aW9uICgpIHtcbiAgICAgIHdoaWxlICghc2VsZi5fc3RvcHBlZCAmJiAhc2VsZi5fbmVlZFRvRmV0Y2guZW1wdHkoKSkge1xuICAgICAgICBpZiAoc2VsZi5fcGhhc2UgPT09IFBIQVNFLlFVRVJZSU5HKSB7XG4gICAgICAgICAgLy8gV2hpbGUgZmV0Y2hpbmcsIHdlIGRlY2lkZWQgdG8gZ28gaW50byBRVUVSWUlORyBtb2RlLCBhbmQgdGhlbiB3ZVxuICAgICAgICAgIC8vIHNhdyBhbm90aGVyIG9wbG9nIGVudHJ5LCBzbyBfbmVlZFRvRmV0Y2ggaXMgbm90IGVtcHR5LiBCdXQgd2VcbiAgICAgICAgICAvLyBzaG91bGRuJ3QgZmV0Y2ggdGhlc2UgZG9jdW1lbnRzIHVudGlsIEFGVEVSIHRoZSBxdWVyeSBpcyBkb25lLlxuICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gQmVpbmcgaW4gc3RlYWR5IHBoYXNlIGhlcmUgd291bGQgYmUgc3VycHJpc2luZy5cbiAgICAgICAgaWYgKHNlbGYuX3BoYXNlICE9PSBQSEFTRS5GRVRDSElORylcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJwaGFzZSBpbiBmZXRjaE1vZGlmaWVkRG9jdW1lbnRzOiBcIiArIHNlbGYuX3BoYXNlKTtcblxuICAgICAgICBzZWxmLl9jdXJyZW50bHlGZXRjaGluZyA9IHNlbGYuX25lZWRUb0ZldGNoO1xuICAgICAgICB2YXIgdGhpc0dlbmVyYXRpb24gPSArK3NlbGYuX2ZldGNoR2VuZXJhdGlvbjtcbiAgICAgICAgc2VsZi5fbmVlZFRvRmV0Y2ggPSBuZXcgTG9jYWxDb2xsZWN0aW9uLl9JZE1hcDtcbiAgICAgICAgdmFyIHdhaXRpbmcgPSAwO1xuXG4gICAgICAgIGxldCBwcm9taXNlUmVzb2x2ZXIgPSBudWxsO1xuICAgICAgICBjb25zdCBhd2FpdGFibGVQcm9taXNlID0gbmV3IFByb21pc2UociA9PiBwcm9taXNlUmVzb2x2ZXIgPSByKTtcbiAgICAgICAgLy8gVGhpcyBsb29wIGlzIHNhZmUsIGJlY2F1c2UgX2N1cnJlbnRseUZldGNoaW5nIHdpbGwgbm90IGJlIHVwZGF0ZWRcbiAgICAgICAgLy8gZHVyaW5nIHRoaXMgbG9vcCAoaW4gZmFjdCwgaXQgaXMgbmV2ZXIgbXV0YXRlZCkuXG4gICAgICAgIGF3YWl0IHNlbGYuX2N1cnJlbnRseUZldGNoaW5nLmZvckVhY2hBc3luYyhhc3luYyBmdW5jdGlvbiAob3AsIGlkKSB7XG4gICAgICAgICAgd2FpdGluZysrO1xuICAgICAgICAgIGF3YWl0IHNlbGYuX21vbmdvSGFuZGxlLl9kb2NGZXRjaGVyLmZldGNoKFxuICAgICAgICAgICAgc2VsZi5fY3Vyc29yRGVzY3JpcHRpb24uY29sbGVjdGlvbk5hbWUsXG4gICAgICAgICAgICBpZCxcbiAgICAgICAgICAgIG9wLFxuICAgICAgICAgICAgZmluaXNoSWZOZWVkVG9Qb2xsUXVlcnkoZnVuY3Rpb24oZXJyLCBkb2MpIHtcbiAgICAgICAgICAgICAgaWYgKGVycikge1xuICAgICAgICAgICAgICAgIE1ldGVvci5fZGVidWcoJ0dvdCBleGNlcHRpb24gd2hpbGUgZmV0Y2hpbmcgZG9jdW1lbnRzJywgZXJyKTtcbiAgICAgICAgICAgICAgICAvLyBJZiB3ZSBnZXQgYW4gZXJyb3IgZnJvbSB0aGUgZmV0Y2hlciAoZWcsIHRyb3VibGVcbiAgICAgICAgICAgICAgICAvLyBjb25uZWN0aW5nIHRvIE1vbmdvKSwgbGV0J3MganVzdCBhYmFuZG9uIHRoZSBmZXRjaCBwaGFzZVxuICAgICAgICAgICAgICAgIC8vIGFsdG9nZXRoZXIgYW5kIGZhbGwgYmFjayB0byBwb2xsaW5nLiBJdCdzIG5vdCBsaWtlIHdlJ3JlXG4gICAgICAgICAgICAgICAgLy8gZ2V0dGluZyBsaXZlIHVwZGF0ZXMgYW55d2F5LlxuICAgICAgICAgICAgICAgIGlmIChzZWxmLl9waGFzZSAhPT0gUEhBU0UuUVVFUllJTkcpIHtcbiAgICAgICAgICAgICAgICAgIHNlbGYuX25lZWRUb1BvbGxRdWVyeSgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB3YWl0aW5nLS07XG4gICAgICAgICAgICAgICAgLy8gQmVjYXVzZSBmZXRjaCgpIG5ldmVyIGNhbGxzIGl0cyBjYWxsYmFjayBzeW5jaHJvbm91c2x5LFxuICAgICAgICAgICAgICAgIC8vIHRoaXMgaXMgc2FmZSAoaWUsIHdlIHdvbid0IGNhbGwgZnV0LnJldHVybigpIGJlZm9yZSB0aGVcbiAgICAgICAgICAgICAgICAvLyBmb3JFYWNoIGlzIGRvbmUpLlxuICAgICAgICAgICAgICAgIGlmICh3YWl0aW5nID09PSAwKSBwcm9taXNlUmVzb2x2ZXIoKTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGlmIChcbiAgICAgICAgICAgICAgICAgICFzZWxmLl9zdG9wcGVkICYmXG4gICAgICAgICAgICAgICAgICBzZWxmLl9waGFzZSA9PT0gUEhBU0UuRkVUQ0hJTkcgJiZcbiAgICAgICAgICAgICAgICAgIHNlbGYuX2ZldGNoR2VuZXJhdGlvbiA9PT0gdGhpc0dlbmVyYXRpb25cbiAgICAgICAgICAgICAgICApIHtcbiAgICAgICAgICAgICAgICAgIC8vIFdlIHJlLWNoZWNrIHRoZSBnZW5lcmF0aW9uIGluIGNhc2Ugd2UndmUgaGFkIGFuIGV4cGxpY2l0XG4gICAgICAgICAgICAgICAgICAvLyBfcG9sbFF1ZXJ5IGNhbGwgKGVnLCBpbiBhbm90aGVyIGZpYmVyKSB3aGljaCBzaG91bGRcbiAgICAgICAgICAgICAgICAgIC8vIGVmZmVjdGl2ZWx5IGNhbmNlbCB0aGlzIHJvdW5kIG9mIGZldGNoZXMuICAoX3BvbGxRdWVyeVxuICAgICAgICAgICAgICAgICAgLy8gaW5jcmVtZW50cyB0aGUgZ2VuZXJhdGlvbi4pXG5cbiAgICAgICAgICAgICAgICAgIHNlbGYuX2hhbmRsZURvYyhpZCwgZG9jKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgICAgICAgd2FpdGluZy0tO1xuICAgICAgICAgICAgICAgIC8vIEJlY2F1c2UgZmV0Y2goKSBuZXZlciBjYWxscyBpdHMgY2FsbGJhY2sgc3luY2hyb25vdXNseSxcbiAgICAgICAgICAgICAgICAvLyB0aGlzIGlzIHNhZmUgKGllLCB3ZSB3b24ndCBjYWxsIGZ1dC5yZXR1cm4oKSBiZWZvcmUgdGhlXG4gICAgICAgICAgICAgICAgLy8gZm9yRWFjaCBpcyBkb25lKS5cbiAgICAgICAgICAgICAgICBpZiAod2FpdGluZyA9PT0gMCkgcHJvbWlzZVJlc29sdmVyKCk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgKTtcbiAgICAgICAgfSk7XG4gICAgICAgIGF3YWl0IGF3YWl0YWJsZVByb21pc2U7XG4gICAgICAgIC8vIEV4aXQgbm93IGlmIHdlJ3ZlIGhhZCBhIF9wb2xsUXVlcnkgY2FsbCAoaGVyZSBvciBpbiBhbm90aGVyIGZpYmVyKS5cbiAgICAgICAgaWYgKHNlbGYuX3BoYXNlID09PSBQSEFTRS5RVUVSWUlORylcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIHNlbGYuX2N1cnJlbnRseUZldGNoaW5nID0gbnVsbDtcbiAgICAgIH1cbiAgICAgIC8vIFdlJ3JlIGRvbmUgZmV0Y2hpbmcsIHNvIHdlIGNhbiBiZSBzdGVhZHksIHVubGVzcyB3ZSd2ZSBoYWQgYVxuICAgICAgLy8gX3BvbGxRdWVyeSBjYWxsIChoZXJlIG9yIGluIGFub3RoZXIgZmliZXIpLlxuICAgICAgaWYgKHNlbGYuX3BoYXNlICE9PSBQSEFTRS5RVUVSWUlORylcbiAgICAgICAgYXdhaXQgc2VsZi5fYmVTdGVhZHkoKTtcbiAgICB9KSk7XG4gIH0sXG4gIF9iZVN0ZWFkeTogYXN5bmMgZnVuY3Rpb24gKCkge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICBzZWxmLl9yZWdpc3RlclBoYXNlQ2hhbmdlKFBIQVNFLlNURUFEWSk7XG4gICAgdmFyIHdyaXRlcyA9IHNlbGYuX3dyaXRlc1RvQ29tbWl0V2hlbldlUmVhY2hTdGVhZHkgfHwgW107XG4gICAgc2VsZi5fd3JpdGVzVG9Db21taXRXaGVuV2VSZWFjaFN0ZWFkeSA9IFtdO1xuICAgIGF3YWl0IHNlbGYuX211bHRpcGxleGVyLm9uRmx1c2goYXN5bmMgZnVuY3Rpb24gKCkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgZm9yIChjb25zdCB3IG9mIHdyaXRlcykge1xuICAgICAgICAgIGF3YWl0IHcuY29tbWl0dGVkKCk7XG4gICAgICAgIH1cbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIl9iZVN0ZWFkeSBlcnJvclwiLCB7d3JpdGVzfSwgZSk7XG4gICAgICB9XG4gICAgfSk7XG4gIH0sXG4gIF9oYW5kbGVPcGxvZ0VudHJ5UXVlcnlpbmc6IGZ1bmN0aW9uIChvcCkge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICBNZXRlb3IuX25vWWllbGRzQWxsb3dlZChmdW5jdGlvbiAoKSB7XG4gICAgICBzZWxmLl9uZWVkVG9GZXRjaC5zZXQoaWRGb3JPcChvcCksIG9wKTtcbiAgICB9KTtcbiAgfSxcbiAgX2hhbmRsZU9wbG9nRW50cnlTdGVhZHlPckZldGNoaW5nOiBmdW5jdGlvbiAob3ApIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgTWV0ZW9yLl9ub1lpZWxkc0FsbG93ZWQoZnVuY3Rpb24gKCkge1xuICAgICAgdmFyIGlkID0gaWRGb3JPcChvcCk7XG4gICAgICAvLyBJZiB3ZSdyZSBhbHJlYWR5IGZldGNoaW5nIHRoaXMgb25lLCBvciBhYm91dCB0bywgd2UgY2FuJ3Qgb3B0aW1pemU7XG4gICAgICAvLyBtYWtlIHN1cmUgdGhhdCB3ZSBmZXRjaCBpdCBhZ2FpbiBpZiBuZWNlc3NhcnkuXG5cbiAgICAgIGlmIChzZWxmLl9waGFzZSA9PT0gUEhBU0UuRkVUQ0hJTkcgJiZcbiAgICAgICAgICAoKHNlbGYuX2N1cnJlbnRseUZldGNoaW5nICYmIHNlbGYuX2N1cnJlbnRseUZldGNoaW5nLmhhcyhpZCkpIHx8XG4gICAgICAgICAgIHNlbGYuX25lZWRUb0ZldGNoLmhhcyhpZCkpKSB7XG4gICAgICAgIHNlbGYuX25lZWRUb0ZldGNoLnNldChpZCwgb3ApO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG5cbiAgICAgIGlmIChvcC5vcCA9PT0gJ2QnKSB7XG4gICAgICAgIGlmIChzZWxmLl9wdWJsaXNoZWQuaGFzKGlkKSB8fFxuICAgICAgICAgICAgKHNlbGYuX2xpbWl0ICYmIHNlbGYuX3VucHVibGlzaGVkQnVmZmVyLmhhcyhpZCkpKVxuICAgICAgICAgIHNlbGYuX3JlbW92ZU1hdGNoaW5nKGlkKTtcbiAgICAgIH0gZWxzZSBpZiAob3Aub3AgPT09ICdpJykge1xuICAgICAgICBpZiAoc2VsZi5fcHVibGlzaGVkLmhhcyhpZCkpXG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiaW5zZXJ0IGZvdW5kIGZvciBhbHJlYWR5LWV4aXN0aW5nIElEIGluIHB1Ymxpc2hlZFwiKTtcbiAgICAgICAgaWYgKHNlbGYuX3VucHVibGlzaGVkQnVmZmVyICYmIHNlbGYuX3VucHVibGlzaGVkQnVmZmVyLmhhcyhpZCkpXG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiaW5zZXJ0IGZvdW5kIGZvciBhbHJlYWR5LWV4aXN0aW5nIElEIGluIGJ1ZmZlclwiKTtcblxuICAgICAgICAvLyBYWFggd2hhdCBpZiBzZWxlY3RvciB5aWVsZHM/ICBmb3Igbm93IGl0IGNhbid0IGJ1dCBsYXRlciBpdCBjb3VsZFxuICAgICAgICAvLyBoYXZlICR3aGVyZVxuICAgICAgICBpZiAoc2VsZi5fbWF0Y2hlci5kb2N1bWVudE1hdGNoZXMob3AubykucmVzdWx0KVxuICAgICAgICAgIHNlbGYuX2FkZE1hdGNoaW5nKG9wLm8pO1xuICAgICAgfSBlbHNlIGlmIChvcC5vcCA9PT0gJ3UnKSB7XG4gICAgICAgIC8vIHdlIGFyZSBtYXBwaW5nIHRoZSBuZXcgb3Bsb2cgZm9ybWF0IG9uIG1vbmdvIDVcbiAgICAgICAgLy8gdG8gd2hhdCB3ZSBrbm93IGJldHRlciwgJHNldFxuICAgICAgICBvcC5vID0gb3Bsb2dWMlYxQ29udmVydGVyKG9wLm8pXG4gICAgICAgIC8vIElzIHRoaXMgYSBtb2RpZmllciAoJHNldC8kdW5zZXQsIHdoaWNoIG1heSByZXF1aXJlIHVzIHRvIHBvbGwgdGhlXG4gICAgICAgIC8vIGRhdGFiYXNlIHRvIGZpZ3VyZSBvdXQgaWYgdGhlIHdob2xlIGRvY3VtZW50IG1hdGNoZXMgdGhlIHNlbGVjdG9yKSBvclxuICAgICAgICAvLyBhIHJlcGxhY2VtZW50IChpbiB3aGljaCBjYXNlIHdlIGNhbiBqdXN0IGRpcmVjdGx5IHJlLWV2YWx1YXRlIHRoZVxuICAgICAgICAvLyBzZWxlY3Rvcik/XG4gICAgICAgIC8vIG9wbG9nIGZvcm1hdCBoYXMgY2hhbmdlZCBvbiBtb25nb2RiIDUsIHdlIGhhdmUgdG8gc3VwcG9ydCBib3RoIG5vd1xuICAgICAgICAvLyBkaWZmIGlzIHRoZSBmb3JtYXQgaW4gTW9uZ28gNSsgKG9wbG9nIHYyKVxuICAgICAgICB2YXIgaXNSZXBsYWNlID0gIV8uaGFzKG9wLm8sICckc2V0JykgJiYgIV8uaGFzKG9wLm8sICdkaWZmJykgJiYgIV8uaGFzKG9wLm8sICckdW5zZXQnKTtcbiAgICAgICAgLy8gSWYgdGhpcyBtb2RpZmllciBtb2RpZmllcyBzb21ldGhpbmcgaW5zaWRlIGFuIEVKU09OIGN1c3RvbSB0eXBlIChpZSxcbiAgICAgICAgLy8gYW55dGhpbmcgd2l0aCBFSlNPTiQpLCB0aGVuIHdlIGNhbid0IHRyeSB0byB1c2VcbiAgICAgICAgLy8gTG9jYWxDb2xsZWN0aW9uLl9tb2RpZnksIHNpbmNlIHRoYXQganVzdCBtdXRhdGVzIHRoZSBFSlNPTiBlbmNvZGluZyxcbiAgICAgICAgLy8gbm90IHRoZSBhY3R1YWwgb2JqZWN0LlxuICAgICAgICB2YXIgY2FuRGlyZWN0bHlNb2RpZnlEb2MgPVxuICAgICAgICAgICFpc1JlcGxhY2UgJiYgbW9kaWZpZXJDYW5CZURpcmVjdGx5QXBwbGllZChvcC5vKTtcblxuICAgICAgICB2YXIgcHVibGlzaGVkQmVmb3JlID0gc2VsZi5fcHVibGlzaGVkLmhhcyhpZCk7XG4gICAgICAgIHZhciBidWZmZXJlZEJlZm9yZSA9IHNlbGYuX2xpbWl0ICYmIHNlbGYuX3VucHVibGlzaGVkQnVmZmVyLmhhcyhpZCk7XG5cbiAgICAgICAgaWYgKGlzUmVwbGFjZSkge1xuICAgICAgICAgIHNlbGYuX2hhbmRsZURvYyhpZCwgXy5leHRlbmQoe19pZDogaWR9LCBvcC5vKSk7XG4gICAgICAgIH0gZWxzZSBpZiAoKHB1Ymxpc2hlZEJlZm9yZSB8fCBidWZmZXJlZEJlZm9yZSkgJiZcbiAgICAgICAgICAgICAgICAgICBjYW5EaXJlY3RseU1vZGlmeURvYykge1xuICAgICAgICAgIC8vIE9oIGdyZWF0LCB3ZSBhY3R1YWxseSBrbm93IHdoYXQgdGhlIGRvY3VtZW50IGlzLCBzbyB3ZSBjYW4gYXBwbHlcbiAgICAgICAgICAvLyB0aGlzIGRpcmVjdGx5LlxuICAgICAgICAgIHZhciBuZXdEb2MgPSBzZWxmLl9wdWJsaXNoZWQuaGFzKGlkKVxuICAgICAgICAgICAgPyBzZWxmLl9wdWJsaXNoZWQuZ2V0KGlkKSA6IHNlbGYuX3VucHVibGlzaGVkQnVmZmVyLmdldChpZCk7XG4gICAgICAgICAgbmV3RG9jID0gRUpTT04uY2xvbmUobmV3RG9jKTtcblxuICAgICAgICAgIG5ld0RvYy5faWQgPSBpZDtcbiAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgTG9jYWxDb2xsZWN0aW9uLl9tb2RpZnkobmV3RG9jLCBvcC5vKTtcbiAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICBpZiAoZS5uYW1lICE9PSBcIk1pbmltb25nb0Vycm9yXCIpXG4gICAgICAgICAgICAgIHRocm93IGU7XG4gICAgICAgICAgICAvLyBXZSBkaWRuJ3QgdW5kZXJzdGFuZCB0aGUgbW9kaWZpZXIuICBSZS1mZXRjaC5cbiAgICAgICAgICAgIHNlbGYuX25lZWRUb0ZldGNoLnNldChpZCwgb3ApO1xuICAgICAgICAgICAgaWYgKHNlbGYuX3BoYXNlID09PSBQSEFTRS5TVEVBRFkpIHtcbiAgICAgICAgICAgICAgc2VsZi5fZmV0Y2hNb2RpZmllZERvY3VtZW50cygpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH1cbiAgICAgICAgICBzZWxmLl9oYW5kbGVEb2MoaWQsIHNlbGYuX3NoYXJlZFByb2plY3Rpb25GbihuZXdEb2MpKTtcbiAgICAgICAgfSBlbHNlIGlmICghY2FuRGlyZWN0bHlNb2RpZnlEb2MgfHxcbiAgICAgICAgICAgICAgICAgICBzZWxmLl9tYXRjaGVyLmNhbkJlY29tZVRydWVCeU1vZGlmaWVyKG9wLm8pIHx8XG4gICAgICAgICAgICAgICAgICAgKHNlbGYuX3NvcnRlciAmJiBzZWxmLl9zb3J0ZXIuYWZmZWN0ZWRCeU1vZGlmaWVyKG9wLm8pKSkge1xuICAgICAgICAgIHNlbGYuX25lZWRUb0ZldGNoLnNldChpZCwgb3ApO1xuICAgICAgICAgIGlmIChzZWxmLl9waGFzZSA9PT0gUEhBU0UuU1RFQURZKVxuICAgICAgICAgICAgc2VsZi5fZmV0Y2hNb2RpZmllZERvY3VtZW50cygpO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aHJvdyBFcnJvcihcIlhYWCBTVVJQUklTSU5HIE9QRVJBVElPTjogXCIgKyBvcCk7XG4gICAgICB9XG4gICAgfSk7XG4gIH0sXG5cbiAgYXN5bmMgX3J1bkluaXRpYWxRdWVyeUFzeW5jKCkge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICBpZiAoc2VsZi5fc3RvcHBlZClcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIm9wbG9nIHN0b3BwZWQgc3VycHJpc2luZ2x5IGVhcmx5XCIpO1xuXG4gICAgYXdhaXQgc2VsZi5fcnVuUXVlcnkoe2luaXRpYWw6IHRydWV9KTsgIC8vIHlpZWxkc1xuXG4gICAgaWYgKHNlbGYuX3N0b3BwZWQpXG4gICAgICByZXR1cm47ICAvLyBjYW4gaGFwcGVuIG9uIHF1ZXJ5RXJyb3JcblxuICAgIC8vIEFsbG93IG9ic2VydmVDaGFuZ2VzIGNhbGxzIHRvIHJldHVybi4gKEFmdGVyIHRoaXMsIGl0J3MgcG9zc2libGUgZm9yXG4gICAgLy8gc3RvcCgpIHRvIGJlIGNhbGxlZC4pXG4gICAgYXdhaXQgc2VsZi5fbXVsdGlwbGV4ZXIucmVhZHkoKTtcblxuICAgIGF3YWl0IHNlbGYuX2RvbmVRdWVyeWluZygpOyAgLy8geWllbGRzXG4gIH0sXG5cbiAgLy8gWWllbGRzIVxuICBfcnVuSW5pdGlhbFF1ZXJ5OiBmdW5jdGlvbiAoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3J1bkluaXRpYWxRdWVyeUFzeW5jKCk7XG4gIH0sXG5cbiAgLy8gSW4gdmFyaW91cyBjaXJjdW1zdGFuY2VzLCB3ZSBtYXkganVzdCB3YW50IHRvIHN0b3AgcHJvY2Vzc2luZyB0aGUgb3Bsb2cgYW5kXG4gIC8vIHJlLXJ1biB0aGUgaW5pdGlhbCBxdWVyeSwganVzdCBhcyBpZiB3ZSB3ZXJlIGEgUG9sbGluZ09ic2VydmVEcml2ZXIuXG4gIC8vXG4gIC8vIFRoaXMgZnVuY3Rpb24gbWF5IG5vdCBibG9jaywgYmVjYXVzZSBpdCBpcyBjYWxsZWQgZnJvbSBhbiBvcGxvZyBlbnRyeVxuICAvLyBoYW5kbGVyLlxuICAvL1xuICAvLyBYWFggV2Ugc2hvdWxkIGNhbGwgdGhpcyB3aGVuIHdlIGRldGVjdCB0aGF0IHdlJ3ZlIGJlZW4gaW4gRkVUQ0hJTkcgZm9yIFwidG9vXG4gIC8vIGxvbmdcIi5cbiAgLy9cbiAgLy8gWFhYIFdlIHNob3VsZCBjYWxsIHRoaXMgd2hlbiB3ZSBkZXRlY3QgTW9uZ28gZmFpbG92ZXIgKHNpbmNlIHRoYXQgbWlnaHRcbiAgLy8gbWVhbiB0aGF0IHNvbWUgb2YgdGhlIG9wbG9nIGVudHJpZXMgd2UgaGF2ZSBwcm9jZXNzZWQgaGF2ZSBiZWVuIHJvbGxlZFxuICAvLyBiYWNrKS4gVGhlIE5vZGUgTW9uZ28gZHJpdmVyIGlzIGluIHRoZSBtaWRkbGUgb2YgYSBidW5jaCBvZiBodWdlXG4gIC8vIHJlZmFjdG9yaW5ncywgaW5jbHVkaW5nIHRoZSB3YXkgdGhhdCBpdCBub3RpZmllcyB5b3Ugd2hlbiBwcmltYXJ5XG4gIC8vIGNoYW5nZXMuIFdpbGwgcHV0IG9mZiBpbXBsZW1lbnRpbmcgdGhpcyB1bnRpbCBkcml2ZXIgMS40IGlzIG91dC5cbiAgX3BvbGxRdWVyeTogZnVuY3Rpb24gKCkge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICBNZXRlb3IuX25vWWllbGRzQWxsb3dlZChmdW5jdGlvbiAoKSB7XG4gICAgICBpZiAoc2VsZi5fc3RvcHBlZClcbiAgICAgICAgcmV0dXJuO1xuXG4gICAgICAvLyBZYXksIHdlIGdldCB0byBmb3JnZXQgYWJvdXQgYWxsIHRoZSB0aGluZ3Mgd2UgdGhvdWdodCB3ZSBoYWQgdG8gZmV0Y2guXG4gICAgICBzZWxmLl9uZWVkVG9GZXRjaCA9IG5ldyBMb2NhbENvbGxlY3Rpb24uX0lkTWFwO1xuICAgICAgc2VsZi5fY3VycmVudGx5RmV0Y2hpbmcgPSBudWxsO1xuICAgICAgKytzZWxmLl9mZXRjaEdlbmVyYXRpb247ICAvLyBpZ25vcmUgYW55IGluLWZsaWdodCBmZXRjaGVzXG4gICAgICBzZWxmLl9yZWdpc3RlclBoYXNlQ2hhbmdlKFBIQVNFLlFVRVJZSU5HKTtcblxuICAgICAgLy8gRGVmZXIgc28gdGhhdCB3ZSBkb24ndCB5aWVsZC4gIFdlIGRvbid0IG5lZWQgZmluaXNoSWZOZWVkVG9Qb2xsUXVlcnlcbiAgICAgIC8vIGhlcmUgYmVjYXVzZSBTd2l0Y2hlZFRvUXVlcnkgaXMgbm90IHRocm93biBpbiBRVUVSWUlORyBtb2RlLlxuICAgICAgTWV0ZW9yLmRlZmVyKGFzeW5jIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgYXdhaXQgc2VsZi5fcnVuUXVlcnkoKTtcbiAgICAgICAgYXdhaXQgc2VsZi5fZG9uZVF1ZXJ5aW5nKCk7XG4gICAgICB9KTtcbiAgICB9KTtcbiAgfSxcblxuICAvLyBZaWVsZHMhXG4gIGFzeW5jIF9ydW5RdWVyeUFzeW5jKG9wdGlvbnMpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgb3B0aW9ucyA9IG9wdGlvbnMgfHwge307XG4gICAgdmFyIG5ld1Jlc3VsdHMsIG5ld0J1ZmZlcjtcblxuICAgIC8vIFRoaXMgd2hpbGUgbG9vcCBpcyBqdXN0IHRvIHJldHJ5IGZhaWx1cmVzLlxuICAgIHdoaWxlICh0cnVlKSB7XG4gICAgICAvLyBJZiB3ZSd2ZSBiZWVuIHN0b3BwZWQsIHdlIGRvbid0IGhhdmUgdG8gcnVuIGFueXRoaW5nIGFueSBtb3JlLlxuICAgICAgaWYgKHNlbGYuX3N0b3BwZWQpXG4gICAgICAgIHJldHVybjtcblxuICAgICAgbmV3UmVzdWx0cyA9IG5ldyBMb2NhbENvbGxlY3Rpb24uX0lkTWFwO1xuICAgICAgbmV3QnVmZmVyID0gbmV3IExvY2FsQ29sbGVjdGlvbi5fSWRNYXA7XG5cbiAgICAgIC8vIFF1ZXJ5IDJ4IGRvY3VtZW50cyBhcyB0aGUgaGFsZiBleGNsdWRlZCBmcm9tIHRoZSBvcmlnaW5hbCBxdWVyeSB3aWxsIGdvXG4gICAgICAvLyBpbnRvIHVucHVibGlzaGVkIGJ1ZmZlciB0byByZWR1Y2UgYWRkaXRpb25hbCBNb25nbyBsb29rdXBzIGluIGNhc2VzXG4gICAgICAvLyB3aGVuIGRvY3VtZW50cyBhcmUgcmVtb3ZlZCBmcm9tIHRoZSBwdWJsaXNoZWQgc2V0IGFuZCBuZWVkIGFcbiAgICAgIC8vIHJlcGxhY2VtZW50LlxuICAgICAgLy8gWFhYIG5lZWRzIG1vcmUgdGhvdWdodCBvbiBub24temVybyBza2lwXG4gICAgICAvLyBYWFggMiBpcyBhIFwibWFnaWMgbnVtYmVyXCIgbWVhbmluZyB0aGVyZSBpcyBhbiBleHRyYSBjaHVuayBvZiBkb2NzIGZvclxuICAgICAgLy8gYnVmZmVyIGlmIHN1Y2ggaXMgbmVlZGVkLlxuICAgICAgdmFyIGN1cnNvciA9IHNlbGYuX2N1cnNvckZvclF1ZXJ5KHsgbGltaXQ6IHNlbGYuX2xpbWl0ICogMiB9KTtcbiAgICAgIHRyeSB7XG4gICAgICAgIGF3YWl0IGN1cnNvci5mb3JFYWNoKGZ1bmN0aW9uIChkb2MsIGkpIHsgIC8vIHlpZWxkc1xuICAgICAgICAgIGlmICghc2VsZi5fbGltaXQgfHwgaSA8IHNlbGYuX2xpbWl0KSB7XG4gICAgICAgICAgICBuZXdSZXN1bHRzLnNldChkb2MuX2lkLCBkb2MpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBuZXdCdWZmZXIuc2V0KGRvYy5faWQsIGRvYyk7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIGlmIChvcHRpb25zLmluaXRpYWwgJiYgdHlwZW9mKGUuY29kZSkgPT09ICdudW1iZXInKSB7XG4gICAgICAgICAgLy8gVGhpcyBpcyBhbiBlcnJvciBkb2N1bWVudCBzZW50IHRvIHVzIGJ5IG1vbmdvZCwgbm90IGEgY29ubmVjdGlvblxuICAgICAgICAgIC8vIGVycm9yIGdlbmVyYXRlZCBieSB0aGUgY2xpZW50LiBBbmQgd2UndmUgbmV2ZXIgc2VlbiB0aGlzIHF1ZXJ5IHdvcmtcbiAgICAgICAgICAvLyBzdWNjZXNzZnVsbHkuIFByb2JhYmx5IGl0J3MgYSBiYWQgc2VsZWN0b3Igb3Igc29tZXRoaW5nLCBzbyB3ZVxuICAgICAgICAgIC8vIHNob3VsZCBOT1QgcmV0cnkuIEluc3RlYWQsIHdlIHNob3VsZCBoYWx0IHRoZSBvYnNlcnZlICh3aGljaCBlbmRzXG4gICAgICAgICAgLy8gdXAgY2FsbGluZyBgc3RvcGAgb24gdXMpLlxuICAgICAgICAgIGF3YWl0IHNlbGYuX211bHRpcGxleGVyLnF1ZXJ5RXJyb3IoZSk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gRHVyaW5nIGZhaWxvdmVyIChlZykgaWYgd2UgZ2V0IGFuIGV4Y2VwdGlvbiB3ZSBzaG91bGQgbG9nIGFuZCByZXRyeVxuICAgICAgICAvLyBpbnN0ZWFkIG9mIGNyYXNoaW5nLlxuICAgICAgICBNZXRlb3IuX2RlYnVnKFwiR290IGV4Y2VwdGlvbiB3aGlsZSBwb2xsaW5nIHF1ZXJ5XCIsIGUpO1xuICAgICAgICBhd2FpdCBNZXRlb3IuX3NsZWVwRm9yTXMoMTAwKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAoc2VsZi5fc3RvcHBlZClcbiAgICAgIHJldHVybjtcblxuICAgIHNlbGYuX3B1Ymxpc2hOZXdSZXN1bHRzKG5ld1Jlc3VsdHMsIG5ld0J1ZmZlcik7XG4gIH0sXG5cbiAgLy8gWWllbGRzIVxuICBfcnVuUXVlcnk6IGZ1bmN0aW9uIChvcHRpb25zKSB7XG4gICAgcmV0dXJuIHRoaXMuX3J1blF1ZXJ5QXN5bmMob3B0aW9ucyk7XG4gIH0sXG5cbiAgLy8gVHJhbnNpdGlvbnMgdG8gUVVFUllJTkcgYW5kIHJ1bnMgYW5vdGhlciBxdWVyeSwgb3IgKGlmIGFscmVhZHkgaW4gUVVFUllJTkcpXG4gIC8vIGVuc3VyZXMgdGhhdCB3ZSB3aWxsIHF1ZXJ5IGFnYWluIGxhdGVyLlxuICAvL1xuICAvLyBUaGlzIGZ1bmN0aW9uIG1heSBub3QgYmxvY2ssIGJlY2F1c2UgaXQgaXMgY2FsbGVkIGZyb20gYW4gb3Bsb2cgZW50cnlcbiAgLy8gaGFuZGxlci4gSG93ZXZlciwgaWYgd2Ugd2VyZSBub3QgYWxyZWFkeSBpbiB0aGUgUVVFUllJTkcgcGhhc2UsIGl0IHRocm93c1xuICAvLyBhbiBleGNlcHRpb24gdGhhdCBpcyBjYXVnaHQgYnkgdGhlIGNsb3Nlc3Qgc3Vycm91bmRpbmdcbiAgLy8gZmluaXNoSWZOZWVkVG9Qb2xsUXVlcnkgY2FsbDsgdGhpcyBlbnN1cmVzIHRoYXQgd2UgZG9uJ3QgY29udGludWUgcnVubmluZ1xuICAvLyBjbG9zZSB0aGF0IHdhcyBkZXNpZ25lZCBmb3IgYW5vdGhlciBwaGFzZSBpbnNpZGUgUEhBU0UuUVVFUllJTkcuXG4gIC8vXG4gIC8vIChJdCdzIGFsc28gbmVjZXNzYXJ5IHdoZW5ldmVyIGxvZ2ljIGluIHRoaXMgZmlsZSB5aWVsZHMgdG8gY2hlY2sgdGhhdCBvdGhlclxuICAvLyBwaGFzZXMgaGF2ZW4ndCBwdXQgdXMgaW50byBRVUVSWUlORyBtb2RlLCB0aG91Z2g7IGVnLFxuICAvLyBfZmV0Y2hNb2RpZmllZERvY3VtZW50cyBkb2VzIHRoaXMuKVxuICBfbmVlZFRvUG9sbFF1ZXJ5OiBmdW5jdGlvbiAoKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgIE1ldGVvci5fbm9ZaWVsZHNBbGxvd2VkKGZ1bmN0aW9uICgpIHtcbiAgICAgIGlmIChzZWxmLl9zdG9wcGVkKVxuICAgICAgICByZXR1cm47XG5cbiAgICAgIC8vIElmIHdlJ3JlIG5vdCBhbHJlYWR5IGluIHRoZSBtaWRkbGUgb2YgYSBxdWVyeSwgd2UgY2FuIHF1ZXJ5IG5vd1xuICAgICAgLy8gKHBvc3NpYmx5IHBhdXNpbmcgRkVUQ0hJTkcpLlxuICAgICAgaWYgKHNlbGYuX3BoYXNlICE9PSBQSEFTRS5RVUVSWUlORykge1xuICAgICAgICBzZWxmLl9wb2xsUXVlcnkoKTtcbiAgICAgICAgdGhyb3cgbmV3IFN3aXRjaGVkVG9RdWVyeTtcbiAgICAgIH1cblxuICAgICAgLy8gV2UncmUgY3VycmVudGx5IGluIFFVRVJZSU5HLiBTZXQgYSBmbGFnIHRvIGVuc3VyZSB0aGF0IHdlIHJ1biBhbm90aGVyXG4gICAgICAvLyBxdWVyeSB3aGVuIHdlJ3JlIGRvbmUuXG4gICAgICBzZWxmLl9yZXF1ZXJ5V2hlbkRvbmVUaGlzUXVlcnkgPSB0cnVlO1xuICAgIH0pO1xuICB9LFxuXG4gIC8vIFlpZWxkcyFcbiAgX2RvbmVRdWVyeWluZzogYXN5bmMgZnVuY3Rpb24gKCkge1xuICAgIHZhciBzZWxmID0gdGhpcztcblxuICAgIGlmIChzZWxmLl9zdG9wcGVkKVxuICAgICAgcmV0dXJuO1xuXG4gICAgYXdhaXQgc2VsZi5fbW9uZ29IYW5kbGUuX29wbG9nSGFuZGxlLndhaXRVbnRpbENhdWdodFVwKCk7XG5cbiAgICBpZiAoc2VsZi5fc3RvcHBlZClcbiAgICAgIHJldHVybjtcblxuICAgIGlmIChzZWxmLl9waGFzZSAhPT0gUEhBU0UuUVVFUllJTkcpXG4gICAgICB0aHJvdyBFcnJvcihcIlBoYXNlIHVuZXhwZWN0ZWRseSBcIiArIHNlbGYuX3BoYXNlKTtcblxuICAgIGlmIChzZWxmLl9yZXF1ZXJ5V2hlbkRvbmVUaGlzUXVlcnkpIHtcbiAgICAgIHNlbGYuX3JlcXVlcnlXaGVuRG9uZVRoaXNRdWVyeSA9IGZhbHNlO1xuICAgICAgc2VsZi5fcG9sbFF1ZXJ5KCk7XG4gICAgfSBlbHNlIGlmIChzZWxmLl9uZWVkVG9GZXRjaC5lbXB0eSgpKSB7XG4gICAgICBhd2FpdCBzZWxmLl9iZVN0ZWFkeSgpO1xuICAgIH0gZWxzZSB7XG4gICAgICBzZWxmLl9mZXRjaE1vZGlmaWVkRG9jdW1lbnRzKCk7XG4gICAgfVxuICB9LFxuXG4gIF9jdXJzb3JGb3JRdWVyeTogZnVuY3Rpb24gKG9wdGlvbnNPdmVyd3JpdGUpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgcmV0dXJuIE1ldGVvci5fbm9ZaWVsZHNBbGxvd2VkKGZ1bmN0aW9uICgpIHtcbiAgICAgIC8vIFRoZSBxdWVyeSB3ZSBydW4gaXMgYWxtb3N0IHRoZSBzYW1lIGFzIHRoZSBjdXJzb3Igd2UgYXJlIG9ic2VydmluZyxcbiAgICAgIC8vIHdpdGggYSBmZXcgY2hhbmdlcy4gV2UgbmVlZCB0byByZWFkIGFsbCB0aGUgZmllbGRzIHRoYXQgYXJlIHJlbGV2YW50IHRvXG4gICAgICAvLyB0aGUgc2VsZWN0b3IsIG5vdCBqdXN0IHRoZSBmaWVsZHMgd2UgYXJlIGdvaW5nIHRvIHB1Ymxpc2ggKHRoYXQncyB0aGVcbiAgICAgIC8vIFwic2hhcmVkXCIgcHJvamVjdGlvbikuIEFuZCB3ZSBkb24ndCB3YW50IHRvIGFwcGx5IGFueSB0cmFuc2Zvcm0gaW4gdGhlXG4gICAgICAvLyBjdXJzb3IsIGJlY2F1c2Ugb2JzZXJ2ZUNoYW5nZXMgc2hvdWxkbid0IHVzZSB0aGUgdHJhbnNmb3JtLlxuICAgICAgdmFyIG9wdGlvbnMgPSBfLmNsb25lKHNlbGYuX2N1cnNvckRlc2NyaXB0aW9uLm9wdGlvbnMpO1xuXG4gICAgICAvLyBBbGxvdyB0aGUgY2FsbGVyIHRvIG1vZGlmeSB0aGUgb3B0aW9ucy4gVXNlZnVsIHRvIHNwZWNpZnkgZGlmZmVyZW50XG4gICAgICAvLyBza2lwIGFuZCBsaW1pdCB2YWx1ZXMuXG4gICAgICBfLmV4dGVuZChvcHRpb25zLCBvcHRpb25zT3ZlcndyaXRlKTtcblxuICAgICAgb3B0aW9ucy5maWVsZHMgPSBzZWxmLl9zaGFyZWRQcm9qZWN0aW9uO1xuICAgICAgZGVsZXRlIG9wdGlvbnMudHJhbnNmb3JtO1xuICAgICAgLy8gV2UgYXJlIE5PVCBkZWVwIGNsb25pbmcgZmllbGRzIG9yIHNlbGVjdG9yIGhlcmUsIHdoaWNoIHNob3VsZCBiZSBPSy5cbiAgICAgIHZhciBkZXNjcmlwdGlvbiA9IG5ldyBDdXJzb3JEZXNjcmlwdGlvbihcbiAgICAgICAgc2VsZi5fY3Vyc29yRGVzY3JpcHRpb24uY29sbGVjdGlvbk5hbWUsXG4gICAgICAgIHNlbGYuX2N1cnNvckRlc2NyaXB0aW9uLnNlbGVjdG9yLFxuICAgICAgICBvcHRpb25zKTtcbiAgICAgIHJldHVybiBuZXcgQ3Vyc29yKHNlbGYuX21vbmdvSGFuZGxlLCBkZXNjcmlwdGlvbik7XG4gICAgfSk7XG4gIH0sXG5cblxuICAvLyBSZXBsYWNlIHNlbGYuX3B1Ymxpc2hlZCB3aXRoIG5ld1Jlc3VsdHMgKGJvdGggYXJlIElkTWFwcyksIGludm9raW5nIG9ic2VydmVcbiAgLy8gY2FsbGJhY2tzIG9uIHRoZSBtdWx0aXBsZXhlci5cbiAgLy8gUmVwbGFjZSBzZWxmLl91bnB1Ymxpc2hlZEJ1ZmZlciB3aXRoIG5ld0J1ZmZlci5cbiAgLy9cbiAgLy8gWFhYIFRoaXMgaXMgdmVyeSBzaW1pbGFyIHRvIExvY2FsQ29sbGVjdGlvbi5fZGlmZlF1ZXJ5VW5vcmRlcmVkQ2hhbmdlcy4gV2VcbiAgLy8gc2hvdWxkIHJlYWxseTogKGEpIFVuaWZ5IElkTWFwIGFuZCBPcmRlcmVkRGljdCBpbnRvIFVub3JkZXJlZC9PcmRlcmVkRGljdFxuICAvLyAoYikgUmV3cml0ZSBkaWZmLmpzIHRvIHVzZSB0aGVzZSBjbGFzc2VzIGluc3RlYWQgb2YgYXJyYXlzIGFuZCBvYmplY3RzLlxuICBfcHVibGlzaE5ld1Jlc3VsdHM6IGZ1bmN0aW9uIChuZXdSZXN1bHRzLCBuZXdCdWZmZXIpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgTWV0ZW9yLl9ub1lpZWxkc0FsbG93ZWQoZnVuY3Rpb24gKCkge1xuXG4gICAgICAvLyBJZiB0aGUgcXVlcnkgaXMgbGltaXRlZCBhbmQgdGhlcmUgaXMgYSBidWZmZXIsIHNodXQgZG93biBzbyBpdCBkb2Vzbid0XG4gICAgICAvLyBzdGF5IGluIGEgd2F5LlxuICAgICAgaWYgKHNlbGYuX2xpbWl0KSB7XG4gICAgICAgIHNlbGYuX3VucHVibGlzaGVkQnVmZmVyLmNsZWFyKCk7XG4gICAgICB9XG5cbiAgICAgIC8vIEZpcnN0IHJlbW92ZSBhbnl0aGluZyB0aGF0J3MgZ29uZS4gQmUgY2FyZWZ1bCBub3QgdG8gbW9kaWZ5XG4gICAgICAvLyBzZWxmLl9wdWJsaXNoZWQgd2hpbGUgaXRlcmF0aW5nIG92ZXIgaXQuXG4gICAgICB2YXIgaWRzVG9SZW1vdmUgPSBbXTtcbiAgICAgIHNlbGYuX3B1Ymxpc2hlZC5mb3JFYWNoKGZ1bmN0aW9uIChkb2MsIGlkKSB7XG4gICAgICAgIGlmICghbmV3UmVzdWx0cy5oYXMoaWQpKVxuICAgICAgICAgIGlkc1RvUmVtb3ZlLnB1c2goaWQpO1xuICAgICAgfSk7XG4gICAgICBfLmVhY2goaWRzVG9SZW1vdmUsIGZ1bmN0aW9uIChpZCkge1xuICAgICAgICBzZWxmLl9yZW1vdmVQdWJsaXNoZWQoaWQpO1xuICAgICAgfSk7XG5cbiAgICAgIC8vIE5vdyBkbyBhZGRzIGFuZCBjaGFuZ2VzLlxuICAgICAgLy8gSWYgc2VsZiBoYXMgYSBidWZmZXIgYW5kIGxpbWl0LCB0aGUgbmV3IGZldGNoZWQgcmVzdWx0IHdpbGwgYmVcbiAgICAgIC8vIGxpbWl0ZWQgY29ycmVjdGx5IGFzIHRoZSBxdWVyeSBoYXMgc29ydCBzcGVjaWZpZXIuXG4gICAgICBuZXdSZXN1bHRzLmZvckVhY2goZnVuY3Rpb24gKGRvYywgaWQpIHtcbiAgICAgICAgc2VsZi5faGFuZGxlRG9jKGlkLCBkb2MpO1xuICAgICAgfSk7XG5cbiAgICAgIC8vIFNhbml0eS1jaGVjayB0aGF0IGV2ZXJ5dGhpbmcgd2UgdHJpZWQgdG8gcHV0IGludG8gX3B1Ymxpc2hlZCBlbmRlZCB1cFxuICAgICAgLy8gdGhlcmUuXG4gICAgICAvLyBYWFggaWYgdGhpcyBpcyBzbG93LCByZW1vdmUgaXQgbGF0ZXJcbiAgICAgIGlmIChzZWxmLl9wdWJsaXNoZWQuc2l6ZSgpICE9PSBuZXdSZXN1bHRzLnNpemUoKSkge1xuICAgICAgICBNZXRlb3IuX2RlYnVnKCdUaGUgTW9uZ28gc2VydmVyIGFuZCB0aGUgTWV0ZW9yIHF1ZXJ5IGRpc2FncmVlIG9uIGhvdyAnICtcbiAgICAgICAgICAnbWFueSBkb2N1bWVudHMgbWF0Y2ggeW91ciBxdWVyeS4gQ3Vyc29yIGRlc2NyaXB0aW9uOiAnLFxuICAgICAgICAgIHNlbGYuX2N1cnNvckRlc2NyaXB0aW9uKTtcbiAgICAgIH1cbiAgICAgIFxuICAgICAgc2VsZi5fcHVibGlzaGVkLmZvckVhY2goZnVuY3Rpb24gKGRvYywgaWQpIHtcbiAgICAgICAgaWYgKCFuZXdSZXN1bHRzLmhhcyhpZCkpXG4gICAgICAgICAgdGhyb3cgRXJyb3IoXCJfcHVibGlzaGVkIGhhcyBhIGRvYyB0aGF0IG5ld1Jlc3VsdHMgZG9lc24ndDsgXCIgKyBpZCk7XG4gICAgICB9KTtcblxuICAgICAgLy8gRmluYWxseSwgcmVwbGFjZSB0aGUgYnVmZmVyXG4gICAgICBuZXdCdWZmZXIuZm9yRWFjaChmdW5jdGlvbiAoZG9jLCBpZCkge1xuICAgICAgICBzZWxmLl9hZGRCdWZmZXJlZChpZCwgZG9jKTtcbiAgICAgIH0pO1xuXG4gICAgICBzZWxmLl9zYWZlQXBwZW5kVG9CdWZmZXIgPSBuZXdCdWZmZXIuc2l6ZSgpIDwgc2VsZi5fbGltaXQ7XG4gICAgfSk7XG4gIH0sXG5cbiAgLy8gVGhpcyBzdG9wIGZ1bmN0aW9uIGlzIGludm9rZWQgZnJvbSB0aGUgb25TdG9wIG9mIHRoZSBPYnNlcnZlTXVsdGlwbGV4ZXIsIHNvXG4gIC8vIGl0IHNob3VsZG4ndCBhY3R1YWxseSBiZSBwb3NzaWJsZSB0byBjYWxsIGl0IHVudGlsIHRoZSBtdWx0aXBsZXhlciBpc1xuICAvLyByZWFkeS5cbiAgLy9cbiAgLy8gSXQncyBpbXBvcnRhbnQgdG8gY2hlY2sgc2VsZi5fc3RvcHBlZCBhZnRlciBldmVyeSBjYWxsIGluIHRoaXMgZmlsZSB0aGF0XG4gIC8vIGNhbiB5aWVsZCFcbiAgX3N0b3A6IGFzeW5jIGZ1bmN0aW9uKCkge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICBpZiAoc2VsZi5fc3RvcHBlZClcbiAgICAgIHJldHVybjtcbiAgICBzZWxmLl9zdG9wcGVkID0gdHJ1ZTtcblxuICAgIC8vIE5vdGU6IHdlICpkb24ndCogdXNlIG11bHRpcGxleGVyLm9uRmx1c2ggaGVyZSBiZWNhdXNlIHRoaXMgc3RvcFxuICAgIC8vIGNhbGxiYWNrIGlzIGFjdHVhbGx5IGludm9rZWQgYnkgdGhlIG11bHRpcGxleGVyIGl0c2VsZiB3aGVuIGl0IGhhc1xuICAgIC8vIGRldGVybWluZWQgdGhhdCB0aGVyZSBhcmUgbm8gaGFuZGxlcyBsZWZ0LiBTbyBub3RoaW5nIGlzIGFjdHVhbGx5IGdvaW5nXG4gICAgLy8gdG8gZ2V0IGZsdXNoZWQgKGFuZCBpdCdzIHByb2JhYmx5IG5vdCB2YWxpZCB0byBjYWxsIG1ldGhvZHMgb24gdGhlXG4gICAgLy8gZHlpbmcgbXVsdGlwbGV4ZXIpLlxuICAgIGZvciAoY29uc3QgdyBvZiBzZWxmLl93cml0ZXNUb0NvbW1pdFdoZW5XZVJlYWNoU3RlYWR5KSB7XG4gICAgICBhd2FpdCB3LmNvbW1pdHRlZCgpO1xuICAgIH1cbiAgICBzZWxmLl93cml0ZXNUb0NvbW1pdFdoZW5XZVJlYWNoU3RlYWR5ID0gbnVsbDtcblxuICAgIC8vIFByb2FjdGl2ZWx5IGRyb3AgcmVmZXJlbmNlcyB0byBwb3RlbnRpYWxseSBiaWcgdGhpbmdzLlxuICAgIHNlbGYuX3B1Ymxpc2hlZCA9IG51bGw7XG4gICAgc2VsZi5fdW5wdWJsaXNoZWRCdWZmZXIgPSBudWxsO1xuICAgIHNlbGYuX25lZWRUb0ZldGNoID0gbnVsbDtcbiAgICBzZWxmLl9jdXJyZW50bHlGZXRjaGluZyA9IG51bGw7XG4gICAgc2VsZi5fb3Bsb2dFbnRyeUhhbmRsZSA9IG51bGw7XG4gICAgc2VsZi5fbGlzdGVuZXJzSGFuZGxlID0gbnVsbDtcblxuICAgIFBhY2thZ2VbJ2ZhY3RzLWJhc2UnXSAmJiBQYWNrYWdlWydmYWN0cy1iYXNlJ10uRmFjdHMuaW5jcmVtZW50U2VydmVyRmFjdChcbiAgICAgICAgXCJtb25nby1saXZlZGF0YVwiLCBcIm9ic2VydmUtZHJpdmVycy1vcGxvZ1wiLCAtMSk7XG5cbiAgICBmb3IgYXdhaXQgKGNvbnN0IGhhbmRsZSBvZiBzZWxmLl9zdG9wSGFuZGxlcykge1xuICAgICAgYXdhaXQgaGFuZGxlLnN0b3AoKTtcbiAgICB9XG4gIH0sXG4gIHN0b3A6IGFzeW5jIGZ1bmN0aW9uKCkge1xuICAgIGNvbnN0IHNlbGYgPSB0aGlzO1xuICAgIHJldHVybiBhd2FpdCBzZWxmLl9zdG9wKCk7XG4gIH0sXG5cbiAgX3JlZ2lzdGVyUGhhc2VDaGFuZ2U6IGZ1bmN0aW9uIChwaGFzZSkge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICBNZXRlb3IuX25vWWllbGRzQWxsb3dlZChmdW5jdGlvbiAoKSB7XG4gICAgICB2YXIgbm93ID0gbmV3IERhdGU7XG5cbiAgICAgIGlmIChzZWxmLl9waGFzZSkge1xuICAgICAgICB2YXIgdGltZURpZmYgPSBub3cgLSBzZWxmLl9waGFzZVN0YXJ0VGltZTtcbiAgICAgICAgUGFja2FnZVsnZmFjdHMtYmFzZSddICYmIFBhY2thZ2VbJ2ZhY3RzLWJhc2UnXS5GYWN0cy5pbmNyZW1lbnRTZXJ2ZXJGYWN0KFxuICAgICAgICAgIFwibW9uZ28tbGl2ZWRhdGFcIiwgXCJ0aW1lLXNwZW50LWluLVwiICsgc2VsZi5fcGhhc2UgKyBcIi1waGFzZVwiLCB0aW1lRGlmZik7XG4gICAgICB9XG5cbiAgICAgIHNlbGYuX3BoYXNlID0gcGhhc2U7XG4gICAgICBzZWxmLl9waGFzZVN0YXJ0VGltZSA9IG5vdztcbiAgICB9KTtcbiAgfVxufSk7XG5cbi8vIERvZXMgb3VyIG9wbG9nIHRhaWxpbmcgY29kZSBzdXBwb3J0IHRoaXMgY3Vyc29yPyBGb3Igbm93LCB3ZSBhcmUgYmVpbmcgdmVyeVxuLy8gY29uc2VydmF0aXZlIGFuZCBhbGxvd2luZyBvbmx5IHNpbXBsZSBxdWVyaWVzIHdpdGggc2ltcGxlIG9wdGlvbnMuXG4vLyAoVGhpcyBpcyBhIFwic3RhdGljIG1ldGhvZFwiLilcbk9wbG9nT2JzZXJ2ZURyaXZlci5jdXJzb3JTdXBwb3J0ZWQgPSBmdW5jdGlvbiAoY3Vyc29yRGVzY3JpcHRpb24sIG1hdGNoZXIpIHtcbiAgLy8gRmlyc3QsIGNoZWNrIHRoZSBvcHRpb25zLlxuICB2YXIgb3B0aW9ucyA9IGN1cnNvckRlc2NyaXB0aW9uLm9wdGlvbnM7XG5cbiAgLy8gRGlkIHRoZSB1c2VyIHNheSBubyBleHBsaWNpdGx5P1xuICAvLyB1bmRlcnNjb3JlZCB2ZXJzaW9uIG9mIHRoZSBvcHRpb24gaXMgQ09NUEFUIHdpdGggMS4yXG4gIGlmIChvcHRpb25zLmRpc2FibGVPcGxvZyB8fCBvcHRpb25zLl9kaXNhYmxlT3Bsb2cpXG4gICAgcmV0dXJuIGZhbHNlO1xuXG4gIC8vIHNraXAgaXMgbm90IHN1cHBvcnRlZDogdG8gc3VwcG9ydCBpdCB3ZSB3b3VsZCBuZWVkIHRvIGtlZXAgdHJhY2sgb2YgYWxsXG4gIC8vIFwic2tpcHBlZFwiIGRvY3VtZW50cyBvciBhdCBsZWFzdCB0aGVpciBpZHMuXG4gIC8vIGxpbWl0IHcvbyBhIHNvcnQgc3BlY2lmaWVyIGlzIG5vdCBzdXBwb3J0ZWQ6IGN1cnJlbnQgaW1wbGVtZW50YXRpb24gbmVlZHMgYVxuICAvLyBkZXRlcm1pbmlzdGljIHdheSB0byBvcmRlciBkb2N1bWVudHMuXG4gIGlmIChvcHRpb25zLnNraXAgfHwgKG9wdGlvbnMubGltaXQgJiYgIW9wdGlvbnMuc29ydCkpIHJldHVybiBmYWxzZTtcblxuICAvLyBJZiBhIGZpZWxkcyBwcm9qZWN0aW9uIG9wdGlvbiBpcyBnaXZlbiBjaGVjayBpZiBpdCBpcyBzdXBwb3J0ZWQgYnlcbiAgLy8gbWluaW1vbmdvIChzb21lIG9wZXJhdG9ycyBhcmUgbm90IHN1cHBvcnRlZCkuXG4gIGNvbnN0IGZpZWxkcyA9IG9wdGlvbnMuZmllbGRzIHx8IG9wdGlvbnMucHJvamVjdGlvbjtcbiAgaWYgKGZpZWxkcykge1xuICAgIHRyeSB7XG4gICAgICBMb2NhbENvbGxlY3Rpb24uX2NoZWNrU3VwcG9ydGVkUHJvamVjdGlvbihmaWVsZHMpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGlmIChlLm5hbWUgPT09IFwiTWluaW1vbmdvRXJyb3JcIikge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aHJvdyBlO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIC8vIFdlIGRvbid0IGFsbG93IHRoZSBmb2xsb3dpbmcgc2VsZWN0b3JzOlxuICAvLyAgIC0gJHdoZXJlIChub3QgY29uZmlkZW50IHRoYXQgd2UgcHJvdmlkZSB0aGUgc2FtZSBKUyBlbnZpcm9ubWVudFxuICAvLyAgICAgICAgICAgICBhcyBNb25nbywgYW5kIGNhbiB5aWVsZCEpXG4gIC8vICAgLSAkbmVhciAoaGFzIFwiaW50ZXJlc3RpbmdcIiBwcm9wZXJ0aWVzIGluIE1vbmdvREIsIGxpa2UgdGhlIHBvc3NpYmlsaXR5XG4gIC8vICAgICAgICAgICAgb2YgcmV0dXJuaW5nIGFuIElEIG11bHRpcGxlIHRpbWVzLCB0aG91Z2ggZXZlbiBwb2xsaW5nIG1heWJlXG4gIC8vICAgICAgICAgICAgaGF2ZSBhIGJ1ZyB0aGVyZSlcbiAgLy8gICAgICAgICAgIFhYWDogb25jZSB3ZSBzdXBwb3J0IGl0LCB3ZSB3b3VsZCBuZWVkIHRvIHRoaW5rIG1vcmUgb24gaG93IHdlXG4gIC8vICAgICAgICAgICBpbml0aWFsaXplIHRoZSBjb21wYXJhdG9ycyB3aGVuIHdlIGNyZWF0ZSB0aGUgZHJpdmVyLlxuICByZXR1cm4gIW1hdGNoZXIuaGFzV2hlcmUoKSAmJiAhbWF0Y2hlci5oYXNHZW9RdWVyeSgpO1xufTtcblxudmFyIG1vZGlmaWVyQ2FuQmVEaXJlY3RseUFwcGxpZWQgPSBmdW5jdGlvbiAobW9kaWZpZXIpIHtcbiAgcmV0dXJuIF8uYWxsKG1vZGlmaWVyLCBmdW5jdGlvbiAoZmllbGRzLCBvcGVyYXRpb24pIHtcbiAgICByZXR1cm4gXy5hbGwoZmllbGRzLCBmdW5jdGlvbiAodmFsdWUsIGZpZWxkKSB7XG4gICAgICByZXR1cm4gIS9FSlNPTlxcJC8udGVzdChmaWVsZCk7XG4gICAgfSk7XG4gIH0pO1xufTtcblxuTW9uZ29JbnRlcm5hbHMuT3Bsb2dPYnNlcnZlRHJpdmVyID0gT3Bsb2dPYnNlcnZlRHJpdmVyO1xuIiwiLy8gQ29udmVydGVyIG9mIHRoZSBuZXcgTW9uZ29EQiBPcGxvZyBmb3JtYXQgKD49NS4wKSB0byB0aGUgb25lIHRoYXQgTWV0ZW9yXG4vLyBoYW5kbGVzIHdlbGwsIGkuZS4sIGAkc2V0YCBhbmQgYCR1bnNldGAuIFRoZSBuZXcgZm9ybWF0IGlzIGNvbXBsZXRlbHkgbmV3LFxuLy8gYW5kIGxvb2tzIGFzIGZvbGxvd3M6XG4vL1xuLy8gICB7ICR2OiAyLCBkaWZmOiBEaWZmIH1cbi8vXG4vLyB3aGVyZSBgRGlmZmAgaXMgYSByZWN1cnNpdmUgc3RydWN0dXJlOlxuLy9cbi8vICAge1xuLy8gICAgIC8vIE5lc3RlZCB1cGRhdGVzIChzb21ldGltZXMgYWxzbyByZXByZXNlbnRlZCB3aXRoIGFuIHMtZmllbGQpLlxuLy8gICAgIC8vIEV4YW1wbGU6IGB7ICRzZXQ6IHsgJ2Zvby5iYXInOiAxIH0gfWAuXG4vLyAgICAgaTogeyA8a2V5PjogPHZhbHVlPiwgLi4uIH0sXG4vL1xuLy8gICAgIC8vIFRvcC1sZXZlbCB1cGRhdGVzLlxuLy8gICAgIC8vIEV4YW1wbGU6IGB7ICRzZXQ6IHsgZm9vOiB7IGJhcjogMSB9IH0gfWAuXG4vLyAgICAgdTogeyA8a2V5PjogPHZhbHVlPiwgLi4uIH0sXG4vL1xuLy8gICAgIC8vIFVuc2V0cy5cbi8vICAgICAvLyBFeGFtcGxlOiBgeyAkdW5zZXQ6IHsgZm9vOiAnJyB9IH1gLlxuLy8gICAgIGQ6IHsgPGtleT46IGZhbHNlLCAuLi4gfSxcbi8vXG4vLyAgICAgLy8gQXJyYXkgb3BlcmF0aW9ucy5cbi8vICAgICAvLyBFeGFtcGxlOiBgeyAkcHVzaDogeyBmb286ICdiYXInIH0gfWAuXG4vLyAgICAgczxrZXk+OiB7IGE6IHRydWUsIHU8aW5kZXg+OiA8dmFsdWU+LCAuLi4gfSxcbi8vICAgICAuLi5cbi8vXG4vLyAgICAgLy8gTmVzdGVkIG9wZXJhdGlvbnMgKHNvbWV0aW1lcyBhbHNvIHJlcHJlc2VudGVkIGluIHRoZSBgaWAgZmllbGQpLlxuLy8gICAgIC8vIEV4YW1wbGU6IGB7ICRzZXQ6IHsgJ2Zvby5iYXInOiAxIH0gfWAuXG4vLyAgICAgczxrZXk+OiBEaWZmLFxuLy8gICAgIC4uLlxuLy8gICB9XG4vL1xuLy8gKGFsbCBmaWVsZHMgYXJlIG9wdGlvbmFsKS5cblxuZnVuY3Rpb24gam9pbihwcmVmaXgsIGtleSkge1xuICByZXR1cm4gcHJlZml4ID8gYCR7cHJlZml4fS4ke2tleX1gIDoga2V5O1xufVxuXG5jb25zdCBhcnJheU9wZXJhdG9yS2V5UmVnZXggPSAvXihhfFtzdV1cXGQrKSQvO1xuXG5mdW5jdGlvbiBpc0FycmF5T3BlcmF0b3JLZXkoZmllbGQpIHtcbiAgcmV0dXJuIGFycmF5T3BlcmF0b3JLZXlSZWdleC50ZXN0KGZpZWxkKTtcbn1cblxuZnVuY3Rpb24gaXNBcnJheU9wZXJhdG9yKG9wZXJhdG9yKSB7XG4gIHJldHVybiBvcGVyYXRvci5hID09PSB0cnVlICYmIE9iamVjdC5rZXlzKG9wZXJhdG9yKS5ldmVyeShpc0FycmF5T3BlcmF0b3JLZXkpO1xufVxuXG5mdW5jdGlvbiBmbGF0dGVuT2JqZWN0SW50byh0YXJnZXQsIHNvdXJjZSwgcHJlZml4KSB7XG4gIGlmIChBcnJheS5pc0FycmF5KHNvdXJjZSkgfHwgdHlwZW9mIHNvdXJjZSAhPT0gJ29iamVjdCcgfHwgc291cmNlID09PSBudWxsIHx8XG4gICAgICBzb3VyY2UgaW5zdGFuY2VvZiBNb25nby5PYmplY3RJRCkge1xuICAgIHRhcmdldFtwcmVmaXhdID0gc291cmNlO1xuICB9IGVsc2Uge1xuICAgIGNvbnN0IGVudHJpZXMgPSBPYmplY3QuZW50cmllcyhzb3VyY2UpO1xuICAgIGlmIChlbnRyaWVzLmxlbmd0aCkge1xuICAgICAgZW50cmllcy5mb3JFYWNoKChba2V5LCB2YWx1ZV0pID0+IHtcbiAgICAgICAgZmxhdHRlbk9iamVjdEludG8odGFyZ2V0LCB2YWx1ZSwgam9pbihwcmVmaXgsIGtleSkpO1xuICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRhcmdldFtwcmVmaXhdID0gc291cmNlO1xuICAgIH1cbiAgfVxufVxuXG5jb25zdCBsb2dEZWJ1Z01lc3NhZ2VzID0gISFwcm9jZXNzLmVudi5PUExPR19DT05WRVJURVJfREVCVUc7XG5cbmZ1bmN0aW9uIGNvbnZlcnRPcGxvZ0RpZmYob3Bsb2dFbnRyeSwgZGlmZiwgcHJlZml4KSB7XG4gIGlmIChsb2dEZWJ1Z01lc3NhZ2VzKSB7XG4gICAgY29uc29sZS5sb2coYGNvbnZlcnRPcGxvZ0RpZmYoJHtKU09OLnN0cmluZ2lmeShvcGxvZ0VudHJ5KX0sICR7SlNPTi5zdHJpbmdpZnkoZGlmZil9LCAke0pTT04uc3RyaW5naWZ5KHByZWZpeCl9KWApO1xuICB9XG5cbiAgT2JqZWN0LmVudHJpZXMoZGlmZikuZm9yRWFjaCgoW2RpZmZLZXksIHZhbHVlXSkgPT4ge1xuICAgIGlmIChkaWZmS2V5ID09PSAnZCcpIHtcbiAgICAgIC8vIEhhbmRsZSBgJHVuc2V0YHMuXG4gICAgICBvcGxvZ0VudHJ5LiR1bnNldCA/Pz0ge307XG4gICAgICBPYmplY3Qua2V5cyh2YWx1ZSkuZm9yRWFjaChrZXkgPT4ge1xuICAgICAgICBvcGxvZ0VudHJ5LiR1bnNldFtqb2luKHByZWZpeCwga2V5KV0gPSB0cnVlO1xuICAgICAgfSk7XG4gICAgfSBlbHNlIGlmIChkaWZmS2V5ID09PSAnaScpIHtcbiAgICAgIC8vIEhhbmRsZSAocG90ZW50aWFsbHkpIG5lc3RlZCBgJHNldGBzLlxuICAgICAgb3Bsb2dFbnRyeS4kc2V0ID8/PSB7fTtcbiAgICAgIGZsYXR0ZW5PYmplY3RJbnRvKG9wbG9nRW50cnkuJHNldCwgdmFsdWUsIHByZWZpeCk7XG4gICAgfSBlbHNlIGlmIChkaWZmS2V5ID09PSAndScpIHtcbiAgICAgIC8vIEhhbmRsZSBmbGF0IGAkc2V0YHMuXG4gICAgICBvcGxvZ0VudHJ5LiRzZXQgPz89IHt9O1xuICAgICAgT2JqZWN0LmVudHJpZXModmFsdWUpLmZvckVhY2goKFtrZXksIHZhbHVlXSkgPT4ge1xuICAgICAgICBvcGxvZ0VudHJ5LiRzZXRbam9pbihwcmVmaXgsIGtleSldID0gdmFsdWU7XG4gICAgICB9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gSGFuZGxlIHMtZmllbGRzLlxuICAgICAgY29uc3Qga2V5ID0gZGlmZktleS5zbGljZSgxKTtcbiAgICAgIGlmIChpc0FycmF5T3BlcmF0b3IodmFsdWUpKSB7XG4gICAgICAgIC8vIEFycmF5IG9wZXJhdG9yLlxuICAgICAgICBPYmplY3QuZW50cmllcyh2YWx1ZSkuZm9yRWFjaCgoW3Bvc2l0aW9uLCB2YWx1ZV0pID0+IHtcbiAgICAgICAgICBpZiAocG9zaXRpb24gPT09ICdhJykge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIGNvbnN0IHBvc2l0aW9uS2V5ID0gam9pbihqb2luKHByZWZpeCwga2V5KSwgcG9zaXRpb24uc2xpY2UoMSkpO1xuICAgICAgICAgIGlmIChwb3NpdGlvblswXSA9PT0gJ3MnKSB7XG4gICAgICAgICAgICBjb252ZXJ0T3Bsb2dEaWZmKG9wbG9nRW50cnksIHZhbHVlLCBwb3NpdGlvbktleSk7XG4gICAgICAgICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gbnVsbCkge1xuICAgICAgICAgICAgb3Bsb2dFbnRyeS4kdW5zZXQgPz89IHt9O1xuICAgICAgICAgICAgb3Bsb2dFbnRyeS4kdW5zZXRbcG9zaXRpb25LZXldID0gdHJ1ZTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgb3Bsb2dFbnRyeS4kc2V0ID8/PSB7fTtcbiAgICAgICAgICAgIG9wbG9nRW50cnkuJHNldFtwb3NpdGlvbktleV0gPSB2YWx1ZTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIGlmIChrZXkpIHtcbiAgICAgICAgLy8gTmVzdGVkIG9iamVjdC5cbiAgICAgICAgY29udmVydE9wbG9nRGlmZihvcGxvZ0VudHJ5LCB2YWx1ZSwgam9pbihwcmVmaXgsIGtleSkpO1xuICAgICAgfVxuICAgIH1cbiAgfSk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBvcGxvZ1YyVjFDb252ZXJ0ZXIob3Bsb2dFbnRyeSkge1xuICAvLyBQYXNzLXRocm91Z2ggdjEgYW5kIChwcm9iYWJseSkgaW52YWxpZCBlbnRyaWVzLlxuICBpZiAob3Bsb2dFbnRyeS4kdiAhPT0gMiB8fCAhb3Bsb2dFbnRyeS5kaWZmKSB7XG4gICAgcmV0dXJuIG9wbG9nRW50cnk7XG4gIH1cblxuICBjb25zdCBjb252ZXJ0ZWRPcGxvZ0VudHJ5ID0geyAkdjogMiB9O1xuICBjb252ZXJ0T3Bsb2dEaWZmKGNvbnZlcnRlZE9wbG9nRW50cnksIG9wbG9nRW50cnkuZGlmZiwgJycpO1xuICByZXR1cm4gY29udmVydGVkT3Bsb2dFbnRyeTtcbn1cbiIsIi8vIHNpbmdsZXRvblxuZXhwb3J0IGNvbnN0IExvY2FsQ29sbGVjdGlvbkRyaXZlciA9IG5ldyAoY2xhc3MgTG9jYWxDb2xsZWN0aW9uRHJpdmVyIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgdGhpcy5ub0Nvbm5Db2xsZWN0aW9ucyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIH1cblxuICBvcGVuKG5hbWUsIGNvbm4pIHtcbiAgICBpZiAoISBuYW1lKSB7XG4gICAgICByZXR1cm4gbmV3IExvY2FsQ29sbGVjdGlvbjtcbiAgICB9XG5cbiAgICBpZiAoISBjb25uKSB7XG4gICAgICByZXR1cm4gZW5zdXJlQ29sbGVjdGlvbihuYW1lLCB0aGlzLm5vQ29ubkNvbGxlY3Rpb25zKTtcbiAgICB9XG5cbiAgICBpZiAoISBjb25uLl9tb25nb19saXZlZGF0YV9jb2xsZWN0aW9ucykge1xuICAgICAgY29ubi5fbW9uZ29fbGl2ZWRhdGFfY29sbGVjdGlvbnMgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuICAgIH1cblxuICAgIC8vIFhYWCBpcyB0aGVyZSBhIHdheSB0byBrZWVwIHRyYWNrIG9mIGEgY29ubmVjdGlvbidzIGNvbGxlY3Rpb25zIHdpdGhvdXRcbiAgICAvLyBkYW5nbGluZyBpdCBvZmYgdGhlIGNvbm5lY3Rpb24gb2JqZWN0P1xuICAgIHJldHVybiBlbnN1cmVDb2xsZWN0aW9uKG5hbWUsIGNvbm4uX21vbmdvX2xpdmVkYXRhX2NvbGxlY3Rpb25zKTtcbiAgfVxufSk7XG5cbmZ1bmN0aW9uIGVuc3VyZUNvbGxlY3Rpb24obmFtZSwgY29sbGVjdGlvbnMpIHtcbiAgcmV0dXJuIChuYW1lIGluIGNvbGxlY3Rpb25zKVxuICAgID8gY29sbGVjdGlvbnNbbmFtZV1cbiAgICA6IGNvbGxlY3Rpb25zW25hbWVdID0gbmV3IExvY2FsQ29sbGVjdGlvbihuYW1lKTtcbn1cbiIsImltcG9ydCB7XG4gIEFTWU5DX0NPTExFQ1RJT05fTUVUSE9EUyxcbiAgZ2V0QXN5bmNNZXRob2ROYW1lLFxuICBDTElFTlRfT05MWV9NRVRIT0RTXG59IGZyb20gXCJtZXRlb3IvbWluaW1vbmdvL2NvbnN0YW50c1wiO1xuXG5Nb25nb0ludGVybmFscy5SZW1vdGVDb2xsZWN0aW9uRHJpdmVyID0gZnVuY3Rpb24gKFxuICBtb25nb191cmwsIG9wdGlvbnMpIHtcbiAgdmFyIHNlbGYgPSB0aGlzO1xuICBzZWxmLm1vbmdvID0gbmV3IE1vbmdvQ29ubmVjdGlvbihtb25nb191cmwsIG9wdGlvbnMpO1xufTtcblxuY29uc3QgUkVNT1RFX0NPTExFQ1RJT05fTUVUSE9EUyA9IFtcbiAgJ2NyZWF0ZUNhcHBlZENvbGxlY3Rpb25Bc3luYycsXG4gICdkcm9wSW5kZXhBc3luYycsXG4gICdlbnN1cmVJbmRleEFzeW5jJyxcbiAgJ2NyZWF0ZUluZGV4QXN5bmMnLFxuICAnY291bnREb2N1bWVudHMnLFxuICAnZHJvcENvbGxlY3Rpb25Bc3luYycsXG4gICdlc3RpbWF0ZWREb2N1bWVudENvdW50JyxcbiAgJ2ZpbmQnLFxuICAnZmluZE9uZUFzeW5jJyxcbiAgJ2luc2VydEFzeW5jJyxcbiAgJ3Jhd0NvbGxlY3Rpb24nLFxuICAncmVtb3ZlQXN5bmMnLFxuICAndXBkYXRlQXN5bmMnLFxuICAndXBzZXJ0QXN5bmMnLFxuXTtcblxuT2JqZWN0LmFzc2lnbihNb25nb0ludGVybmFscy5SZW1vdGVDb2xsZWN0aW9uRHJpdmVyLnByb3RvdHlwZSwge1xuICBvcGVuOiBmdW5jdGlvbiAobmFtZSkge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICB2YXIgcmV0ID0ge307XG4gICAgUkVNT1RFX0NPTExFQ1RJT05fTUVUSE9EUy5mb3JFYWNoKGZ1bmN0aW9uIChtKSB7XG4gICAgICByZXRbbV0gPSBfLmJpbmQoc2VsZi5tb25nb1ttXSwgc2VsZi5tb25nbywgbmFtZSk7XG5cbiAgICAgIGlmICghQVNZTkNfQ09MTEVDVElPTl9NRVRIT0RTLmluY2x1ZGVzKG0pKSByZXR1cm47XG4gICAgICBjb25zdCBhc3luY01ldGhvZE5hbWUgPSBnZXRBc3luY01ldGhvZE5hbWUobSk7XG4gICAgICByZXRbYXN5bmNNZXRob2ROYW1lXSA9IGZ1bmN0aW9uICguLi5hcmdzKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZShyZXRbbV0oLi4uYXJncykpO1xuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgIHJldHVybiBQcm9taXNlLnJlamVjdChlcnJvcik7XG4gICAgICAgIH1cbiAgICAgIH07XG4gICAgfSk7XG5cbiAgICBDTElFTlRfT05MWV9NRVRIT0RTLmZvckVhY2goZnVuY3Rpb24gKG0pIHtcbiAgICAgIHJldFttXSA9IF8uYmluZChzZWxmLm1vbmdvW21dLCBzZWxmLm1vbmdvLCBuYW1lKTtcblxuICAgICAgcmV0W21dID0gZnVuY3Rpb24gKC4uLmFyZ3MpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAgIGAke219ICsgIGlzIG5vdCBhdmFpbGFibGUgb24gdGhlIHNlcnZlci4gUGxlYXNlIHVzZSAke2dldEFzeW5jTWV0aG9kTmFtZShcbiAgICAgICAgICAgIG1cbiAgICAgICAgICApfSgpIGluc3RlYWQuYFxuICAgICAgICApO1xuICAgICAgfTtcbiAgICB9KTtcbiAgICByZXR1cm4gcmV0O1xuICB9LFxufSk7XG5cbi8vIENyZWF0ZSB0aGUgc2luZ2xldG9uIFJlbW90ZUNvbGxlY3Rpb25Ecml2ZXIgb25seSBvbiBkZW1hbmQsIHNvIHdlXG4vLyBvbmx5IHJlcXVpcmUgTW9uZ28gY29uZmlndXJhdGlvbiBpZiBpdCdzIGFjdHVhbGx5IHVzZWQgKGVnLCBub3QgaWZcbi8vIHlvdSdyZSBvbmx5IHRyeWluZyB0byByZWNlaXZlIGRhdGEgZnJvbSBhIHJlbW90ZSBERFAgc2VydmVyLilcbk1vbmdvSW50ZXJuYWxzLmRlZmF1bHRSZW1vdGVDb2xsZWN0aW9uRHJpdmVyID0gXy5vbmNlKGZ1bmN0aW9uICgpIHtcbiAgdmFyIGNvbm5lY3Rpb25PcHRpb25zID0ge307XG5cbiAgdmFyIG1vbmdvVXJsID0gcHJvY2Vzcy5lbnYuTU9OR09fVVJMO1xuXG4gIGlmIChwcm9jZXNzLmVudi5NT05HT19PUExPR19VUkwpIHtcbiAgICBjb25uZWN0aW9uT3B0aW9ucy5vcGxvZ1VybCA9IHByb2Nlc3MuZW52Lk1PTkdPX09QTE9HX1VSTDtcbiAgfVxuXG4gIGlmICghIG1vbmdvVXJsKVxuICAgIHRocm93IG5ldyBFcnJvcihcIk1PTkdPX1VSTCBtdXN0IGJlIHNldCBpbiBlbnZpcm9ubWVudFwiKTtcblxuICBjb25zdCBkcml2ZXIgPSBuZXcgTW9uZ29JbnRlcm5hbHMuUmVtb3RlQ29sbGVjdGlvbkRyaXZlcihtb25nb1VybCwgY29ubmVjdGlvbk9wdGlvbnMpO1xuXG4gIC8vIEFzIG1hbnkgZGVwbG95bWVudCB0b29scywgaW5jbHVkaW5nIE1ldGVvciBVcCwgc2VuZCByZXF1ZXN0cyB0byB0aGUgYXBwIGluXG4gIC8vIG9yZGVyIHRvIGNvbmZpcm0gdGhhdCB0aGUgZGVwbG95bWVudCBmaW5pc2hlZCBzdWNjZXNzZnVsbHksIGl0J3MgcmVxdWlyZWRcbiAgLy8gdG8ga25vdyBhYm91dCBhIGRhdGFiYXNlIGNvbm5lY3Rpb24gcHJvYmxlbSBiZWZvcmUgdGhlIGFwcCBzdGFydHMuIERvaW5nIHNvXG4gIC8vIGluIGEgYE1ldGVvci5zdGFydHVwYCBpcyBmaW5lLCBhcyB0aGUgYFdlYkFwcGAgaGFuZGxlcyByZXF1ZXN0cyBvbmx5IGFmdGVyXG4gIC8vIGFsbCBhcmUgZmluaXNoZWQuXG4gIE1ldGVvci5zdGFydHVwKGFzeW5jICgpID0+IHtcbiAgICBhd2FpdCBkcml2ZXIubW9uZ28uY2xpZW50LmNvbm5lY3QoKTtcbiAgfSk7XG5cbiAgcmV0dXJuIGRyaXZlcjtcbn0pO1xuIiwiLy8gb3B0aW9ucy5jb25uZWN0aW9uLCBpZiBnaXZlbiwgaXMgYSBMaXZlZGF0YUNsaWVudCBvciBMaXZlZGF0YVNlcnZlclxuLy8gWFhYIHByZXNlbnRseSB0aGVyZSBpcyBubyB3YXkgdG8gZGVzdHJveS9jbGVhbiB1cCBhIENvbGxlY3Rpb25cbmltcG9ydCB7XG4gIEFTWU5DX0NPTExFQ1RJT05fTUVUSE9EUyxcbiAgZ2V0QXN5bmNNZXRob2ROYW1lLFxufSBmcm9tICdtZXRlb3IvbWluaW1vbmdvL2NvbnN0YW50cyc7XG5cbmltcG9ydCB7IG5vcm1hbGl6ZVByb2plY3Rpb24gfSBmcm9tIFwiLi9tb25nb191dGlsc1wiO1xuXG4vKipcbiAqIEBzdW1tYXJ5IE5hbWVzcGFjZSBmb3IgTW9uZ29EQi1yZWxhdGVkIGl0ZW1zXG4gKiBAbmFtZXNwYWNlXG4gKi9cbk1vbmdvID0ge307XG5cbi8qKlxuICogQHN1bW1hcnkgQ29uc3RydWN0b3IgZm9yIGEgQ29sbGVjdGlvblxuICogQGxvY3VzIEFueXdoZXJlXG4gKiBAaW5zdGFuY2VuYW1lIGNvbGxlY3Rpb25cbiAqIEBjbGFzc1xuICogQHBhcmFtIHtTdHJpbmd9IG5hbWUgVGhlIG5hbWUgb2YgdGhlIGNvbGxlY3Rpb24uICBJZiBudWxsLCBjcmVhdGVzIGFuIHVubWFuYWdlZCAodW5zeW5jaHJvbml6ZWQpIGxvY2FsIGNvbGxlY3Rpb24uXG4gKiBAcGFyYW0ge09iamVjdH0gW29wdGlvbnNdXG4gKiBAcGFyYW0ge09iamVjdH0gb3B0aW9ucy5jb25uZWN0aW9uIFRoZSBzZXJ2ZXIgY29ubmVjdGlvbiB0aGF0IHdpbGwgbWFuYWdlIHRoaXMgY29sbGVjdGlvbi4gVXNlcyB0aGUgZGVmYXVsdCBjb25uZWN0aW9uIGlmIG5vdCBzcGVjaWZpZWQuICBQYXNzIHRoZSByZXR1cm4gdmFsdWUgb2YgY2FsbGluZyBbYEREUC5jb25uZWN0YF0oI0REUC1jb25uZWN0KSB0byBzcGVjaWZ5IGEgZGlmZmVyZW50IHNlcnZlci4gUGFzcyBgbnVsbGAgdG8gc3BlY2lmeSBubyBjb25uZWN0aW9uLiBVbm1hbmFnZWQgKGBuYW1lYCBpcyBudWxsKSBjb2xsZWN0aW9ucyBjYW5ub3Qgc3BlY2lmeSBhIGNvbm5lY3Rpb24uXG4gKiBAcGFyYW0ge1N0cmluZ30gb3B0aW9ucy5pZEdlbmVyYXRpb24gVGhlIG1ldGhvZCBvZiBnZW5lcmF0aW5nIHRoZSBgX2lkYCBmaWVsZHMgb2YgbmV3IGRvY3VtZW50cyBpbiB0aGlzIGNvbGxlY3Rpb24uICBQb3NzaWJsZSB2YWx1ZXM6XG5cbiAtICoqYCdTVFJJTkcnYCoqOiByYW5kb20gc3RyaW5nc1xuIC0gKipgJ01PTkdPJ2AqKjogIHJhbmRvbSBbYE1vbmdvLk9iamVjdElEYF0oI21vbmdvX29iamVjdF9pZCkgdmFsdWVzXG5cblRoZSBkZWZhdWx0IGlkIGdlbmVyYXRpb24gdGVjaG5pcXVlIGlzIGAnU1RSSU5HJ2AuXG4gKiBAcGFyYW0ge0Z1bmN0aW9ufSBvcHRpb25zLnRyYW5zZm9ybSBBbiBvcHRpb25hbCB0cmFuc2Zvcm1hdGlvbiBmdW5jdGlvbi4gRG9jdW1lbnRzIHdpbGwgYmUgcGFzc2VkIHRocm91Z2ggdGhpcyBmdW5jdGlvbiBiZWZvcmUgYmVpbmcgcmV0dXJuZWQgZnJvbSBgZmV0Y2hgIG9yIGBmaW5kT25lQXN5bmNgLCBhbmQgYmVmb3JlIGJlaW5nIHBhc3NlZCB0byBjYWxsYmFja3Mgb2YgYG9ic2VydmVgLCBgbWFwYCwgYGZvckVhY2hgLCBgYWxsb3dgLCBhbmQgYGRlbnlgLiBUcmFuc2Zvcm1zIGFyZSAqbm90KiBhcHBsaWVkIGZvciB0aGUgY2FsbGJhY2tzIG9mIGBvYnNlcnZlQ2hhbmdlc2Agb3IgdG8gY3Vyc29ycyByZXR1cm5lZCBmcm9tIHB1Ymxpc2ggZnVuY3Rpb25zLlxuICogQHBhcmFtIHtCb29sZWFufSBvcHRpb25zLmRlZmluZU11dGF0aW9uTWV0aG9kcyBTZXQgdG8gYGZhbHNlYCB0byBza2lwIHNldHRpbmcgdXAgdGhlIG11dGF0aW9uIG1ldGhvZHMgdGhhdCBlbmFibGUgaW5zZXJ0L3VwZGF0ZS9yZW1vdmUgZnJvbSBjbGllbnQgY29kZS4gRGVmYXVsdCBgdHJ1ZWAuXG4gKi9cbk1vbmdvLkNvbGxlY3Rpb24gPSBmdW5jdGlvbiBDb2xsZWN0aW9uKG5hbWUsIG9wdGlvbnMpIHtcbiAgaWYgKCFuYW1lICYmIG5hbWUgIT09IG51bGwpIHtcbiAgICBNZXRlb3IuX2RlYnVnKFxuICAgICAgJ1dhcm5pbmc6IGNyZWF0aW5nIGFub255bW91cyBjb2xsZWN0aW9uLiBJdCB3aWxsIG5vdCBiZSAnICtcbiAgICAgICAgJ3NhdmVkIG9yIHN5bmNocm9uaXplZCBvdmVyIHRoZSBuZXR3b3JrLiAoUGFzcyBudWxsIGZvciAnICtcbiAgICAgICAgJ3RoZSBjb2xsZWN0aW9uIG5hbWUgdG8gdHVybiBvZmYgdGhpcyB3YXJuaW5nLiknXG4gICAgKTtcbiAgICBuYW1lID0gbnVsbDtcbiAgfVxuXG4gIGlmIChuYW1lICE9PSBudWxsICYmIHR5cGVvZiBuYW1lICE9PSAnc3RyaW5nJykge1xuICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICdGaXJzdCBhcmd1bWVudCB0byBuZXcgTW9uZ28uQ29sbGVjdGlvbiBtdXN0IGJlIGEgc3RyaW5nIG9yIG51bGwnXG4gICAgKTtcbiAgfVxuXG4gIGlmIChvcHRpb25zICYmIG9wdGlvbnMubWV0aG9kcykge1xuICAgIC8vIEJhY2t3YXJkcyBjb21wYXRpYmlsaXR5IGhhY2sgd2l0aCBvcmlnaW5hbCBzaWduYXR1cmUgKHdoaWNoIHBhc3NlZFxuICAgIC8vIFwiY29ubmVjdGlvblwiIGRpcmVjdGx5IGluc3RlYWQgb2YgaW4gb3B0aW9ucy4gKENvbm5lY3Rpb25zIG11c3QgaGF2ZSBhIFwibWV0aG9kc1wiXG4gICAgLy8gbWV0aG9kLilcbiAgICAvLyBYWFggcmVtb3ZlIGJlZm9yZSAxLjBcbiAgICBvcHRpb25zID0geyBjb25uZWN0aW9uOiBvcHRpb25zIH07XG4gIH1cbiAgLy8gQmFja3dhcmRzIGNvbXBhdGliaWxpdHk6IFwiY29ubmVjdGlvblwiIHVzZWQgdG8gYmUgY2FsbGVkIFwibWFuYWdlclwiLlxuICBpZiAob3B0aW9ucyAmJiBvcHRpb25zLm1hbmFnZXIgJiYgIW9wdGlvbnMuY29ubmVjdGlvbikge1xuICAgIG9wdGlvbnMuY29ubmVjdGlvbiA9IG9wdGlvbnMubWFuYWdlcjtcbiAgfVxuXG4gIG9wdGlvbnMgPSB7XG4gICAgY29ubmVjdGlvbjogdW5kZWZpbmVkLFxuICAgIGlkR2VuZXJhdGlvbjogJ1NUUklORycsXG4gICAgdHJhbnNmb3JtOiBudWxsLFxuICAgIF9kcml2ZXI6IHVuZGVmaW5lZCxcbiAgICBfcHJldmVudEF1dG9wdWJsaXNoOiBmYWxzZSxcbiAgICAuLi5vcHRpb25zLFxuICB9O1xuXG4gIHN3aXRjaCAob3B0aW9ucy5pZEdlbmVyYXRpb24pIHtcbiAgICBjYXNlICdNT05HTyc6XG4gICAgICB0aGlzLl9tYWtlTmV3SUQgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgdmFyIHNyYyA9IG5hbWVcbiAgICAgICAgICA/IEREUC5yYW5kb21TdHJlYW0oJy9jb2xsZWN0aW9uLycgKyBuYW1lKVxuICAgICAgICAgIDogUmFuZG9tLmluc2VjdXJlO1xuICAgICAgICByZXR1cm4gbmV3IE1vbmdvLk9iamVjdElEKHNyYy5oZXhTdHJpbmcoMjQpKTtcbiAgICAgIH07XG4gICAgICBicmVhaztcbiAgICBjYXNlICdTVFJJTkcnOlxuICAgIGRlZmF1bHQ6XG4gICAgICB0aGlzLl9tYWtlTmV3SUQgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgdmFyIHNyYyA9IG5hbWVcbiAgICAgICAgICA/IEREUC5yYW5kb21TdHJlYW0oJy9jb2xsZWN0aW9uLycgKyBuYW1lKVxuICAgICAgICAgIDogUmFuZG9tLmluc2VjdXJlO1xuICAgICAgICByZXR1cm4gc3JjLmlkKCk7XG4gICAgICB9O1xuICAgICAgYnJlYWs7XG4gIH1cblxuICB0aGlzLl90cmFuc2Zvcm0gPSBMb2NhbENvbGxlY3Rpb24ud3JhcFRyYW5zZm9ybShvcHRpb25zLnRyYW5zZm9ybSk7XG5cbiAgdGhpcy5yZXNvbHZlclR5cGUgPSBvcHRpb25zLnJlc29sdmVyVHlwZTtcblxuICBpZiAoIW5hbWUgfHwgb3B0aW9ucy5jb25uZWN0aW9uID09PSBudWxsKVxuICAgIC8vIG5vdGU6IG5hbWVsZXNzIGNvbGxlY3Rpb25zIG5ldmVyIGhhdmUgYSBjb25uZWN0aW9uXG4gICAgdGhpcy5fY29ubmVjdGlvbiA9IG51bGw7XG4gIGVsc2UgaWYgKG9wdGlvbnMuY29ubmVjdGlvbikgdGhpcy5fY29ubmVjdGlvbiA9IG9wdGlvbnMuY29ubmVjdGlvbjtcbiAgZWxzZSBpZiAoTWV0ZW9yLmlzQ2xpZW50KSB0aGlzLl9jb25uZWN0aW9uID0gTWV0ZW9yLmNvbm5lY3Rpb247XG4gIGVsc2UgdGhpcy5fY29ubmVjdGlvbiA9IE1ldGVvci5zZXJ2ZXI7XG5cbiAgaWYgKCFvcHRpb25zLl9kcml2ZXIpIHtcbiAgICAvLyBYWFggVGhpcyBjaGVjayBhc3N1bWVzIHRoYXQgd2ViYXBwIGlzIGxvYWRlZCBzbyB0aGF0IE1ldGVvci5zZXJ2ZXIgIT09XG4gICAgLy8gbnVsbC4gV2Ugc2hvdWxkIGZ1bGx5IHN1cHBvcnQgdGhlIGNhc2Ugb2YgXCJ3YW50IHRvIHVzZSBhIE1vbmdvLWJhY2tlZFxuICAgIC8vIGNvbGxlY3Rpb24gZnJvbSBOb2RlIGNvZGUgd2l0aG91dCB3ZWJhcHBcIiwgYnV0IHdlIGRvbid0IHlldC5cbiAgICAvLyAjTWV0ZW9yU2VydmVyTnVsbFxuICAgIGlmIChcbiAgICAgIG5hbWUgJiZcbiAgICAgIHRoaXMuX2Nvbm5lY3Rpb24gPT09IE1ldGVvci5zZXJ2ZXIgJiZcbiAgICAgIHR5cGVvZiBNb25nb0ludGVybmFscyAhPT0gJ3VuZGVmaW5lZCcgJiZcbiAgICAgIE1vbmdvSW50ZXJuYWxzLmRlZmF1bHRSZW1vdGVDb2xsZWN0aW9uRHJpdmVyXG4gICAgKSB7XG4gICAgICBvcHRpb25zLl9kcml2ZXIgPSBNb25nb0ludGVybmFscy5kZWZhdWx0UmVtb3RlQ29sbGVjdGlvbkRyaXZlcigpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCB7IExvY2FsQ29sbGVjdGlvbkRyaXZlciB9ID0gcmVxdWlyZSgnLi9sb2NhbF9jb2xsZWN0aW9uX2RyaXZlci5qcycpO1xuICAgICAgb3B0aW9ucy5fZHJpdmVyID0gTG9jYWxDb2xsZWN0aW9uRHJpdmVyO1xuICAgIH1cbiAgfVxuXG4gIHRoaXMuX2NvbGxlY3Rpb24gPSBvcHRpb25zLl9kcml2ZXIub3BlbihuYW1lLCB0aGlzLl9jb25uZWN0aW9uKTtcbiAgdGhpcy5fbmFtZSA9IG5hbWU7XG4gIHRoaXMuX2RyaXZlciA9IG9wdGlvbnMuX2RyaXZlcjtcblxuICAvLyBUT0RPW2ZpYmVyc106IF9tYXliZVNldFVwUmVwbGljYXRpb24gaXMgbm93IGFzeW5jLiBMZXQncyB3YXRjaCBob3cgbm90IHdhaXRpbmcgZm9yIHRoaXMgZnVuY3Rpb24gdG8gZmluaXNoXG4gICAgLy8gd2lsbCBhZmZlY3QgZXZlcnl0aGluZ1xuICB0aGlzLl9zZXR0aW5nVXBSZXBsaWNhdGlvblByb21pc2UgPSB0aGlzLl9tYXliZVNldFVwUmVwbGljYXRpb24obmFtZSwgb3B0aW9ucyk7XG5cbiAgLy8gWFhYIGRvbid0IGRlZmluZSB0aGVzZSB1bnRpbCBhbGxvdyBvciBkZW55IGlzIGFjdHVhbGx5IHVzZWQgZm9yIHRoaXNcbiAgLy8gY29sbGVjdGlvbi4gQ291bGQgYmUgaGFyZCBpZiB0aGUgc2VjdXJpdHkgcnVsZXMgYXJlIG9ubHkgZGVmaW5lZCBvbiB0aGVcbiAgLy8gc2VydmVyLlxuICBpZiAob3B0aW9ucy5kZWZpbmVNdXRhdGlvbk1ldGhvZHMgIT09IGZhbHNlKSB7XG4gICAgdHJ5IHtcbiAgICAgIHRoaXMuX2RlZmluZU11dGF0aW9uTWV0aG9kcyh7XG4gICAgICAgIHVzZUV4aXN0aW5nOiBvcHRpb25zLl9zdXBwcmVzc1NhbWVOYW1lRXJyb3IgPT09IHRydWUsXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgLy8gVGhyb3cgYSBtb3JlIHVuZGVyc3RhbmRhYmxlIGVycm9yIG9uIHRoZSBzZXJ2ZXIgZm9yIHNhbWUgY29sbGVjdGlvbiBuYW1lXG4gICAgICBpZiAoXG4gICAgICAgIGVycm9yLm1lc3NhZ2UgPT09IGBBIG1ldGhvZCBuYW1lZCAnLyR7bmFtZX0vaW5zZXJ0QXN5bmMnIGlzIGFscmVhZHkgZGVmaW5lZGBcbiAgICAgIClcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBUaGVyZSBpcyBhbHJlYWR5IGEgY29sbGVjdGlvbiBuYW1lZCBcIiR7bmFtZX1cImApO1xuICAgICAgdGhyb3cgZXJyb3I7XG4gICAgfVxuICB9XG5cbiAgLy8gYXV0b3B1Ymxpc2hcbiAgaWYgKFxuICAgIFBhY2thZ2UuYXV0b3B1Ymxpc2ggJiZcbiAgICAhb3B0aW9ucy5fcHJldmVudEF1dG9wdWJsaXNoICYmXG4gICAgdGhpcy5fY29ubmVjdGlvbiAmJlxuICAgIHRoaXMuX2Nvbm5lY3Rpb24ucHVibGlzaFxuICApIHtcbiAgICB0aGlzLl9jb25uZWN0aW9uLnB1Ymxpc2gobnVsbCwgKCkgPT4gdGhpcy5maW5kKCksIHtcbiAgICAgIGlzX2F1dG86IHRydWUsXG4gICAgfSk7XG4gIH1cbn07XG5cbk9iamVjdC5hc3NpZ24oTW9uZ28uQ29sbGVjdGlvbi5wcm90b3R5cGUsIHtcbiAgYXN5bmMgX21heWJlU2V0VXBSZXBsaWNhdGlvbihuYW1lKSB7XG4gICAgY29uc3Qgc2VsZiA9IHRoaXM7XG4gICAgaWYgKFxuICAgICAgIShcbiAgICAgICAgc2VsZi5fY29ubmVjdGlvbiAmJlxuICAgICAgICBzZWxmLl9jb25uZWN0aW9uLnJlZ2lzdGVyU3RvcmVDbGllbnQgJiZcbiAgICAgICAgc2VsZi5fY29ubmVjdGlvbi5yZWdpc3RlclN0b3JlU2VydmVyXG4gICAgICApXG4gICAgKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG5cbiAgICBjb25zdCB3cmFwcGVkU3RvcmVDb21tb24gPSB7XG4gICAgICAvLyBDYWxsZWQgYXJvdW5kIG1ldGhvZCBzdHViIGludm9jYXRpb25zIHRvIGNhcHR1cmUgdGhlIG9yaWdpbmFsIHZlcnNpb25zXG4gICAgICAvLyBvZiBtb2RpZmllZCBkb2N1bWVudHMuXG4gICAgICBzYXZlT3JpZ2luYWxzKCkge1xuICAgICAgICBzZWxmLl9jb2xsZWN0aW9uLnNhdmVPcmlnaW5hbHMoKTtcbiAgICAgIH0sXG4gICAgICByZXRyaWV2ZU9yaWdpbmFscygpIHtcbiAgICAgICAgcmV0dXJuIHNlbGYuX2NvbGxlY3Rpb24ucmV0cmlldmVPcmlnaW5hbHMoKTtcbiAgICAgIH0sXG4gICAgICAvLyBUbyBiZSBhYmxlIHRvIGdldCBiYWNrIHRvIHRoZSBjb2xsZWN0aW9uIGZyb20gdGhlIHN0b3JlLlxuICAgICAgX2dldENvbGxlY3Rpb24oKSB7XG4gICAgICAgIHJldHVybiBzZWxmO1xuICAgICAgfSxcbiAgICB9O1xuICAgIGNvbnN0IHdyYXBwZWRTdG9yZUNsaWVudCA9IHtcbiAgICAgIC8vIENhbGxlZCBhdCB0aGUgYmVnaW5uaW5nIG9mIGEgYmF0Y2ggb2YgdXBkYXRlcy4gYmF0Y2hTaXplIGlzIHRoZSBudW1iZXJcbiAgICAgIC8vIG9mIHVwZGF0ZSBjYWxscyB0byBleHBlY3QuXG4gICAgICAvL1xuICAgICAgLy8gWFhYIFRoaXMgaW50ZXJmYWNlIGlzIHByZXR0eSBqYW5reS4gcmVzZXQgcHJvYmFibHkgb3VnaHQgdG8gZ28gYmFjayB0b1xuICAgICAgLy8gYmVpbmcgaXRzIG93biBmdW5jdGlvbiwgYW5kIGNhbGxlcnMgc2hvdWxkbid0IGhhdmUgdG8gY2FsY3VsYXRlXG4gICAgICAvLyBiYXRjaFNpemUuIFRoZSBvcHRpbWl6YXRpb24gb2Ygbm90IGNhbGxpbmcgcGF1c2UvcmVtb3ZlIHNob3VsZCBiZVxuICAgICAgLy8gZGVsYXllZCB1bnRpbCBsYXRlcjogdGhlIGZpcnN0IGNhbGwgdG8gdXBkYXRlKCkgc2hvdWxkIGJ1ZmZlciBpdHNcbiAgICAgIC8vIG1lc3NhZ2UsIGFuZCB0aGVuIHdlIGNhbiBlaXRoZXIgZGlyZWN0bHkgYXBwbHkgaXQgYXQgZW5kVXBkYXRlIHRpbWUgaWZcbiAgICAgIC8vIGl0IHdhcyB0aGUgb25seSB1cGRhdGUsIG9yIGRvIHBhdXNlT2JzZXJ2ZXJzL2FwcGx5L2FwcGx5IGF0IHRoZSBuZXh0XG4gICAgICAvLyB1cGRhdGUoKSBpZiB0aGVyZSdzIGFub3RoZXIgb25lLlxuICAgICAgYXN5bmMgYmVnaW5VcGRhdGUoYmF0Y2hTaXplLCByZXNldCkge1xuICAgICAgICAvLyBwYXVzZSBvYnNlcnZlcnMgc28gdXNlcnMgZG9uJ3Qgc2VlIGZsaWNrZXIgd2hlbiB1cGRhdGluZyBzZXZlcmFsXG4gICAgICAgIC8vIG9iamVjdHMgYXQgb25jZSAoaW5jbHVkaW5nIHRoZSBwb3N0LXJlY29ubmVjdCByZXNldC1hbmQtcmVhcHBseVxuICAgICAgICAvLyBzdGFnZSksIGFuZCBzbyB0aGF0IGEgcmUtc29ydGluZyBvZiBhIHF1ZXJ5IGNhbiB0YWtlIGFkdmFudGFnZSBvZiB0aGVcbiAgICAgICAgLy8gZnVsbCBfZGlmZlF1ZXJ5IG1vdmVkIGNhbGN1bGF0aW9uIGluc3RlYWQgb2YgYXBwbHlpbmcgY2hhbmdlIG9uZSBhdCBhXG4gICAgICAgIC8vIHRpbWUuXG4gICAgICAgIGlmIChiYXRjaFNpemUgPiAxIHx8IHJlc2V0KSBzZWxmLl9jb2xsZWN0aW9uLnBhdXNlT2JzZXJ2ZXJzKCk7XG5cbiAgICAgICAgaWYgKHJlc2V0KSBhd2FpdCBzZWxmLl9jb2xsZWN0aW9uLnJlbW92ZSh7fSk7XG4gICAgICB9LFxuXG4gICAgICAvLyBBcHBseSBhbiB1cGRhdGUuXG4gICAgICAvLyBYWFggYmV0dGVyIHNwZWNpZnkgdGhpcyBpbnRlcmZhY2UgKG5vdCBpbiB0ZXJtcyBvZiBhIHdpcmUgbWVzc2FnZSk/XG4gICAgICB1cGRhdGUobXNnKSB7XG4gICAgICAgIHZhciBtb25nb0lkID0gTW9uZ29JRC5pZFBhcnNlKG1zZy5pZCk7XG4gICAgICAgIHZhciBkb2MgPSBzZWxmLl9jb2xsZWN0aW9uLl9kb2NzLmdldChtb25nb0lkKTtcblxuICAgICAgICAvL1doZW4gdGhlIHNlcnZlcidzIG1lcmdlYm94IGlzIGRpc2FibGVkIGZvciBhIGNvbGxlY3Rpb24sIHRoZSBjbGllbnQgbXVzdCBncmFjZWZ1bGx5IGhhbmRsZSBpdCB3aGVuOlxuICAgICAgICAvLyAqV2UgcmVjZWl2ZSBhbiBhZGRlZCBtZXNzYWdlIGZvciBhIGRvY3VtZW50IHRoYXQgaXMgYWxyZWFkeSB0aGVyZS4gSW5zdGVhZCwgaXQgd2lsbCBiZSBjaGFuZ2VkXG4gICAgICAgIC8vICpXZSByZWVpdmUgYSBjaGFuZ2UgbWVzc2FnZSBmb3IgYSBkb2N1bWVudCB0aGF0IGlzIG5vdCB0aGVyZS4gSW5zdGVhZCwgaXQgd2lsbCBiZSBhZGRlZFxuICAgICAgICAvLyAqV2UgcmVjZWl2ZSBhIHJlbW92ZWQgbWVzc3NhZ2UgZm9yIGEgZG9jdW1lbnQgdGhhdCBpcyBub3QgdGhlcmUuIEluc3RlYWQsIG5vdGluZyB3aWwgaGFwcGVuLlxuXG4gICAgICAgIC8vQ29kZSBpcyBkZXJpdmVkIGZyb20gY2xpZW50LXNpZGUgY29kZSBvcmlnaW5hbGx5IGluIHBlZXJsaWJyYXJ5OmNvbnRyb2wtbWVyZ2Vib3hcbiAgICAgICAgLy9odHRwczovL2dpdGh1Yi5jb20vcGVlcmxpYnJhcnkvbWV0ZW9yLWNvbnRyb2wtbWVyZ2Vib3gvYmxvYi9tYXN0ZXIvY2xpZW50LmNvZmZlZVxuXG4gICAgICAgIC8vRm9yIG1vcmUgaW5mb3JtYXRpb24sIHJlZmVyIHRvIGRpc2N1c3Npb24gXCJJbml0aWFsIHN1cHBvcnQgZm9yIHB1YmxpY2F0aW9uIHN0cmF0ZWdpZXMgaW4gbGl2ZWRhdGEgc2VydmVyXCI6XG4gICAgICAgIC8vaHR0cHM6Ly9naXRodWIuY29tL21ldGVvci9tZXRlb3IvcHVsbC8xMTE1MVxuICAgICAgICBpZiAoTWV0ZW9yLmlzQ2xpZW50KSB7XG4gICAgICAgICAgaWYgKG1zZy5tc2cgPT09ICdhZGRlZCcgJiYgZG9jKSB7XG4gICAgICAgICAgICBtc2cubXNnID0gJ2NoYW5nZWQnO1xuICAgICAgICAgIH0gZWxzZSBpZiAobXNnLm1zZyA9PT0gJ3JlbW92ZWQnICYmICFkb2MpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICB9IGVsc2UgaWYgKG1zZy5tc2cgPT09ICdjaGFuZ2VkJyAmJiAhZG9jKSB7XG4gICAgICAgICAgICBtc2cubXNnID0gJ2FkZGVkJztcbiAgICAgICAgICAgIGNvbnN0IF9yZWYgPSBtc2cuZmllbGRzO1xuICAgICAgICAgICAgZm9yIChsZXQgZmllbGQgaW4gX3JlZikge1xuICAgICAgICAgICAgICBjb25zdCB2YWx1ZSA9IF9yZWZbZmllbGRdO1xuICAgICAgICAgICAgICBpZiAodmFsdWUgPT09IHZvaWQgMCkge1xuICAgICAgICAgICAgICAgIGRlbGV0ZSBtc2cuZmllbGRzW2ZpZWxkXTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICAvLyBJcyB0aGlzIGEgXCJyZXBsYWNlIHRoZSB3aG9sZSBkb2NcIiBtZXNzYWdlIGNvbWluZyBmcm9tIHRoZSBxdWllc2NlbmNlXG4gICAgICAgIC8vIG9mIG1ldGhvZCB3cml0ZXMgdG8gYW4gb2JqZWN0PyAoTm90ZSB0aGF0ICd1bmRlZmluZWQnIGlzIGEgdmFsaWRcbiAgICAgICAgLy8gdmFsdWUgbWVhbmluZyBcInJlbW92ZSBpdFwiLilcbiAgICAgICAgaWYgKG1zZy5tc2cgPT09ICdyZXBsYWNlJykge1xuICAgICAgICAgIHZhciByZXBsYWNlID0gbXNnLnJlcGxhY2U7XG4gICAgICAgICAgaWYgKCFyZXBsYWNlKSB7XG4gICAgICAgICAgICBpZiAoZG9jKSBzZWxmLl9jb2xsZWN0aW9uLnJlbW92ZShtb25nb0lkKTtcbiAgICAgICAgICB9IGVsc2UgaWYgKCFkb2MpIHtcbiAgICAgICAgICAgIHNlbGYuX2NvbGxlY3Rpb24uaW5zZXJ0KHJlcGxhY2UpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAvLyBYWFggY2hlY2sgdGhhdCByZXBsYWNlIGhhcyBubyAkIG9wc1xuICAgICAgICAgICAgc2VsZi5fY29sbGVjdGlvbi51cGRhdGUobW9uZ29JZCwgcmVwbGFjZSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfSBlbHNlIGlmIChtc2cubXNnID09PSAnYWRkZWQnKSB7XG4gICAgICAgICAgaWYgKGRvYykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAgICAgICAnRXhwZWN0ZWQgbm90IHRvIGZpbmQgYSBkb2N1bWVudCBhbHJlYWR5IHByZXNlbnQgZm9yIGFuIGFkZCdcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHNlbGYuX2NvbGxlY3Rpb24uaW5zZXJ0KHsgX2lkOiBtb25nb0lkLCAuLi5tc2cuZmllbGRzIH0pO1xuICAgICAgICB9IGVsc2UgaWYgKG1zZy5tc2cgPT09ICdyZW1vdmVkJykge1xuICAgICAgICAgIGlmICghZG9jKVxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAgICAgICAnRXhwZWN0ZWQgdG8gZmluZCBhIGRvY3VtZW50IGFscmVhZHkgcHJlc2VudCBmb3IgcmVtb3ZlZCdcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgc2VsZi5fY29sbGVjdGlvbi5yZW1vdmUobW9uZ29JZCk7XG4gICAgICAgIH0gZWxzZSBpZiAobXNnLm1zZyA9PT0gJ2NoYW5nZWQnKSB7XG4gICAgICAgICAgaWYgKCFkb2MpIHRocm93IG5ldyBFcnJvcignRXhwZWN0ZWQgdG8gZmluZCBhIGRvY3VtZW50IHRvIGNoYW5nZScpO1xuICAgICAgICAgIGNvbnN0IGtleXMgPSBPYmplY3Qua2V5cyhtc2cuZmllbGRzKTtcbiAgICAgICAgICBpZiAoa2V5cy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICB2YXIgbW9kaWZpZXIgPSB7fTtcbiAgICAgICAgICAgIGtleXMuZm9yRWFjaChrZXkgPT4ge1xuICAgICAgICAgICAgICBjb25zdCB2YWx1ZSA9IG1zZy5maWVsZHNba2V5XTtcbiAgICAgICAgICAgICAgaWYgKEVKU09OLmVxdWFscyhkb2Nba2V5XSwgdmFsdWUpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGlmICh0eXBlb2YgdmFsdWUgPT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgICAgICAgICAgaWYgKCFtb2RpZmllci4kdW5zZXQpIHtcbiAgICAgICAgICAgICAgICAgIG1vZGlmaWVyLiR1bnNldCA9IHt9O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBtb2RpZmllci4kdW5zZXRba2V5XSA9IDE7XG4gICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgaWYgKCFtb2RpZmllci4kc2V0KSB7XG4gICAgICAgICAgICAgICAgICBtb2RpZmllci4kc2V0ID0ge307XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIG1vZGlmaWVyLiRzZXRba2V5XSA9IHZhbHVlO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGlmIChPYmplY3Qua2V5cyhtb2RpZmllcikubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICBzZWxmLl9jb2xsZWN0aW9uLnVwZGF0ZShtb25nb0lkLCBtb2RpZmllcik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcIkkgZG9uJ3Qga25vdyBob3cgdG8gZGVhbCB3aXRoIHRoaXMgbWVzc2FnZVwiKTtcbiAgICAgICAgfVxuICAgICAgfSxcblxuICAgICAgLy8gQ2FsbGVkIGF0IHRoZSBlbmQgb2YgYSBiYXRjaCBvZiB1cGRhdGVzLmxpdmVkYXRhX2Nvbm5lY3Rpb24uanM6MTI4N1xuICAgICAgZW5kVXBkYXRlKCkge1xuICAgICAgICBzZWxmLl9jb2xsZWN0aW9uLnJlc3VtZU9ic2VydmVyc0NsaWVudCgpO1xuICAgICAgfSxcblxuICAgICAgLy8gVXNlZCB0byBwcmVzZXJ2ZSBjdXJyZW50IHZlcnNpb25zIG9mIGRvY3VtZW50cyBhY3Jvc3MgYSBzdG9yZSByZXNldC5cbiAgICAgIGdldERvYyhpZCkge1xuICAgICAgICByZXR1cm4gc2VsZi5maW5kT25lKGlkKTtcbiAgICAgIH0sXG5cbiAgICAgIC4uLndyYXBwZWRTdG9yZUNvbW1vbixcbiAgICB9O1xuICAgIGNvbnN0IHdyYXBwZWRTdG9yZVNlcnZlciA9IHtcbiAgICAgIGFzeW5jIGJlZ2luVXBkYXRlKGJhdGNoU2l6ZSwgcmVzZXQpIHtcbiAgICAgICAgaWYgKGJhdGNoU2l6ZSA+IDEgfHwgcmVzZXQpIHNlbGYuX2NvbGxlY3Rpb24ucGF1c2VPYnNlcnZlcnMoKTtcblxuICAgICAgICBpZiAocmVzZXQpIGF3YWl0IHNlbGYuX2NvbGxlY3Rpb24ucmVtb3ZlQXN5bmMoe30pO1xuICAgICAgfSxcblxuICAgICAgYXN5bmMgdXBkYXRlKG1zZykge1xuICAgICAgICB2YXIgbW9uZ29JZCA9IE1vbmdvSUQuaWRQYXJzZShtc2cuaWQpO1xuICAgICAgICB2YXIgZG9jID0gc2VsZi5fY29sbGVjdGlvbi5fZG9jcy5nZXQobW9uZ29JZCk7XG5cbiAgICAgICAgLy8gSXMgdGhpcyBhIFwicmVwbGFjZSB0aGUgd2hvbGUgZG9jXCIgbWVzc2FnZSBjb21pbmcgZnJvbSB0aGUgcXVpZXNjZW5jZVxuICAgICAgICAvLyBvZiBtZXRob2Qgd3JpdGVzIHRvIGFuIG9iamVjdD8gKE5vdGUgdGhhdCAndW5kZWZpbmVkJyBpcyBhIHZhbGlkXG4gICAgICAgIC8vIHZhbHVlIG1lYW5pbmcgXCJyZW1vdmUgaXRcIi4pXG4gICAgICAgIGlmIChtc2cubXNnID09PSAncmVwbGFjZScpIHtcbiAgICAgICAgICB2YXIgcmVwbGFjZSA9IG1zZy5yZXBsYWNlO1xuICAgICAgICAgIGlmICghcmVwbGFjZSkge1xuICAgICAgICAgICAgaWYgKGRvYykgYXdhaXQgc2VsZi5fY29sbGVjdGlvbi5yZW1vdmVBc3luYyhtb25nb0lkKTtcbiAgICAgICAgICB9IGVsc2UgaWYgKCFkb2MpIHtcbiAgICAgICAgICAgIGF3YWl0IHNlbGYuX2NvbGxlY3Rpb24uaW5zZXJ0QXN5bmMocmVwbGFjZSk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIC8vIFhYWCBjaGVjayB0aGF0IHJlcGxhY2UgaGFzIG5vICQgb3BzXG4gICAgICAgICAgICBhd2FpdCBzZWxmLl9jb2xsZWN0aW9uLnVwZGF0ZUFzeW5jKG1vbmdvSWQsIHJlcGxhY2UpO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH0gZWxzZSBpZiAobXNnLm1zZyA9PT0gJ2FkZGVkJykge1xuICAgICAgICAgIGlmIChkb2MpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgICAgICAgJ0V4cGVjdGVkIG5vdCB0byBmaW5kIGEgZG9jdW1lbnQgYWxyZWFkeSBwcmVzZW50IGZvciBhbiBhZGQnXG4gICAgICAgICAgICApO1xuICAgICAgICAgIH1cbiAgICAgICAgICBhd2FpdCBzZWxmLl9jb2xsZWN0aW9uLmluc2VydEFzeW5jKHsgX2lkOiBtb25nb0lkLCAuLi5tc2cuZmllbGRzIH0pO1xuICAgICAgICB9IGVsc2UgaWYgKG1zZy5tc2cgPT09ICdyZW1vdmVkJykge1xuICAgICAgICAgIGlmICghZG9jKVxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAgICAgICAnRXhwZWN0ZWQgdG8gZmluZCBhIGRvY3VtZW50IGFscmVhZHkgcHJlc2VudCBmb3IgcmVtb3ZlZCdcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgYXdhaXQgc2VsZi5fY29sbGVjdGlvbi5yZW1vdmVBc3luYyhtb25nb0lkKTtcbiAgICAgICAgfSBlbHNlIGlmIChtc2cubXNnID09PSAnY2hhbmdlZCcpIHtcbiAgICAgICAgICBpZiAoIWRvYykgdGhyb3cgbmV3IEVycm9yKCdFeHBlY3RlZCB0byBmaW5kIGEgZG9jdW1lbnQgdG8gY2hhbmdlJyk7XG4gICAgICAgICAgY29uc3Qga2V5cyA9IE9iamVjdC5rZXlzKG1zZy5maWVsZHMpO1xuICAgICAgICAgIGlmIChrZXlzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIHZhciBtb2RpZmllciA9IHt9O1xuICAgICAgICAgICAga2V5cy5mb3JFYWNoKGtleSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IHZhbHVlID0gbXNnLmZpZWxkc1trZXldO1xuICAgICAgICAgICAgICBpZiAoRUpTT04uZXF1YWxzKGRvY1trZXldLCB2YWx1ZSkpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgICAgICAgICBpZiAoIW1vZGlmaWVyLiR1bnNldCkge1xuICAgICAgICAgICAgICAgICAgbW9kaWZpZXIuJHVuc2V0ID0ge307XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIG1vZGlmaWVyLiR1bnNldFtrZXldID0gMTtcbiAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBpZiAoIW1vZGlmaWVyLiRzZXQpIHtcbiAgICAgICAgICAgICAgICAgIG1vZGlmaWVyLiRzZXQgPSB7fTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgbW9kaWZpZXIuJHNldFtrZXldID0gdmFsdWU7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgaWYgKE9iamVjdC5rZXlzKG1vZGlmaWVyKS5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgIGF3YWl0IHNlbGYuX2NvbGxlY3Rpb24udXBkYXRlQXN5bmMobW9uZ29JZCwgbW9kaWZpZXIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJJIGRvbid0IGtub3cgaG93IHRvIGRlYWwgd2l0aCB0aGlzIG1lc3NhZ2VcIik7XG4gICAgICAgIH1cbiAgICAgIH0sXG5cbiAgICAgIC8vIENhbGxlZCBhdCB0aGUgZW5kIG9mIGEgYmF0Y2ggb2YgdXBkYXRlcy5cbiAgICAgIGFzeW5jIGVuZFVwZGF0ZSgpIHtcbiAgICAgICAgYXdhaXQgc2VsZi5fY29sbGVjdGlvbi5yZXN1bWVPYnNlcnZlcnNTZXJ2ZXIoKTtcbiAgICAgIH0sXG5cbiAgICAgIC8vIFVzZWQgdG8gcHJlc2VydmUgY3VycmVudCB2ZXJzaW9ucyBvZiBkb2N1bWVudHMgYWNyb3NzIGEgc3RvcmUgcmVzZXQuXG4gICAgICBhc3luYyBnZXREb2MoaWQpIHtcbiAgICAgICAgcmV0dXJuIHNlbGYuZmluZE9uZUFzeW5jKGlkKTtcbiAgICAgIH0sXG4gICAgICAuLi53cmFwcGVkU3RvcmVDb21tb24sXG4gICAgfTtcblxuXG4gICAgLy8gT0ssIHdlJ3JlIGdvaW5nIHRvIGJlIGEgc2xhdmUsIHJlcGxpY2F0aW5nIHNvbWUgcmVtb3RlXG4gICAgLy8gZGF0YWJhc2UsIGV4Y2VwdCBwb3NzaWJseSB3aXRoIHNvbWUgdGVtcG9yYXJ5IGRpdmVyZ2VuY2Ugd2hpbGVcbiAgICAvLyB3ZSBoYXZlIHVuYWNrbm93bGVkZ2VkIFJQQydzLlxuICAgIGxldCByZWdpc3RlclN0b3JlUmVzdWx0O1xuICAgIGlmIChNZXRlb3IuaXNDbGllbnQpIHtcbiAgICAgIHJlZ2lzdGVyU3RvcmVSZXN1bHQgPSBzZWxmLl9jb25uZWN0aW9uLnJlZ2lzdGVyU3RvcmVDbGllbnQoXG4gICAgICAgIG5hbWUsXG4gICAgICAgIHdyYXBwZWRTdG9yZUNsaWVudFxuICAgICAgKTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmVnaXN0ZXJTdG9yZVJlc3VsdCA9IHNlbGYuX2Nvbm5lY3Rpb24ucmVnaXN0ZXJTdG9yZVNlcnZlcihcbiAgICAgICAgbmFtZSxcbiAgICAgICAgd3JhcHBlZFN0b3JlU2VydmVyXG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnN0IG1lc3NhZ2UgPSBgVGhlcmUgaXMgYWxyZWFkeSBhIGNvbGxlY3Rpb24gbmFtZWQgXCIke25hbWV9XCJgO1xuICAgIGNvbnN0IGxvZ1dhcm4gPSAoKSA9PiB7XG4gICAgICBjb25zb2xlLndhcm4gPyBjb25zb2xlLndhcm4obWVzc2FnZSkgOiBjb25zb2xlLmxvZyhtZXNzYWdlKTtcbiAgICB9O1xuXG4gICAgaWYgKCFyZWdpc3RlclN0b3JlUmVzdWx0KSB7XG4gICAgICByZXR1cm4gbG9nV2FybigpO1xuICAgIH1cblxuICAgIHJldHVybiByZWdpc3RlclN0b3JlUmVzdWx0Py50aGVuPy4ob2sgPT4ge1xuICAgICAgaWYgKCFvaykge1xuICAgICAgICBsb2dXYXJuKCk7XG4gICAgICB9XG4gICAgfSk7XG4gIH0sXG5cbiAgLy8vXG4gIC8vLyBNYWluIGNvbGxlY3Rpb24gQVBJXG4gIC8vL1xuICAvKipcbiAgICogQHN1bW1hcnkgR2V0cyB0aGUgbnVtYmVyIG9mIGRvY3VtZW50cyBtYXRjaGluZyB0aGUgZmlsdGVyLiBGb3IgYSBmYXN0IGNvdW50IG9mIHRoZSB0b3RhbCBkb2N1bWVudHMgaW4gYSBjb2xsZWN0aW9uIHNlZSBgZXN0aW1hdGVkRG9jdW1lbnRDb3VudGAuXG4gICAqIEBsb2N1cyBBbnl3aGVyZVxuICAgKiBAbWV0aG9kIGNvdW50RG9jdW1lbnRzXG4gICAqIEBtZW1iZXJvZiBNb25nby5Db2xsZWN0aW9uXG4gICAqIEBpbnN0YW5jZVxuICAgKiBAcGFyYW0ge01vbmdvU2VsZWN0b3J9IFtzZWxlY3Rvcl0gQSBxdWVyeSBkZXNjcmliaW5nIHRoZSBkb2N1bWVudHMgdG8gY291bnRcbiAgICogQHBhcmFtIHtPYmplY3R9IFtvcHRpb25zXSBBbGwgb3B0aW9ucyBhcmUgbGlzdGVkIGluIFtNb25nb0RCIGRvY3VtZW50YXRpb25dKGh0dHBzOi8vbW9uZ29kYi5naXRodWIuaW8vbm9kZS1tb25nb2RiLW5hdGl2ZS80LjExL2ludGVyZmFjZXMvQ291bnREb2N1bWVudHNPcHRpb25zLmh0bWwpLiBQbGVhc2Ugbm90ZSB0aGF0IG5vdCBhbGwgb2YgdGhlbSBhcmUgYXZhaWxhYmxlIG9uIHRoZSBjbGllbnQuXG4gICAqIEByZXR1cm5zIHtQcm9taXNlPG51bWJlcj59XG4gICAqL1xuICBjb3VudERvY3VtZW50cyguLi5hcmdzKSB7XG4gICAgcmV0dXJuIHRoaXMuX2NvbGxlY3Rpb24uY291bnREb2N1bWVudHMoLi4uYXJncyk7XG4gIH0sXG5cbiAgLyoqXG4gICAqIEBzdW1tYXJ5IEdldHMgYW4gZXN0aW1hdGUgb2YgdGhlIGNvdW50IG9mIGRvY3VtZW50cyBpbiBhIGNvbGxlY3Rpb24gdXNpbmcgY29sbGVjdGlvbiBtZXRhZGF0YS4gRm9yIGFuIGV4YWN0IGNvdW50IG9mIHRoZSBkb2N1bWVudHMgaW4gYSBjb2xsZWN0aW9uIHNlZSBgY291bnREb2N1bWVudHNgLlxuICAgKiBAbG9jdXMgQW55d2hlcmVcbiAgICogQG1ldGhvZCBlc3RpbWF0ZWREb2N1bWVudENvdW50XG4gICAqIEBtZW1iZXJvZiBNb25nby5Db2xsZWN0aW9uXG4gICAqIEBpbnN0YW5jZVxuICAgKiBAcGFyYW0ge09iamVjdH0gW29wdGlvbnNdIEFsbCBvcHRpb25zIGFyZSBsaXN0ZWQgaW4gW01vbmdvREIgZG9jdW1lbnRhdGlvbl0oaHR0cHM6Ly9tb25nb2RiLmdpdGh1Yi5pby9ub2RlLW1vbmdvZGItbmF0aXZlLzQuMTEvaW50ZXJmYWNlcy9Fc3RpbWF0ZWREb2N1bWVudENvdW50T3B0aW9ucy5odG1sKS4gUGxlYXNlIG5vdGUgdGhhdCBub3QgYWxsIG9mIHRoZW0gYXJlIGF2YWlsYWJsZSBvbiB0aGUgY2xpZW50LlxuICAgKiBAcmV0dXJucyB7UHJvbWlzZTxudW1iZXI+fVxuICAgKi9cbiAgZXN0aW1hdGVkRG9jdW1lbnRDb3VudCguLi5hcmdzKSB7XG4gICAgcmV0dXJuIHRoaXMuX2NvbGxlY3Rpb24uZXN0aW1hdGVkRG9jdW1lbnRDb3VudCguLi5hcmdzKTtcbiAgfSxcblxuICBfZ2V0RmluZFNlbGVjdG9yKGFyZ3MpIHtcbiAgICBpZiAoYXJncy5sZW5ndGggPT0gMCkgcmV0dXJuIHt9O1xuICAgIGVsc2UgcmV0dXJuIGFyZ3NbMF07XG4gIH0sXG5cbiAgX2dldEZpbmRPcHRpb25zKGFyZ3MpIHtcbiAgICBjb25zdCBbLCBvcHRpb25zXSA9IGFyZ3MgfHwgW107XG4gICAgY29uc3QgbmV3T3B0aW9ucyA9IG5vcm1hbGl6ZVByb2plY3Rpb24ob3B0aW9ucyk7XG5cbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgaWYgKGFyZ3MubGVuZ3RoIDwgMikge1xuICAgICAgcmV0dXJuIHsgdHJhbnNmb3JtOiBzZWxmLl90cmFuc2Zvcm0gfTtcbiAgICB9IGVsc2Uge1xuICAgICAgY2hlY2soXG4gICAgICAgIG5ld09wdGlvbnMsXG4gICAgICAgIE1hdGNoLk9wdGlvbmFsKFxuICAgICAgICAgIE1hdGNoLk9iamVjdEluY2x1ZGluZyh7XG4gICAgICAgICAgICBwcm9qZWN0aW9uOiBNYXRjaC5PcHRpb25hbChNYXRjaC5PbmVPZihPYmplY3QsIHVuZGVmaW5lZCkpLFxuICAgICAgICAgICAgc29ydDogTWF0Y2guT3B0aW9uYWwoXG4gICAgICAgICAgICAgIE1hdGNoLk9uZU9mKE9iamVjdCwgQXJyYXksIEZ1bmN0aW9uLCB1bmRlZmluZWQpXG4gICAgICAgICAgICApLFxuICAgICAgICAgICAgbGltaXQ6IE1hdGNoLk9wdGlvbmFsKE1hdGNoLk9uZU9mKE51bWJlciwgdW5kZWZpbmVkKSksXG4gICAgICAgICAgICBza2lwOiBNYXRjaC5PcHRpb25hbChNYXRjaC5PbmVPZihOdW1iZXIsIHVuZGVmaW5lZCkpLFxuICAgICAgICAgIH0pXG4gICAgICAgIClcbiAgICAgICk7XG5cbiAgICAgIHJldHVybiB7XG4gICAgICAgIHRyYW5zZm9ybTogc2VsZi5fdHJhbnNmb3JtLFxuICAgICAgICAuLi5uZXdPcHRpb25zLFxuICAgICAgfTtcbiAgICB9XG4gIH0sXG5cbiAgLyoqXG4gICAqIEBzdW1tYXJ5IEZpbmQgdGhlIGRvY3VtZW50cyBpbiBhIGNvbGxlY3Rpb24gdGhhdCBtYXRjaCB0aGUgc2VsZWN0b3IuXG4gICAqIEBsb2N1cyBBbnl3aGVyZVxuICAgKiBAbWV0aG9kIGZpbmRcbiAgICogQG1lbWJlcm9mIE1vbmdvLkNvbGxlY3Rpb25cbiAgICogQGluc3RhbmNlXG4gICAqIEBwYXJhbSB7TW9uZ29TZWxlY3Rvcn0gW3NlbGVjdG9yXSBBIHF1ZXJ5IGRlc2NyaWJpbmcgdGhlIGRvY3VtZW50cyB0byBmaW5kXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBbb3B0aW9uc11cbiAgICogQHBhcmFtIHtNb25nb1NvcnRTcGVjaWZpZXJ9IG9wdGlvbnMuc29ydCBTb3J0IG9yZGVyIChkZWZhdWx0OiBuYXR1cmFsIG9yZGVyKVxuICAgKiBAcGFyYW0ge051bWJlcn0gb3B0aW9ucy5za2lwIE51bWJlciBvZiByZXN1bHRzIHRvIHNraXAgYXQgdGhlIGJlZ2lubmluZ1xuICAgKiBAcGFyYW0ge051bWJlcn0gb3B0aW9ucy5saW1pdCBNYXhpbXVtIG51bWJlciBvZiByZXN1bHRzIHRvIHJldHVyblxuICAgKiBAcGFyYW0ge01vbmdvRmllbGRTcGVjaWZpZXJ9IG9wdGlvbnMuZmllbGRzIERpY3Rpb25hcnkgb2YgZmllbGRzIHRvIHJldHVybiBvciBleGNsdWRlLlxuICAgKiBAcGFyYW0ge0Jvb2xlYW59IG9wdGlvbnMucmVhY3RpdmUgKENsaWVudCBvbmx5KSBEZWZhdWx0IGB0cnVlYDsgcGFzcyBgZmFsc2VgIHRvIGRpc2FibGUgcmVhY3Rpdml0eVxuICAgKiBAcGFyYW0ge0Z1bmN0aW9ufSBvcHRpb25zLnRyYW5zZm9ybSBPdmVycmlkZXMgYHRyYW5zZm9ybWAgb24gdGhlICBbYENvbGxlY3Rpb25gXSgjY29sbGVjdGlvbnMpIGZvciB0aGlzIGN1cnNvci4gIFBhc3MgYG51bGxgIHRvIGRpc2FibGUgdHJhbnNmb3JtYXRpb24uXG4gICAqIEBwYXJhbSB7Qm9vbGVhbn0gb3B0aW9ucy5kaXNhYmxlT3Bsb2cgKFNlcnZlciBvbmx5KSBQYXNzIHRydWUgdG8gZGlzYWJsZSBvcGxvZy10YWlsaW5nIG9uIHRoaXMgcXVlcnkuIFRoaXMgYWZmZWN0cyB0aGUgd2F5IHNlcnZlciBwcm9jZXNzZXMgY2FsbHMgdG8gYG9ic2VydmVgIG9uIHRoaXMgcXVlcnkuIERpc2FibGluZyB0aGUgb3Bsb2cgY2FuIGJlIHVzZWZ1bCB3aGVuIHdvcmtpbmcgd2l0aCBkYXRhIHRoYXQgdXBkYXRlcyBpbiBsYXJnZSBiYXRjaGVzLlxuICAgKiBAcGFyYW0ge051bWJlcn0gb3B0aW9ucy5wb2xsaW5nSW50ZXJ2YWxNcyAoU2VydmVyIG9ubHkpIFdoZW4gb3Bsb2cgaXMgZGlzYWJsZWQgKHRocm91Z2ggdGhlIHVzZSBvZiBgZGlzYWJsZU9wbG9nYCBvciB3aGVuIG90aGVyd2lzZSBub3QgYXZhaWxhYmxlKSwgdGhlIGZyZXF1ZW5jeSAoaW4gbWlsbGlzZWNvbmRzKSBvZiBob3cgb2Z0ZW4gdG8gcG9sbCB0aGlzIHF1ZXJ5IHdoZW4gb2JzZXJ2aW5nIG9uIHRoZSBzZXJ2ZXIuIERlZmF1bHRzIHRvIDEwMDAwbXMgKDEwIHNlY29uZHMpLlxuICAgKiBAcGFyYW0ge051bWJlcn0gb3B0aW9ucy5wb2xsaW5nVGhyb3R0bGVNcyAoU2VydmVyIG9ubHkpIFdoZW4gb3Bsb2cgaXMgZGlzYWJsZWQgKHRocm91Z2ggdGhlIHVzZSBvZiBgZGlzYWJsZU9wbG9nYCBvciB3aGVuIG90aGVyd2lzZSBub3QgYXZhaWxhYmxlKSwgdGhlIG1pbmltdW0gdGltZSAoaW4gbWlsbGlzZWNvbmRzKSB0byBhbGxvdyBiZXR3ZWVuIHJlLXBvbGxpbmcgd2hlbiBvYnNlcnZpbmcgb24gdGhlIHNlcnZlci4gSW5jcmVhc2luZyB0aGlzIHdpbGwgc2F2ZSBDUFUgYW5kIG1vbmdvIGxvYWQgYXQgdGhlIGV4cGVuc2Ugb2Ygc2xvd2VyIHVwZGF0ZXMgdG8gdXNlcnMuIERlY3JlYXNpbmcgdGhpcyBpcyBub3QgcmVjb21tZW5kZWQuIERlZmF1bHRzIHRvIDUwbXMuXG4gICAqIEBwYXJhbSB7TnVtYmVyfSBvcHRpb25zLm1heFRpbWVNcyAoU2VydmVyIG9ubHkpIElmIHNldCwgaW5zdHJ1Y3RzIE1vbmdvREIgdG8gc2V0IGEgdGltZSBsaW1pdCBmb3IgdGhpcyBjdXJzb3IncyBvcGVyYXRpb25zLiBJZiB0aGUgb3BlcmF0aW9uIHJlYWNoZXMgdGhlIHNwZWNpZmllZCB0aW1lIGxpbWl0IChpbiBtaWxsaXNlY29uZHMpIHdpdGhvdXQgdGhlIGhhdmluZyBiZWVuIGNvbXBsZXRlZCwgYW4gZXhjZXB0aW9uIHdpbGwgYmUgdGhyb3duLiBVc2VmdWwgdG8gcHJldmVudCBhbiAoYWNjaWRlbnRhbCBvciBtYWxpY2lvdXMpIHVub3B0aW1pemVkIHF1ZXJ5IGZyb20gY2F1c2luZyBhIGZ1bGwgY29sbGVjdGlvbiBzY2FuIHRoYXQgd291bGQgZGlzcnVwdCBvdGhlciBkYXRhYmFzZSB1c2VycywgYXQgdGhlIGV4cGVuc2Ugb2YgbmVlZGluZyB0byBoYW5kbGUgdGhlIHJlc3VsdGluZyBlcnJvci5cbiAgICogQHBhcmFtIHtTdHJpbmd8T2JqZWN0fSBvcHRpb25zLmhpbnQgKFNlcnZlciBvbmx5KSBPdmVycmlkZXMgTW9uZ29EQidzIGRlZmF1bHQgaW5kZXggc2VsZWN0aW9uIGFuZCBxdWVyeSBvcHRpbWl6YXRpb24gcHJvY2Vzcy4gU3BlY2lmeSBhbiBpbmRleCB0byBmb3JjZSBpdHMgdXNlLCBlaXRoZXIgYnkgaXRzIG5hbWUgb3IgaW5kZXggc3BlY2lmaWNhdGlvbi4gWW91IGNhbiBhbHNvIHNwZWNpZnkgYHsgJG5hdHVyYWwgOiAxIH1gIHRvIGZvcmNlIGEgZm9yd2FyZHMgY29sbGVjdGlvbiBzY2FuLCBvciBgeyAkbmF0dXJhbCA6IC0xIH1gIGZvciBhIHJldmVyc2UgY29sbGVjdGlvbiBzY2FuLiBTZXR0aW5nIHRoaXMgaXMgb25seSByZWNvbW1lbmRlZCBmb3IgYWR2YW5jZWQgdXNlcnMuXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBvcHRpb25zLnJlYWRQcmVmZXJlbmNlIChTZXJ2ZXIgb25seSkgU3BlY2lmaWVzIGEgY3VzdG9tIE1vbmdvREIgW2ByZWFkUHJlZmVyZW5jZWBdKGh0dHBzOi8vZG9jcy5tb25nb2RiLmNvbS9tYW51YWwvY29yZS9yZWFkLXByZWZlcmVuY2UpIGZvciB0aGlzIHBhcnRpY3VsYXIgY3Vyc29yLiBQb3NzaWJsZSB2YWx1ZXMgYXJlIGBwcmltYXJ5YCwgYHByaW1hcnlQcmVmZXJyZWRgLCBgc2Vjb25kYXJ5YCwgYHNlY29uZGFyeVByZWZlcnJlZGAgYW5kIGBuZWFyZXN0YC5cbiAgICogQHJldHVybnMge01vbmdvLkN1cnNvcn1cbiAgICovXG4gIGZpbmQoLi4uYXJncykge1xuICAgIC8vIENvbGxlY3Rpb24uZmluZCgpIChyZXR1cm4gYWxsIGRvY3MpIGJlaGF2ZXMgZGlmZmVyZW50bHlcbiAgICAvLyBmcm9tIENvbGxlY3Rpb24uZmluZCh1bmRlZmluZWQpIChyZXR1cm4gMCBkb2NzKS4gIHNvIGJlXG4gICAgLy8gY2FyZWZ1bCBhYm91dCB0aGUgbGVuZ3RoIG9mIGFyZ3VtZW50cy5cbiAgICByZXR1cm4gdGhpcy5fY29sbGVjdGlvbi5maW5kKFxuICAgICAgdGhpcy5fZ2V0RmluZFNlbGVjdG9yKGFyZ3MpLFxuICAgICAgdGhpcy5fZ2V0RmluZE9wdGlvbnMoYXJncylcbiAgICApO1xuICB9LFxuXG4gIC8qKlxuICAgKiBAc3VtbWFyeSBGaW5kcyB0aGUgZmlyc3QgZG9jdW1lbnQgdGhhdCBtYXRjaGVzIHRoZSBzZWxlY3RvciwgYXMgb3JkZXJlZCBieSBzb3J0IGFuZCBza2lwIG9wdGlvbnMuIFJldHVybnMgYHVuZGVmaW5lZGAgaWYgbm8gbWF0Y2hpbmcgZG9jdW1lbnQgaXMgZm91bmQuXG4gICAqIEBsb2N1cyBBbnl3aGVyZVxuICAgKiBAbWV0aG9kIGZpbmRPbmVBc3luY1xuICAgKiBAbWVtYmVyb2YgTW9uZ28uQ29sbGVjdGlvblxuICAgKiBAaW5zdGFuY2VcbiAgICogQHBhcmFtIHtNb25nb1NlbGVjdG9yfSBbc2VsZWN0b3JdIEEgcXVlcnkgZGVzY3JpYmluZyB0aGUgZG9jdW1lbnRzIHRvIGZpbmRcbiAgICogQHBhcmFtIHtPYmplY3R9IFtvcHRpb25zXVxuICAgKiBAcGFyYW0ge01vbmdvU29ydFNwZWNpZmllcn0gb3B0aW9ucy5zb3J0IFNvcnQgb3JkZXIgKGRlZmF1bHQ6IG5hdHVyYWwgb3JkZXIpXG4gICAqIEBwYXJhbSB7TnVtYmVyfSBvcHRpb25zLnNraXAgTnVtYmVyIG9mIHJlc3VsdHMgdG8gc2tpcCBhdCB0aGUgYmVnaW5uaW5nXG4gICAqIEBwYXJhbSB7TW9uZ29GaWVsZFNwZWNpZmllcn0gb3B0aW9ucy5maWVsZHMgRGljdGlvbmFyeSBvZiBmaWVsZHMgdG8gcmV0dXJuIG9yIGV4Y2x1ZGUuXG4gICAqIEBwYXJhbSB7Qm9vbGVhbn0gb3B0aW9ucy5yZWFjdGl2ZSAoQ2xpZW50IG9ubHkpIERlZmF1bHQgdHJ1ZTsgcGFzcyBmYWxzZSB0byBkaXNhYmxlIHJlYWN0aXZpdHlcbiAgICogQHBhcmFtIHtGdW5jdGlvbn0gb3B0aW9ucy50cmFuc2Zvcm0gT3ZlcnJpZGVzIGB0cmFuc2Zvcm1gIG9uIHRoZSBbYENvbGxlY3Rpb25gXSgjY29sbGVjdGlvbnMpIGZvciB0aGlzIGN1cnNvci4gIFBhc3MgYG51bGxgIHRvIGRpc2FibGUgdHJhbnNmb3JtYXRpb24uXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBvcHRpb25zLnJlYWRQcmVmZXJlbmNlIChTZXJ2ZXIgb25seSkgU3BlY2lmaWVzIGEgY3VzdG9tIE1vbmdvREIgW2ByZWFkUHJlZmVyZW5jZWBdKGh0dHBzOi8vZG9jcy5tb25nb2RiLmNvbS9tYW51YWwvY29yZS9yZWFkLXByZWZlcmVuY2UpIGZvciBmZXRjaGluZyB0aGUgZG9jdW1lbnQuIFBvc3NpYmxlIHZhbHVlcyBhcmUgYHByaW1hcnlgLCBgcHJpbWFyeVByZWZlcnJlZGAsIGBzZWNvbmRhcnlgLCBgc2Vjb25kYXJ5UHJlZmVycmVkYCBhbmQgYG5lYXJlc3RgLlxuICAgKiBAcmV0dXJucyB7T2JqZWN0fVxuICAgKi9cbiAgZmluZE9uZUFzeW5jKC4uLmFyZ3MpIHtcbiAgICByZXR1cm4gdGhpcy5fY29sbGVjdGlvbi5maW5kT25lQXN5bmMoXG4gICAgICB0aGlzLl9nZXRGaW5kU2VsZWN0b3IoYXJncyksXG4gICAgICB0aGlzLl9nZXRGaW5kT3B0aW9ucyhhcmdzKVxuICAgICk7XG4gIH0sXG4gIC8qKlxuICAgKiBAc3VtbWFyeSBGaW5kcyB0aGUgZmlyc3QgZG9jdW1lbnQgdGhhdCBtYXRjaGVzIHRoZSBzZWxlY3RvciwgYXMgb3JkZXJlZCBieSBzb3J0IGFuZCBza2lwIG9wdGlvbnMuIFJldHVybnMgYHVuZGVmaW5lZGAgaWYgbm8gbWF0Y2hpbmcgZG9jdW1lbnQgaXMgZm91bmQuXG4gICAqIEBsb2N1cyBBbnl3aGVyZVxuICAgKiBAbWV0aG9kIGZpbmRPbmVcbiAgICogQG1lbWJlcm9mIE1vbmdvLkNvbGxlY3Rpb25cbiAgICogQGluc3RhbmNlXG4gICAqIEBwYXJhbSB7TW9uZ29TZWxlY3Rvcn0gW3NlbGVjdG9yXSBBIHF1ZXJ5IGRlc2NyaWJpbmcgdGhlIGRvY3VtZW50cyB0byBmaW5kXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBbb3B0aW9uc11cbiAgICogQHBhcmFtIHtNb25nb1NvcnRTcGVjaWZpZXJ9IG9wdGlvbnMuc29ydCBTb3J0IG9yZGVyIChkZWZhdWx0OiBuYXR1cmFsIG9yZGVyKVxuICAgKiBAcGFyYW0ge051bWJlcn0gb3B0aW9ucy5za2lwIE51bWJlciBvZiByZXN1bHRzIHRvIHNraXAgYXQgdGhlIGJlZ2lubmluZ1xuICAgKiBAcGFyYW0ge01vbmdvRmllbGRTcGVjaWZpZXJ9IG9wdGlvbnMuZmllbGRzIERpY3Rpb25hcnkgb2YgZmllbGRzIHRvIHJldHVybiBvciBleGNsdWRlLlxuICAgKiBAcGFyYW0ge0Jvb2xlYW59IG9wdGlvbnMucmVhY3RpdmUgKENsaWVudCBvbmx5KSBEZWZhdWx0IHRydWU7IHBhc3MgZmFsc2UgdG8gZGlzYWJsZSByZWFjdGl2aXR5XG4gICAqIEBwYXJhbSB7RnVuY3Rpb259IG9wdGlvbnMudHJhbnNmb3JtIE92ZXJyaWRlcyBgdHJhbnNmb3JtYCBvbiB0aGUgW2BDb2xsZWN0aW9uYF0oI2NvbGxlY3Rpb25zKSBmb3IgdGhpcyBjdXJzb3IuICBQYXNzIGBudWxsYCB0byBkaXNhYmxlIHRyYW5zZm9ybWF0aW9uLlxuICAgKiBAcGFyYW0ge1N0cmluZ30gb3B0aW9ucy5yZWFkUHJlZmVyZW5jZSAoU2VydmVyIG9ubHkpIFNwZWNpZmllcyBhIGN1c3RvbSBNb25nb0RCIFtgcmVhZFByZWZlcmVuY2VgXShodHRwczovL2RvY3MubW9uZ29kYi5jb20vbWFudWFsL2NvcmUvcmVhZC1wcmVmZXJlbmNlKSBmb3IgZmV0Y2hpbmcgdGhlIGRvY3VtZW50LiBQb3NzaWJsZSB2YWx1ZXMgYXJlIGBwcmltYXJ5YCwgYHByaW1hcnlQcmVmZXJyZWRgLCBgc2Vjb25kYXJ5YCwgYHNlY29uZGFyeVByZWZlcnJlZGAgYW5kIGBuZWFyZXN0YC5cbiAgICogQHJldHVybnMge09iamVjdH1cbiAgICovXG4gIGZpbmRPbmUoLi4uYXJncykge1xuICAgIHJldHVybiB0aGlzLl9jb2xsZWN0aW9uLmZpbmRPbmUoXG4gICAgICB0aGlzLl9nZXRGaW5kU2VsZWN0b3IoYXJncyksXG4gICAgICB0aGlzLl9nZXRGaW5kT3B0aW9ucyhhcmdzKVxuICAgICk7XG4gIH0sXG59KTtcblxuT2JqZWN0LmFzc2lnbihNb25nby5Db2xsZWN0aW9uLCB7XG4gIGFzeW5jIF9wdWJsaXNoQ3Vyc29yKGN1cnNvciwgc3ViLCBjb2xsZWN0aW9uKSB7XG4gICAgdmFyIG9ic2VydmVIYW5kbGUgPSBhd2FpdCBjdXJzb3Iub2JzZXJ2ZUNoYW5nZXMoXG4gICAgICAgIHtcbiAgICAgICAgICBhZGRlZDogZnVuY3Rpb24oaWQsIGZpZWxkcykge1xuICAgICAgICAgICAgc3ViLmFkZGVkKGNvbGxlY3Rpb24sIGlkLCBmaWVsZHMpO1xuICAgICAgICAgIH0sXG4gICAgICAgICAgY2hhbmdlZDogZnVuY3Rpb24oaWQsIGZpZWxkcykge1xuICAgICAgICAgICAgc3ViLmNoYW5nZWQoY29sbGVjdGlvbiwgaWQsIGZpZWxkcyk7XG4gICAgICAgICAgfSxcbiAgICAgICAgICByZW1vdmVkOiBmdW5jdGlvbihpZCkge1xuICAgICAgICAgICAgc3ViLnJlbW92ZWQoY29sbGVjdGlvbiwgaWQpO1xuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICAgIC8vIFB1YmxpY2F0aW9ucyBkb24ndCBtdXRhdGUgdGhlIGRvY3VtZW50c1xuICAgICAgICAvLyBUaGlzIGlzIHRlc3RlZCBieSB0aGUgYGxpdmVkYXRhIC0gcHVibGlzaCBjYWxsYmFja3MgY2xvbmVgIHRlc3RcbiAgICAgICAgeyBub25NdXRhdGluZ0NhbGxiYWNrczogdHJ1ZSB9XG4gICAgKTtcblxuICAgIC8vIFdlIGRvbid0IGNhbGwgc3ViLnJlYWR5KCkgaGVyZTogaXQgZ2V0cyBjYWxsZWQgaW4gbGl2ZWRhdGFfc2VydmVyLCBhZnRlclxuICAgIC8vIHBvc3NpYmx5IGNhbGxpbmcgX3B1Ymxpc2hDdXJzb3Igb24gbXVsdGlwbGUgcmV0dXJuZWQgY3Vyc29ycy5cblxuICAgIC8vIHJlZ2lzdGVyIHN0b3AgY2FsbGJhY2sgKGV4cGVjdHMgbGFtYmRhIHcvIG5vIGFyZ3MpLlxuICAgIHN1Yi5vblN0b3AoYXN5bmMgZnVuY3Rpb24oKSB7XG4gICAgICByZXR1cm4gYXdhaXQgb2JzZXJ2ZUhhbmRsZS5zdG9wKCk7XG4gICAgfSk7XG5cbiAgICAvLyByZXR1cm4gdGhlIG9ic2VydmVIYW5kbGUgaW4gY2FzZSBpdCBuZWVkcyB0byBiZSBzdG9wcGVkIGVhcmx5XG4gICAgcmV0dXJuIG9ic2VydmVIYW5kbGU7XG4gIH0sXG5cbiAgLy8gcHJvdGVjdCBhZ2FpbnN0IGRhbmdlcm91cyBzZWxlY3RvcnMuICBmYWxzZXkgYW5kIHtfaWQ6IGZhbHNleX0gYXJlIGJvdGhcbiAgLy8gbGlrZWx5IHByb2dyYW1tZXIgZXJyb3IsIGFuZCBub3Qgd2hhdCB5b3Ugd2FudCwgcGFydGljdWxhcmx5IGZvciBkZXN0cnVjdGl2ZVxuICAvLyBvcGVyYXRpb25zLiBJZiBhIGZhbHNleSBfaWQgaXMgc2VudCBpbiwgYSBuZXcgc3RyaW5nIF9pZCB3aWxsIGJlXG4gIC8vIGdlbmVyYXRlZCBhbmQgcmV0dXJuZWQ7IGlmIGEgZmFsbGJhY2tJZCBpcyBwcm92aWRlZCwgaXQgd2lsbCBiZSByZXR1cm5lZFxuICAvLyBpbnN0ZWFkLlxuICBfcmV3cml0ZVNlbGVjdG9yKHNlbGVjdG9yLCB7IGZhbGxiYWNrSWQgfSA9IHt9KSB7XG4gICAgLy8gc2hvcnRoYW5kIC0tIHNjYWxhcnMgbWF0Y2ggX2lkXG4gICAgaWYgKExvY2FsQ29sbGVjdGlvbi5fc2VsZWN0b3JJc0lkKHNlbGVjdG9yKSkgc2VsZWN0b3IgPSB7IF9pZDogc2VsZWN0b3IgfTtcblxuICAgIGlmIChBcnJheS5pc0FycmF5KHNlbGVjdG9yKSkge1xuICAgICAgLy8gVGhpcyBpcyBjb25zaXN0ZW50IHdpdGggdGhlIE1vbmdvIGNvbnNvbGUgaXRzZWxmOyBpZiB3ZSBkb24ndCBkbyB0aGlzXG4gICAgICAvLyBjaGVjayBwYXNzaW5nIGFuIGVtcHR5IGFycmF5IGVuZHMgdXAgc2VsZWN0aW5nIGFsbCBpdGVtc1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiTW9uZ28gc2VsZWN0b3IgY2FuJ3QgYmUgYW4gYXJyYXkuXCIpO1xuICAgIH1cblxuICAgIGlmICghc2VsZWN0b3IgfHwgKCdfaWQnIGluIHNlbGVjdG9yICYmICFzZWxlY3Rvci5faWQpKSB7XG4gICAgICAvLyBjYW4ndCBtYXRjaCBhbnl0aGluZ1xuICAgICAgcmV0dXJuIHsgX2lkOiBmYWxsYmFja0lkIHx8IFJhbmRvbS5pZCgpIH07XG4gICAgfVxuXG4gICAgcmV0dXJuIHNlbGVjdG9yO1xuICB9LFxufSk7XG5cbk9iamVjdC5hc3NpZ24oTW9uZ28uQ29sbGVjdGlvbi5wcm90b3R5cGUsIHtcbiAgLy8gJ2luc2VydCcgaW1tZWRpYXRlbHkgcmV0dXJucyB0aGUgaW5zZXJ0ZWQgZG9jdW1lbnQncyBuZXcgX2lkLlxuICAvLyBUaGUgb3RoZXJzIHJldHVybiB2YWx1ZXMgaW1tZWRpYXRlbHkgaWYgeW91IGFyZSBpbiBhIHN0dWIsIGFuIGluLW1lbW9yeVxuICAvLyB1bm1hbmFnZWQgY29sbGVjdGlvbiwgb3IgYSBtb25nby1iYWNrZWQgY29sbGVjdGlvbiBhbmQgeW91IGRvbid0IHBhc3MgYVxuICAvLyBjYWxsYmFjay4gJ3VwZGF0ZScgYW5kICdyZW1vdmUnIHJldHVybiB0aGUgbnVtYmVyIG9mIGFmZmVjdGVkXG4gIC8vIGRvY3VtZW50cy4gJ3Vwc2VydCcgcmV0dXJucyBhbiBvYmplY3Qgd2l0aCBrZXlzICdudW1iZXJBZmZlY3RlZCcgYW5kLCBpZiBhblxuICAvLyBpbnNlcnQgaGFwcGVuZWQsICdpbnNlcnRlZElkJy5cbiAgLy9cbiAgLy8gT3RoZXJ3aXNlLCB0aGUgc2VtYW50aWNzIGFyZSBleGFjdGx5IGxpa2Ugb3RoZXIgbWV0aG9kczogdGhleSB0YWtlXG4gIC8vIGEgY2FsbGJhY2sgYXMgYW4gb3B0aW9uYWwgbGFzdCBhcmd1bWVudDsgaWYgbm8gY2FsbGJhY2sgaXNcbiAgLy8gcHJvdmlkZWQsIHRoZXkgYmxvY2sgdW50aWwgdGhlIG9wZXJhdGlvbiBpcyBjb21wbGV0ZSwgYW5kIHRocm93IGFuXG4gIC8vIGV4Y2VwdGlvbiBpZiBpdCBmYWlsczsgaWYgYSBjYWxsYmFjayBpcyBwcm92aWRlZCwgdGhlbiB0aGV5IGRvbid0XG4gIC8vIG5lY2Vzc2FyaWx5IGJsb2NrLCBhbmQgdGhleSBjYWxsIHRoZSBjYWxsYmFjayB3aGVuIHRoZXkgZmluaXNoIHdpdGggZXJyb3IgYW5kXG4gIC8vIHJlc3VsdCBhcmd1bWVudHMuICAoVGhlIGluc2VydCBtZXRob2QgcHJvdmlkZXMgdGhlIGRvY3VtZW50IElEIGFzIGl0cyByZXN1bHQ7XG4gIC8vIHVwZGF0ZSBhbmQgcmVtb3ZlIHByb3ZpZGUgdGhlIG51bWJlciBvZiBhZmZlY3RlZCBkb2NzIGFzIHRoZSByZXN1bHQ7IHVwc2VydFxuICAvLyBwcm92aWRlcyBhbiBvYmplY3Qgd2l0aCBudW1iZXJBZmZlY3RlZCBhbmQgbWF5YmUgaW5zZXJ0ZWRJZC4pXG4gIC8vXG4gIC8vIE9uIHRoZSBjbGllbnQsIGJsb2NraW5nIGlzIGltcG9zc2libGUsIHNvIGlmIGEgY2FsbGJhY2tcbiAgLy8gaXNuJ3QgcHJvdmlkZWQsIHRoZXkganVzdCByZXR1cm4gaW1tZWRpYXRlbHkgYW5kIGFueSBlcnJvclxuICAvLyBpbmZvcm1hdGlvbiBpcyBsb3N0LlxuICAvL1xuICAvLyBUaGVyZSdzIG9uZSBtb3JlIHR3ZWFrLiBPbiB0aGUgY2xpZW50LCBpZiB5b3UgZG9uJ3QgcHJvdmlkZSBhXG4gIC8vIGNhbGxiYWNrLCB0aGVuIGlmIHRoZXJlIGlzIGFuIGVycm9yLCBhIG1lc3NhZ2Ugd2lsbCBiZSBsb2dnZWQgd2l0aFxuICAvLyBNZXRlb3IuX2RlYnVnLlxuICAvL1xuICAvLyBUaGUgaW50ZW50ICh0aG91Z2ggdGhpcyBpcyBhY3R1YWxseSBkZXRlcm1pbmVkIGJ5IHRoZSB1bmRlcmx5aW5nXG4gIC8vIGRyaXZlcnMpIGlzIHRoYXQgdGhlIG9wZXJhdGlvbnMgc2hvdWxkIGJlIGRvbmUgc3luY2hyb25vdXNseSwgbm90XG4gIC8vIGdlbmVyYXRpbmcgdGhlaXIgcmVzdWx0IHVudGlsIHRoZSBkYXRhYmFzZSBoYXMgYWNrbm93bGVkZ2VkXG4gIC8vIHRoZW0uIEluIHRoZSBmdXR1cmUgbWF5YmUgd2Ugc2hvdWxkIHByb3ZpZGUgYSBmbGFnIHRvIHR1cm4gdGhpc1xuICAvLyBvZmYuXG5cbiAgX2luc2VydChkb2MsIGNhbGxiYWNrKSB7XG4gICAgLy8gTWFrZSBzdXJlIHdlIHdlcmUgcGFzc2VkIGEgZG9jdW1lbnQgdG8gaW5zZXJ0XG4gICAgaWYgKCFkb2MpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignaW5zZXJ0IHJlcXVpcmVzIGFuIGFyZ3VtZW50Jyk7XG4gICAgfVxuXG5cbiAgICAvLyBNYWtlIGEgc2hhbGxvdyBjbG9uZSBvZiB0aGUgZG9jdW1lbnQsIHByZXNlcnZpbmcgaXRzIHByb3RvdHlwZS5cbiAgICBkb2MgPSBPYmplY3QuY3JlYXRlKFxuICAgICAgT2JqZWN0LmdldFByb3RvdHlwZU9mKGRvYyksXG4gICAgICBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycyhkb2MpXG4gICAgKTtcblxuICAgIGlmICgnX2lkJyBpbiBkb2MpIHtcbiAgICAgIGlmIChcbiAgICAgICAgIWRvYy5faWQgfHxcbiAgICAgICAgISh0eXBlb2YgZG9jLl9pZCA9PT0gJ3N0cmluZycgfHwgZG9jLl9pZCBpbnN0YW5jZW9mIE1vbmdvLk9iamVjdElEKVxuICAgICAgKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgICAnTWV0ZW9yIHJlcXVpcmVzIGRvY3VtZW50IF9pZCBmaWVsZHMgdG8gYmUgbm9uLWVtcHR5IHN0cmluZ3Mgb3IgT2JqZWN0SURzJ1xuICAgICAgICApO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBsZXQgZ2VuZXJhdGVJZCA9IHRydWU7XG5cbiAgICAgIC8vIERvbid0IGdlbmVyYXRlIHRoZSBpZCBpZiB3ZSdyZSB0aGUgY2xpZW50IGFuZCB0aGUgJ291dGVybW9zdCcgY2FsbFxuICAgICAgLy8gVGhpcyBvcHRpbWl6YXRpb24gc2F2ZXMgdXMgcGFzc2luZyBib3RoIHRoZSByYW5kb21TZWVkIGFuZCB0aGUgaWRcbiAgICAgIC8vIFBhc3NpbmcgYm90aCBpcyByZWR1bmRhbnQuXG4gICAgICBpZiAodGhpcy5faXNSZW1vdGVDb2xsZWN0aW9uKCkpIHtcbiAgICAgICAgY29uc3QgZW5jbG9zaW5nID0gRERQLl9DdXJyZW50TWV0aG9kSW52b2NhdGlvbi5nZXQoKTtcbiAgICAgICAgaWYgKCFlbmNsb3NpbmcpIHtcbiAgICAgICAgICBnZW5lcmF0ZUlkID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgaWYgKGdlbmVyYXRlSWQpIHtcbiAgICAgICAgZG9jLl9pZCA9IHRoaXMuX21ha2VOZXdJRCgpO1xuICAgICAgfVxuICAgIH1cblxuXG4gICAgLy8gT24gaW5zZXJ0cywgYWx3YXlzIHJldHVybiB0aGUgaWQgdGhhdCB3ZSBnZW5lcmF0ZWQ7IG9uIGFsbCBvdGhlclxuICAgIC8vIG9wZXJhdGlvbnMsIGp1c3QgcmV0dXJuIHRoZSByZXN1bHQgZnJvbSB0aGUgY29sbGVjdGlvbi5cbiAgICB2YXIgY2hvb3NlUmV0dXJuVmFsdWVGcm9tQ29sbGVjdGlvblJlc3VsdCA9IGZ1bmN0aW9uKHJlc3VsdCkge1xuICAgICAgaWYgKE1ldGVvci5faXNQcm9taXNlKHJlc3VsdCkpIHJldHVybiByZXN1bHQ7XG5cbiAgICAgIGlmIChkb2MuX2lkKSB7XG4gICAgICAgIHJldHVybiBkb2MuX2lkO1xuICAgICAgfVxuXG4gICAgICAvLyBYWFggd2hhdCBpcyB0aGlzIGZvcj8/XG4gICAgICAvLyBJdCdzIHNvbWUgaXRlcmFjdGlvbiBiZXR3ZWVuIHRoZSBjYWxsYmFjayB0byBfY2FsbE11dGF0b3JNZXRob2QgYW5kXG4gICAgICAvLyB0aGUgcmV0dXJuIHZhbHVlIGNvbnZlcnNpb25cbiAgICAgIGRvYy5faWQgPSByZXN1bHQ7XG5cbiAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfTtcblxuICAgIGNvbnN0IHdyYXBwZWRDYWxsYmFjayA9IHdyYXBDYWxsYmFjayhcbiAgICAgIGNhbGxiYWNrLFxuICAgICAgY2hvb3NlUmV0dXJuVmFsdWVGcm9tQ29sbGVjdGlvblJlc3VsdFxuICAgICk7XG5cbiAgICBpZiAodGhpcy5faXNSZW1vdGVDb2xsZWN0aW9uKCkpIHtcbiAgICAgIGNvbnN0IHJlc3VsdCA9IHRoaXMuX2NhbGxNdXRhdG9yTWV0aG9kKCdpbnNlcnQnLCBbZG9jXSwgd3JhcHBlZENhbGxiYWNrKTtcbiAgICAgIHJldHVybiBjaG9vc2VSZXR1cm5WYWx1ZUZyb21Db2xsZWN0aW9uUmVzdWx0KHJlc3VsdCk7XG4gICAgfVxuXG4gICAgLy8gaXQncyBteSBjb2xsZWN0aW9uLiAgZGVzY2VuZCBpbnRvIHRoZSBjb2xsZWN0aW9uIG9iamVjdFxuICAgIC8vIGFuZCBwcm9wYWdhdGUgYW55IGV4Y2VwdGlvbi5cbiAgICB0cnkge1xuICAgICAgLy8gSWYgdGhlIHVzZXIgcHJvdmlkZWQgYSBjYWxsYmFjayBhbmQgdGhlIGNvbGxlY3Rpb24gaW1wbGVtZW50cyB0aGlzXG4gICAgICAvLyBvcGVyYXRpb24gYXN5bmNocm9ub3VzbHksIHRoZW4gcXVlcnlSZXQgd2lsbCBiZSB1bmRlZmluZWQsIGFuZCB0aGVcbiAgICAgIC8vIHJlc3VsdCB3aWxsIGJlIHJldHVybmVkIHRocm91Z2ggdGhlIGNhbGxiYWNrIGluc3RlYWQuXG4gICAgICBsZXQgcmVzdWx0O1xuICAgICAgaWYgKCEhd3JhcHBlZENhbGxiYWNrKSB7XG4gICAgICAgIHRoaXMuX2NvbGxlY3Rpb24uaW5zZXJ0KGRvYywgd3JhcHBlZENhbGxiYWNrKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIElmIHdlIGRvbid0IGhhdmUgdGhlIGNhbGxiYWNrLCB3ZSBhc3N1bWUgdGhlIHVzZXIgaXMgdXNpbmcgdGhlIHByb21pc2UuXG4gICAgICAgIC8vIFdlIGNhbid0IGp1c3QgcGFzcyB0aGlzLl9jb2xsZWN0aW9uLmluc2VydCB0byB0aGUgcHJvbWlzaWZ5IGJlY2F1c2UgaXQgd291bGQgbG9zZSB0aGUgY29udGV4dC5cbiAgICAgICAgcmVzdWx0ID0gdGhpcy5fY29sbGVjdGlvbi5pbnNlcnQoZG9jKTtcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIGNob29zZVJldHVyblZhbHVlRnJvbUNvbGxlY3Rpb25SZXN1bHQocmVzdWx0KTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBpZiAoY2FsbGJhY2spIHtcbiAgICAgICAgY2FsbGJhY2soZSk7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgICAgfVxuICAgICAgdGhyb3cgZTtcbiAgICB9XG4gIH0sXG5cbiAgLyoqXG4gICAqIEBzdW1tYXJ5IEluc2VydCBhIGRvY3VtZW50IGluIHRoZSBjb2xsZWN0aW9uLiAgUmV0dXJucyBpdHMgdW5pcXVlIF9pZC5cbiAgICogQGxvY3VzIEFueXdoZXJlXG4gICAqIEBtZXRob2QgIGluc2VydFxuICAgKiBAbWVtYmVyb2YgTW9uZ28uQ29sbGVjdGlvblxuICAgKiBAaW5zdGFuY2VcbiAgICogQHBhcmFtIHtPYmplY3R9IGRvYyBUaGUgZG9jdW1lbnQgdG8gaW5zZXJ0LiBNYXkgbm90IHlldCBoYXZlIGFuIF9pZCBhdHRyaWJ1dGUsIGluIHdoaWNoIGNhc2UgTWV0ZW9yIHdpbGwgZ2VuZXJhdGUgb25lIGZvciB5b3UuXG4gICAqIEBwYXJhbSB7RnVuY3Rpb259IFtjYWxsYmFja10gT3B0aW9uYWwuICBJZiBwcmVzZW50LCBjYWxsZWQgd2l0aCBhbiBlcnJvciBvYmplY3QgYXMgdGhlIGZpcnN0IGFyZ3VtZW50IGFuZCwgaWYgbm8gZXJyb3IsIHRoZSBfaWQgYXMgdGhlIHNlY29uZC5cbiAgICovXG4gIGluc2VydChkb2MsIGNhbGxiYWNrKSB7XG4gICAgcmV0dXJuIHRoaXMuX2luc2VydChkb2MsIGNhbGxiYWNrKTtcbiAgfSxcblxuICBfaW5zZXJ0QXN5bmMoZG9jLCBvcHRpb25zID0ge30pIHtcbiAgICAvLyBNYWtlIHN1cmUgd2Ugd2VyZSBwYXNzZWQgYSBkb2N1bWVudCB0byBpbnNlcnRcbiAgICBpZiAoIWRvYykge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdpbnNlcnQgcmVxdWlyZXMgYW4gYXJndW1lbnQnKTtcbiAgICB9XG5cbiAgICAvLyBNYWtlIGEgc2hhbGxvdyBjbG9uZSBvZiB0aGUgZG9jdW1lbnQsIHByZXNlcnZpbmcgaXRzIHByb3RvdHlwZS5cbiAgICBkb2MgPSBPYmplY3QuY3JlYXRlKFxuICAgICAgICBPYmplY3QuZ2V0UHJvdG90eXBlT2YoZG9jKSxcbiAgICAgICAgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcnMoZG9jKVxuICAgICk7XG5cbiAgICBpZiAoJ19pZCcgaW4gZG9jKSB7XG4gICAgICBpZiAoXG4gICAgICAgICAgIWRvYy5faWQgfHxcbiAgICAgICAgICAhKHR5cGVvZiBkb2MuX2lkID09PSAnc3RyaW5nJyB8fCBkb2MuX2lkIGluc3RhbmNlb2YgTW9uZ28uT2JqZWN0SUQpXG4gICAgICApIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAgICAgJ01ldGVvciByZXF1aXJlcyBkb2N1bWVudCBfaWQgZmllbGRzIHRvIGJlIG5vbi1lbXB0eSBzdHJpbmdzIG9yIE9iamVjdElEcydcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgbGV0IGdlbmVyYXRlSWQgPSB0cnVlO1xuXG4gICAgICAvLyBEb24ndCBnZW5lcmF0ZSB0aGUgaWQgaWYgd2UncmUgdGhlIGNsaWVudCBhbmQgdGhlICdvdXRlcm1vc3QnIGNhbGxcbiAgICAgIC8vIFRoaXMgb3B0aW1pemF0aW9uIHNhdmVzIHVzIHBhc3NpbmcgYm90aCB0aGUgcmFuZG9tU2VlZCBhbmQgdGhlIGlkXG4gICAgICAvLyBQYXNzaW5nIGJvdGggaXMgcmVkdW5kYW50LlxuICAgICAgaWYgKHRoaXMuX2lzUmVtb3RlQ29sbGVjdGlvbigpKSB7XG4gICAgICAgIGNvbnN0IGVuY2xvc2luZyA9IEREUC5fQ3VycmVudE1ldGhvZEludm9jYXRpb24uZ2V0KCk7XG4gICAgICAgIGlmICghZW5jbG9zaW5nKSB7XG4gICAgICAgICAgZ2VuZXJhdGVJZCA9IGZhbHNlO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGlmIChnZW5lcmF0ZUlkKSB7XG4gICAgICAgIGRvYy5faWQgPSB0aGlzLl9tYWtlTmV3SUQoKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBPbiBpbnNlcnRzLCBhbHdheXMgcmV0dXJuIHRoZSBpZCB0aGF0IHdlIGdlbmVyYXRlZDsgb24gYWxsIG90aGVyXG4gICAgLy8gb3BlcmF0aW9ucywganVzdCByZXR1cm4gdGhlIHJlc3VsdCBmcm9tIHRoZSBjb2xsZWN0aW9uLlxuICAgIHZhciBjaG9vc2VSZXR1cm5WYWx1ZUZyb21Db2xsZWN0aW9uUmVzdWx0ID0gZnVuY3Rpb24ocmVzdWx0KSB7XG4gICAgICBpZiAoTWV0ZW9yLl9pc1Byb21pc2UocmVzdWx0KSkgcmV0dXJuIHJlc3VsdDtcblxuICAgICAgaWYgKGRvYy5faWQpIHtcbiAgICAgICAgcmV0dXJuIGRvYy5faWQ7XG4gICAgICB9XG5cbiAgICAgIC8vIFhYWCB3aGF0IGlzIHRoaXMgZm9yPz9cbiAgICAgIC8vIEl0J3Mgc29tZSBpdGVyYWN0aW9uIGJldHdlZW4gdGhlIGNhbGxiYWNrIHRvIF9jYWxsTXV0YXRvck1ldGhvZCBhbmRcbiAgICAgIC8vIHRoZSByZXR1cm4gdmFsdWUgY29udmVyc2lvblxuICAgICAgZG9jLl9pZCA9IHJlc3VsdDtcblxuICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9O1xuXG4gICAgaWYgKHRoaXMuX2lzUmVtb3RlQ29sbGVjdGlvbigpKSB7XG4gICAgICBjb25zdCBwcm9taXNlID0gdGhpcy5fY2FsbE11dGF0b3JNZXRob2RBc3luYygnaW5zZXJ0QXN5bmMnLCBbZG9jXSwgb3B0aW9ucyk7XG4gICAgICBwcm9taXNlLnRoZW4oY2hvb3NlUmV0dXJuVmFsdWVGcm9tQ29sbGVjdGlvblJlc3VsdCk7XG4gICAgICBwcm9taXNlLnN0dWJQcm9taXNlID0gcHJvbWlzZS5zdHViUHJvbWlzZS50aGVuKGNob29zZVJldHVyblZhbHVlRnJvbUNvbGxlY3Rpb25SZXN1bHQpO1xuICAgICAgcHJvbWlzZS5zZXJ2ZXJQcm9taXNlID0gcHJvbWlzZS5zZXJ2ZXJQcm9taXNlLnRoZW4oY2hvb3NlUmV0dXJuVmFsdWVGcm9tQ29sbGVjdGlvblJlc3VsdCk7XG4gICAgICByZXR1cm4gcHJvbWlzZTtcbiAgICB9XG5cbiAgICAvLyBpdCdzIG15IGNvbGxlY3Rpb24uICBkZXNjZW5kIGludG8gdGhlIGNvbGxlY3Rpb24gb2JqZWN0XG4gICAgLy8gYW5kIHByb3BhZ2F0ZSBhbnkgZXhjZXB0aW9uLlxuICAgIHJldHVybiB0aGlzLl9jb2xsZWN0aW9uLmluc2VydEFzeW5jKGRvYylcbiAgICAgIC50aGVuKGNob29zZVJldHVyblZhbHVlRnJvbUNvbGxlY3Rpb25SZXN1bHQpO1xuICB9LFxuXG4gIC8qKlxuICAgKiBAc3VtbWFyeSBJbnNlcnQgYSBkb2N1bWVudCBpbiB0aGUgY29sbGVjdGlvbi4gIFJldHVybnMgYSBwcm9taXNlIHRoYXQgd2lsbCByZXR1cm4gdGhlIGRvY3VtZW50J3MgdW5pcXVlIF9pZCB3aGVuIHNvbHZlZC5cbiAgICogQGxvY3VzIEFueXdoZXJlXG4gICAqIEBtZXRob2QgIGluc2VydFxuICAgKiBAbWVtYmVyb2YgTW9uZ28uQ29sbGVjdGlvblxuICAgKiBAaW5zdGFuY2VcbiAgICogQHBhcmFtIHtPYmplY3R9IGRvYyBUaGUgZG9jdW1lbnQgdG8gaW5zZXJ0LiBNYXkgbm90IHlldCBoYXZlIGFuIF9pZCBhdHRyaWJ1dGUsIGluIHdoaWNoIGNhc2UgTWV0ZW9yIHdpbGwgZ2VuZXJhdGUgb25lIGZvciB5b3UuXG4gICAqL1xuICBpbnNlcnRBc3luYyhkb2MsIG9wdGlvbnMpIHtcbiAgICByZXR1cm4gdGhpcy5faW5zZXJ0QXN5bmMoZG9jLCBvcHRpb25zKTtcbiAgfSxcblxuICAvKipcbiAgICogQHN1bW1hcnkgTW9kaWZ5IG9uZSBvciBtb3JlIGRvY3VtZW50cyBpbiB0aGUgY29sbGVjdGlvbi4gUmV0dXJucyB0aGUgbnVtYmVyIG9mIG1hdGNoZWQgZG9jdW1lbnRzLlxuICAgKiBAbG9jdXMgQW55d2hlcmVcbiAgICogQG1ldGhvZCB1cGRhdGVcbiAgICogQG1lbWJlcm9mIE1vbmdvLkNvbGxlY3Rpb25cbiAgICogQGluc3RhbmNlXG4gICAqIEBwYXJhbSB7TW9uZ29TZWxlY3Rvcn0gc2VsZWN0b3IgU3BlY2lmaWVzIHdoaWNoIGRvY3VtZW50cyB0byBtb2RpZnlcbiAgICogQHBhcmFtIHtNb25nb01vZGlmaWVyfSBtb2RpZmllciBTcGVjaWZpZXMgaG93IHRvIG1vZGlmeSB0aGUgZG9jdW1lbnRzXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBbb3B0aW9uc11cbiAgICogQHBhcmFtIHtCb29sZWFufSBvcHRpb25zLm11bHRpIFRydWUgdG8gbW9kaWZ5IGFsbCBtYXRjaGluZyBkb2N1bWVudHM7IGZhbHNlIHRvIG9ubHkgbW9kaWZ5IG9uZSBvZiB0aGUgbWF0Y2hpbmcgZG9jdW1lbnRzICh0aGUgZGVmYXVsdCkuXG4gICAqIEBwYXJhbSB7Qm9vbGVhbn0gb3B0aW9ucy51cHNlcnQgVHJ1ZSB0byBpbnNlcnQgYSBkb2N1bWVudCBpZiBubyBtYXRjaGluZyBkb2N1bWVudHMgYXJlIGZvdW5kLlxuICAgKiBAcGFyYW0ge0FycmF5fSBvcHRpb25zLmFycmF5RmlsdGVycyBPcHRpb25hbC4gVXNlZCBpbiBjb21iaW5hdGlvbiB3aXRoIE1vbmdvREIgW2ZpbHRlcmVkIHBvc2l0aW9uYWwgb3BlcmF0b3JdKGh0dHBzOi8vZG9jcy5tb25nb2RiLmNvbS9tYW51YWwvcmVmZXJlbmNlL29wZXJhdG9yL3VwZGF0ZS9wb3NpdGlvbmFsLWZpbHRlcmVkLykgdG8gc3BlY2lmeSB3aGljaCBlbGVtZW50cyB0byBtb2RpZnkgaW4gYW4gYXJyYXkgZmllbGQuXG4gICAqL1xuICB1cGRhdGVBc3luYyhzZWxlY3RvciwgbW9kaWZpZXIsIC4uLm9wdGlvbnNBbmRDYWxsYmFjaykge1xuXG4gICAgLy8gV2UndmUgYWxyZWFkeSBwb3BwZWQgb2ZmIHRoZSBjYWxsYmFjaywgc28gd2UgYXJlIGxlZnQgd2l0aCBhbiBhcnJheVxuICAgIC8vIG9mIG9uZSBvciB6ZXJvIGl0ZW1zXG4gICAgY29uc3Qgb3B0aW9ucyA9IHsgLi4uKG9wdGlvbnNBbmRDYWxsYmFja1swXSB8fCBudWxsKSB9O1xuICAgIGxldCBpbnNlcnRlZElkO1xuICAgIGlmIChvcHRpb25zICYmIG9wdGlvbnMudXBzZXJ0KSB7XG4gICAgICAvLyBzZXQgYGluc2VydGVkSWRgIGlmIGFic2VudC4gIGBpbnNlcnRlZElkYCBpcyBhIE1ldGVvciBleHRlbnNpb24uXG4gICAgICBpZiAob3B0aW9ucy5pbnNlcnRlZElkKSB7XG4gICAgICAgIGlmIChcbiAgICAgICAgICAhKFxuICAgICAgICAgICAgdHlwZW9mIG9wdGlvbnMuaW5zZXJ0ZWRJZCA9PT0gJ3N0cmluZycgfHxcbiAgICAgICAgICAgIG9wdGlvbnMuaW5zZXJ0ZWRJZCBpbnN0YW5jZW9mIE1vbmdvLk9iamVjdElEXG4gICAgICAgICAgKVxuICAgICAgICApXG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdpbnNlcnRlZElkIG11c3QgYmUgc3RyaW5nIG9yIE9iamVjdElEJyk7XG4gICAgICAgIGluc2VydGVkSWQgPSBvcHRpb25zLmluc2VydGVkSWQ7XG4gICAgICB9IGVsc2UgaWYgKCFzZWxlY3RvciB8fCAhc2VsZWN0b3IuX2lkKSB7XG4gICAgICAgIGluc2VydGVkSWQgPSB0aGlzLl9tYWtlTmV3SUQoKTtcbiAgICAgICAgb3B0aW9ucy5nZW5lcmF0ZWRJZCA9IHRydWU7XG4gICAgICAgIG9wdGlvbnMuaW5zZXJ0ZWRJZCA9IGluc2VydGVkSWQ7XG4gICAgICB9XG4gICAgfVxuXG4gICAgc2VsZWN0b3IgPSBNb25nby5Db2xsZWN0aW9uLl9yZXdyaXRlU2VsZWN0b3Ioc2VsZWN0b3IsIHtcbiAgICAgIGZhbGxiYWNrSWQ6IGluc2VydGVkSWQsXG4gICAgfSk7XG5cbiAgICBpZiAodGhpcy5faXNSZW1vdGVDb2xsZWN0aW9uKCkpIHtcbiAgICAgIGNvbnN0IGFyZ3MgPSBbc2VsZWN0b3IsIG1vZGlmaWVyLCBvcHRpb25zXTtcblxuICAgICAgcmV0dXJuIHRoaXMuX2NhbGxNdXRhdG9yTWV0aG9kQXN5bmMoJ3VwZGF0ZUFzeW5jJywgYXJncywgb3B0aW9ucyk7XG4gICAgfVxuXG4gICAgLy8gaXQncyBteSBjb2xsZWN0aW9uLiAgZGVzY2VuZCBpbnRvIHRoZSBjb2xsZWN0aW9uIG9iamVjdFxuICAgIC8vIGFuZCBwcm9wYWdhdGUgYW55IGV4Y2VwdGlvbi5cbiAgICAgIC8vIElmIHRoZSB1c2VyIHByb3ZpZGVkIGEgY2FsbGJhY2sgYW5kIHRoZSBjb2xsZWN0aW9uIGltcGxlbWVudHMgdGhpc1xuICAgICAgLy8gb3BlcmF0aW9uIGFzeW5jaHJvbm91c2x5LCB0aGVuIHF1ZXJ5UmV0IHdpbGwgYmUgdW5kZWZpbmVkLCBhbmQgdGhlXG4gICAgICAvLyByZXN1bHQgd2lsbCBiZSByZXR1cm5lZCB0aHJvdWdoIHRoZSBjYWxsYmFjayBpbnN0ZWFkLlxuXG4gICAgcmV0dXJuIHRoaXMuX2NvbGxlY3Rpb24udXBkYXRlQXN5bmMoXG4gICAgICBzZWxlY3RvcixcbiAgICAgIG1vZGlmaWVyLFxuICAgICAgb3B0aW9uc1xuICAgICk7XG4gIH0sXG5cbiAgLyoqXG4gICAqIEBzdW1tYXJ5IEFzeW5jaHJvbm91c2x5IG1vZGlmaWVzIG9uZSBvciBtb3JlIGRvY3VtZW50cyBpbiB0aGUgY29sbGVjdGlvbi4gUmV0dXJucyB0aGUgbnVtYmVyIG9mIG1hdGNoZWQgZG9jdW1lbnRzLlxuICAgKiBAbG9jdXMgQW55d2hlcmVcbiAgICogQG1ldGhvZCB1cGRhdGVcbiAgICogQG1lbWJlcm9mIE1vbmdvLkNvbGxlY3Rpb25cbiAgICogQGluc3RhbmNlXG4gICAqIEBwYXJhbSB7TW9uZ29TZWxlY3Rvcn0gc2VsZWN0b3IgU3BlY2lmaWVzIHdoaWNoIGRvY3VtZW50cyB0byBtb2RpZnlcbiAgICogQHBhcmFtIHtNb25nb01vZGlmaWVyfSBtb2RpZmllciBTcGVjaWZpZXMgaG93IHRvIG1vZGlmeSB0aGUgZG9jdW1lbnRzXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBbb3B0aW9uc11cbiAgICogQHBhcmFtIHtCb29sZWFufSBvcHRpb25zLm11bHRpIFRydWUgdG8gbW9kaWZ5IGFsbCBtYXRjaGluZyBkb2N1bWVudHM7IGZhbHNlIHRvIG9ubHkgbW9kaWZ5IG9uZSBvZiB0aGUgbWF0Y2hpbmcgZG9jdW1lbnRzICh0aGUgZGVmYXVsdCkuXG4gICAqIEBwYXJhbSB7Qm9vbGVhbn0gb3B0aW9ucy51cHNlcnQgVHJ1ZSB0byBpbnNlcnQgYSBkb2N1bWVudCBpZiBubyBtYXRjaGluZyBkb2N1bWVudHMgYXJlIGZvdW5kLlxuICAgKiBAcGFyYW0ge0FycmF5fSBvcHRpb25zLmFycmF5RmlsdGVycyBPcHRpb25hbC4gVXNlZCBpbiBjb21iaW5hdGlvbiB3aXRoIE1vbmdvREIgW2ZpbHRlcmVkIHBvc2l0aW9uYWwgb3BlcmF0b3JdKGh0dHBzOi8vZG9jcy5tb25nb2RiLmNvbS9tYW51YWwvcmVmZXJlbmNlL29wZXJhdG9yL3VwZGF0ZS9wb3NpdGlvbmFsLWZpbHRlcmVkLykgdG8gc3BlY2lmeSB3aGljaCBlbGVtZW50cyB0byBtb2RpZnkgaW4gYW4gYXJyYXkgZmllbGQuXG4gICAqIEBwYXJhbSB7RnVuY3Rpb259IFtjYWxsYmFja10gT3B0aW9uYWwuICBJZiBwcmVzZW50LCBjYWxsZWQgd2l0aCBhbiBlcnJvciBvYmplY3QgYXMgdGhlIGZpcnN0IGFyZ3VtZW50IGFuZCwgaWYgbm8gZXJyb3IsIHRoZSBudW1iZXIgb2YgYWZmZWN0ZWQgZG9jdW1lbnRzIGFzIHRoZSBzZWNvbmQuXG4gICAqL1xuICB1cGRhdGUoc2VsZWN0b3IsIG1vZGlmaWVyLCAuLi5vcHRpb25zQW5kQ2FsbGJhY2spIHtcbiAgICBjb25zdCBjYWxsYmFjayA9IHBvcENhbGxiYWNrRnJvbUFyZ3Mob3B0aW9uc0FuZENhbGxiYWNrKTtcblxuICAgIC8vIFdlJ3ZlIGFscmVhZHkgcG9wcGVkIG9mZiB0aGUgY2FsbGJhY2ssIHNvIHdlIGFyZSBsZWZ0IHdpdGggYW4gYXJyYXlcbiAgICAvLyBvZiBvbmUgb3IgemVybyBpdGVtc1xuICAgIGNvbnN0IG9wdGlvbnMgPSB7IC4uLihvcHRpb25zQW5kQ2FsbGJhY2tbMF0gfHwgbnVsbCkgfTtcbiAgICBsZXQgaW5zZXJ0ZWRJZDtcbiAgICBpZiAob3B0aW9ucyAmJiBvcHRpb25zLnVwc2VydCkge1xuICAgICAgLy8gc2V0IGBpbnNlcnRlZElkYCBpZiBhYnNlbnQuICBgaW5zZXJ0ZWRJZGAgaXMgYSBNZXRlb3IgZXh0ZW5zaW9uLlxuICAgICAgaWYgKG9wdGlvbnMuaW5zZXJ0ZWRJZCkge1xuICAgICAgICBpZiAoXG4gICAgICAgICAgIShcbiAgICAgICAgICAgIHR5cGVvZiBvcHRpb25zLmluc2VydGVkSWQgPT09ICdzdHJpbmcnIHx8XG4gICAgICAgICAgICBvcHRpb25zLmluc2VydGVkSWQgaW5zdGFuY2VvZiBNb25nby5PYmplY3RJRFxuICAgICAgICAgIClcbiAgICAgICAgKVxuICAgICAgICAgIHRocm93IG5ldyBFcnJvcignaW5zZXJ0ZWRJZCBtdXN0IGJlIHN0cmluZyBvciBPYmplY3RJRCcpO1xuICAgICAgICBpbnNlcnRlZElkID0gb3B0aW9ucy5pbnNlcnRlZElkO1xuICAgICAgfSBlbHNlIGlmICghc2VsZWN0b3IgfHwgIXNlbGVjdG9yLl9pZCkge1xuICAgICAgICBpbnNlcnRlZElkID0gdGhpcy5fbWFrZU5ld0lEKCk7XG4gICAgICAgIG9wdGlvbnMuZ2VuZXJhdGVkSWQgPSB0cnVlO1xuICAgICAgICBvcHRpb25zLmluc2VydGVkSWQgPSBpbnNlcnRlZElkO1xuICAgICAgfVxuICAgIH1cblxuICAgIHNlbGVjdG9yID0gTW9uZ28uQ29sbGVjdGlvbi5fcmV3cml0ZVNlbGVjdG9yKHNlbGVjdG9yLCB7XG4gICAgICBmYWxsYmFja0lkOiBpbnNlcnRlZElkLFxuICAgIH0pO1xuXG4gICAgY29uc3Qgd3JhcHBlZENhbGxiYWNrID0gd3JhcENhbGxiYWNrKGNhbGxiYWNrKTtcblxuICAgIGlmICh0aGlzLl9pc1JlbW90ZUNvbGxlY3Rpb24oKSkge1xuICAgICAgY29uc3QgYXJncyA9IFtzZWxlY3RvciwgbW9kaWZpZXIsIG9wdGlvbnNdO1xuICAgICAgcmV0dXJuIHRoaXMuX2NhbGxNdXRhdG9yTWV0aG9kKCd1cGRhdGUnLCBhcmdzLCBjYWxsYmFjayk7XG4gICAgfVxuXG4gICAgLy8gaXQncyBteSBjb2xsZWN0aW9uLiAgZGVzY2VuZCBpbnRvIHRoZSBjb2xsZWN0aW9uIG9iamVjdFxuICAgIC8vIGFuZCBwcm9wYWdhdGUgYW55IGV4Y2VwdGlvbi5cbiAgICAvLyBJZiB0aGUgdXNlciBwcm92aWRlZCBhIGNhbGxiYWNrIGFuZCB0aGUgY29sbGVjdGlvbiBpbXBsZW1lbnRzIHRoaXNcbiAgICAvLyBvcGVyYXRpb24gYXN5bmNocm9ub3VzbHksIHRoZW4gcXVlcnlSZXQgd2lsbCBiZSB1bmRlZmluZWQsIGFuZCB0aGVcbiAgICAvLyByZXN1bHQgd2lsbCBiZSByZXR1cm5lZCB0aHJvdWdoIHRoZSBjYWxsYmFjayBpbnN0ZWFkLlxuICAgIC8vY29uc29sZS5sb2coe2NhbGxiYWNrLCBvcHRpb25zLCBzZWxlY3RvciwgbW9kaWZpZXIsIGNvbGw6IHRoaXMuX2NvbGxlY3Rpb259KTtcbiAgICB0cnkge1xuICAgICAgLy8gSWYgdGhlIHVzZXIgcHJvdmlkZWQgYSBjYWxsYmFjayBhbmQgdGhlIGNvbGxlY3Rpb24gaW1wbGVtZW50cyB0aGlzXG4gICAgICAvLyBvcGVyYXRpb24gYXN5bmNocm9ub3VzbHksIHRoZW4gcXVlcnlSZXQgd2lsbCBiZSB1bmRlZmluZWQsIGFuZCB0aGVcbiAgICAgIC8vIHJlc3VsdCB3aWxsIGJlIHJldHVybmVkIHRocm91Z2ggdGhlIGNhbGxiYWNrIGluc3RlYWQuXG4gICAgICByZXR1cm4gdGhpcy5fY29sbGVjdGlvbi51cGRhdGUoXG4gICAgICAgIHNlbGVjdG9yLFxuICAgICAgICBtb2RpZmllcixcbiAgICAgICAgb3B0aW9ucyxcbiAgICAgICAgd3JhcHBlZENhbGxiYWNrXG4gICAgICApO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGlmIChjYWxsYmFjaykge1xuICAgICAgICBjYWxsYmFjayhlKTtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICB9XG4gICAgICB0aHJvdyBlO1xuICAgIH1cbiAgfSxcblxuICAvKipcbiAgICogQHN1bW1hcnkgQXN5bmNocm9ub3VzbHkgcmVtb3ZlcyBkb2N1bWVudHMgZnJvbSB0aGUgY29sbGVjdGlvbi5cbiAgICogQGxvY3VzIEFueXdoZXJlXG4gICAqIEBtZXRob2QgcmVtb3ZlXG4gICAqIEBtZW1iZXJvZiBNb25nby5Db2xsZWN0aW9uXG4gICAqIEBpbnN0YW5jZVxuICAgKiBAcGFyYW0ge01vbmdvU2VsZWN0b3J9IHNlbGVjdG9yIFNwZWNpZmllcyB3aGljaCBkb2N1bWVudHMgdG8gcmVtb3ZlXG4gICAqL1xuICByZW1vdmVBc3luYyhzZWxlY3Rvciwgb3B0aW9ucyA9IHt9KSB7XG4gICAgc2VsZWN0b3IgPSBNb25nby5Db2xsZWN0aW9uLl9yZXdyaXRlU2VsZWN0b3Ioc2VsZWN0b3IpO1xuXG4gICAgaWYgKHRoaXMuX2lzUmVtb3RlQ29sbGVjdGlvbigpKSB7XG4gICAgICByZXR1cm4gdGhpcy5fY2FsbE11dGF0b3JNZXRob2RBc3luYygncmVtb3ZlQXN5bmMnLCBbc2VsZWN0b3JdLCBvcHRpb25zKTtcbiAgICB9XG5cbiAgICAvLyBpdCdzIG15IGNvbGxlY3Rpb24uICBkZXNjZW5kIGludG8gdGhlIGNvbGxlY3Rpb24xIG9iamVjdFxuICAgIC8vIGFuZCBwcm9wYWdhdGUgYW55IGV4Y2VwdGlvbi5cbiAgICByZXR1cm4gdGhpcy5fY29sbGVjdGlvbi5yZW1vdmVBc3luYyhzZWxlY3Rvcik7XG4gIH0sXG5cbiAgLyoqXG4gICAqIEBzdW1tYXJ5IFJlbW92ZSBkb2N1bWVudHMgZnJvbSB0aGUgY29sbGVjdGlvblxuICAgKiBAbG9jdXMgQW55d2hlcmVcbiAgICogQG1ldGhvZCByZW1vdmVcbiAgICogQG1lbWJlcm9mIE1vbmdvLkNvbGxlY3Rpb25cbiAgICogQGluc3RhbmNlXG4gICAqIEBwYXJhbSB7TW9uZ29TZWxlY3Rvcn0gc2VsZWN0b3IgU3BlY2lmaWVzIHdoaWNoIGRvY3VtZW50cyB0byByZW1vdmVcbiAgICogQHBhcmFtIHtGdW5jdGlvbn0gW2NhbGxiYWNrXSBPcHRpb25hbC4gIElmIHByZXNlbnQsIGNhbGxlZCB3aXRoIGFuIGVycm9yIG9iamVjdCBhcyB0aGUgZmlyc3QgYXJndW1lbnQgYW5kLCBpZiBubyBlcnJvciwgdGhlIG51bWJlciBvZiBhZmZlY3RlZCBkb2N1bWVudHMgYXMgdGhlIHNlY29uZC5cbiAgICovXG4gIHJlbW92ZShzZWxlY3RvciwgY2FsbGJhY2spIHtcbiAgICBzZWxlY3RvciA9IE1vbmdvLkNvbGxlY3Rpb24uX3Jld3JpdGVTZWxlY3RvcihzZWxlY3Rvcik7XG5cbiAgICBpZiAodGhpcy5faXNSZW1vdGVDb2xsZWN0aW9uKCkpIHtcbiAgICAgIHJldHVybiB0aGlzLl9jYWxsTXV0YXRvck1ldGhvZCgncmVtb3ZlJywgW3NlbGVjdG9yXSwgY2FsbGJhY2spO1xuICAgIH1cblxuXG4gICAgLy8gaXQncyBteSBjb2xsZWN0aW9uLiAgZGVzY2VuZCBpbnRvIHRoZSBjb2xsZWN0aW9uMSBvYmplY3RcbiAgICAvLyBhbmQgcHJvcGFnYXRlIGFueSBleGNlcHRpb24uXG4gICAgcmV0dXJuIHRoaXMuX2NvbGxlY3Rpb24ucmVtb3ZlKHNlbGVjdG9yKTtcbiAgfSxcblxuXG4gIC8vIERldGVybWluZSBpZiB0aGlzIGNvbGxlY3Rpb24gaXMgc2ltcGx5IGEgbWluaW1vbmdvIHJlcHJlc2VudGF0aW9uIG9mIGEgcmVhbFxuICAvLyBkYXRhYmFzZSBvbiBhbm90aGVyIHNlcnZlclxuICBfaXNSZW1vdGVDb2xsZWN0aW9uKCkge1xuICAgIC8vIFhYWCBzZWUgI01ldGVvclNlcnZlck51bGxcbiAgICByZXR1cm4gdGhpcy5fY29ubmVjdGlvbiAmJiB0aGlzLl9jb25uZWN0aW9uICE9PSBNZXRlb3Iuc2VydmVyO1xuICB9LFxuXG4gIC8qKlxuICAgKiBAc3VtbWFyeSBBc3luY2hyb25vdXNseSBtb2RpZmllcyBvbmUgb3IgbW9yZSBkb2N1bWVudHMgaW4gdGhlIGNvbGxlY3Rpb24sIG9yIGluc2VydCBvbmUgaWYgbm8gbWF0Y2hpbmcgZG9jdW1lbnRzIHdlcmUgZm91bmQuIFJldHVybnMgYW4gb2JqZWN0IHdpdGgga2V5cyBgbnVtYmVyQWZmZWN0ZWRgICh0aGUgbnVtYmVyIG9mIGRvY3VtZW50cyBtb2RpZmllZCkgIGFuZCBgaW5zZXJ0ZWRJZGAgKHRoZSB1bmlxdWUgX2lkIG9mIHRoZSBkb2N1bWVudCB0aGF0IHdhcyBpbnNlcnRlZCwgaWYgYW55KS5cbiAgICogQGxvY3VzIEFueXdoZXJlXG4gICAqIEBtZXRob2QgdXBzZXJ0XG4gICAqIEBtZW1iZXJvZiBNb25nby5Db2xsZWN0aW9uXG4gICAqIEBpbnN0YW5jZVxuICAgKiBAcGFyYW0ge01vbmdvU2VsZWN0b3J9IHNlbGVjdG9yIFNwZWNpZmllcyB3aGljaCBkb2N1bWVudHMgdG8gbW9kaWZ5XG4gICAqIEBwYXJhbSB7TW9uZ29Nb2RpZmllcn0gbW9kaWZpZXIgU3BlY2lmaWVzIGhvdyB0byBtb2RpZnkgdGhlIGRvY3VtZW50c1xuICAgKiBAcGFyYW0ge09iamVjdH0gW29wdGlvbnNdXG4gICAqIEBwYXJhbSB7Qm9vbGVhbn0gb3B0aW9ucy5tdWx0aSBUcnVlIHRvIG1vZGlmeSBhbGwgbWF0Y2hpbmcgZG9jdW1lbnRzOyBmYWxzZSB0byBvbmx5IG1vZGlmeSBvbmUgb2YgdGhlIG1hdGNoaW5nIGRvY3VtZW50cyAodGhlIGRlZmF1bHQpLlxuICAgKi9cbiAgICBhc3luYyB1cHNlcnRBc3luYyhzZWxlY3RvciwgbW9kaWZpZXIsIG9wdGlvbnMpIHtcbiAgICAgIHJldHVybiB0aGlzLnVwZGF0ZUFzeW5jKFxuICAgICAgICBzZWxlY3RvcixcbiAgICAgICAgbW9kaWZpZXIsXG4gICAgICAgIHtcbiAgICAgICAgICAuLi5vcHRpb25zLFxuICAgICAgICAgIF9yZXR1cm5PYmplY3Q6IHRydWUsXG4gICAgICAgICAgdXBzZXJ0OiB0cnVlLFxuICAgICAgICB9KTtcbiAgICB9LFxuXG5cbiAgLyoqXG4gICAqIEBzdW1tYXJ5IEFzeW5jaHJvbm91c2x5IG1vZGlmaWVzIG9uZSBvciBtb3JlIGRvY3VtZW50cyBpbiB0aGUgY29sbGVjdGlvbiwgb3IgaW5zZXJ0IG9uZSBpZiBubyBtYXRjaGluZyBkb2N1bWVudHMgd2VyZSBmb3VuZC4gUmV0dXJucyBhbiBvYmplY3Qgd2l0aCBrZXlzIGBudW1iZXJBZmZlY3RlZGAgKHRoZSBudW1iZXIgb2YgZG9jdW1lbnRzIG1vZGlmaWVkKSAgYW5kIGBpbnNlcnRlZElkYCAodGhlIHVuaXF1ZSBfaWQgb2YgdGhlIGRvY3VtZW50IHRoYXQgd2FzIGluc2VydGVkLCBpZiBhbnkpLlxuICAgKiBAbG9jdXMgQW55d2hlcmVcbiAgICogQG1ldGhvZCB1cHNlcnRcbiAgICogQG1lbWJlcm9mIE1vbmdvLkNvbGxlY3Rpb25cbiAgICogQGluc3RhbmNlXG4gICAqIEBwYXJhbSB7TW9uZ29TZWxlY3Rvcn0gc2VsZWN0b3IgU3BlY2lmaWVzIHdoaWNoIGRvY3VtZW50cyB0byBtb2RpZnlcbiAgICogQHBhcmFtIHtNb25nb01vZGlmaWVyfSBtb2RpZmllciBTcGVjaWZpZXMgaG93IHRvIG1vZGlmeSB0aGUgZG9jdW1lbnRzXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBbb3B0aW9uc11cbiAgICogQHBhcmFtIHtCb29sZWFufSBvcHRpb25zLm11bHRpIFRydWUgdG8gbW9kaWZ5IGFsbCBtYXRjaGluZyBkb2N1bWVudHM7IGZhbHNlIHRvIG9ubHkgbW9kaWZ5IG9uZSBvZiB0aGUgbWF0Y2hpbmcgZG9jdW1lbnRzICh0aGUgZGVmYXVsdCkuXG4gICAqIEBwYXJhbSB7RnVuY3Rpb259IFtjYWxsYmFja10gT3B0aW9uYWwuICBJZiBwcmVzZW50LCBjYWxsZWQgd2l0aCBhbiBlcnJvciBvYmplY3QgYXMgdGhlIGZpcnN0IGFyZ3VtZW50IGFuZCwgaWYgbm8gZXJyb3IsIHRoZSBudW1iZXIgb2YgYWZmZWN0ZWQgZG9jdW1lbnRzIGFzIHRoZSBzZWNvbmQuXG4gICAqL1xuICB1cHNlcnQoc2VsZWN0b3IsIG1vZGlmaWVyLCBvcHRpb25zLCBjYWxsYmFjaykge1xuICAgIGlmICghY2FsbGJhY2sgJiYgdHlwZW9mIG9wdGlvbnMgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgIGNhbGxiYWNrID0gb3B0aW9ucztcbiAgICAgIG9wdGlvbnMgPSB7fTtcbiAgICB9XG5cbiAgICByZXR1cm4gdGhpcy51cGRhdGUoXG4gICAgICBzZWxlY3RvcixcbiAgICAgIG1vZGlmaWVyLFxuICAgICAge1xuICAgICAgICAuLi5vcHRpb25zLFxuICAgICAgICBfcmV0dXJuT2JqZWN0OiB0cnVlLFxuICAgICAgICB1cHNlcnQ6IHRydWUsXG4gICAgICB9KTtcbiAgfSxcblxuICAvLyBXZSdsbCBhY3R1YWxseSBkZXNpZ24gYW4gaW5kZXggQVBJIGxhdGVyLiBGb3Igbm93LCB3ZSBqdXN0IHBhc3MgdGhyb3VnaCB0b1xuICAvLyBNb25nbydzLCBidXQgbWFrZSBpdCBzeW5jaHJvbm91cy5cbiAgLyoqXG4gICAqIEBzdW1tYXJ5IEFzeW5jaHJvbm91c2x5IGNyZWF0ZXMgdGhlIHNwZWNpZmllZCBpbmRleCBvbiB0aGUgY29sbGVjdGlvbi5cbiAgICogQGxvY3VzIHNlcnZlclxuICAgKiBAbWV0aG9kIGVuc3VyZUluZGV4QXN5bmNcbiAgICogQGRlcHJlY2F0ZWQgaW4gMy4wXG4gICAqIEBtZW1iZXJvZiBNb25nby5Db2xsZWN0aW9uXG4gICAqIEBpbnN0YW5jZVxuICAgKiBAcGFyYW0ge09iamVjdH0gaW5kZXggQSBkb2N1bWVudCB0aGF0IGNvbnRhaW5zIHRoZSBmaWVsZCBhbmQgdmFsdWUgcGFpcnMgd2hlcmUgdGhlIGZpZWxkIGlzIHRoZSBpbmRleCBrZXkgYW5kIHRoZSB2YWx1ZSBkZXNjcmliZXMgdGhlIHR5cGUgb2YgaW5kZXggZm9yIHRoYXQgZmllbGQuIEZvciBhbiBhc2NlbmRpbmcgaW5kZXggb24gYSBmaWVsZCwgc3BlY2lmeSBhIHZhbHVlIG9mIGAxYDsgZm9yIGRlc2NlbmRpbmcgaW5kZXgsIHNwZWNpZnkgYSB2YWx1ZSBvZiBgLTFgLiBVc2UgYHRleHRgIGZvciB0ZXh0IGluZGV4ZXMuXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBbb3B0aW9uc10gQWxsIG9wdGlvbnMgYXJlIGxpc3RlZCBpbiBbTW9uZ29EQiBkb2N1bWVudGF0aW9uXShodHRwczovL2RvY3MubW9uZ29kYi5jb20vbWFudWFsL3JlZmVyZW5jZS9tZXRob2QvZGIuY29sbGVjdGlvbi5jcmVhdGVJbmRleC8jb3B0aW9ucylcbiAgICogQHBhcmFtIHtTdHJpbmd9IG9wdGlvbnMubmFtZSBOYW1lIG9mIHRoZSBpbmRleFxuICAgKiBAcGFyYW0ge0Jvb2xlYW59IG9wdGlvbnMudW5pcXVlIERlZmluZSB0aGF0IHRoZSBpbmRleCB2YWx1ZXMgbXVzdCBiZSB1bmlxdWUsIG1vcmUgYXQgW01vbmdvREIgZG9jdW1lbnRhdGlvbl0oaHR0cHM6Ly9kb2NzLm1vbmdvZGIuY29tL21hbnVhbC9jb3JlL2luZGV4LXVuaXF1ZS8pXG4gICAqIEBwYXJhbSB7Qm9vbGVhbn0gb3B0aW9ucy5zcGFyc2UgRGVmaW5lIHRoYXQgdGhlIGluZGV4IGlzIHNwYXJzZSwgbW9yZSBhdCBbTW9uZ29EQiBkb2N1bWVudGF0aW9uXShodHRwczovL2RvY3MubW9uZ29kYi5jb20vbWFudWFsL2NvcmUvaW5kZXgtc3BhcnNlLylcbiAgICovXG4gIGFzeW5jIGVuc3VyZUluZGV4QXN5bmMoaW5kZXgsIG9wdGlvbnMpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgaWYgKCFzZWxmLl9jb2xsZWN0aW9uLmVuc3VyZUluZGV4QXN5bmMgfHwgIXNlbGYuX2NvbGxlY3Rpb24uY3JlYXRlSW5kZXhBc3luYylcbiAgICAgIHRocm93IG5ldyBFcnJvcignQ2FuIG9ubHkgY2FsbCBjcmVhdGVJbmRleEFzeW5jIG9uIHNlcnZlciBjb2xsZWN0aW9ucycpO1xuICAgIGlmIChzZWxmLl9jb2xsZWN0aW9uLmNyZWF0ZUluZGV4QXN5bmMpIHtcbiAgICAgIGF3YWl0IHNlbGYuX2NvbGxlY3Rpb24uY3JlYXRlSW5kZXhBc3luYyhpbmRleCwgb3B0aW9ucyk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGltcG9ydCB7IExvZyB9IGZyb20gJ21ldGVvci9sb2dnaW5nJztcblxuICAgICAgTG9nLmRlYnVnKGBlbnN1cmVJbmRleEFzeW5jIGhhcyBiZWVuIGRlcHJlY2F0ZWQsIHBsZWFzZSB1c2UgdGhlIG5ldyAnY3JlYXRlSW5kZXhBc3luYycgaW5zdGVhZCR7IG9wdGlvbnM/Lm5hbWUgPyBgLCBpbmRleCBuYW1lOiAkeyBvcHRpb25zLm5hbWUgfWAgOiBgLCBpbmRleDogJHsgSlNPTi5zdHJpbmdpZnkoaW5kZXgpIH1gIH1gKVxuICAgICAgYXdhaXQgc2VsZi5fY29sbGVjdGlvbi5lbnN1cmVJbmRleEFzeW5jKGluZGV4LCBvcHRpb25zKTtcbiAgICB9XG4gIH0sXG5cbiAgLyoqXG4gICAqIEBzdW1tYXJ5IEFzeW5jaHJvbm91c2x5IGNyZWF0ZXMgdGhlIHNwZWNpZmllZCBpbmRleCBvbiB0aGUgY29sbGVjdGlvbi5cbiAgICogQGxvY3VzIHNlcnZlclxuICAgKiBAbWV0aG9kIGNyZWF0ZUluZGV4QXN5bmNcbiAgICogQG1lbWJlcm9mIE1vbmdvLkNvbGxlY3Rpb25cbiAgICogQGluc3RhbmNlXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBpbmRleCBBIGRvY3VtZW50IHRoYXQgY29udGFpbnMgdGhlIGZpZWxkIGFuZCB2YWx1ZSBwYWlycyB3aGVyZSB0aGUgZmllbGQgaXMgdGhlIGluZGV4IGtleSBhbmQgdGhlIHZhbHVlIGRlc2NyaWJlcyB0aGUgdHlwZSBvZiBpbmRleCBmb3IgdGhhdCBmaWVsZC4gRm9yIGFuIGFzY2VuZGluZyBpbmRleCBvbiBhIGZpZWxkLCBzcGVjaWZ5IGEgdmFsdWUgb2YgYDFgOyBmb3IgZGVzY2VuZGluZyBpbmRleCwgc3BlY2lmeSBhIHZhbHVlIG9mIGAtMWAuIFVzZSBgdGV4dGAgZm9yIHRleHQgaW5kZXhlcy5cbiAgICogQHBhcmFtIHtPYmplY3R9IFtvcHRpb25zXSBBbGwgb3B0aW9ucyBhcmUgbGlzdGVkIGluIFtNb25nb0RCIGRvY3VtZW50YXRpb25dKGh0dHBzOi8vZG9jcy5tb25nb2RiLmNvbS9tYW51YWwvcmVmZXJlbmNlL21ldGhvZC9kYi5jb2xsZWN0aW9uLmNyZWF0ZUluZGV4LyNvcHRpb25zKVxuICAgKiBAcGFyYW0ge1N0cmluZ30gb3B0aW9ucy5uYW1lIE5hbWUgb2YgdGhlIGluZGV4XG4gICAqIEBwYXJhbSB7Qm9vbGVhbn0gb3B0aW9ucy51bmlxdWUgRGVmaW5lIHRoYXQgdGhlIGluZGV4IHZhbHVlcyBtdXN0IGJlIHVuaXF1ZSwgbW9yZSBhdCBbTW9uZ29EQiBkb2N1bWVudGF0aW9uXShodHRwczovL2RvY3MubW9uZ29kYi5jb20vbWFudWFsL2NvcmUvaW5kZXgtdW5pcXVlLylcbiAgICogQHBhcmFtIHtCb29sZWFufSBvcHRpb25zLnNwYXJzZSBEZWZpbmUgdGhhdCB0aGUgaW5kZXggaXMgc3BhcnNlLCBtb3JlIGF0IFtNb25nb0RCIGRvY3VtZW50YXRpb25dKGh0dHBzOi8vZG9jcy5tb25nb2RiLmNvbS9tYW51YWwvY29yZS9pbmRleC1zcGFyc2UvKVxuICAgKi9cbiAgYXN5bmMgY3JlYXRlSW5kZXhBc3luYyhpbmRleCwgb3B0aW9ucykge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICBpZiAoIXNlbGYuX2NvbGxlY3Rpb24uY3JlYXRlSW5kZXhBc3luYylcbiAgICAgIHRocm93IG5ldyBFcnJvcignQ2FuIG9ubHkgY2FsbCBjcmVhdGVJbmRleEFzeW5jIG9uIHNlcnZlciBjb2xsZWN0aW9ucycpO1xuXG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IHNlbGYuX2NvbGxlY3Rpb24uY3JlYXRlSW5kZXhBc3luYyhpbmRleCwgb3B0aW9ucyk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgaWYgKFxuICAgICAgICBlLm1lc3NhZ2UuaW5jbHVkZXMoXG4gICAgICAgICAgJ0FuIGVxdWl2YWxlbnQgaW5kZXggYWxyZWFkeSBleGlzdHMgd2l0aCB0aGUgc2FtZSBuYW1lIGJ1dCBkaWZmZXJlbnQgb3B0aW9ucy4nXG4gICAgICAgICkgJiZcbiAgICAgICAgTWV0ZW9yLnNldHRpbmdzPy5wYWNrYWdlcz8ubW9uZ28/LnJlQ3JlYXRlSW5kZXhPbk9wdGlvbk1pc21hdGNoXG4gICAgICApIHtcbiAgICAgICAgaW1wb3J0IHsgTG9nIH0gZnJvbSAnbWV0ZW9yL2xvZ2dpbmcnO1xuXG4gICAgICAgIExvZy5pbmZvKGBSZS1jcmVhdGluZyBpbmRleCAkeyBpbmRleCB9IGZvciAkeyBzZWxmLl9uYW1lIH0gZHVlIHRvIG9wdGlvbnMgbWlzbWF0Y2guYCk7XG4gICAgICAgIGF3YWl0IHNlbGYuX2NvbGxlY3Rpb24uZHJvcEluZGV4QXN5bmMoaW5kZXgpO1xuICAgICAgICBhd2FpdCBzZWxmLl9jb2xsZWN0aW9uLmNyZWF0ZUluZGV4QXN5bmMoaW5kZXgsIG9wdGlvbnMpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihlKTtcbiAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihgQW4gZXJyb3Igb2NjdXJyZWQgd2hlbiBjcmVhdGluZyBhbiBpbmRleCBmb3IgY29sbGVjdGlvbiBcIiR7IHNlbGYuX25hbWUgfTogJHsgZS5tZXNzYWdlIH1gKTtcbiAgICAgIH1cbiAgICB9XG4gIH0sXG5cbiAgLyoqXG4gICAqIEBzdW1tYXJ5IEFzeW5jaHJvbm91c2x5IGNyZWF0ZXMgdGhlIHNwZWNpZmllZCBpbmRleCBvbiB0aGUgY29sbGVjdGlvbi5cbiAgICogQGxvY3VzIHNlcnZlclxuICAgKiBAbWV0aG9kIGNyZWF0ZUluZGV4XG4gICAqIEBtZW1iZXJvZiBNb25nby5Db2xsZWN0aW9uXG4gICAqIEBpbnN0YW5jZVxuICAgKiBAcGFyYW0ge09iamVjdH0gaW5kZXggQSBkb2N1bWVudCB0aGF0IGNvbnRhaW5zIHRoZSBmaWVsZCBhbmQgdmFsdWUgcGFpcnMgd2hlcmUgdGhlIGZpZWxkIGlzIHRoZSBpbmRleCBrZXkgYW5kIHRoZSB2YWx1ZSBkZXNjcmliZXMgdGhlIHR5cGUgb2YgaW5kZXggZm9yIHRoYXQgZmllbGQuIEZvciBhbiBhc2NlbmRpbmcgaW5kZXggb24gYSBmaWVsZCwgc3BlY2lmeSBhIHZhbHVlIG9mIGAxYDsgZm9yIGRlc2NlbmRpbmcgaW5kZXgsIHNwZWNpZnkgYSB2YWx1ZSBvZiBgLTFgLiBVc2UgYHRleHRgIGZvciB0ZXh0IGluZGV4ZXMuXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBbb3B0aW9uc10gQWxsIG9wdGlvbnMgYXJlIGxpc3RlZCBpbiBbTW9uZ29EQiBkb2N1bWVudGF0aW9uXShodHRwczovL2RvY3MubW9uZ29kYi5jb20vbWFudWFsL3JlZmVyZW5jZS9tZXRob2QvZGIuY29sbGVjdGlvbi5jcmVhdGVJbmRleC8jb3B0aW9ucylcbiAgICogQHBhcmFtIHtTdHJpbmd9IG9wdGlvbnMubmFtZSBOYW1lIG9mIHRoZSBpbmRleFxuICAgKiBAcGFyYW0ge0Jvb2xlYW59IG9wdGlvbnMudW5pcXVlIERlZmluZSB0aGF0IHRoZSBpbmRleCB2YWx1ZXMgbXVzdCBiZSB1bmlxdWUsIG1vcmUgYXQgW01vbmdvREIgZG9jdW1lbnRhdGlvbl0oaHR0cHM6Ly9kb2NzLm1vbmdvZGIuY29tL21hbnVhbC9jb3JlL2luZGV4LXVuaXF1ZS8pXG4gICAqIEBwYXJhbSB7Qm9vbGVhbn0gb3B0aW9ucy5zcGFyc2UgRGVmaW5lIHRoYXQgdGhlIGluZGV4IGlzIHNwYXJzZSwgbW9yZSBhdCBbTW9uZ29EQiBkb2N1bWVudGF0aW9uXShodHRwczovL2RvY3MubW9uZ29kYi5jb20vbWFudWFsL2NvcmUvaW5kZXgtc3BhcnNlLylcbiAgICovXG4gIGNyZWF0ZUluZGV4KGluZGV4LCBvcHRpb25zKXtcbiAgICByZXR1cm4gdGhpcy5jcmVhdGVJbmRleEFzeW5jKGluZGV4LCBvcHRpb25zKTtcbiAgfSxcblxuICBhc3luYyBkcm9wSW5kZXhBc3luYyhpbmRleCkge1xuICAgIHZhciBzZWxmID0gdGhpcztcbiAgICBpZiAoIXNlbGYuX2NvbGxlY3Rpb24uZHJvcEluZGV4QXN5bmMpXG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0NhbiBvbmx5IGNhbGwgZHJvcEluZGV4QXN5bmMgb24gc2VydmVyIGNvbGxlY3Rpb25zJyk7XG4gICAgYXdhaXQgc2VsZi5fY29sbGVjdGlvbi5kcm9wSW5kZXhBc3luYyhpbmRleCk7XG4gIH0sXG5cbiAgYXN5bmMgZHJvcENvbGxlY3Rpb25Bc3luYygpIHtcbiAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgaWYgKCFzZWxmLl9jb2xsZWN0aW9uLmRyb3BDb2xsZWN0aW9uQXN5bmMpXG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0NhbiBvbmx5IGNhbGwgZHJvcENvbGxlY3Rpb25Bc3luYyBvbiBzZXJ2ZXIgY29sbGVjdGlvbnMnKTtcbiAgIGF3YWl0IHNlbGYuX2NvbGxlY3Rpb24uZHJvcENvbGxlY3Rpb25Bc3luYygpO1xuICB9LFxuXG4gIGFzeW5jIGNyZWF0ZUNhcHBlZENvbGxlY3Rpb25Bc3luYyhieXRlU2l6ZSwgbWF4RG9jdW1lbnRzKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgIGlmICghIGF3YWl0IHNlbGYuX2NvbGxlY3Rpb24uY3JlYXRlQ2FwcGVkQ29sbGVjdGlvbkFzeW5jKVxuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAnQ2FuIG9ubHkgY2FsbCBjcmVhdGVDYXBwZWRDb2xsZWN0aW9uQXN5bmMgb24gc2VydmVyIGNvbGxlY3Rpb25zJ1xuICAgICAgKTtcbiAgICBhd2FpdCBzZWxmLl9jb2xsZWN0aW9uLmNyZWF0ZUNhcHBlZENvbGxlY3Rpb25Bc3luYyhieXRlU2l6ZSwgbWF4RG9jdW1lbnRzKTtcbiAgfSxcblxuICAvKipcbiAgICogQHN1bW1hcnkgUmV0dXJucyB0aGUgW2BDb2xsZWN0aW9uYF0oaHR0cDovL21vbmdvZGIuZ2l0aHViLmlvL25vZGUtbW9uZ29kYi1uYXRpdmUvMy4wL2FwaS9Db2xsZWN0aW9uLmh0bWwpIG9iamVjdCBjb3JyZXNwb25kaW5nIHRvIHRoaXMgY29sbGVjdGlvbiBmcm9tIHRoZSBbbnBtIGBtb25nb2RiYCBkcml2ZXIgbW9kdWxlXShodHRwczovL3d3dy5ucG1qcy5jb20vcGFja2FnZS9tb25nb2RiKSB3aGljaCBpcyB3cmFwcGVkIGJ5IGBNb25nby5Db2xsZWN0aW9uYC5cbiAgICogQGxvY3VzIFNlcnZlclxuICAgKiBAbWVtYmVyb2YgTW9uZ28uQ29sbGVjdGlvblxuICAgKiBAaW5zdGFuY2VcbiAgICovXG4gIHJhd0NvbGxlY3Rpb24oKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgIGlmICghc2VsZi5fY29sbGVjdGlvbi5yYXdDb2xsZWN0aW9uKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0NhbiBvbmx5IGNhbGwgcmF3Q29sbGVjdGlvbiBvbiBzZXJ2ZXIgY29sbGVjdGlvbnMnKTtcbiAgICB9XG4gICAgcmV0dXJuIHNlbGYuX2NvbGxlY3Rpb24ucmF3Q29sbGVjdGlvbigpO1xuICB9LFxuXG4gIC8qKlxuICAgKiBAc3VtbWFyeSBSZXR1cm5zIHRoZSBbYERiYF0oaHR0cDovL21vbmdvZGIuZ2l0aHViLmlvL25vZGUtbW9uZ29kYi1uYXRpdmUvMy4wL2FwaS9EYi5odG1sKSBvYmplY3QgY29ycmVzcG9uZGluZyB0byB0aGlzIGNvbGxlY3Rpb24ncyBkYXRhYmFzZSBjb25uZWN0aW9uIGZyb20gdGhlIFtucG0gYG1vbmdvZGJgIGRyaXZlciBtb2R1bGVdKGh0dHBzOi8vd3d3Lm5wbWpzLmNvbS9wYWNrYWdlL21vbmdvZGIpIHdoaWNoIGlzIHdyYXBwZWQgYnkgYE1vbmdvLkNvbGxlY3Rpb25gLlxuICAgKiBAbG9jdXMgU2VydmVyXG4gICAqIEBtZW1iZXJvZiBNb25nby5Db2xsZWN0aW9uXG4gICAqIEBpbnN0YW5jZVxuICAgKi9cbiAgcmF3RGF0YWJhc2UoKSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgIGlmICghKHNlbGYuX2RyaXZlci5tb25nbyAmJiBzZWxmLl9kcml2ZXIubW9uZ28uZGIpKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0NhbiBvbmx5IGNhbGwgcmF3RGF0YWJhc2Ugb24gc2VydmVyIGNvbGxlY3Rpb25zJyk7XG4gICAgfVxuICAgIHJldHVybiBzZWxmLl9kcml2ZXIubW9uZ28uZGI7XG4gIH0sXG59KTtcblxuLy8gQ29udmVydCB0aGUgY2FsbGJhY2sgdG8gbm90IHJldHVybiBhIHJlc3VsdCBpZiB0aGVyZSBpcyBhbiBlcnJvclxuZnVuY3Rpb24gd3JhcENhbGxiYWNrKGNhbGxiYWNrLCBjb252ZXJ0UmVzdWx0KSB7XG4gIHJldHVybiAoXG4gICAgY2FsbGJhY2sgJiZcbiAgICBmdW5jdGlvbihlcnJvciwgcmVzdWx0KSB7XG4gICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgY2FsbGJhY2soZXJyb3IpO1xuICAgICAgfSBlbHNlIGlmICh0eXBlb2YgY29udmVydFJlc3VsdCA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICBjYWxsYmFjayhlcnJvciwgY29udmVydFJlc3VsdChyZXN1bHQpKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNhbGxiYWNrKGVycm9yLCByZXN1bHQpO1xuICAgICAgfVxuICAgIH1cbiAgKTtcbn1cblxuLyoqXG4gKiBAc3VtbWFyeSBDcmVhdGUgYSBNb25nby1zdHlsZSBgT2JqZWN0SURgLiAgSWYgeW91IGRvbid0IHNwZWNpZnkgYSBgaGV4U3RyaW5nYCwgdGhlIGBPYmplY3RJRGAgd2lsbCBiZSBnZW5lcmF0ZWQgcmFuZG9tbHkgKG5vdCB1c2luZyBNb25nb0RCJ3MgSUQgY29uc3RydWN0aW9uIHJ1bGVzKS5cbiAqIEBsb2N1cyBBbnl3aGVyZVxuICogQGNsYXNzXG4gKiBAcGFyYW0ge1N0cmluZ30gW2hleFN0cmluZ10gT3B0aW9uYWwuICBUaGUgMjQtY2hhcmFjdGVyIGhleGFkZWNpbWFsIGNvbnRlbnRzIG9mIHRoZSBPYmplY3RJRCB0byBjcmVhdGVcbiAqL1xuTW9uZ28uT2JqZWN0SUQgPSBNb25nb0lELk9iamVjdElEO1xuXG4vKipcbiAqIEBzdW1tYXJ5IFRvIGNyZWF0ZSBhIGN1cnNvciwgdXNlIGZpbmQuIFRvIGFjY2VzcyB0aGUgZG9jdW1lbnRzIGluIGEgY3Vyc29yLCB1c2UgZm9yRWFjaCwgbWFwLCBvciBmZXRjaC5cbiAqIEBjbGFzc1xuICogQGluc3RhbmNlTmFtZSBjdXJzb3JcbiAqL1xuTW9uZ28uQ3Vyc29yID0gTG9jYWxDb2xsZWN0aW9uLkN1cnNvcjtcblxuLyoqXG4gKiBAZGVwcmVjYXRlZCBpbiAwLjkuMVxuICovXG5Nb25nby5Db2xsZWN0aW9uLkN1cnNvciA9IE1vbmdvLkN1cnNvcjtcblxuLyoqXG4gKiBAZGVwcmVjYXRlZCBpbiAwLjkuMVxuICovXG5Nb25nby5Db2xsZWN0aW9uLk9iamVjdElEID0gTW9uZ28uT2JqZWN0SUQ7XG5cbi8qKlxuICogQGRlcHJlY2F0ZWQgaW4gMC45LjFcbiAqL1xuTWV0ZW9yLkNvbGxlY3Rpb24gPSBNb25nby5Db2xsZWN0aW9uO1xuXG4vLyBBbGxvdyBkZW55IHN0dWZmIGlzIG5vdyBpbiB0aGUgYWxsb3ctZGVueSBwYWNrYWdlXG5PYmplY3QuYXNzaWduKE1vbmdvLkNvbGxlY3Rpb24ucHJvdG90eXBlLCBBbGxvd0RlbnkuQ29sbGVjdGlvblByb3RvdHlwZSk7XG5cbmZ1bmN0aW9uIHBvcENhbGxiYWNrRnJvbUFyZ3MoYXJncykge1xuICAvLyBQdWxsIG9mZiBhbnkgY2FsbGJhY2sgKG9yIHBlcmhhcHMgYSAnY2FsbGJhY2snIHZhcmlhYmxlIHRoYXQgd2FzIHBhc3NlZFxuICAvLyBpbiB1bmRlZmluZWQsIGxpa2UgaG93ICd1cHNlcnQnIGRvZXMgaXQpLlxuICBpZiAoXG4gICAgYXJncy5sZW5ndGggJiZcbiAgICAoYXJnc1thcmdzLmxlbmd0aCAtIDFdID09PSB1bmRlZmluZWQgfHxcbiAgICAgIGFyZ3NbYXJncy5sZW5ndGggLSAxXSBpbnN0YW5jZW9mIEZ1bmN0aW9uKVxuICApIHtcbiAgICByZXR1cm4gYXJncy5wb3AoKTtcbiAgfVxufVxuIiwiLyoqXG4gKiBAc3VtbWFyeSBBbGxvd3MgZm9yIHVzZXIgc3BlY2lmaWVkIGNvbm5lY3Rpb24gb3B0aW9uc1xuICogQGV4YW1wbGUgaHR0cDovL21vbmdvZGIuZ2l0aHViLmlvL25vZGUtbW9uZ29kYi1uYXRpdmUvMy4wL3JlZmVyZW5jZS9jb25uZWN0aW5nL2Nvbm5lY3Rpb24tc2V0dGluZ3MvXG4gKiBAbG9jdXMgU2VydmVyXG4gKiBAcGFyYW0ge09iamVjdH0gb3B0aW9ucyBVc2VyIHNwZWNpZmllZCBNb25nbyBjb25uZWN0aW9uIG9wdGlvbnNcbiAqL1xuTW9uZ28uc2V0Q29ubmVjdGlvbk9wdGlvbnMgPSBmdW5jdGlvbiBzZXRDb25uZWN0aW9uT3B0aW9ucyAob3B0aW9ucykge1xuICBjaGVjayhvcHRpb25zLCBPYmplY3QpO1xuICBNb25nby5fY29ubmVjdGlvbk9wdGlvbnMgPSBvcHRpb25zO1xufTsiLCJleHBvcnQgY29uc3Qgbm9ybWFsaXplUHJvamVjdGlvbiA9IG9wdGlvbnMgPT4ge1xuICAvLyB0cmFuc2Zvcm0gZmllbGRzIGtleSBpbiBwcm9qZWN0aW9uXG4gIGNvbnN0IHsgZmllbGRzLCBwcm9qZWN0aW9uLCAuLi5vdGhlck9wdGlvbnMgfSA9IG9wdGlvbnMgfHwge307XG4gIC8vIFRPRE86IGVuYWJsZSB0aGlzIGNvbW1lbnQgd2hlbiBkZXByZWNhdGluZyB0aGUgZmllbGRzIG9wdGlvblxuICAvLyBMb2cuZGVidWcoYGZpZWxkcyBvcHRpb24gaGFzIGJlZW4gZGVwcmVjYXRlZCwgcGxlYXNlIHVzZSB0aGUgbmV3ICdwcm9qZWN0aW9uJyBpbnN0ZWFkYClcblxuICByZXR1cm4ge1xuICAgIC4uLm90aGVyT3B0aW9ucyxcbiAgICAuLi4ocHJvamVjdGlvbiB8fCBmaWVsZHMgPyB7IHByb2plY3Rpb246IGZpZWxkcyB8fCBwcm9qZWN0aW9uIH0gOiB7fSksXG4gIH07XG59O1xuIl19
