Package["core-runtime"].queue("null",function () {/* Imports for global scope */

MongoInternals = Package.mongo.MongoInternals;
Mongo = Package.mongo.Mongo;
ECMAScript = Package.ecmascript.ECMAScript;
Meteor = Package.meteor.Meteor;
global = Package.meteor.global;
meteorEnv = Package.meteor.meteorEnv;
EmitterPromise = Package.meteor.EmitterPromise;
WebApp = Package.webapp.WebApp;
WebAppInternals = Package.webapp.WebAppInternals;
main = Package.webapp.main;
DDP = Package['ddp-client'].DDP;
DDPServer = Package['ddp-server'].DDPServer;
LaunchScreen = Package['launch-screen'].LaunchScreen;
meteorInstall = Package.modules.meteorInstall;
Promise = Package.promise.Promise;
Autoupdate = Package.autoupdate.Autoupdate;

var require = meteorInstall({"imports":{"api":{"inputs":{"inputs.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                        //
// imports/api/inputs/inputs.js                                                           //
//                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////
                                                                                          //
!module.wrapAsync(async function (module, __reifyWaitForDeps__, __reify_async_result__) {
  "use strict";
  try {
    module.export({
      InputsCollection: () => InputsCollection
    });
    let Mongo;
    module.link("meteor/mongo", {
      Mongo(v) {
        Mongo = v;
      }
    }, 0);
    if (__reifyWaitForDeps__()) (await __reifyWaitForDeps__())();
    const InputsCollection = new Mongo.Collection("inputs");
    __reify_async_result__();
  } catch (_reifyError) {
    return __reify_async_result__(_reifyError);
  }
  __reify_async_result__()
}, {
  self: this,
  async: false
});
////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                        //
// imports/api/inputs/publications.js                                                     //
//                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////
                                                                                          //
!module.wrapAsync(async function (module, __reifyWaitForDeps__, __reify_async_result__) {
  "use strict";
  try {
    let Meteor;
    module.link("meteor/meteor", {
      Meteor(v) {
        Meteor = v;
      }
    }, 0);
    let InputsCollection;
    module.link("/imports/api/inputs/inputs", {
      InputsCollection(v) {
        InputsCollection = v;
      }
    }, 1);
    if (__reifyWaitForDeps__()) (await __reifyWaitForDeps__())();
    Meteor.publish('inputs.all', function publishInputsAll() {
      return InputsCollection.find();
    });
    __reify_async_result__();
  } catch (_reifyError) {
    return __reify_async_result__(_reifyError);
  }
  __reify_async_result__()
}, {
  self: this,
  async: false
});
////////////////////////////////////////////////////////////////////////////////////////////

}},"webapp":{"index.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                        //
// imports/api/webapp/index.js                                                            //
//                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////
                                                                                          //
!module.wrapAsync(async function (module, __reifyWaitForDeps__, __reify_async_result__) {
  "use strict";
  try {
    let Meteor;
    module.link("meteor/meteor", {
      Meteor(v) {
        Meteor = v;
      }
    }, 0);
    let WebApp;
    module.link("meteor/webapp", {
      WebApp(v) {
        WebApp = v;
      }
    }, 1);
    let express;
    module.link("express", {
      default(v) {
        express = v;
      }
    }, 2);
    let multer;
    module.link("multer", {
      default(v) {
        multer = v;
      }
    }, 3);
    let fs;
    module.link("fs", {
      default(v) {
        fs = v;
      }
    }, 4);
    let path;
    module.link("path", {
      default(v) {
        path = v;
      }
    }, 5);
    let InputsCollection;
    module.link("/imports/api/inputs/inputs", {
      InputsCollection(v) {
        InputsCollection = v;
      }
    }, 6);
    if (__reifyWaitForDeps__()) (await __reifyWaitForDeps__())();
    const router = express.Router();
    const UPLOAD_DIR = path.join(Meteor.absolutePath, 'app', 'uploads');
    const upload = multer({
      dest: UPLOAD_DIR
    });
    router.use('/uploads', express.static(UPLOAD_DIR));

    // Ensure the upload directory exists
    if (!fs.existsSync(UPLOAD_DIR)) {
      fs.mkdirSync(UPLOAD_DIR, {
        recursive: true
      });
    }

    // Route to handle file uploads
    router.post("/inputs", upload.single('uploaded_image'), async function (req, res) {
      const {
        file
      } = req;
      const {
        image_type
      } = req.body;
      if (!file || !image_type) {
        return res.status(400).json({
          error: "Missing file or image_type"
        });
      }
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const filename = "".concat(path.basename(file.originalname), "_").concat(image_type, "_").concat(timestamp).concat(path.extname(file.originalname));
      const filePath = path.join(UPLOAD_DIR, filename);

      // Move the file to the desired location
      fs.renameSync(file.path, filePath);

      // Insert new file metadata into the collection
      await InputsCollection.insertAsync({
        filename,
        image_type,
        timestamp: new Date(),
        path: "/uploads/".concat(filename)
      });
      console.log("count", await InputsCollection.find({}).countAsync());
      res.json({
        message: "Image of type ".concat(image_type, " uploaded successfully")
      });
    });
    WebApp.connectHandlers.use(router);
    __reify_async_result__();
  } catch (_reifyError) {
    return __reify_async_result__(_reifyError);
  }
  __reify_async_result__()
}, {
  self: this,
  async: false
});
////////////////////////////////////////////////////////////////////////////////////////////

}}},"startup":{"both":{"index.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                        //
// imports/startup/both/index.js                                                          //
//                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////
                                                                                          //
!module.wrapAsync(async function (module, __reifyWaitForDeps__, __reify_async_result__) {
  "use strict";
  try {
    let InputsCollection;
    module.link("/imports/api/inputs/inputs", {
      InputsCollection(v) {
        InputsCollection = v;
      }
    }, 0);
    if (__reifyWaitForDeps__()) (await __reifyWaitForDeps__())();
    __reify_async_result__();
  } catch (_reifyError) {
    return __reify_async_result__(_reifyError);
  }
  __reify_async_result__()
}, {
  self: this,
  async: false
});
////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"index.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                        //
// imports/startup/server/index.js                                                        //
//                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////
                                                                                          //
!module.wrapAsync(async function (module, __reifyWaitForDeps__, __reify_async_result__) {
  "use strict";
  try {
    module.link("/imports/api/webapp");
    module.link("/imports/api/inputs/publications");
    if (__reifyWaitForDeps__()) (await __reifyWaitForDeps__())();
    __reify_async_result__();
  } catch (_reifyError) {
    return __reify_async_result__(_reifyError);
  }
  __reify_async_result__()
}, {
  self: this,
  async: false
});
////////////////////////////////////////////////////////////////////////////////////////////

}}}},"server":{"main.js":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                        //
// server/main.js                                                                         //
//                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////
                                                                                          //
!module.wrapAsync(async function (module, __reifyWaitForDeps__, __reify_async_result__) {
  "use strict";
  try {
    let Meteor;
    module.link("meteor/meteor", {
      Meteor(v) {
        Meteor = v;
      }
    }, 0);
    module.link("/imports/startup/both/");
    module.link("/imports/startup/server/");
    if (__reifyWaitForDeps__()) (await __reifyWaitForDeps__())();
    Meteor.startup(() => {
      // code to run on server at startup
    });
    __reify_async_result__();
  } catch (_reifyError) {
    return __reify_async_result__(_reifyError);
  }
  __reify_async_result__()
}, {
  self: this,
  async: false
});
////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".ts",
    ".d.ts",
    ".mjs",
    ".d.ts.map",
    ".svelte"
  ]
});


/* Exports */
return {
  require: require,
  eagerModulePaths: [
    "/server/main.js"
  ]
}});

//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvaW5wdXRzL2lucHV0cy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvaW5wdXRzL3B1YmxpY2F0aW9ucy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvd2ViYXBwL2luZGV4LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3N0YXJ0dXAvYm90aC9pbmRleC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zdGFydHVwL3NlcnZlci9pbmRleC5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4uanMiXSwibmFtZXMiOlsibW9kdWxlIiwiZXhwb3J0IiwiSW5wdXRzQ29sbGVjdGlvbiIsIk1vbmdvIiwibGluayIsInYiLCJfX3JlaWZ5V2FpdEZvckRlcHNfXyIsIkNvbGxlY3Rpb24iLCJfX3JlaWZ5X2FzeW5jX3Jlc3VsdF9fIiwiX3JlaWZ5RXJyb3IiLCJzZWxmIiwiYXN5bmMiLCJNZXRlb3IiLCJwdWJsaXNoIiwicHVibGlzaElucHV0c0FsbCIsImZpbmQiLCJXZWJBcHAiLCJleHByZXNzIiwiZGVmYXVsdCIsIm11bHRlciIsImZzIiwicGF0aCIsInJvdXRlciIsIlJvdXRlciIsIlVQTE9BRF9ESVIiLCJqb2luIiwiYWJzb2x1dGVQYXRoIiwidXBsb2FkIiwiZGVzdCIsInVzZSIsInN0YXRpYyIsImV4aXN0c1N5bmMiLCJta2RpclN5bmMiLCJyZWN1cnNpdmUiLCJwb3N0Iiwic2luZ2xlIiwicmVxIiwicmVzIiwiZmlsZSIsImltYWdlX3R5cGUiLCJib2R5Iiwic3RhdHVzIiwianNvbiIsImVycm9yIiwidGltZXN0YW1wIiwiRGF0ZSIsInRvSVNPU3RyaW5nIiwicmVwbGFjZSIsImZpbGVuYW1lIiwiY29uY2F0IiwiYmFzZW5hbWUiLCJvcmlnaW5hbG5hbWUiLCJleHRuYW1lIiwiZmlsZVBhdGgiLCJyZW5hbWVTeW5jIiwiaW5zZXJ0QXN5bmMiLCJjb25zb2xlIiwibG9nIiwiY291bnRBc3luYyIsIm1lc3NhZ2UiLCJjb25uZWN0SGFuZGxlcnMiLCJzdGFydHVwIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7SUFBQUEsTUFBTSxDQUFDQyxNQUFNLENBQUM7TUFBQ0MsZ0JBQWdCLEVBQUNBLENBQUEsS0FBSUE7SUFBZ0IsQ0FBQyxDQUFDO0lBQUMsSUFBSUMsS0FBSztJQUFDSCxNQUFNLENBQUNJLElBQUksQ0FBQyxjQUFjLEVBQUM7TUFBQ0QsS0FBS0EsQ0FBQ0UsQ0FBQyxFQUFDO1FBQUNGLEtBQUssR0FBQ0UsQ0FBQztNQUFBO0lBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztJQUFDLElBQUlDLG9CQUFvQixDQUFDLENBQUMsRUFBRSxDQUFDLE1BQU1BLG9CQUFvQixDQUFDLENBQUMsRUFBRSxDQUFDO0lBQ3hLLE1BQU1KLGdCQUFnQixHQUFHLElBQUlDLEtBQUssQ0FBQ0ksVUFBVSxDQUFDLFFBQVEsQ0FBQztJQUFDQyxzQkFBQTtFQUFBLFNBQUFDLFdBQUE7SUFBQSxPQUFBRCxzQkFBQSxDQUFBQyxXQUFBO0VBQUE7RUFBQUQsc0JBQUE7QUFBQTtFQUFBRSxJQUFBO0VBQUFDLEtBQUE7QUFBQSxHOzs7Ozs7Ozs7Ozs7OztJQ0QvRCxJQUFJQyxNQUFNO0lBQUNaLE1BQU0sQ0FBQ0ksSUFBSSxDQUFDLGVBQWUsRUFBQztNQUFDUSxNQUFNQSxDQUFDUCxDQUFDLEVBQUM7UUFBQ08sTUFBTSxHQUFDUCxDQUFDO01BQUE7SUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0lBQUMsSUFBSUgsZ0JBQWdCO0lBQUNGLE1BQU0sQ0FBQ0ksSUFBSSxDQUFDLDRCQUE0QixFQUFDO01BQUNGLGdCQUFnQkEsQ0FBQ0csQ0FBQyxFQUFDO1FBQUNILGdCQUFnQixHQUFDRyxDQUFDO01BQUE7SUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0lBQUMsSUFBSUMsb0JBQW9CLENBQUMsQ0FBQyxFQUFFLENBQUMsTUFBTUEsb0JBQW9CLENBQUMsQ0FBQyxFQUFFLENBQUM7SUFJdk9NLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDLFlBQVksRUFBRSxTQUFTQyxnQkFBZ0JBLENBQUEsRUFBRztNQUNyRCxPQUFPWixnQkFBZ0IsQ0FBQ2EsSUFBSSxDQUFDLENBQUM7SUFDbEMsQ0FBQyxDQUFDO0lBQUFQLHNCQUFBO0VBQUEsU0FBQUMsV0FBQTtJQUFBLE9BQUFELHNCQUFBLENBQUFDLFdBQUE7RUFBQTtFQUFBRCxzQkFBQTtBQUFBO0VBQUFFLElBQUE7RUFBQUMsS0FBQTtBQUFBLEc7Ozs7Ozs7Ozs7Ozs7O0lDTkYsSUFBSUMsTUFBTTtJQUFDWixNQUFNLENBQUNJLElBQUksQ0FBQyxlQUFlLEVBQUM7TUFBQ1EsTUFBTUEsQ0FBQ1AsQ0FBQyxFQUFDO1FBQUNPLE1BQU0sR0FBQ1AsQ0FBQztNQUFBO0lBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztJQUFDLElBQUlXLE1BQU07SUFBQ2hCLE1BQU0sQ0FBQ0ksSUFBSSxDQUFDLGVBQWUsRUFBQztNQUFDWSxNQUFNQSxDQUFDWCxDQUFDLEVBQUM7UUFBQ1csTUFBTSxHQUFDWCxDQUFDO01BQUE7SUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0lBQUMsSUFBSVksT0FBTztJQUFDakIsTUFBTSxDQUFDSSxJQUFJLENBQUMsU0FBUyxFQUFDO01BQUNjLE9BQU9BLENBQUNiLENBQUMsRUFBQztRQUFDWSxPQUFPLEdBQUNaLENBQUM7TUFBQTtJQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7SUFBQyxJQUFJYyxNQUFNO0lBQUNuQixNQUFNLENBQUNJLElBQUksQ0FBQyxRQUFRLEVBQUM7TUFBQ2MsT0FBT0EsQ0FBQ2IsQ0FBQyxFQUFDO1FBQUNjLE1BQU0sR0FBQ2QsQ0FBQztNQUFBO0lBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztJQUFDLElBQUllLEVBQUU7SUFBQ3BCLE1BQU0sQ0FBQ0ksSUFBSSxDQUFDLElBQUksRUFBQztNQUFDYyxPQUFPQSxDQUFDYixDQUFDLEVBQUM7UUFBQ2UsRUFBRSxHQUFDZixDQUFDO01BQUE7SUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0lBQUMsSUFBSWdCLElBQUk7SUFBQ3JCLE1BQU0sQ0FBQ0ksSUFBSSxDQUFDLE1BQU0sRUFBQztNQUFDYyxPQUFPQSxDQUFDYixDQUFDLEVBQUM7UUFBQ2dCLElBQUksR0FBQ2hCLENBQUM7TUFBQTtJQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7SUFBQyxJQUFJSCxnQkFBZ0I7SUFBQ0YsTUFBTSxDQUFDSSxJQUFJLENBQUMsNEJBQTRCLEVBQUM7TUFBQ0YsZ0JBQWdCQSxDQUFDRyxDQUFDLEVBQUM7UUFBQ0gsZ0JBQWdCLEdBQUNHLENBQUM7TUFBQTtJQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7SUFBQyxJQUFJQyxvQkFBb0IsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxNQUFNQSxvQkFBb0IsQ0FBQyxDQUFDLEVBQUUsQ0FBQztJQVloZ0IsTUFBTWdCLE1BQU0sR0FBR0wsT0FBTyxDQUFDTSxNQUFNLENBQUMsQ0FBQztJQUMvQixNQUFNQyxVQUFVLEdBQUdILElBQUksQ0FBQ0ksSUFBSSxDQUFDYixNQUFNLENBQUNjLFlBQVksRUFBRSxLQUFLLEVBQUUsU0FBUyxDQUFDO0lBQ25FLE1BQU1DLE1BQU0sR0FBR1IsTUFBTSxDQUFDO01BQUVTLElBQUksRUFBRUo7SUFBVyxDQUFDLENBQUM7SUFDM0NGLE1BQU0sQ0FBQ08sR0FBRyxDQUFDLFVBQVUsRUFBRVosT0FBTyxDQUFDYSxNQUFNLENBQUNOLFVBQVUsQ0FBQyxDQUFDOztJQUVsRDtJQUNBLElBQUksQ0FBQ0osRUFBRSxDQUFDVyxVQUFVLENBQUNQLFVBQVUsQ0FBQyxFQUFFO01BQzVCSixFQUFFLENBQUNZLFNBQVMsQ0FBQ1IsVUFBVSxFQUFFO1FBQUVTLFNBQVMsRUFBRTtNQUFLLENBQUMsQ0FBQztJQUNqRDs7SUFFQTtJQUNBWCxNQUFNLENBQUNZLElBQUksQ0FBQyxTQUFTLEVBQUVQLE1BQU0sQ0FBQ1EsTUFBTSxDQUFDLGdCQUFnQixDQUFDLEVBQUUsZ0JBQWdCQyxHQUFHLEVBQUVDLEdBQUcsRUFBRTtNQUM5RSxNQUFNO1FBQUVDO01BQUssQ0FBQyxHQUFHRixHQUFHO01BQ3BCLE1BQU07UUFBRUc7TUFBVyxDQUFDLEdBQUdILEdBQUcsQ0FBQ0ksSUFBSTtNQUUvQixJQUFJLENBQUNGLElBQUksSUFBSSxDQUFDQyxVQUFVLEVBQUU7UUFDdEIsT0FBT0YsR0FBRyxDQUFDSSxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUNDLElBQUksQ0FBQztVQUFFQyxLQUFLLEVBQUU7UUFBNkIsQ0FBQyxDQUFDO01BQ3hFO01BRUEsTUFBTUMsU0FBUyxHQUFHLElBQUlDLElBQUksQ0FBQyxDQUFDLENBQUNDLFdBQVcsQ0FBQyxDQUFDLENBQUNDLE9BQU8sQ0FBQyxPQUFPLEVBQUUsR0FBRyxDQUFDO01BRWhFLE1BQU1DLFFBQVEsTUFBQUMsTUFBQSxDQUFNNUIsSUFBSSxDQUFDNkIsUUFBUSxDQUFDWixJQUFJLENBQUNhLFlBQVksQ0FBQyxPQUFBRixNQUFBLENBQUlWLFVBQVUsT0FBQVUsTUFBQSxDQUFJTCxTQUFTLEVBQUFLLE1BQUEsQ0FBRzVCLElBQUksQ0FBQytCLE9BQU8sQ0FBQ2QsSUFBSSxDQUFDYSxZQUFZLENBQUMsQ0FBRTtNQUNuSCxNQUFNRSxRQUFRLEdBQUdoQyxJQUFJLENBQUNJLElBQUksQ0FBQ0QsVUFBVSxFQUFFd0IsUUFBUSxDQUFDOztNQUVoRDtNQUNBNUIsRUFBRSxDQUFDa0MsVUFBVSxDQUFDaEIsSUFBSSxDQUFDakIsSUFBSSxFQUFFZ0MsUUFBUSxDQUFDOztNQUVsQztNQUNBLE1BQU1uRCxnQkFBZ0IsQ0FBQ3FELFdBQVcsQ0FBQztRQUMvQlAsUUFBUTtRQUNSVCxVQUFVO1FBQ1ZLLFNBQVMsRUFBRSxJQUFJQyxJQUFJLENBQUMsQ0FBQztRQUNyQnhCLElBQUksY0FBQTRCLE1BQUEsQ0FBY0QsUUFBUTtNQUM5QixDQUFDLENBQUM7TUFFRlEsT0FBTyxDQUFDQyxHQUFHLENBQUMsT0FBTyxFQUFFLE1BQU12RCxnQkFBZ0IsQ0FBQ2EsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMyQyxVQUFVLENBQUMsQ0FBQyxDQUFDO01BRWxFckIsR0FBRyxDQUFDSyxJQUFJLENBQUM7UUFBRWlCLE9BQU8sbUJBQUFWLE1BQUEsQ0FBbUJWLFVBQVU7TUFBeUIsQ0FBQyxDQUFDO0lBQzlFLENBQUMsQ0FBQztJQUdGdkIsTUFBTSxDQUFDNEMsZUFBZSxDQUFDL0IsR0FBRyxDQUFDUCxNQUFNLENBQUM7SUFBQ2Qsc0JBQUE7RUFBQSxTQUFBQyxXQUFBO0lBQUEsT0FBQUQsc0JBQUEsQ0FBQUMsV0FBQTtFQUFBO0VBQUFELHNCQUFBO0FBQUE7RUFBQUUsSUFBQTtFQUFBQyxLQUFBO0FBQUEsRzs7Ozs7Ozs7Ozs7Ozs7SUNyRG5DLElBQUlULGdCQUFnQjtJQUFDRixNQUFNLENBQUNJLElBQUksQ0FBQyw0QkFBNEIsRUFBQztNQUFDRixnQkFBZ0JBLENBQUNHLENBQUMsRUFBQztRQUFDSCxnQkFBZ0IsR0FBQ0csQ0FBQztNQUFBO0lBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztJQUFDLElBQUlDLG9CQUFvQixDQUFDLENBQUMsRUFBRSxDQUFDLE1BQU1BLG9CQUFvQixDQUFDLENBQUMsRUFBRSxDQUFDO0lBQUNFLHNCQUFBO0VBQUEsU0FBQUMsV0FBQTtJQUFBLE9BQUFELHNCQUFBLENBQUFDLFdBQUE7RUFBQTtFQUFBRCxzQkFBQTtBQUFBO0VBQUFFLElBQUE7RUFBQUMsS0FBQTtBQUFBLEc7Ozs7Ozs7Ozs7Ozs7O0lDQXhLWCxNQUFNLENBQUNJLElBQUksQ0FBQyxxQkFBcUIsQ0FBQztJQUFDSixNQUFNLENBQUNJLElBQUksQ0FBQyxrQ0FBa0MsQ0FBQztJQUFDLElBQUlFLG9CQUFvQixDQUFDLENBQUMsRUFBRSxDQUFDLE1BQU1BLG9CQUFvQixDQUFDLENBQUMsRUFBRSxDQUFDO0lBQUNFLHNCQUFBO0VBQUEsU0FBQUMsV0FBQTtJQUFBLE9BQUFELHNCQUFBLENBQUFDLFdBQUE7RUFBQTtFQUFBRCxzQkFBQTtBQUFBO0VBQUFFLElBQUE7RUFBQUMsS0FBQTtBQUFBLEc7Ozs7Ozs7Ozs7Ozs7O0lDQWhKLElBQUlDLE1BQU07SUFBQ1osTUFBTSxDQUFDSSxJQUFJLENBQUMsZUFBZSxFQUFDO01BQUNRLE1BQU1BLENBQUNQLENBQUMsRUFBQztRQUFDTyxNQUFNLEdBQUNQLENBQUM7TUFBQTtJQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7SUFBQ0wsTUFBTSxDQUFDSSxJQUFJLENBQUMsd0JBQXdCLENBQUM7SUFBQ0osTUFBTSxDQUFDSSxJQUFJLENBQUMsMEJBQTBCLENBQUM7SUFBQyxJQUFJRSxvQkFBb0IsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxNQUFNQSxvQkFBb0IsQ0FBQyxDQUFDLEVBQUUsQ0FBQztJQUsxTU0sTUFBTSxDQUFDaUQsT0FBTyxDQUFDLE1BQU07TUFDbkI7SUFBQSxDQUVELENBQUM7SUFBQ3JELHNCQUFBO0VBQUEsU0FBQUMsV0FBQTtJQUFBLE9BQUFELHNCQUFBLENBQUFDLFdBQUE7RUFBQTtFQUFBRCxzQkFBQTtBQUFBO0VBQUFFLElBQUE7RUFBQUMsS0FBQTtBQUFBLEciLCJmaWxlIjoiL2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmV4cG9ydCBjb25zdCBJbnB1dHNDb2xsZWN0aW9uID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oXCJpbnB1dHNcIik7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCB7SW5wdXRzQ29sbGVjdGlvbn0gZnJvbSBcIi9pbXBvcnRzL2FwaS9pbnB1dHMvaW5wdXRzXCJcblxuXG5NZXRlb3IucHVibGlzaCgnaW5wdXRzLmFsbCcsIGZ1bmN0aW9uIHB1Ymxpc2hJbnB1dHNBbGwoKSB7XG4gICAgcmV0dXJuIElucHV0c0NvbGxlY3Rpb24uZmluZCgpO1xufSkiLCJcbmltcG9ydCB7IE1ldGVvciB9IGZyb20gXCJtZXRlb3IvbWV0ZW9yXCI7XG5pbXBvcnQgeyBXZWJBcHAgfSBmcm9tIFwibWV0ZW9yL3dlYmFwcFwiO1xuXG5pbXBvcnQgZXhwcmVzcyBmcm9tIFwiZXhwcmVzc1wiO1xuaW1wb3J0IG11bHRlciBmcm9tIFwibXVsdGVyXCI7XG5cbmltcG9ydCBmcyBmcm9tIFwiZnNcIjtcbmltcG9ydCBwYXRoIGZyb20gXCJwYXRoXCI7XG5cbmltcG9ydCB7IElucHV0c0NvbGxlY3Rpb24gfSBmcm9tIFwiL2ltcG9ydHMvYXBpL2lucHV0cy9pbnB1dHNcIjtcblxuY29uc3Qgcm91dGVyID0gZXhwcmVzcy5Sb3V0ZXIoKTtcbmNvbnN0IFVQTE9BRF9ESVIgPSBwYXRoLmpvaW4oTWV0ZW9yLmFic29sdXRlUGF0aCwgJ2FwcCcsICd1cGxvYWRzJyk7XG5jb25zdCB1cGxvYWQgPSBtdWx0ZXIoeyBkZXN0OiBVUExPQURfRElSIH0pO1xucm91dGVyLnVzZSgnL3VwbG9hZHMnLCBleHByZXNzLnN0YXRpYyhVUExPQURfRElSKSk7XG5cbi8vIEVuc3VyZSB0aGUgdXBsb2FkIGRpcmVjdG9yeSBleGlzdHNcbmlmICghZnMuZXhpc3RzU3luYyhVUExPQURfRElSKSkge1xuICAgIGZzLm1rZGlyU3luYyhVUExPQURfRElSLCB7IHJlY3Vyc2l2ZTogdHJ1ZSB9KTtcbn1cblxuLy8gUm91dGUgdG8gaGFuZGxlIGZpbGUgdXBsb2Fkc1xucm91dGVyLnBvc3QoXCIvaW5wdXRzXCIsIHVwbG9hZC5zaW5nbGUoJ3VwbG9hZGVkX2ltYWdlJyksIGFzeW5jIGZ1bmN0aW9uIChyZXEsIHJlcykge1xuICAgIGNvbnN0IHsgZmlsZSB9ID0gcmVxO1xuICAgIGNvbnN0IHsgaW1hZ2VfdHlwZSB9ID0gcmVxLmJvZHk7XG5cbiAgICBpZiAoIWZpbGUgfHwgIWltYWdlX3R5cGUpIHtcbiAgICAgICAgcmV0dXJuIHJlcy5zdGF0dXMoNDAwKS5qc29uKHsgZXJyb3I6IFwiTWlzc2luZyBmaWxlIG9yIGltYWdlX3R5cGVcIiB9KTtcbiAgICB9XG5cbiAgICBjb25zdCB0aW1lc3RhbXAgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkucmVwbGFjZSgvWzouXS9nLCAnLScpO1xuICAgIFxuICAgIGNvbnN0IGZpbGVuYW1lID0gYCR7cGF0aC5iYXNlbmFtZShmaWxlLm9yaWdpbmFsbmFtZSl9XyR7aW1hZ2VfdHlwZX1fJHt0aW1lc3RhbXB9JHtwYXRoLmV4dG5hbWUoZmlsZS5vcmlnaW5hbG5hbWUpfWA7XG4gICAgY29uc3QgZmlsZVBhdGggPSBwYXRoLmpvaW4oVVBMT0FEX0RJUiwgZmlsZW5hbWUpO1xuXG4gICAgLy8gTW92ZSB0aGUgZmlsZSB0byB0aGUgZGVzaXJlZCBsb2NhdGlvblxuICAgIGZzLnJlbmFtZVN5bmMoZmlsZS5wYXRoLCBmaWxlUGF0aCk7XG5cbiAgICAvLyBJbnNlcnQgbmV3IGZpbGUgbWV0YWRhdGEgaW50byB0aGUgY29sbGVjdGlvblxuICAgIGF3YWl0IElucHV0c0NvbGxlY3Rpb24uaW5zZXJ0QXN5bmMoe1xuICAgICAgICBmaWxlbmFtZSxcbiAgICAgICAgaW1hZ2VfdHlwZSxcbiAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLFxuICAgICAgICBwYXRoOiBgL3VwbG9hZHMvJHtmaWxlbmFtZX1gXG4gICAgfSk7XG5cbiAgICBjb25zb2xlLmxvZyhcImNvdW50XCIsIGF3YWl0IElucHV0c0NvbGxlY3Rpb24uZmluZCh7fSkuY291bnRBc3luYygpKVxuXG4gICAgcmVzLmpzb24oeyBtZXNzYWdlOiBgSW1hZ2Ugb2YgdHlwZSAke2ltYWdlX3R5cGV9IHVwbG9hZGVkIHN1Y2Nlc3NmdWxseWAgfSk7XG59KTtcblxuXG5XZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZShyb3V0ZXIpOyIsImltcG9ydCB7IElucHV0c0NvbGxlY3Rpb24gfSBmcm9tICcvaW1wb3J0cy9hcGkvaW5wdXRzL2lucHV0cyc7XG5cbi8vIGltcG9ydCBcIi9pbXBvcnRzL2FwaS9pbnB1dHMvcHVibGljYXRpb25zLmpzXCIiLCJpbXBvcnQgJy9pbXBvcnRzL2FwaS93ZWJhcHAnXG5cbmltcG9ydCBcIi9pbXBvcnRzL2FwaS9pbnB1dHMvcHVibGljYXRpb25zXCIiLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcblxuaW1wb3J0ICcvaW1wb3J0cy9zdGFydHVwL2JvdGgvJztcbmltcG9ydCAnL2ltcG9ydHMvc3RhcnR1cC9zZXJ2ZXIvJztcblxuTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xuICAvLyBjb2RlIHRvIHJ1biBvbiBzZXJ2ZXIgYXQgc3RhcnR1cFxuXG59KTtcbiJdfQ==
